# Católica FC — A Reconstrução (Godot)

Migração nativa do jogo original em HTML/React (`CatolicaFC.html`) para um
projeto Godot Engine com GDScript. Este README é atualizado a cada etapa da
migração — a seção **"Progresso e pendências"** no final é a fonte da
verdade sobre o que já funciona de verdade e o que ainda falta.

## Como executar e jogar

**Requisitos:** Godot 4.4 ou superior (testado na 4.4.1 e usado na 4.7.2), versão padrão (sem C#). Download: https://godotengine.org/download

**Executar pelo editor**
1. Clone ou baixe este repositório e abra o Godot.
2. Em *Importar*, selecione o arquivo `project.godot` e clique em *Importar e editar*.
3. Aguarde a importação dos recursos e aperte **F5** (cena principal `scenes/Main.tscn`).

**Executável e versão web:** use *Projeto → Exportar* (veja as seções 4 a 6). O link do executável da entrega está em `docs/ENTREGA.md`.

**Como jogar**
- Menu inicial: **Jogar partida** (carreira 11x11 ou amistoso FUT7), Professor (sala de aula) e Sair.
- Na carreira, escolha o destino no mapa: Treino, Sede, Estádio, Mercado, Federação, Bar. Antes de cada partida, resolva o Desafio do Diretor (opcional) e ajuste tática e escalação.
- Controles da partida: mover **WASD/setas**; passe **J/Z**; chute **K/X** (segure para dar força); passe alto **I/C**; correr **Shift/Espaço**; trocar jogador **L/U**; pausa **P/Esc**; ajuda **H/F1**. Também funciona com controle e, no celular, com joystick e botões na tela.
- Bolas paradas (pênalti, falta, escanteio): setas movem a mira; segure CHUTE para a força e solte.

**Testes:** `godot --headless --path . --import` (uma vez) e depois `godot --headless --path . --fixed-fps 60 res://tests/teste_fase7.tscn` (troque pelo teste desejado).

**Documentação:** `docs/GDD.md` (GDD final), `docs/ATUALIZACAO_GERAL.md` (histórico técnico), `docs/ENTREGA.md` (checklist de entrega).

## Estado atual (Fases 1–7) — leia primeiro

Os itens "pendente" da seção 9 abaixo são históricos; o estado atual é este:

- **Modos:** 11x11 é o modo principal (carreira); FUT7 é um modo divertido no Amistoso, em que se escolhe o time.
- **Carreira:** Universitário (28 rodadas), InterLajes e Copa dos Gigantes, com finanças, estádio, mercado, treino, tática, scouting, disciplina e lesões.
- **Partida jogável:** campo grande com câmera que segue a bola, pênaltis, faltas e escanteios jogáveis (também no toque).
- **Educação (matemática):** Desafio do Diretor com 5 áreas × 3 níveis, árvore de competências, prancheta, calculadora, coletiva de imprensa e metas da diretoria; modo sala de aula com código da turma e relatório CSV/JSON para o professor.
- **Fase 7:** categoria de base e empréstimos, rival e clássico, metas pessoais, clima (sol/chuva/calor) e 14 conquistas.
- **Testes:** `bash` com as suítes em `tests/` (`godot --headless --path . res://tests/teste_faseN.tscn`); `teste_etapa7` abre 23 telas em 5 resoluções. Rodar `godot --headless --path . --import` antes ao adicionar scripts com `class_name`.
- **Validação:** testado na Godot 4.4.1; ainda falta conferir na 4.7.2 e em celular real.
- Histórico detalhado: `docs/ATUALIZACAO_GERAL.md`; plano: `docs/GDD_RECONSTRUCAO.md`.

## 1. Versão do Godot

Use o **Godot Engine 4.7.x estável** (a versão usada para depurar este
projeto foi a 4.7.2.stable — funciona igual em qualquer 4.2+/4.3.x/4.7.x,
já que o projeto não usa nenhum recurso exclusivo de versões
experimentais/beta). Baixe em https://godotengine.org/download — não é
necessária a versão com suporte a C#, pois o projeto é 100% GDScript.

## 2. Como importar o projeto

1. Abra o Godot Engine.
2. Na tela de projetos, clique em **Importar**.
3. Selecione o arquivo `project.godot` desta pasta.
4. Clique em **Importar e Editar**.

## 3. Como executar pelo editor

1. Com o projeto aberto, pressione **F5** (ou o botão de play no canto
   superior direito).
2. A cena inicial (`scenes/Main.tscn`) já está configurada como cena
   principal em `project.godot` (`run/main_scene`), então basta rodar.
3. Para rodar só uma cena específica durante o desenvolvimento, abra-a e
   use **F6**.

## 4. Como exportar para Windows

1. Vá em **Projeto → Exportar…**.
2. Clique em **Adicionar…** e escolha **Windows Desktop**.
3. O Godot pede os *templates de exportação* na primeira vez — se pedir,
   vá em **Editor → Gerenciar Templates de Exportação** e baixe a versão
   correspondente (precisa de internet nessa etapa).
4. Defina o caminho de saída (ex.: `export/windows/CatolicaFC.exe`).
5. Clique em **Exportar Projeto**.

## 5. Como gerar uma versão Android

1. Instale o **Android Studio** (para o SDK/NDK) e o **Java JDK 17+**.
2. No Godot, vá em **Editor → Gerenciar Templates de Exportação** e baixe os
   templates da mesma versão do editor.
3. Em **Editor → Configurações do Editor → Exportação → Android**, aponte
   os caminhos do Android SDK e do `debug.keystore` (o Godot consegue gerar
   um automaticamente pelo botão correspondente nessa tela).
4. Vá em **Projeto → Exportar…**, adicione o preset **Android**.
5. Confirme `orientação = retrato` (já configurado em `project.godot`) e o
   nome do pacote (ex.: `com.suaempresa.catolicafc`).
6. Clique em **Exportar Projeto** para gerar o `.apk` (ou `.aab` para a
   Play Store).
7. **Botão físico Voltar**: já está tratado em `scripts/Main.gd` via
   `NOTIFICATION_WM_GO_BACK_REQUEST` + `run/quit_on_go_back=false` no
   `project.godot` — não precisa de nenhuma configuração extra no Android.

## 6. Como exportar para navegador (Web)

1. Baixe os templates de exportação (mesmo passo do Android/Windows).
2. Em **Projeto → Exportar…**, adicione o preset **Web**.
3. Exporte para uma pasta (gera `index.html` + arquivos `.wasm`/`.pck`).
4. Para testar localmente, sirva a pasta com um servidor HTTP simples (abrir
   o `index.html` direto do disco costuma falhar por causa de CORS):
   ```
   python3 -m http.server 8000
   ```
   e acesse `http://localhost:8000` no navegador.
5. Para publicar de verdade, hospede a pasta exportada em qualquer servidor
   estático (GitHub Pages, Netlify, servidor próprio etc.).

## 7. O que falta para exportar para iOS

Exportar para iOS exige, além do próprio Godot:

- Um **Mac** com **Xcode** instalado (obrigatório da Apple — não dá para
  gerar o build final em Windows/Linux).
- Uma conta de desenvolvedor Apple (paga, US$ 99/ano) para assinar o app e
  publicar na App Store.
- Os **templates de exportação iOS** do Godot baixados no editor.
- Configurar o preset **iOS** em **Projeto → Exportar…**, com o *Bundle
  Identifier*, ícones e *provisioning profile* corretos.
- Gerar o projeto Xcode pelo Godot e, a partir dele, arquivar e enviar via
  Xcode/Transporter, como qualquer app iOS nativo.

Nada no código deste projeto impede a exportação para iOS (não há
dependências específicas de Android/Web) — falta apenas o ambiente Apple
para gerar e assinar o build.

## 8. Estrutura de pastas

```
CatolicaFC/
  project.godot
  README.md
  scenes/            # Cenas .tscn (uma por tela)
  scripts/           # Scripts .gd das cenas
    autoload/        # GameData, GameState, MatchEngine, SceneManager, SaveSystem
  data/              # Dados extraídos do HTML original, em JSON
  ui/                # Tema visual (tema_catolica.tres)
  assets/            # Ícones e imagens (ver nota abaixo)
  audio/             # (reservado para sons/músicas futuras)
```

### Nota sobre assets visuais

O HTML original desenha o escudo, os personagens e os campos com SVG/CSS
gerados em tempo real pelo React. Nesta etapa, as telas do Godot usam
**controles nativos estilizados** (Label, PanelContainer, Button com
StyleBoxFlat) na paleta oficial do jogo, em vez de tentar recriar pixel a
pixel os SVGs — é a forma correta e nativa de reproduzir uma UI cartoon no
Godot, mas ainda não há um "boneco" ilustrado como no HTML. Converter os
personagens/escudo em texturas (`.svg`/`.png`) ou recursos vetoriais
(`Polygon2D`/`Line2D`) do Godot é um passo posterior claramente pendente
(ver seção 9).

## 9. Progresso e pendências

### ✅ Funcionando nesta etapa
- Estrutura completa do projeto (autoloads, pastas, tema)
- Extração fiel de dados do HTML: clubes (Universitário + Copa), elenco
  inicial (17 atletas), economia, fórmulas de balanceamento, formações,
  táticas
- Fórmula de força efetiva (`calcular_forca_detalhada`) e de probabilidade
  do Universitário (`calcular_probabilidades_universitario`), portadas
  linha a linha do HTML
- Tela inicial com Novo Jogo / Continuar / Apagar progresso (com
  confirmação)
- Painel do clube (caixa, temporada, rodada — atualiza sozinho)
- Elenco e Escalação: 17 jogadores reais, troca de formação (5 formações),
  escalar/banco respeitando exatamente as categorias de posição do jogo
  original (`POSICOES_CATEGORIAS`)
- Salvamento local em `user://savegame.json`
- Botão físico Voltar do Android tratado corretamente

### ⏳ Pendente para as próximas etapas (não implementado ainda)
- Mercado de jogadores (catálogo completo, compra/venda)
- Estádio e suas melhorias
- Preparação da equipe (cartas de preparação) e escolha de tática na prática
- Partida animada com botão de pular e tela de resultado
- Ficha do jogador e aplicação de itens
- Calendário, classificação e artilharia
- Eventos aleatórios (incluindo a exclusão obrigatória de EDICARSIA,
  MAURICIO, EDSON VAZ e MANSEIRA, e a probabilidade especial do DINHO — já
  extraídas mas ainda não ligadas a uma tela)
- InterLajes (ida e volta) com disputa de pênaltis e incentivo em dinheiro
  fictício
- Copa dos Gigantes e sua fórmula de probabilidade própria (logística)
- Progressão entre temporadas (reinício de níveis sazonais + permanência de
  elenco/itens/estádio)
- Desafio periódico de pênalti com moeda fictícia
- Conversão dos personagens/escudo em assets visuais reais

## Divergência encontrada entre o pedido e o HTML

O pedido menciona "24 rodadas", mas o arquivo `CatolicaFC.html` analisado
usa **28 rodadas** (11 do Campeonato Universitário + 6 do InterLajes + 11
da Copa dos Gigantes — ver `TOTAL_RODADAS` e `RODADA_UNIVERSITARIO_FIM` no
código-fonte). Como o HTML é a fonte oficial pela regra do próprio pedido,
o projeto Godot usa 28 rodadas. Isso está registrado também em
`data/regras_especiais.json`.


## Créditos

Equipe do projeto: Erik Pinheiro, Wesley Reis e Daniel Trindade.
