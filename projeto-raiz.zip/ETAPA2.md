# Etapa 2 — Partida jogável ligada ao jogo de gestão

Na tela **Tática** agora há dois botões:
- **⚽ JOGAR PARTIDA** — abre a partida em tempo real (tela vira paisagem 1280×720).
- **SIMULAR PARTIDA** — o sorteio por probabilidades de sempre (inalterado).

## O que a partida recebe do clube
| Do jogo de gestão | Na partida |
|---|---|
| 11 titulares dos slots (GOL, 4 DEF, 3 MEI, 3 ATA) | nomes e camisas dos jogadores da casa |
| overall | velocidade, chute, passe, desarme, drible, goleiro (76 ≈ 0,84; cada 4 pontos ≈ 0,016) |
| energia | até −8% nos atributos quando exausto |
| moral | ajuste pequeno (±0,03) |
| tática escolhida | posicionamento/pressão do time da casa |
| força e cores do adversário | atributos e uniforme do adversário |

Posição influencia: ATA +chute, MEI +passe, DEF +desarme, goleiro +reflexo.

## O que volta para o jogo de gestão
O placar jogado vira o **resultado oficial** (`GameState.simular_partida({proprio, adversario})`):
tipo vitória/empate/derrota, bilheteria, patrocínio, prêmio, salários, manutenção, viagem,
desgaste/moral dos titulares, tabela do Universitário e sequência de forma — tudo pela mesma
lógica do SIMULAR. Depois vai para a tela de Resultado normalmente.

## Arquivos novos / alterados
- novo `scripts/PartidaJogo.gd`, `scenes/PartidaJogo.tscn` — ponte: monta a partida, gira a tela, devolve o placar
- novo `scripts/partida/*` — a partida da Etapa 1 (com `escalacao_casa`, `cor_fora_*`, `modo_carreira`)
- `GameState.gd` — `simular_partida(placar_jogado = null)` e `dados_partida_jogavel()`
- `SceneManager.gd` — cena `partida` e `bloqueio_voltar` (Voltar/Esc não sai no meio do jogo)
- `Tatica.gd` — botão JOGAR PARTIDA
- **correção** `GameState._gerar_elenco_inicial`: titulares não tinham `salario` e o SIMULAR quebrava
  (`Invalid access ... 'salario'`). Agora salário = overall × 30, a mesma regra do HTML.

## Testes
`godot --headless --path . --import` e depois
`godot --headless --path . --script res://tests/teste_etapa2.gd` (fluxo completo, 0 falhas) e
`tests/balance.gd` (placares por força do adversário).

## Limites conhecidos
- Toque, giro de tela e botão Voltar do Android não foram testados em aparelho real.
- Partidas IA×IA saem com ~7–8 gols por time; ajustar a taxa de finalização da IA se quiser placares menores.
- Sem faltas, cartões, impedimento ou substituições em campo.

# Etapa 3 — Hub 2D do clube
Depois do menu inicial (e do Resultado) o jogador cai no **Hub**: anda com WASD/setas ou joystick de toque
(arrastar na parte esquerda da tela) e entra nos prédios com o botão que aparece (ou E/Espaço/Enter):
- Secretaria → Painel (caixa, salvar)
- Centro de Treino → Elenco/escalação
- Mercado → Mercado
- Estádio → fluxo da rodada (desafio → preparação → elenco → tática → JOGAR/SIMULAR)
- 3 NPCs (Presidente, Olheiro, Treinador) com dicas. Arquivos: `scripts/Hub.gd`, `scenes/Hub.tscn`.

# Etapa 5 — Polimento da partida
- Torcida animada (`scripts/partida/Torcida.gd`): balança sempre, pula e levanta bandeiras (cores dos dois times) no gol.
- Confete caindo e tremor de câmera a cada gol.
- Ainda pendente: teste em aparelho (toque, giro de tela, Voltar do Android) — só é possível no seu celular.

# Etapa 6 — Regras da partida e competições completas
**Partida jogável:** faltas (carrinho que falha e desarme da IA), cartões amarelo/vermelho (2º amarelo = vermelho,
jogador expulso sai de campo), pênalti (falta na área, cobrança resolvida por chute × goleiro), 3 substituições
(tecla U / botão TROCA, na pausa ou intervalo; entra o melhor reserva da posição) e substituição automática do
adversário aos 60' e 75'. HUD mostra faltas, cartões, trocas e pênaltis. Os gols da partida alimentam a artilharia.

**Competições (mesmas regras do jogo web):** Universitário (rodadas 1–11, top 8 vai ao InterLajes e paga título/vice/3º) →
InterLajes (12–17: quartas, semifinal e final em ida e volta; empate no agregado vai a pênaltis ponderados pela força;
paga 75 mil/125 mil por avanço e 500 mil pelo título) → Copa dos Gigantes (18–28: Católica + 11 profissionais em pontos
corridos; cota de 20 mil por jogo e 1,5 mi/450 mil/250 mil para 1º/2º/3º). Eliminação encerra a temporada e a Copa é simulada.
Fim de temporada → resumo e **Nova temporada** (reset de tabelas e calendário, energia 100, apoio de 300 mil se o caixa < 150 mil).

**Telas novas:** Federação (tabela do Universitário, chave do InterLajes, tabela da Copa, artilharia, troféus),
Obras do Estádio (arquibancada, iluminação, lanchonete, centro de treinamento: 3 níveis cada, com custo e manutenção
iguais ao jogo web e efeito real na bilheteria/torcida/energia) e Fim de Temporada. Save/load inclui tudo.

**Testes:** `tests/teste_temporada.gd` (temporada campeã dos 3 torneios, 12 temporadas ruins, save/load, estádio) e
`tests/teste_regras.gd` (faltas, cartões, expulsão, substituições).

**Ainda não migrado do jogo web:** eventos aleatórios, itens/produtos de loja, peneira, disputa de pênaltis interativa
no InterLajes (hoje é sorteada), rivalidades e metas da diretoria.

## Reforma visual (estilo arcade pixel-art)
- Jogadores em sprites pixel-art gerados em runtime a partir de `assets/jogadores/labels.png` (recolorido por time, pele e cabelo); poses: parado, corrida, chute, carrinho, festa.
- Fonte pixel própria (`PixelUI.gd` e `assets/fonte/pixel2.fnt`), gramado quadriculado, HUD inferior com placar, radar, faltas/cartões/trocas.
- Tela inicial noturna, chave do InterLajes desenhada, títulos e botões restilizados em todas as telas de gestão, Hub com rótulos pixel e botão ancorado.
- Mecânicas e fórmulas inalteradas; os 3 testes (etapa2, temporada, regras) passam.
- Ainda não migrado do jogo web: eventos aleatórios, itens, peneira, metas da diretoria, rivalidades.

## Partida arcade 480x270 (visual novo, jogo integrado)
- Campo horizontal 480x270 em perspectiva leve (`Pitch.project(x, y)`), estádio com torcida animada, gols, jogadores chibi 24x28 recoloridos por clube, bola com sombra, HUD pixel e efeitos (confete, flash, tremor). Arte gerada por código em `scripts/arte/` (rodar `python3 campo_gen.py`, `estadio_gen.py`, `jogador_gen.py`, `bola_gen.py`; saída em `assets/gerado/`).
- A lógica (IA, faltas, cartões, pênalti, trocas) não mudou; `PartidaVis` só lê o estado e desenha.
- A câmera agora mostra o campo inteiro (sem seguir a bola). A janela abre em 1440x810 no PC; no celular usa paisagem com barras laterais para manter a proporção.

### Comandos
| Ação | Teclado | Controle | Celular |
|---|---|---|---|
| Mover | WASD / setas | analógico | joystick |
| Passe rasteiro | J / Z | A | PASSE |
| Passe alto | I / C | X | ALTO |
| Chute (segure = força) | K / X | B | CHUTE |
| Carrinho (sem a bola) | K | B | CARRINHO |
| Correr | Shift / Espaço | RB | CORRER |
| Trocar jogador (pausado/intervalo: substituir) | L / U (ou J sem a bola) | Y | TROCA |
| Pausa | P / Esc | Start | II |
| Ajuda | H / F1 | LB | — |

## Polimento visual (sprites v2, animações, HUD, tela cheia)
- Sprites: `scripts/arte/jogador_gen_v2.py` gera `assets/gerado/jogadores_v2_e0..5.png` (6 cortes de cabelo) + `jogadores_v2.json` (37 animações, fps, loop, âncoras do número). Cores por shader `jogador_cores.gdshader`.
- Animações pontuais (passe, chute, recepção, desarme, bloqueio, defesa, reposição) são deduzidas em `PartidaVis._eventos()` a partir do estado da lógica; a lógica não foi alterada.
- HUD: posse de bola, cartões e trocas por time, lamento dos adversários após gol.
- Tela cheia: F11 / Alt+Enter; partida entra em tela cheia no PC; na web, o 1º toque na partida pede tela cheia e trava a horizontal.
- Testes: `tests/teste_regras.gd`, `teste_temporada.gd`, `teste_etapa2.gd`, `teste_final.gd` (3 partidas completas), `teste_rapido.gd` (fumaça p/ Godot 4.7.2), `diag_perf.gd`.

## FUT7 e IA (nov/2026)
- Partida 7x7 (formação 2-3-1, `Partida.FORMACAO`). Dos 11 da escalação do clube entram os 7 melhores por posição; os demais vão para o banco.
- IA: pressão de 1 jogador + cobertura do 2º, marcação individual pelo lado do gol, apoio/desmarque de quem ataca (escolhe o espaço mais livre), passe com checagem da linha, reação/pressão por nível do adversário (`nivel_ia`).
- Goleiro: não é controlável; repõe para companheiro livre; defesas difíceis podem ser espalmadas (rebote/escanteio).
- Testes: `tests/balance_fut7.gd` (8 partidas completas), `teste_melhorias.gd`.
