shader_type canvas_item;
// Troca de paleta por etiquetas: o canal R da folha guarda o "papel" de cada pixel
// (1 pele, 2 cabelo, 3 camisa, 4 calção, 5 meia, 6 chuteira, 7 luva, 8 olho, 11 manga, 99 contorno);
// o canal G > 0 indica sombra (cor x0.82).
uniform vec4 c_pele = vec4(0.96, 0.78, 0.63, 1.0);
uniform vec4 c_cabelo = vec4(0.14, 0.09, 0.07, 1.0);
uniform vec4 c_camisa = vec4(0.75, 0.22, 0.17, 1.0);
uniform vec4 c_calcao = vec4(1.0);
uniform vec4 c_meia = vec4(0.75, 0.22, 0.17, 1.0);
uniform vec4 c_bota = vec4(0.08, 0.06, 0.11, 1.0);
uniform vec4 c_luva = vec4(1.0);
uniform vec4 c_manga = vec4(1.0);
void fragment() {
	vec4 t = texture(TEXTURE, UV);
	if (t.a < 0.5) {
		COLOR = vec4(0.0);
	} else {
		int l = int(floor(t.r * 255.0 + 0.5));
		vec3 c = vec3(1.0, 0.0, 1.0);
		if (l == 1) c = c_pele.rgb;
		else if (l == 2) c = c_cabelo.rgb;
		else if (l == 3) c = c_camisa.rgb;
		else if (l == 4) c = c_calcao.rgb;
		else if (l == 5) c = c_meia.rgb;
		else if (l == 6) c = c_bota.rgb;
		else if (l == 7) c = c_luva.rgb;
		else if (l == 8) c = vec3(0.14, 0.09, 0.07);
		else if (l == 11) c = c_manga.rgb;
		else if (l == 99) c = vec3(0.078, 0.063, 0.11);
		if (t.g * 255.0 > 0.5) c *= 0.82;
		COLOR = vec4(c, 1.0);
	}
}
