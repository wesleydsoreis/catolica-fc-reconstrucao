extends Node2D
class_name Campo
## Desenha o gramado, as linhas, os gols com rede e a arquibancada. Desenho estático (feito uma vez).

static var _tex_gramado: ImageTexture = null

func _gramado(w: int, h: int) -> Texture2D:
	if _tex_gramado != null:
		return _tex_gramado
	var img := Image.create(w, h, false, Image.FORMAT_RGB8)
	var a := Color('86d028')
	var b := Color('62a81c')
	for y in h:
		var banda: int = (y / 50) % 2
		for x in w:
			img.set_pixel(x, y, (b if (x + y) % 2 == 0 else a) if banda == 1 else a)
	_tex_gramado = ImageTexture.create_from_image(img)
	return _tex_gramado

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _draw() -> void:
	var pw: float = Cfg.PW
	var ph: float = Cfg.PH
	var m: float = Cfg.MARGEM
	var cy: float = ph * 0.5
	# fundo
	draw_rect(Rect2(-m - 400.0, -m - 400.0, pw + 2.0 * m + 800.0, ph + 2.0 * m + 800.0), Color("1d2a55"))
	draw_rect(Rect2(-m, -m, pw + 2.0 * m, ph + 2.0 * m), Color("2c8a3a"))
	# gramado em pixel art: faixas horizontais com dithering xadrez
	var tex: Texture2D = _gramado(int((pw + 2.0 * m) / 4.0), int((ph + 2.0 * m) / 4.0))
	draw_texture_rect(tex, Rect2(-m, -m, pw + 2.0 * m, ph + 2.0 * m), false)
	# placas de publicidade e público
	for i in 44:
		var x: float = -m + float(i) * (pw + 2.0 * m) / 44.0
		var cor: Color = [Color("C0392B"), Color("F5E6C8"), Color("2E6FD6"), Color("F39C12")][i % 4]
		draw_rect(Rect2(x, -m - 34.0, (pw + 2.0 * m) / 44.0 - 4.0, 26.0), cor)
		draw_rect(Rect2(x, ph + m + 8.0, (pw + 2.0 * m) / 44.0 - 4.0, 26.0), cor)
	# linhas
	var w: float = 5.0
	var lc: Color = Color(1, 1, 1, 0.92)
	draw_rect(Rect2(0, 0, pw, ph), lc, false, w)
	draw_line(Vector2(pw * 0.5, 0), Vector2(pw * 0.5, ph), lc, w)
	draw_arc(Vector2(pw * 0.5, cy), 170.0, 0.0, TAU, 56, lc, w)
	draw_circle(Vector2(pw * 0.5, cy), 7.0, lc)
	# áreas
	for lado in 2:
		var s: float = 1.0 if lado == 0 else -1.0
		var x0: float = 0.0 if lado == 0 else pw
		draw_rect(Rect2(minf(x0, x0 + s * 340.0), cy - 360.0, 340.0, 720.0), lc, false, w)
		draw_rect(Rect2(minf(x0, x0 + s * 130.0), cy - 190.0, 130.0, 380.0), lc, false, w)
		draw_circle(Vector2(x0 + s * 230.0, cy), 6.0, lc)
		var ang0: float = -0.93 if lado == 0 else PI - 0.93
		draw_arc(Vector2(x0 + s * 230.0, cy), 170.0, ang0, ang0 + 1.86, 24, lc, w)
	# escanteios
	for p in [Vector2(0, 0), Vector2(pw, 0), Vector2(0, ph), Vector2(pw, ph)]:
		draw_circle(p, 9.0, lc)
	# gols
	for lado in 2:
		var s2: float = -1.0 if lado == 0 else 1.0
		var xg: float = 0.0 if lado == 0 else pw
		var rect: Rect2 = Rect2(minf(xg, xg + s2 * Cfg.GOL_PROF), cy - Cfg.GOL_METADE, Cfg.GOL_PROF, Cfg.GOL_METADE * 2.0)
		draw_rect(rect, Color(0.1, 0.12, 0.2, 0.35))
		for k in range(0, 9):
			var xx: float = rect.position.x + float(k) * Cfg.GOL_PROF / 8.0
			draw_line(Vector2(xx, rect.position.y), Vector2(xx, rect.position.y + rect.size.y), Color(1, 1, 1, 0.7), 1.5)
		for k in range(0, 13):
			var yy: float = rect.position.y + float(k) * rect.size.y / 12.0
			draw_line(Vector2(rect.position.x, yy), Vector2(rect.position.x + rect.size.x, yy), Color(1, 1, 1, 0.7), 1.5)
		draw_rect(rect, Color.WHITE, false, 5.0)
		draw_circle(Vector2(xg, cy - Cfg.GOL_METADE), 7.0, Color.WHITE)
		draw_circle(Vector2(xg, cy + Cfg.GOL_METADE), 7.0, Color.WHITE)
