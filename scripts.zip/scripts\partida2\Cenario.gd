extends Node2D
class_name Cenario
## Estádio (fundo fixo com torcida) + mundo que rola com a câmera (campo, gols, jogadores e bola).
var estadio: Stadium
var mundo: Node2D
var campo: Pitch
func _ready() -> void:
	Pitch.usar_modo()
	estadio = Stadium.new(); add_child(estadio)
	estadio.modulate = Color(0.8, 0.8, 0.88)   # arquibancada mais escura: o foco fica no gramado
	mundo = Node2D.new(); add_child(mundo)
	campo = Pitch.new(); mundo.add_child(campo)
