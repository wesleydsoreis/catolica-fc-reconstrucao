extends Control
## Fase 7: conquistas, rivalidade (clássico) e clima.

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	mg.add_child(col)
	_montar(col)

func _voltar(col: Control) -> void:
	var b := Tema.botao("VOLTAR", "primario", 48)
	b.name = "BotaoSair"
	b.pressed.connect(func(): SceneManager.voltar())
	col.add_child(b)

func _montar(col: VBoxContainer) -> void:
	col.add_child(Tema.titulo_secao("Conquistas"))
	col.add_child(Tema.rotulo("%d de %d desbloqueadas · cada uma rende R$ %s." % [GameState.conquistas.size(), Extras.CONQUISTAS.size(), str(Extras.PREMIO_CONQUISTA)], 13))
	var rv := Tema.cartao(Tema.AMARELO)
	rv.name = "CartaoRival"
	var h: Dictionary = GameState.h2h.get(GameState.rival_id, {"v": 0, "e": 0, "d": 0})
	rv.add_child(Tema.rotulo("CLÁSSICO contra %s: %dV %dE %dD (público +25%%, torcida e diretoria ±3)" % [GameState.nome_rival(), h["v"], h["e"], h["d"]], 13, Tema.TINTA))
	col.add_child(rv)
	for q in Extras.CONQUISTAS:
		var ok: bool = GameState.conquistas.has(q["id"])
		var c := Tema.cartao(Tema.BRANCO if ok else Tema.CREME)
		c.name = "Conquista_" + str(q["id"])
		c.add_child(Tema.rotulo("%s %s — %s" % ["[OK]" if ok else "[ ]", q["nome"], q["desc"]], 13, Tema.TITULO if ok else Tema.TEXTO))
		col.add_child(c)
	col.add_child(Tema.titulo_secao("Clima"))
	for k in Extras.CLIMAS:
		col.add_child(Tema.rotulo("%s: %s" % [Extras.CLIMAS[k]["nome"], Extras.CLIMAS[k]["desc"]], 12, Tema.TEXTO2))
	_voltar(col)
