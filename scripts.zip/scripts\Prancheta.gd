extends Control
## Prancheta do Treinador: dados reais da carreira (estatística, campanha), gráfico e calculadora.
## O desvio padrão só é liberado ao chegar ao nível Intermediário de Estatística (árvore de competências).

var _col: VBoxContainer
var _calc: Calculadora = null

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	mg.add_child(_col)
	_montar()

func _linha(a: String, b: String, nome: String = "") -> HBoxContainer:
	var h := HBoxContainer.new()
	var la := Tema.rotulo(a, 14)
	var lb := Tema.rotulo(b, 14, Tema.AMARELO)
	lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	if nome != "":
		lb.name = nome
	h.add_child(la)
	h.add_child(lb)
	return h

func _montar() -> void:
	var ctx: Dictionary = Educacao.contexto(GameState)
	_col.add_child(Tema.titulo_secao("Prancheta do Treinador"))
	_visao_geral()
	var tits: Array = ctx["tits"]
	var vals: Array = tits.map(func(x): return int(x["overall"]))
	# --- estatística dos titulares
	var c1 := Tema.cartao(Tema.BRANCO)
	var v1 := VBoxContainer.new()
	v1.add_theme_constant_override("separation", 6)
	c1.add_child(v1)
	v1.add_child(Tema.rotulo("OVERALL DOS TITULARES (%d)" % vals.size(), 12, Tema.TITULO))
	if not vals.is_empty():
		var g := GraficoBarras.new()
		g.name = "GraficoOverall"
		var mn: float = float(vals.min())
		var mx: float = float(vals.max())
		g.definir(tits.map(func(x): return x["nome"]), vals, Educacao.media(vals), maxf(0.0, mn - 10.0), mx + 4.0)
		v1.add_child(g)
		v1.add_child(_linha("Média", Educacao.num(Educacao.media(vals), 1), "StatMedia"))
		v1.add_child(_linha("Mediana", Educacao.num(Educacao.mediana(vals), 1), "StatMediana"))
		var mo: Array = Educacao.moda(vals)
		v1.add_child(_linha("Moda", ", ".join(mo.map(func(x): return str(x))) if not mo.is_empty() else "sem moda", "StatModa"))
		v1.add_child(_linha("Amplitude (máx − mín)", str(vals.max() - vals.min()), "StatAmplitude"))
		var nivel_est: int = GameState.nivel_area("estatistica")
		if nivel_est >= 1:
			v1.add_child(_linha("Desvio padrão", Educacao.num(Educacao.desvio(vals), 2), "StatDesvio"))
		else:
			var bl := Tema.rotulo("🔒 Desvio padrão: libera ao chegar no nível Intermediário de Estatística (3 acertos de primeira nos Desafios).", 12, Tema.TEXTO2)
			bl.name = "StatDesvioBloqueado"
			v1.add_child(bl)
		if nivel_est >= 2:
			var q: Array = Educacao.quartis(vals)
			v1.add_child(_linha("Quartis Q1 · Q3 · IQR", "%s · %s · %s" % [Educacao.num(q[0], 1), Educacao.num(q[1], 1), Educacao.num(float(q[1]) - float(q[0]), 1)], "StatQuartis"))
	_col.add_child(c1)
	# --- campanha
	var c2 := Tema.cartao(Tema.BRANCO)
	var v2 := VBoxContainer.new()
	v2.add_theme_constant_override("separation", 6)
	c2.add_child(v2)
	v2.add_child(Tema.rotulo("CAMPANHA NO UNIVERSITÁRIO", 12, Tema.TITULO))
	var j: int = ctx["jogos"]
	v2.add_child(_linha("Jogos · V / E / D", "%d · %d / %d / %d" % [j, ctx["v"], ctx["e"], ctx["d"]]))
	if j > 0:
		v2.add_child(_linha("Aproveitamento", Educacao.pct(float(ctx["pontos"]) / float(3 * j) * 100.0, 1), "StatAprov"))
		v2.add_child(_linha("Gols pró / contra (saldo)", "%d / %d (%+d)" % [ctx["gp"], ctx["gc"], int(ctx["gp"]) - int(ctx["gc"])]))
		v2.add_child(_linha("Gols marcados por jogo", Educacao.num(float(ctx["gp"]) / float(j), 2), "StatGolsJogo"))
	else:
		v2.add_child(Tema.rotulo("Ainda sem jogos nesta temporada: jogue a primeira rodada para ver os números.", 13))
	if j > 0 and GameState.nivel_area("porcentagem") >= 1:
		var cx0: float = float(GameData.economia["caixa_inicial"])
		v2.add_child(_linha("Variação do caixa desde o início", "%+s" % Educacao.pct((float(ctx["caixa"]) - cx0) / cx0 * 100.0, 1), "StatVarCaixa"))
	if j > 0 and GameState.nivel_area("porcentagem") >= 2:
		var total_r: int = int(GameData.regras_especiais.get("total_rodadas", 28))
		var proj: float = float(ctx["pontos"]) / float(j) * float(total_r)
		v2.add_child(_linha("Pontos projetados na temporada", "%d de %d (%s)" % [int(round(proj)), 3 * total_r, Educacao.pct(proj / float(3 * total_r) * 100.0, 0)], "StatProjecao"))
	if GameState.nivel_area("probabilidade") >= 1:
		v2.add_child(_linha("Valor esperado de pontos (próx. rodada)", Educacao.num(3.0 * ctx["pv"] + ctx["pe"], 2), "StatEsperado"))
	if GameState.nivel_area("probabilidade") >= 2:
		var rest: int = int(GameData.regras_especiais.get("total_rodadas", 28)) - j
		v2.add_child(_linha("Pontos esperados nas %d rodadas restantes" % rest, "≈ %d" % int(round((3.0 * ctx["pv"] + ctx["pe"]) * rest)), "StatEsperadoTemporada"))
	var chance: Label = Tema.rotulo("Próxima rodada · vitória %s · empate %s" % [Educacao.pct(ctx["pv"] * 100.0), Educacao.pct(ctx["pe"] * 100.0)], 13)
	v2.add_child(chance)
	_col.add_child(c2)
	# --- competências
	var c3 := Tema.cartao(Tema.BRANCO)
	var v3 := VBoxContainer.new()
	v3.add_theme_constant_override("separation", 6)
	c3.add_child(v3)
	v3.add_child(Tema.rotulo("ÁRVORE DE COMPETÊNCIAS · %s" % str(Educacao.NIVEL_NOME[GameState.nivel_escolar]).to_upper(), 12, Tema.TITULO))
	for a in Educacao.AREAS:
		var cm: Dictionary = GameState.competencias.get(a, {"acertos": 0, "total": 0})
		var nv: int = Educacao.nivel_competencia(int(cm["acertos"]))
		var prox: int = 3 if nv == 0 else (8 if nv == 1 else 8)
		v3.add_child(Tema.barra("%s · %s (%d acertos de primeira, %d desafios)" % [Educacao.AREA_NOME[a], Educacao.nome_nivel_comp(nv), cm["acertos"], cm["total"]], minf(100.0, float(cm["acertos"]) / float(prox) * 100.0), Tema.AMARELO))
	_col.add_child(v3.get_parent())
	var bcomp := Tema.botao("ÁRVORE DE COMPETÊNCIAS", "secundario", 44)
	bcomp.name = "BotaoCompetencias"
	bcomp.pressed.connect(func(): SceneManager.ir_para("competencias"))
	_col.add_child(bcomp)
	# --- calculadora
	_calc = Calculadora.new()
	_calc.name = "Calculadora"
	var c4 := Tema.cartao(Tema.BRANCO)
	var v4 := VBoxContainer.new()
	c4.add_child(v4)
	v4.add_child(Tema.rotulo("CALCULADORA", 12, Tema.TITULO))
	v4.add_child(_calc)
	_col.add_child(c4)
	var bd := Tema.botao("IR AO DESAFIO DO DIRETOR", "primario", 48)
	bd.name = "BotaoDesafio"
	bd.pressed.connect(func(): SceneManager.ir_para("diretor"))
	_col.add_child(bd)

# ------------------------------------------------------------------ Fase 5: visão geral da carreira (tudo calculado de dados reais)
func _cartao_secao(nome: String, titulo: String) -> VBoxContainer:
	var c := Tema.cartao(Tema.BRANCO)
	c.name = nome
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	c.add_child(v)
	v.add_child(Tema.rotulo(titulo, 12, Tema.TITULO))
	_col.add_child(c)
	return v

func _texto(t: String, tam: int = 13, cor: Color = Tema.TEXTO) -> Label:
	var l := Tema.rotulo(t, tam, cor)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

## Resultados da Católica no Universitário já jogados: [{rodada, adv, gp, gc, casa, r}].
func resultados() -> Array:
	var out: Array = []
	for i in GameState.calendario.size():
		for m in GameState.calendario[i]:
			if not bool(m.get("jogado", false)):
				continue
			var casa: bool = m["mandante_id"] == "catolica"
			if not casa and m["visitante_id"] != "catolica":
				continue
			var a: int = int(m["placar_mandante"] if casa else m["placar_visitante"])
			var b: int = int(m["placar_visitante"] if casa else m["placar_mandante"])
			var adv: Dictionary = GameState.clube_por_id(str(m["visitante_id"] if casa else m["mandante_id"]))
			out.append({"rodada": i + 1, "adv": str(adv.get("nome_curto", adv.get("nome", "?"))), "gp": a, "gc": b, "casa": casa, "r": "v" if a > b else ("e" if a == b else "d")})
	return out

func alertas_financeiros() -> Array:
	var al: Array = []
	var caixa: float = float(GameState.financas.get("caixa", 0))
	var salarios: int = 0
	for j in GameState.elenco:
		if int(j.get("emprestado", 0)) <= 0:
			salarios += int(j["salario"])
	var custo_rodada: int = salarios + GameState.manutencao_estadio_total()
	if caixa < 0.0:
		al.append("Caixa NEGATIVO (%s): o clube está em déficit." % Tema.reais(int(caixa)))
	elif caixa < custo_rodada * 3.0:
		al.append("Caixa cobre menos de 3 rodadas de despesas fixas (%s por rodada)." % Tema.reais(custo_rodada))
	if GameState.divida() > 0.5:
		al.append("Dívida de %s com juros de %d%% por rodada." % [Tema.reais(int(GameState.divida())), int(Gestao.TAXA_DIVIDA * 100.0)])
	return al

func _visao_geral() -> void:
	# --- mascote + mensagem
	var humor: String = Mascote.humor_do_clube()
	var vm := _cartao_secao("Visao_Mascote", "SEU ASSISTENTE")
	var hm := HBoxContainer.new()
	hm.add_theme_constant_override("separation", 12)
	vm.add_child(hm)
	var g: TextureRect = Mascote.criar(humor, Vector2(96, 110))
	hm.add_child(g)
	var msg: String
	match humor:
		"triste": msg = "Fase difícil, mas dá para virar. Confira os alertas e o próximo jogo."
		"lesionado": msg = "Temos %d lesionados! Revise a escalação antes da rodada." % GameState.lesionados().size()
		"bravo": msg = "A diretoria está insatisfeita (%d%%). Precisamos de resultados!" % int(GameState.financas.get("confianca_diretoria", 70))
		"animado": msg = "Última vitória! Vamos manter o ritmo."
		"pensativo": msg = "Empate no último jogo. O que dá para ajustar?"
		_: msg = "Tudo pronto para a temporada! Veja as tarefas abaixo."
	var lm := _texto(msg, 15, Tema.AMARELO)
	lm.name = "MensagemMascote"
	lm.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hm.add_child(lm)
	# --- próxima rodada
	var vp := _cartao_secao("Visao_Proximo", "PRÓXIMO ADVERSÁRIO")
	var info: Variant = GameState.obter_partida_da_rodada()
	if info == null:
		vp.add_child(_texto("Sem jogo da Católica agora." if GameState.temporada_status == "em_andamento" else "Temporada encerrada: veja o balanço no Estádio.", 14))
	else:
		var adv: Dictionary = info["adversario"]
		vp.add_child(_linha("Rodada %d" % GameState.rodada_atual, "%s%s · %s" % ["CLÁSSICO · " if GameState.eh_classico(adv) else "", adv.get("nome", "?"), "em casa" if info["em_casa"] else "fora"], "ProxAdversario"))
		vp.add_child(_linha("Força do adversário", str(int(adv.get("forca", 0)))))
	# --- resultados + gráfico de pontos
	var vr := _cartao_secao("Visao_Resultados", "ÚLTIMOS RESULTADOS")
	var res: Array = resultados()
	if res.is_empty():
		vr.add_child(_texto("Nenhum jogo disputado ainda.", 13, Tema.TEXTO2))
	else:
		var ult: Array = res.slice(maxi(0, res.size() - 5))
		var hr := HBoxContainer.new()
		hr.add_theme_constant_override("separation", 6)
		for x in ult:
			hr.add_child(Tema.chip("%s %d-%d" % [str(x["adv"]).substr(0, 8), x["gp"], x["gc"]], Tema.VERDE if x["r"] == "v" else (Tema.LARANJA if x["r"] == "e" else Tema.VINHO)))
		vr.add_child(hr)
		var pts: Array = res.map(func(x): return 3 if x["r"] == "v" else (1 if x["r"] == "e" else 0))
		var gr := GraficoBarras.new()
		gr.name = "GraficoPontos"
		gr.definir(res.map(func(x): return "R%d" % x["rodada"]), pts, Educacao.media(pts), 0.0, 3.5)
		vr.add_child(gr)
		vr.add_child(_texto("Pontos por rodada (linha = média).", 11, Tema.TEXTO2))
	# --- tarefas
	var vt := _cartao_secao("Visao_Tarefas", "TAREFAS DA RODADA")
	var tarefas: Array = []
	if not GameState.treino_confirmado:
		tarefas.append(["Treino da semana pendente", "treino", "IR AO TREINO", "TarefaTreino"])
	var ls: int = GameState.lesionados().size()
	var sp: int = GameState.suspensos().size()
	if ls > 0 or sp > 0:
		tarefas.append(["%d lesionado(s) · %d suspenso(s): revise a escalação" % [ls, sp], "escalacao", "ESCALAÇÃO", "TarefaEscalacao"])
	if GameState.temporada_status == "em_andamento":
		tarefas.append(["Jogar a rodada %d" % GameState.rodada_atual, "mapa", "IR AO ESTÁDIO", "TarefaRodada"])
	if tarefas.is_empty():
		vt.add_child(_texto("✔ Nenhuma tarefa pendente.", 14, Tema.VERDE))
	for t in tarefas:
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 8)
		h.add_child(_texto("• " + str(t[0]), 13))
		var b := Tema.botao(str(t[2]), "secundario", 38)
		b.name = str(t[3])
		b.add_theme_font_size_override("font_size", 11)
		b.custom_minimum_size = Vector2(150, 38)
		b.size_flags_horizontal = Control.SIZE_SHRINK_END
		var dest: String = str(t[1])
		b.pressed.connect(func(): SceneManager.ir_para(dest, false))
		h.add_child(b)
		vt.add_child(h)
	# --- objetivos
	var vo := _cartao_secao("Visao_Objetivos", "OBJETIVOS DA DIRETORIA")
	for m in GameState.metas:
		var sit: Dictionary = GameState.situacao_meta(m)
		var ok_: bool = bool(m["cumprida"]) or bool(sit["ok"])
		vo.add_child(_texto("%s %s  ·  %s" % ["✔" if ok_ else "○", str(m["titulo"]), str(sit["texto"])], 13, Tema.VERDE if ok_ else Tema.TEXTO))
	# --- alertas financeiros e notificações
	var va := _cartao_secao("Visao_Alertas", "ALERTAS E NOTIFICAÇÕES")
	var avisos: Array = alertas_financeiros()
	for a in avisos:
		va.add_child(_texto("! " + str(a), 13, Tema.LARANJA))
	var nomes_les: Array = GameState.lesionados().map(func(j): return str(j["nome"]))
	if not nomes_les.is_empty():
		va.add_child(_texto("Lesionados: " + ", ".join(nomes_les), 13))
	var nomes_sus: Array = GameState.suspensos().map(func(j): return str(j["nome"]))
	if not nomes_sus.is_empty():
		va.add_child(_texto("Suspensos: " + ", ".join(nomes_sus), 13))
	if avisos.is_empty() and nomes_les.is_empty() and nomes_sus.is_empty():
		va.add_child(_texto("✔ Sem alertas. Finanças e elenco em ordem.", 13, Tema.VERDE))
	# --- atalhos
	var vs := _cartao_secao("Visao_Atalhos", "ATALHOS")
	var gd := GridContainer.new()
	gd.columns = 2
	gd.add_theme_constant_override("h_separation", 8)
	gd.add_theme_constant_override("v_separation", 8)
	vs.add_child(gd)
	for a in [["treino", "TREINO", "treino"], ["secretaria", "SECRETARIA", "painel"], ["mercado", "MERCADO", "mercado"], ["obras", "OBRAS", "estadio_obras"], ["classificacao", "CLASSIFICAÇÃO", "torneios"], ["financas", "FINANÇAS", "financas"], ["elenco", "ELENCO", "elenco"], ["mapa", "MAPA", "mapa"]]:
		var b := Tema.botao(str(a[1]), "secundario", 40)
		b.name = "Atalho_" + str(a[0])
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var dest2: String = str(a[2])
		b.pressed.connect(func(): SceneManager.ir_para(dest2, dest2 != "mapa"))
		gd.add_child(b)
	var bt := Tema.botao("REVER TUTORIAL", "ouro", 40)
	bt.name = "BotaoTutorial"
	bt.pressed.connect(func():
		SceneManager.tutorial_pendente = true
		SceneManager.ir_para("mapa", false))
	vs.add_child(bt)
