class_name Educacao
extends RefCounted
## Camada educacional (Fase 4): problemas gerados com os DADOS REAIS da carreira do aluno.
## A matemática é a ferramenta para decidir melhor; errar mostra o passo a passo e nunca trava o jogo.

const NIVEIS := ["fund2", "medio", "superior"]
const NIVEL_NOME := {"fund2": "Fundamental II", "medio": "Ensino Médio", "superior": "Superior"}
const AREAS := ["estatistica", "porcentagem", "probabilidade", "financas", "funcoes"]
const AREA_NOME := {"estatistica": "Estatística", "porcentagem": "Porcentagem e razão", "probabilidade": "Probabilidade",
	"financas": "Finanças", "funcoes": "Funções"}
const RECOMPENSA_1A := 5000
const RECOMPENSA_2A := 2500

# ------------------------------------------------------------------ formatação
static func num(v: float, casas: int = 1) -> String:
	var s: String = ("%d" % int(round(v))) if casas == 0 or is_equal_approx(v, round(v)) and casas == 1 else ("%." + str(casas) + "f") % v
	return s.replace(".", ",")

static func rs(v: float) -> String:
	var n: int = int(round(v))
	var t: String = str(absi(n))
	var out := ""
	while t.length() > 3:
		out = "." + t.substr(t.length() - 3) + out
		t = t.substr(0, t.length() - 3)
	return ("-" if n < 0 else "") + "R$ " + t + out

static func pct(v: float, casas: int = 0) -> String:
	return num(v, casas) + "%"

# ------------------------------------------------------------------ contexto (dados reais, com reserva para início de carreira)
static func contexto(gs: Node) -> Dictionary:
	var tits: Array = []
	for s in gs.slots:
		if s["jogador_id"] == null:
			continue
		for j in gs.elenco:
			if j["id"] == s["jogador_id"]:
				tits.append({"nome": str(j["nome"]), "overall": int(j["overall"]), "salario": int(j["salario"])})
	var cat: Dictionary = {}
	for c in gs.clubes:
		if str(c.get("id", "")) == "catolica":
			cat = c
	var pv := 0.40
	var pe := 0.18
	var ch: Dictionary = gs.chances_proxima_rodada()
	if not ch.is_empty():
		pv = float(ch["vitoria"])
		pe = float(ch["empate"])
	return {"tits": tits, "caixa": float(gs.financas["caixa"]), "ingresso": float(gs.financas["preco_ingresso"]),
		"capacidade": float(gs.financas["capacidade_estadio"]), "manut": float(gs.manutencao_estadio_total()),
		"pontos": int(cat.get("pontos", 0)), "jogos": int(cat.get("jogos", 0)),
		"v": int(cat.get("vitorias", 0)), "e": int(cat.get("empates", 0)), "d": int(cat.get("derrotas", 0)),
		"gp": int(cat.get("gols_pro", 0)), "gc": int(cat.get("gols_contra", 0)), "pv": pv, "pe": pe,
		"rodada": int(gs.rodada_atual), "temporada": int(gs.temporada), "divida": float(gs.divida()),
		"pub25": float(gs.financas["capacidade_estadio"]) * (0.22 + (clampf(float(gs.financas["torcida"]), 0.0, 100.0) / 100.0) * 0.5) * 1.0}

# ------------------------------------------------------------------ estatística descritiva (usada pela Prancheta e pelos problemas)
static func media(v: Array) -> float:
	var s := 0.0
	for x in v:
		s += float(x)
	return s / maxf(1.0, float(v.size()))

static func mediana(v: Array) -> float:
	var a: Array = v.duplicate()
	a.sort()
	if a.is_empty():
		return 0.0
	var n: int = a.size()
	return float(a[n / 2]) if n % 2 == 1 else (float(a[n / 2 - 1]) + float(a[n / 2])) / 2.0

static func moda(v: Array) -> Array:
	var cont: Dictionary = {}
	for x in v:
		cont[x] = int(cont.get(x, 0)) + 1
	var mx := 0
	for k in cont:
		mx = maxi(mx, int(cont[k]))
	var r: Array = []
	if mx < 2:
		return r
	for k in cont:
		if int(cont[k]) == mx:
			r.append(k)
	r.sort()
	return r

static func desvio(v: Array) -> float:
	var m: float = media(v)
	var s := 0.0
	for x in v:
		s += (float(x) - m) * (float(x) - m)
	return sqrt(s / maxf(1.0, float(v.size())))

# ------------------------------------------------------------------ problemas
## Monta 4 alternativas distintas ao redor da correta. Retorna {opcoes, correta}.
static func _alternativas(rng: RandomNumberGenerator, certa: float, casas: int, formatar: Callable, passos: Array) -> Dictionary:
	var vistos: Array = [formatar.call(certa)]
	var vals: Array = [certa]
	var tent := 0
	while vals.size() < 4 and tent < 200:
		tent += 1
		var d: float = passos[rng.randi() % passos.size()] * (1.0 if rng.randf() < 0.5 else -1.0)
		var cand: float = certa + d
		if cand <= 0.0 and certa > 0.0:
			continue
		var t: String = formatar.call(cand)
		if vistos.has(t):
			continue
		vistos.append(t)
		vals.append(cand)
	var ordem: Array = range(vals.size())
	for i in range(ordem.size() - 1, 0, -1):
		var j: int = rng.randi() % (i + 1)
		var tmp = ordem[i]
		ordem[i] = ordem[j]
		ordem[j] = tmp
	var ops: Array = []
	var correta := 0
	for k in ordem.size():
		ops.append(formatar.call(vals[ordem[k]]))
		if ordem[k] == 0:
			correta = k
	return {"opcoes": ops, "correta": correta}

static func _escolher(rng: RandomNumberGenerator, a: Array, n: int) -> Array:
	var c: Array = a.duplicate()
	var r: Array = []
	while r.size() < n and not c.is_empty():
		r.append(c.pop_at(rng.randi() % c.size()))
	return r

static func _tits(rng: RandomNumberGenerator, ctx: Dictionary, n: int) -> Array:
	var t: Array = _escolher(rng, ctx["tits"], n)
	while t.size() < n:      # reserva: carreira sem escalação completa
		t.append({"nome": "Jogador %d" % (t.size() + 1), "overall": 60 + rng.randi() % 25, "salario": 1500 + rng.randi() % 1500})
	return t

static func gerar(area: String, nivel: String, ctx: Dictionary, semente: int) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = semente
	var p: Dictionary
	match area:
		"estatistica": p = _estatistica(rng, nivel, ctx)
		"porcentagem": p = _porcentagem(rng, nivel, ctx)
		"probabilidade": p = _probabilidade(rng, nivel, ctx)
		"financas": p = _financas(rng, nivel, ctx)
		_: p = _funcoes(rng, nivel, ctx)
	p["area"] = area
	p["nivel"] = nivel
	return p

static func _estatistica(rng: RandomNumberGenerator, nivel: String, ctx: Dictionary) -> Dictionary:
	var n: int = 5 if nivel != "medio" else 7
	var t: Array = _tits(rng, ctx, n)
	var vals: Array = t.map(func(x): return int(x["overall"]))
	var dados: Array = t.map(func(x): return {"rotulo": str(x["nome"]), "valor": str(x["overall"])})
	var soma := 0
	for x in vals:
		soma += int(x)
	if nivel == "fund2":
		var m: float = media(vals)
		var alt: Dictionary = _alternativas(rng, m, 1, func(v): return num(v, 1), [0.4, 0.6, 1.0, 1.4, 2.2])
		return {"titulo": "Média do ataque", "enunciado": "Os overalls de %d jogadores da sua escalação estão na tabela. Qual é a MÉDIA deles?" % n,
			"dados": dados, "opcoes": alt["opcoes"], "correta": alt["correta"], "dica": "Média = soma dos valores ÷ quantidade de valores.",
			"passos": ["Some todos os overalls: %s = %d." % [" + ".join(vals.map(func(x): return str(x))), soma], "Divida pela quantidade (%d): %d ÷ %d = %s." % [n, soma, n, num(m, 1)]],
			"valor": m}
	if nivel == "medio":
		var med: float = mediana(vals)
		var ord: Array = vals.duplicate()
		ord.sort()
		var alt2: Dictionary = _alternativas(rng, med, 1, func(v): return num(v, 1), [1.0, 2.0, 3.0, 0.5, 4.0])
		return {"titulo": "Mediana do elenco", "enunciado": "Qual é a MEDIANA dos overalls destes %d jogadores?" % n, "dados": dados,
			"opcoes": alt2["opcoes"], "correta": alt2["correta"], "dica": "Coloque os valores em ordem crescente e pegue o do meio.",
			"passos": ["Ordene: %s." % ", ".join(ord.map(func(x): return str(x))), "Com %d valores, a mediana é o %dº da lista: %s." % [n, n / 2 + 1, num(med, 1)]], "valor": med}
	var dp: float = desvio(vals)
	var m3: float = media(vals)
	var alt3: Dictionary = _alternativas(rng, dp, 1, func(v): return num(v, 1), [0.5, 0.8, 1.2, 1.7, 2.4])
	return {"titulo": "Regularidade do time", "enunciado": "Calcule o DESVIO PADRÃO (populacional) dos overalls. Quanto menor, mais regular é o grupo.", "dados": dados,
		"opcoes": alt3["opcoes"], "correta": alt3["correta"], "dica": "Desvio = raiz de [soma de (valor − média)² ÷ quantidade].",
		"passos": ["Média: %s." % num(m3, 2), "Some (valor − média)² de cada jogador e divida por %d (variância = %s)." % [n, num(dp * dp, 2)], "Desvio padrão = √%s = %s." % [num(dp * dp, 2), num(dp, 1)]], "valor": dp}

static func _porcentagem(rng: RandomNumberGenerator, nivel: String, ctx: Dictionary) -> Dictionary:
	if nivel == "fund2":
		var v: int = ctx["v"]
		var e: int = ctx["e"]
		var d: int = ctx["d"]
		var real: bool = v + e + d >= 3
		if not real:
			v = 2 + rng.randi() % 4
			e = 1 + rng.randi() % 3
			d = 1 + rng.randi() % 3
		var j: int = v + e + d
		var pts: int = 3 * v + e
		var ap: float = float(pts) / float(3 * j) * 100.0
		var alt: Dictionary = _alternativas(rng, ap, 0, func(x): return pct(x, 0), [3.0, 5.0, 8.0, 12.0, 15.0])
		return {"titulo": "Aproveitamento", "enunciado": "%s %d vitórias, %d empates e %d derrotas (%d jogos). Qual o APROVEITAMENTO em pontos? (vitória 3, empate 1)" % ["Sua campanha:" if real else "Imagine uma campanha com", v, e, d, j],
			"dados": [{"rotulo": "Pontos feitos", "valor": str(pts)}, {"rotulo": "Pontos possíveis", "valor": str(3 * j)}], "opcoes": alt["opcoes"], "correta": alt["correta"],
			"dica": "Porcentagem = parte ÷ total × 100.", "passos": ["Pontos feitos: %d×3 + %d×1 = %d." % [v, e, pts], "Pontos possíveis: %d jogos × 3 = %d." % [j, 3 * j], "%d ÷ %d × 100 = %s." % [pts, 3 * j, pct(ap, 0)]], "valor": ap}
	if nivel == "medio":
		var t: Array = _tits(rng, ctx, 1)
		var sal: float = float(t[0]["salario"])
		var a: int = 5 + (rng.randi() % 4) * 5
		var b: int = 5 + (rng.randi() % 3) * 5
		var fin: float = sal * (1.0 + a / 100.0) * (1.0 + b / 100.0)
		var alt2: Dictionary = _alternativas(rng, fin, 0, func(x): return rs(x), [sal * 0.02, sal * 0.04, sal * 0.07, sal * 0.1])
		return {"titulo": "Reajustes sucessivos", "enunciado": "%s ganha %s por mês. Recebe reajuste de %d%% e, depois, outro de %d%% sobre o novo valor. Quanto passa a ganhar?" % [t[0]["nome"], rs(sal), a, b],
			"dados": [{"rotulo": "Salário atual", "valor": rs(sal)}], "opcoes": alt2["opcoes"], "correta": alt2["correta"], "dica": "Cada reajuste multiplica o valor por (1 + taxa). Reajustes sucessivos NÃO se somam.",
			"passos": ["1º reajuste: %s × %s = %s." % [rs(sal), num(1.0 + a / 100.0, 2), rs(sal * (1.0 + a / 100.0))], "2º reajuste: × %s = %s." % [num(1.0 + b / 100.0, 2), rs(fin)]], "valor": fin}
	var c: float = roundf(ctx["caixa"] / 10000.0) * 1000.0
	var i: int = 2 + rng.randi() % 4
	var n: int = 2 + rng.randi() % 3
	var mont: float = c * pow(1.0 + i / 100.0, n)
	var alt3: Dictionary = _alternativas(rng, mont, 0, func(x): return rs(x), [c * 0.015, c * 0.03, c * 0.06, c * 0.1])
	return {"titulo": "Juros compostos", "enunciado": "A diretoria aplica %s do caixa a %d%% por rodada, juros COMPOSTOS. Qual o montante após %d rodadas?" % [rs(c), i, n],
		"dados": [{"rotulo": "Capital", "valor": rs(c)}, {"rotulo": "Taxa por rodada", "valor": "%d%%" % i}, {"rotulo": "Rodadas", "valor": str(n)}], "opcoes": alt3["opcoes"], "correta": alt3["correta"],
		"dica": "M = C · (1 + i)ⁿ.", "passos": ["Fator por rodada: 1 + %d%% = %s." % [i, num(1.0 + i / 100.0, 2)], "M = %s × %s^%d = %s." % [rs(c), num(1.0 + i / 100.0, 2), n, rs(mont)]], "valor": mont}

static func _probabilidade(rng: RandomNumberGenerator, nivel: String, ctx: Dictionary) -> Dictionary:
	var pv: float = roundf(ctx["pv"] * 100.0)
	var pe: float = roundf(ctx["pe"] * 100.0)
	var pd: float = 100.0 - pv - pe
	var dados: Array = [{"rotulo": "Vitória", "valor": pct(pv)}, {"rotulo": "Empate", "valor": pct(pe)}, {"rotulo": "Derrota", "valor": pct(pd)}]
	if nivel == "fund2":
		var nao: float = pv + pe
		var alt: Dictionary = _alternativas(rng, nao, 0, func(x): return pct(x), [4.0, 7.0, 10.0, 12.0, 18.0])
		return {"titulo": "Chance de não perder", "enunciado": "A chance estimada da próxima rodada está na tabela. Qual a probabilidade de a Católica NÃO PERDER?", "dados": dados,
			"opcoes": alt["opcoes"], "correta": alt["correta"], "dica": "Não perder = vencer OU empatar. Some as chances.", "passos": ["Vitória + Empate = %s + %s = %s." % [pct(pv), pct(pe), pct(nao)], "(ou 100%% − derrota = 100%% − %s)" % pct(pd)], "valor": nao}
	if nivel == "medio":
		var dois: float = pv * pv / 100.0
		var alt2: Dictionary = _alternativas(rng, dois, 1, func(x): return pct(x, 1), [2.0, 3.5, 5.0, 8.0, 12.0])
		return {"titulo": "Duas vitórias seguidas", "enunciado": "Supondo que as duas próximas partidas tenham a mesma chance de vitória e sejam independentes, qual a probabilidade de VENCER AS DUAS?", "dados": dados,
			"opcoes": alt2["opcoes"], "correta": alt2["correta"], "dica": "Eventos independentes: multiplique as probabilidades.", "passos": ["P(vencer) = %s = %s." % [pct(pv), num(pv / 100.0, 2)], "P(duas) = %s × %s = %s." % [num(pv / 100.0, 2), num(pv / 100.0, 2), pct(dois, 1)]], "valor": dois}
	var ev: float = 3.0 * pv / 100.0 + pe / 100.0
	var alt3: Dictionary = _alternativas(rng, ev, 2, func(x): return num(x, 2), [0.12, 0.2, 0.31, 0.45])
	return {"titulo": "Valor esperado de pontos", "enunciado": "Vitória vale 3 pontos, empate 1 e derrota 0. Qual o VALOR ESPERADO de pontos nesta rodada?", "dados": dados,
		"opcoes": alt3["opcoes"], "correta": alt3["correta"], "dica": "E = Σ (pontos × probabilidade).", "passos": ["3 × %s + 1 × %s + 0 × %s" % [num(pv / 100.0, 2), num(pe / 100.0, 2), num(pd / 100.0, 2)], "= %s + %s = %s pontos." % [num(3.0 * pv / 100.0, 2), num(pe / 100.0, 2), num(ev, 2)]], "valor": ev}

static func _financas(rng: RandomNumberGenerator, nivel: String, ctx: Dictionary) -> Dictionary:
	if nivel == "fund2":
		var cap: float = ctx["capacidade"]
		var lot: int = 40 + (rng.randi() % 5) * 10
		var ing: float = ctx["ingresso"]
		var rec: float = cap * lot / 100.0 * ing
		var alt: Dictionary = _alternativas(rng, rec, 0, func(x): return rs(x), [ing * 100.0, ing * 200.0, ing * 350.0, ing * 500.0])
		return {"titulo": "Bilheteria", "enunciado": "O estádio comporta %d torcedores e o ingresso custa %s. Se %d%% dos lugares forem vendidos, qual a RECEITA da bilheteria?" % [int(cap), rs(ing), lot],
			"dados": [{"rotulo": "Capacidade", "valor": str(int(cap))}, {"rotulo": "Ingresso", "valor": rs(ing)}, {"rotulo": "Ocupação", "valor": "%d%%" % lot}], "opcoes": alt["opcoes"], "correta": alt["correta"],
			"dica": "Primeiro ache quantos ingressos foram vendidos (porcentagem de um número).", "passos": ["Vendidos: %d × %d%% = %s ingressos." % [int(cap), lot, num(cap * lot / 100.0, 0)], "Receita: %s × %s = %s." % [num(cap * lot / 100.0, 0), rs(ing), rs(rec)]], "valor": rec}
	var gasto: float = ctx["manut"]
	var caixa: float = ctx["caixa"]
	if nivel == "medio":
		var rodadas: float = floorf(caixa / gasto)
		var alt2: Dictionary = _alternativas(rng, rodadas, 0, func(x): return "%d rodadas" % int(x), [3.0, 8.0, 15.0, 22.0, 30.0])
		return {"titulo": "Fôlego do caixa", "enunciado": "Sem nenhuma receita, o clube gasta só a manutenção do estádio a cada rodada. Por quantas rodadas COMPLETAS o caixa aguenta?",
			"dados": [{"rotulo": "Caixa", "valor": rs(caixa)}, {"rotulo": "Manutenção por rodada", "valor": rs(gasto)}], "opcoes": alt2["opcoes"], "correta": alt2["correta"],
			"dica": "Divida o caixa pelo gasto por rodada e fique só com a parte inteira.", "passos": ["%s ÷ %s = %s." % [rs(caixa), rs(gasto), num(caixa / gasto, 2)], "Rodadas completas: %d." % int(rodadas)], "valor": rodadas}
	if rng.randi() % 2 == 0:
		var dv: float = roundf(ctx["divida"] / 1000.0) * 1000.0 if ctx["divida"] >= 1000.0 else float(50 + (rng.randi() % 5) * 25) * 1000.0
		var nn: int = 3 + rng.randi() % 5
		var tot: float = Gestao.divida_apos(dv, nn)
		var altd: Dictionary = _alternativas(rng, roundf(tot), 0, func(x): return rs(x), [dv * 0.02, dv * 0.04, dv * 0.07, dv * 0.1])
		return {"titulo": "O peso da dívida", "enunciado": "%s a banco cobra %s por rodada, juros COMPOSTOS, sobre uma dívida de %s. Quanto será devido após %d rodadas sem pagar?" % ["O" if ctx["divida"] >= 1000.0 else "Se o clube pegasse um empréstimo, o", pct(Gestao.TAXA_DIVIDA * 100.0), rs(dv), nn],
			"dados": [{"rotulo": "Dívida", "valor": rs(dv)}, {"rotulo": "Taxa por rodada", "valor": pct(Gestao.TAXA_DIVIDA * 100.0)}, {"rotulo": "Rodadas", "valor": str(nn)}], "opcoes": altd["opcoes"], "correta": altd["correta"],
			"dica": "D = D0 · (1 + i)ⁿ.", "passos": ["Fator por rodada: %s." % num(1.0 + Gestao.TAXA_DIVIDA, 2), "D = %s × %s^%d = %s." % [rs(dv), num(1.0 + Gestao.TAXA_DIVIDA, 2), nn, rs(tot)]], "valor": roundf(tot)}
	var margem: float = 8.0 + float(rng.randi() % 5) * 2.0
	var fixo: float = gasto
	var eq: float = ceilf(fixo / margem)
	var alt3: Dictionary = _alternativas(rng, eq, 0, func(x): return "%d torcedores" % int(x), [30.0, 60.0, 110.0, 190.0, 240.0])
	return {"titulo": "Ponto de equilíbrio", "enunciado": "Cada torcedor deixa %s de lucro (ingresso + lanchonete) e o custo fixo da rodada é a manutenção. Quantos torcedores, no mínimo, são necessários para NÃO TER PREJUÍZO?" % rs(margem),
		"dados": [{"rotulo": "Custo fixo", "valor": rs(fixo)}, {"rotulo": "Lucro por torcedor", "valor": rs(margem)}], "opcoes": alt3["opcoes"], "correta": alt3["correta"],
		"dica": "Equilíbrio: lucro por torcedor × torcedores = custo fixo.", "passos": ["x · %s = %s" % [rs(margem), rs(fixo)], "x = %s ÷ %s = %s → arredonde para cima: %d." % [rs(fixo), rs(margem), num(fixo / margem, 1), int(eq)]], "valor": eq}

static func _funcoes(rng: RandomNumberGenerator, nivel: String, ctx: Dictionary) -> Dictionary:
	if nivel == "fund2":
		var fixo: int = 2000 + (rng.randi() % 5) * 500
		var por: int = 10 + (rng.randi() % 4) * 5
		var n: int = 300 + (rng.randi() % 5) * 100
		var r: float = fixo + por * n
		var alt: Dictionary = _alternativas(rng, r, 0, func(x): return rs(x), [por * 20.0, por * 50.0, fixo * 1.0, por * 80.0])
		return {"titulo": "Receita de um jogo", "enunciado": "A receita de um jogo é R(n) = %d + %d·n, com n torcedores pagantes. Qual a receita com n = %d?" % [fixo, por, n],
			"dados": [{"rotulo": "Parte fixa (patrocínio)", "valor": rs(fixo)}, {"rotulo": "Por torcedor", "valor": rs(por)}], "opcoes": alt["opcoes"], "correta": alt["correta"],
			"dica": "Substitua n pelo valor dado e calcule.", "passos": ["R(%d) = %d + %d × %d." % [n, fixo, por, n], "= %d + %d = %s." % [fixo, por * n, rs(r)]], "valor": r}
	var a: int = 400 + (rng.randi() % 5) * 100
	var b: int = 6 + rng.randi() % 5
	if nivel == "medio" and rng.randi() % 2 == 0:
		var p25: float = roundf(ctx["pub25"])
		var pr: int = 10 + (rng.randi() % 7) * 5
		var pubr: float = p25 * Gestao.fator_preco(float(pr))
		var altr: Dictionary = _alternativas(rng, roundf(pubr), 0, func(x): return "%d torcedores" % int(x), [p25 * 0.04, p25 * 0.08, p25 * 0.13, p25 * 0.2])
		return {"titulo": "A demanda do seu estádio", "enunciado": "No seu clube, com o ingresso a R$ 25 vão %d torcedores e cada R$ 1 a mais tira %s do público (função afim). Qual o público com o ingresso a R$ %d?" % [int(p25), pct(Gestao.K_PRECO * 100.0, 1), pr],
			"dados": [{"rotulo": "Público a R$ 25", "valor": str(int(p25))}, {"rotulo": "Queda por R$ 1", "valor": pct(Gestao.K_PRECO * 100.0, 1)}], "opcoes": altr["opcoes"], "correta": altr["correta"],
			"dica": "P(p) = P25 · (1 − 0,018 · (p − 25)).", "passos": ["Variação de preço: %d − 25 = %d." % [pr, pr - 25], "Fator: 1 − 0,018 × %d = %s." % [pr - 25, num(Gestao.fator_preco(float(pr)), 3)], "Público: %d × %s ≈ %d." % [int(p25), num(Gestao.fator_preco(float(pr)), 3), int(roundf(pubr))]], "valor": roundf(pubr)}
	if nivel == "medio":
		var preco: int = 10 + (rng.randi() % 6) * 5
		var pub: int = a - b * preco
		var alt2: Dictionary = _alternativas(rng, pub, 0, func(x): return "%d torcedores" % int(x), [b * 5.0, b * 10.0, b * 15.0, 60.0, 120.0])
		return {"titulo": "Preço × público", "enunciado": "Com o ingresso a R$ p, o público estimado é P(p) = %d − %d·p. Quantos torcedores vão ao jogo com o ingresso a R$ %d?" % [a, b, preco],
			"dados": [{"rotulo": "Função", "valor": "P(p) = %d − %d·p" % [a, b]}], "opcoes": alt2["opcoes"], "correta": alt2["correta"], "dica": "É uma função afim decrescente: troque p pelo preço.",
			"passos": ["P(%d) = %d − %d × %d." % [preco, a, b, preco], "= %d − %d = %d torcedores." % [a, b * preco, pub]], "valor": pub}
	var pot: float = float(a) / (2.0 * b)
	var rmax: float = pot * (a - b * pot)
	var pr: float = roundf(pot)
	var alt3: Dictionary = _alternativas(rng, pr, 0, func(x): return "R$ %d" % int(x), [4.0, 7.0, 10.0, 15.0, 22.0])
	return {"titulo": "Preço que maximiza a receita", "enunciado": "Com público P(p) = %d − %d·p, a receita é R(p) = p·P(p). Qual preço (inteiro mais próximo) MAXIMIZA a receita?" % [a, b],
		"dados": [{"rotulo": "R(p)", "valor": "−%dp² + %dp" % [b, a]}], "opcoes": alt3["opcoes"], "correta": alt3["correta"], "dica": "R(p) é uma parábola voltada para baixo: o máximo está no vértice p = −B ÷ 2A.",
		"passos": ["R(p) = −%d·p² + %d·p, então A = −%d e B = %d." % [b, a, b, a], "Vértice: p = −B ÷ (2A) = %d ÷ %d = %s." % [a, 2 * b, num(pot, 1)], "Receita máxima ≈ %s." % rs(rmax)], "valor": pr}

# ------------------------------------------------------------------ progressão
const DESBLOQUEIOS := {
	"estatistica": ["", "Prancheta: desvio padrão dos titulares", "Prancheta: quartis e amplitude interquartil"],
	"porcentagem": ["", "Prancheta: variação percentual do caixa", "Prancheta: aproveitamento projetado até o fim da temporada"],
	"probabilidade": ["", "Prancheta: valor esperado de pontos da próxima rodada", "Prancheta: pontos esperados até o fim da temporada"],
	"financas": ["", "Finanças: simulador de quitação da dívida (parcela por rodada)", "Finanças: preço ótimo calculado pelo vértice da parábola"],
	"funcoes": ["", "Finanças: tabela preço × público × receita", "Finanças: equação da função de demanda do seu estádio"],
}
const ACERTOS_NIVEL := [0, 3, 8]

static func quartis(v: Array) -> Array:
	var a: Array = v.duplicate()
	a.sort()
	var n: int = a.size()
	if n < 4:
		return [0.0, 0.0]
	var metade: int = n / 2
	var baixo: Array = a.slice(0, metade)
	var alto: Array = a.slice(metade if n % 2 == 0 else metade + 1)
	return [mediana(baixo), mediana(alto)]

static func nivel_competencia(acertos: int) -> int:
	return 0 if acertos < 3 else (1 if acertos < 8 else 2)

static func nome_nivel_comp(n: int) -> String:
	return ["Iniciante", "Intermediário", "Avançado"][n]

## Área da semana: gira pelas 5 áreas, começando pela menos praticada.
static func area_da_rodada(competencias: Dictionary, rodada: int) -> String:
	return AREAS[(rodada - 1) % AREAS.size()]

static func semente(rodada: int, temporada: int, area: String, nivel: String, sala: int) -> int:
	return hash("%d|%d|%s|%s|%d" % [rodada, temporada, area, nivel, sala])
