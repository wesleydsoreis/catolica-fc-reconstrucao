extends Control
## Finanças e Diretoria: preço do ingresso (função de demanda), dívida com juros compostos, metas e confiança.

var _col: VBoxContainer

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	mg.add_child(_col)
	_montar()

func _forca_adv() -> float:
	var info = GameState.obter_partida_da_rodada()
	return float(info["adversario"]["forca"]) if info != null else 70.0

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_col.add_child(Tema.titulo_secao("Finanças e Diretoria"))
	# --- caixa e dívida
	var c0 := Tema.cartao(Tema.AMARELO)
	var v0 := VBoxContainer.new()
	c0.add_child(v0)
	v0.add_child(Tema.rotulo("CAIXA", 12, Tema.TINTA))
	var lc := Tema.rotulo(Tema.reais(int(GameState.financas["caixa"])), 28, Tema.TINTA)
	lc.name = "LabelCaixa"
	v0.add_child(lc)
	var ld := Tema.rotulo("Dívida: %s" % Tema.reais(int(GameState.divida())), 14, Tema.TINTA)
	ld.name = "LabelDivida"
	v0.add_child(ld)
	_col.add_child(c0)
	# --- ingresso
	var preco: int = int(GameState.financas["preco_ingresso"])
	var fa: float = _forca_adv()
	var c1 := Tema.cartao(Tema.BRANCO)
	var v1 := VBoxContainer.new()
	v1.add_theme_constant_override("separation", 6)
	c1.add_child(v1)
	v1.add_child(Tema.rotulo("PREÇO DO INGRESSO", 12, Tema.TITULO))
	var lp := HBoxContainer.new()
	lp.add_theme_constant_override("separation", 8)
	var bm := Tema.botao("− R$ 5", "secundario", 44)
	bm.name = "PrecoMenos"
	bm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bm.pressed.connect(func():
		GameState.definir_preco_ingresso(preco - 5)
		_montar.call_deferred())
	var vp := Tema.rotulo("R$ %d" % preco, 24, Tema.AMARELO)
	vp.name = "LabelPreco"
	vp.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var bp := Tema.botao("+ R$ 5", "secundario", 44)
	bp.name = "PrecoMais"
	bp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bp.pressed.connect(func():
		GameState.definir_preco_ingresso(preco + 5)
		_montar.call_deferred())
	lp.add_child(bm)
	lp.add_child(vp)
	lp.add_child(bp)
	v1.add_child(lp)
	var prev: Dictionary = GameState.previsao_bilheteria(preco, fa)
	var lpv := Tema.rotulo("Previsão em casa: %d torcedores · bilheteria %s" % [prev["publico"], Tema.reais(int(prev["receita"]))], 14)
	lpv.name = "LabelPrevisao"
	v1.add_child(lpv)
	var gr := GraficoFuncao.new()
	gr.name = "GraficoReceita"
	var pts: Array = []
	for p in range(Gestao.PRECO_MIN, Gestao.PRECO_MAX + 1):
		pts.append(Vector2(p, GameState.previsao_bilheteria(p, fa)["receita"]))
	gr.definir(pts, float(preco))
	v1.add_child(gr)
	var dica := Tema.rotulo("Preço alto afasta torcedores (função afim) e a receita forma uma parábola: existe um preço ideal. Acima de R$ 45 a torcida se irrita; até R$ 20 ela cresce.", 12, Tema.TEXTO2)
	v1.add_child(dica)
	if GameState.nivel_area("funcoes") >= 1:
		var tabl := VBoxContainer.new()
		tabl.name = "TabelaDemanda"
		tabl.add_child(Tema.rotulo("TABELA preço × público × receita", 12, Tema.TITULO))
		for pp in [15, 20, 25, 30, 35, 40, 45, 50]:
			var pb: Dictionary = GameState.previsao_bilheteria(pp, fa)
			tabl.add_child(Tema.rotulo("R$ %d  →  %d torcedores  →  %s" % [pp, pb["publico"], Tema.reais(int(pb["receita"]))], 13))
		v1.add_child(tabl)
	if GameState.nivel_area("funcoes") >= 2:
		v1.add_child(Tema.rotulo("Equação: P(p) = P25 · (1 − %s · (p − 25)), com P25 = público a R$ 25." % Educacao.num(Gestao.K_PRECO, 3), 13, Tema.AMARELO))
	if GameState.nivel_area("financas") >= 2:
		var ot: int = 25
		var rbest := -1
		for pq in range(Gestao.PRECO_MIN, Gestao.PRECO_MAX + 1):
			var rr: int = GameState.previsao_bilheteria(pq, fa)["receita"]
			if rr > rbest:
				rbest = rr
				ot = pq
		var lo := Tema.rotulo("Preço ótimo (vértice da parábola de receita): R$ %d, bilheteria ≈ %s" % [ot, Tema.reais(rbest)], 13, Tema.AMARELO)
		lo.name = "PrecoOtimo"
		v1.add_child(lo)
	_col.add_child(c1)
	# --- dívida
	var c2 := Tema.cartao(Tema.BRANCO)
	var v2 := VBoxContainer.new()
	v2.add_theme_constant_override("separation", 6)
	c2.add_child(v2)
	v2.add_child(Tema.rotulo("EMPRÉSTIMO · juros compostos de %d%% por rodada · limite %s" % [int(Gestao.TAXA_DIVIDA * 100), Tema.reais(Gestao.LIMITE_DIVIDA)], 12, Tema.TITULO))
	var lb := HBoxContainer.new()
	lb.add_theme_constant_override("separation", 6)
	for v in [50000, 100000, 200000]:
		var b := Tema.botao("PEGAR %dk" % (v / 1000), "secundario", 40)
		b.name = "Emprestimo_%d" % v
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			GameState.tomar_emprestimo(v)
			_montar.call_deferred())
		lb.add_child(b)
	v2.add_child(lb)
	var lq := HBoxContainer.new()
	lq.add_theme_constant_override("separation", 6)
	for v2x in [50000, 1000000]:
		var bq := Tema.botao("PAGAR 50k" if v2x == 50000 else "QUITAR TUDO", "secundario", 40)
		bq.name = "Pagar_%d" % v2x
		bq.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bq.pressed.connect(func():
			GameState.pagar_divida(v2x)
			_montar.call_deferred())
		lq.add_child(bq)
	v2.add_child(lq)
	if GameState.divida() > 0.0:
		var tab := Tema.rotulo("Se não pagar: " + " → ".join([1, 3, 5, 10].map(func(n): return "%d rod.: %s" % [n, Tema.reais(int(Gestao.divida_apos(GameState.divida(), n)))])), 13)
		tab.name = "ProjecaoDivida"
		v2.add_child(tab)
	if GameState.nivel_area("financas") >= 1 and GameState.divida() > 0.0:
		var nq: int = 5
		var i: float = Gestao.TAXA_DIVIDA
		var pmt: float = GameState.divida() * i / (1.0 - pow(1.0 + i, -nq))
		var ls := Tema.rotulo("Simulador: para quitar %s em %d rodadas pagando parcelas iguais, a parcela é %s (PMT = D·i ÷ [1 − (1+i)⁻ⁿ])." % [Tema.reais(int(GameState.divida())), nq, Tema.reais(int(round(pmt)))], 13, Tema.AMARELO)
		ls.name = "SimuladorQuitacao"
		v2.add_child(ls)
	_col.add_child(c2)
	# --- diretoria
	var c3 := Tema.cartao(Tema.BRANCO)
	var v3 := VBoxContainer.new()
	v3.add_theme_constant_override("separation", 6)
	c3.add_child(v3)
	v3.add_child(Tema.rotulo("METAS DA DIRETORIA · TEMPORADA %d (cada meta cumprida: +%s e +4 de confiança)" % [GameState.temporada, Tema.reais(Gestao.BONUS_META)], 12, Tema.TITULO))
	for m in GameState.metas:
		var sit: Dictionary = GameState.situacao_meta(m)
		var h := HBoxContainer.new()
		var tt := Tema.rotulo("%s %s" % ["✔" if bool(m["cumprida"]) else ("●" if bool(sit["ok"]) else "○"), m["titulo"]], 14)
		tt.name = "Meta_" + str(m["id"])
		h.add_child(tt)
		v3.add_child(h)
		v3.add_child(Tema.rotulo("   " + str(sit["texto"]) + (" (no caminho)" if bool(sit["ok"]) and not bool(m["cumprida"]) else ""), 12, Tema.TEXTO2))
	v3.add_child(Tema.barra("Confiança da diretoria", float(GameState.financas["confianca_diretoria"]), Tema.AZUL, "%"))
	v3.add_child(Tema.barra("Torcida", float(GameState.financas["torcida"]), Tema.AMARELO, "%"))
	_col.add_child(c3)
