class_name Competicoes
extends RefCounted
## Funções puras das competições (InterLajes mata-mata e Copa dos Gigantes).
## Regras seguem o jogo web: Universitário 1-11, InterLajes 12-17 (quartas, semifinal e final
## em ida e volta), Copa dos Gigantes 18-28 (pontos corridos, 12 clubes).

const R_UNIV_FIM := 11
const R_INTERLAJES_INI := 12
const R_INTERLAJES_FIM := 17
const R_COPA_INI := 18
const R_COPA_FIM := 28

static func competicao_da_rodada(r: int) -> String:
	if r >= 1 and r <= R_UNIV_FIM:
		return "universitario"
	if r >= R_INTERLAJES_INI and r <= R_INTERLAJES_FIM:
		return "interlajes"
	if r >= R_COPA_INI and r <= R_COPA_FIM:
		return "copa"
	return "encerrada"

## Ordena a tabela: pontos, saldo de gols, gols pró.
static func ordenar_tabela(lista: Array) -> Array:
	var copia: Array = lista.duplicate()
	copia.sort_custom(func(a, b):
		if int(a["pontos"]) != int(b["pontos"]):
			return int(a["pontos"]) > int(b["pontos"])
		var sa: int = int(a["gols_pro"]) - int(a["gols_contra"])
		var sb: int = int(b["gols_pro"]) - int(b["gols_contra"])
		if sa != sb:
			return sa > sb
		return int(a["gols_pro"]) > int(b["gols_pro"]))
	return copia

static func zerar_clube(c: Dictionary) -> Dictionary:
	c["pontos"] = 0
	c["jogos"] = 0
	c["vitorias"] = 0
	c["empates"] = 0
	c["derrotas"] = 0
	c["gols_pro"] = 0
	c["gols_contra"] = 0
	return c

static func aplicar_resultado(c: Dictionary, gols_pro: int, gols_contra: int) -> void:
	c["jogos"] = int(c["jogos"]) + 1
	c["gols_pro"] = int(c["gols_pro"]) + gols_pro
	c["gols_contra"] = int(c["gols_contra"]) + gols_contra
	if gols_pro > gols_contra:
		c["vitorias"] = int(c["vitorias"]) + 1
		c["pontos"] = int(c["pontos"]) + 3
	elif gols_pro == gols_contra:
		c["empates"] = int(c["empates"]) + 1
		c["pontos"] = int(c["pontos"]) + 1
	else:
		c["derrotas"] = int(c["derrotas"]) + 1

## Placar sorteado entre dois clubes (mandante ganha leve vantagem).
static func placar_sim(forca_mandante: float, forca_visitante: float) -> Vector2i:
	var diferenca: float = (forca_mandante + 1.5) - forca_visitante
	var chance_v: float = clampf(0.40 + diferenca * 0.02, 0.15, 0.75)
	var r: float = randf()
	var gm: int = 0
	var gv: int = 0
	if r < chance_v:
		gm = 1 + (randi() % 3)
		gv = randi() % gm
	elif r < chance_v + 0.20:
		gm = randi() % 3
		gv = gm
	else:
		gv = 1 + (randi() % 3)
		gm = randi() % gv
	return Vector2i(gm, gv)

## Confronto de ida e volta. idA joga em casa na ida; idB na volta.
static func tie_novo(id_a: String, id_b: String) -> Dictionary:
	return {"idA": id_a, "idB": id_b, "ida": [-1, -1], "volta": [-1, -1],
		"vencedor_id": "", "agregado_a": 0, "agregado_b": 0, "penaltis": ""}

## Cruzamento: o pior colocado é idA (manda a ida, decide fora); o melhor manda a volta.
static func tie_por_seed(id_x: String, id_y: String, posicoes: Dictionary) -> Dictionary:
	var px: int = int(posicoes.get(id_x, 99))
	var py: int = int(posicoes.get(id_y, 99))
	if px > py:
		return tie_novo(id_x, id_y)
	return tie_novo(id_y, id_x)

static func quartas(g8_ids: Array, posicoes: Dictionary) -> Array:
	return [
		tie_por_seed(g8_ids[0], g8_ids[7], posicoes), tie_por_seed(g8_ids[1], g8_ids[6], posicoes),
		tie_por_seed(g8_ids[2], g8_ids[5], posicoes), tie_por_seed(g8_ids[3], g8_ids[4], posicoes)]

## Resolve (agregado e, se empatar, pênaltis ponderados pela força).
static func resolver_tie(tie: Dictionary, forca_a: float, forca_b: float) -> void:
	var ga: int = int(tie["ida"][0]) + int(tie["volta"][0])
	var gb: int = int(tie["ida"][1]) + int(tie["volta"][1])
	tie["agregado_a"] = ga
	tie["agregado_b"] = gb
	if ga > gb:
		tie["vencedor_id"] = tie["idA"]
	elif gb > ga:
		tie["vencedor_id"] = tie["idB"]
	else:
		var p_a: float = clampf(0.5 + (forca_a - forca_b) * 0.012, 0.32, 0.68)
		var a_vence: bool = randf() < p_a
		var n: int = 3 + (randi() % 3)
		var l: int = maxi(0, n - (1 + (randi() % 3)))
		tie["penaltis"] = "%d-%d" % [n, l] if a_vence else "%d-%d" % [l, n]
		tie["vencedor_id"] = tie["idA"] if a_vence else tie["idB"]

## Joga as duas partidas que faltam num confronto (para ties sem a Católica).
static func simular_tie(tie: Dictionary, forca_a: float, forca_b: float) -> void:
	if int(tie["ida"][0]) < 0:
		var p1: Vector2i = placar_sim(forca_a, forca_b)
		tie["ida"] = [p1.x, p1.y]
	if int(tie["volta"][0]) < 0:
		var p2: Vector2i = placar_sim(forca_b, forca_a)
		tie["volta"] = [p2.y, p2.x]
	resolver_tie(tie, forca_a, forca_b)

static func tie_da_catolica(lista: Array) -> Dictionary:
	for t in lista:
		if t["idA"] == "catolica" or t["idB"] == "catolica":
			return t
	return {}
