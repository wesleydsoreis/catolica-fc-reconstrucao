extends RefCounted
class_name Palette
## Paleta única da partida (espelha scripts/arte/palette.py).
const CEU1 := Color("3FB8FF")
const CEU2 := Color("1E7FE0")
const PAREDE1 := Color("3A0F18")
const PAREDE2 := Color("5A1420")
const SILH := Color("7A1E2C")
const MUR1 := Color("F7F2E4")
const MUR2 := Color("D8202F")
const MUR3 := Color("8F1A26")
const G1 := Color("12A012")
const G2 := Color("0E8A0E")
const G3 := Color("0A730A")
const BRANCO := Color("FFFFFF")
const REDE := Color("C8D2DC")
const CONTORNO := Color("14101C")
const VERM := Color("D8202F")
const AMAR := Color("FFD84A")
