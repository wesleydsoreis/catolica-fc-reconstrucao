extends Node2D
class_name Partida
## Partida jogável em tempo real. Você controla um jogador por vez (o dono da bola, ou o mais perto dela).
## Os outros 21 jogam sozinhos pela formação e pela tática.

signal partida_terminada(gols_casa: int, gols_fora: int)
signal sair_pedido        # jogador pediu para abandonar a partida pelo menu de pausa
signal reiniciar_pedido   # amistoso: jogador pediu para reiniciar a partida pelo menu de pausa
signal mudou_tatica       # jogador mudou os eixos táticos pelo menu de pausa
signal continuar_pedido   # modo carreira: jogador tocou/apertou para sair após o apito final

enum Estado { SAIDA, JOGANDO, GOL, PARADO, INTERVALO, FIM, BOLA_PARADA }

# FUT7 (7 contra 7, esquema 2-3-1): papel, x (0 = próprio gol, 1 = gol rival), y, número da camisa
const FORMACAO: Array = [
	["GOL", 0.04, 0.50, 1],
	["DEF", 0.22, 0.30, 2], ["DEF", 0.22, 0.70, 3],
	["MEI", 0.45, 0.17, 6], ["MEI", 0.43, 0.50, 8], ["MEI", 0.45, 0.83, 10],
	["ATA", 0.66, 0.50, 9],
]
var formacao_casa: Array = FORMACAO     # formação escolhida pelo clube (lista [papel, x, y, número])
var formacao_fora: Array = []           # vazio = padrão do modo (4-4-2 no 11x11)

## Formação de 11 a partir dos números de DEF/MEI/ATA (4-4-2, 4-3-3...). x: 0 = próprio gol, 1 = gol rival; y: lateral.
static func formacao_11(id: String) -> Array:
	var p: Array = id.split("-")
	var d: int = int(p[0])
	var m: int = 0
	var a: int = int(p[p.size() - 1])
	for k in range(1, p.size() - 1):
		m += int(p[k])
	var l: Array = [["GOL", 0.04, 0.50, 1]]
	var num: int = 2
	for linha in [["DEF", d, 0.20 if d < 5 else 0.18], ["MEI", m, 0.46], ["ATA", a, 0.72]]:
		var q: int = int(linha[1])
		for i in q:
			var y: float = 0.5 if q == 1 else 0.12 + float(i) * (0.76 / float(q - 1))
			l.append([linha[0], float(linha[2]), y, num])
			num += 1
	return l
const NOMES_CASA: Array = ["JOÃO", "MARCOS", "VLIE", "KAIAN", "JOSI", "VH", "LUCAS", "PEDRO", "RAFA", "DUDU", "GABI"]
static var DURACAO_REAL: float = 150.0   # segundos reais para os 90 minutos (150 no FUT7, 210 no 11x11)

# ---- configuração (a etapa de integração com o clube preenche isto) ----
var nome_casa: String = "CATÓLICA FC"
var nome_fora: String = "ADVERSÁRIO"
var sigla_casa: String = "CFC"
var sigla_fora: String = "ADV"
var tatica_casa: String = "equilibrado"   # equilibrado | ofensivo | defensivo
var forca_casa: float = 1.0
var forca_fora: float = 0.95

# ---- estado ----
var estado: int = Estado.SAIDA
var gols: Array = [0, 0]
var timer: float = 0.0
var tempo_real: float = 0.0
var segundo_tempo: bool = false
var estamina: float = 1.0
var sem_folego: bool = false
var pausado: bool = false
var mensagem: String = ""
var mensagem_sub: String = ""
var mensagem_t: float = 0.0
var reposicao_tomador: Jogador = null
var cd_troca: float = 0.0
var graca_fora: float = 0.0
var bp: Dictionary = {}               # bola parada jogável (pênalti, escanteio, falta perigosa) do time da casa
var bp_jogavel: bool = true
var bp_stats := {"penalti": 0, "escanteio": 0, "falta": 0}
## Integração com o clube (Etapa 2). escalacao_casa = até 11 Dictionaries na ordem
## GOL, DEF x4, MEI x3, ATA x3: {nome, numero, overall, energia, moral}. Vazio = aleatório.
var escalacao_casa: Array = []
var cor_casa_1: Color = Color(0, 0, 0, 0)
var cor_casa_2: Color = Color(0, 0, 0, 0)
var cor_fora_1: Color = Color(0, 0, 0, 0)
var cor_fora_2: Color = Color(0, 0, 0, 0)
var modo_carreira: bool = false   # true = fim de jogo emite continuar_pedido em vez de reiniciar
var piloto_auto: bool = false   # true = o time da casa joga sozinho (teste/demonstração)
## Faltas, cartões e substituições
var faltas: Array = [0, 0]
var amarelos: Array = [0, 0]
var vermelhos: Array = [0, 0]
var subs_restantes: Array = [5, 5]
var menu: Node = null            # MenuPartida (pausa + substituição visual)
var reservas_casa: Array = []     # {nome, numero, overall, energia, moral, cat}
var _reservas_fora: int = 5
var _sub_ia_feitas: Array = [false, false]
var penaltis: Array = [0, 0]
var autores_casa: Array = []   # nomes de quem marcou pela casa (artilharia)
var estat: Dictionary = {"passes": [0, 0], "chutes": [0, 0], "roubos": [0, 0], "defesas": [0, 0], "fora": 0, "dist_passes": [0.0, 0.0], "posse_t": [0.0, 0.0], "faltas_t": [0, 0]}

var jogadores: Array[Jogador] = []
var times: Array = [[], []]
var perseguidores: Array = [[], []]
var cobertura: Array = [null, null]          # 2º mais próximo da bola quando o rival tem a posse (cobre o pressionador)
var marcacao: Dictionary = {}                # jogador -> adversário que ele marca (lado do gol)
var nivel_ia: Array = [0.5, 0.5]             # 0..1: reação, pressão e proximidade da marcação
var _ataque_cache: Dictionary = {}           # jogador -> [posição de apoio, instante do cálculo]
var controlado: Jogador = null
## ---- Fase 1: tática de 3 eixos, fadiga, moral e disciplina ----
## pressao: 0 baixa, 1 média, 2 alta | linha: 0 recuada, 1 média, 2 adiantada | construcao: 0 toque curto, 1 bola longa, 2 contra-ataque
const PRESETS_TATICA: Dictionary = {
	"equilibrado": {"pressao": 1, "linha": 1, "construcao": 0},
	"ofensivo": {"pressao": 2, "linha": 2, "construcao": 0},
	"defensivo": {"pressao": 0, "linha": 0, "construcao": 2},
	"pressao": {"pressao": 2, "linha": 1, "construcao": 0},
	"contra_ataque": {"pressao": 0, "linha": 0, "construcao": 2},
}
var eixos: Array = [{"pressao": 1, "linha": 1, "construcao": 0}, {"pressao": 1, "linha": 1, "construcao": 0}]
var eixos_definidos: bool = false      # true = eixos[0] foi escolhido pelo jogador (senão deriva de tatica_casa)
var cansaco: Array = [0.0, 0.0]        # 0..1, acumula com o jogo e com pressão alta/linha adiantada
var transicao: Array = [0.0, 0.0]      # segundos de contra-ataque após recuperar a bola
var clima: String = "sol"             # Fase 7: sol / chuva / calor
var bonus_scout: float = 0.0          # scouting: vantagem por jogar contra o ponto fraco estudado
var forma_casa: float = 0.0            # -1..1 (últimos resultados)
var extra_prep: float = 0.0            # 0..4 (cartas de preparação) em pontos de overall
var reposicao_goleiro: int = -1        # time cujo goleiro está com a bola esperando o time se arrumar
var entrosamento_casa: float = 60.0    # 0..100 no estilo de construção escolhido
var lesoes_log: Array = []            # [{id, nome, rodadas}] lesões ocorridas na partida (time da casa)
var ultimo_lance: Vector2 = Vector2.ZERO     # local da última falta (o árbitro vai até lá)
var ultimo_faltoso: Jogador = null
var cartoes_log: Array = []            # [{id, nome, time, tipo}] tipo: amarelo | vermelho_2a | vermelho_direto
var bola: Bola
var cenario: Cenario
var grupo: Node2D            # nós de LÓGICA (invisíveis); a apresentação fica em PartidaVis
var vis: PartidaVis
var ajuda_aberta: bool = false
var toque: TouchControles

func _ready() -> void:
	randomize()
	DURACAO_REAL = 210.0 if Cfg.MODO_11 else 150.0
	if Cfg.MODO_11:
		if formacao_casa == FORMACAO:
			formacao_casa = formacao_11("4-4-2")
		if formacao_fora.is_empty():
			formacao_fora = formacao_11("4-4-2")
	else:
		subs_restantes = [3, 3]
	nivel_ia[1] = clampf((forca_fora - 0.90) / 0.16, 0.0, 1.0)
	if not eixos_definidos:
		eixos[0] = (PRESETS_TATICA.get(tatica_casa, PRESETS_TATICA["equilibrado"]) as Dictionary).duplicate()
	_registrar_acoes()
	Opcoes.aplicar()
	cenario = Cenario.new()
	add_child(cenario)
	grupo = Node2D.new()
	grupo.visible = false
	add_child(grupo)
	bola = Bola.new()
	grupo.add_child(bola)
	_criar_times()
	vis = PartidaVis.new()
	vis.p = self
	vis.cenario = cenario
	add_child(vis)
	var camada: CanvasLayer = CanvasLayer.new()
	add_child(camada)
	toque = TouchControles.new()
	camada.add_child(toque)
	iniciar()

func iniciar() -> void:
	gols = [0, 0]
	tempo_real = 0.0
	segundo_tempo = false
	estamina = 1.0
	mensagem = ""
	cansaco = [0.0, 0.0]
	transicao = [0.0, 0.0]
	reposicao_goleiro = -1
	cartoes_log.clear()
	lesoes_log.clear()
	_saida(0)
	_mostrar("COMEÇA O JOGO", "%s x %s" % [nome_casa, nome_fora], 2.0)

# ----------------------------------------------------------------- entrada
func _registrar_acoes() -> void:
	_acao("esq", [KEY_A, KEY_LEFT], [], JOY_AXIS_LEFT_X, -1.0)
	_acao("dir", [KEY_D, KEY_RIGHT], [], JOY_AXIS_LEFT_X, 1.0)
	_acao("cima", [KEY_W, KEY_UP], [], JOY_AXIS_LEFT_Y, -1.0)
	_acao("baixo", [KEY_S, KEY_DOWN], [], JOY_AXIS_LEFT_Y, 1.0)
	_acao("passe", [KEY_J, KEY_Z], [JOY_BUTTON_A])
	_acao("chute", [KEY_K, KEY_X], [JOY_BUTTON_B])
	_acao("lob", [KEY_I, KEY_C], [JOY_BUTTON_X])
	_acao("correr", [KEY_SHIFT, KEY_SPACE], [JOY_BUTTON_RIGHT_SHOULDER])
	_acao("ajuda", [KEY_H, KEY_F1], [JOY_BUTTON_LEFT_SHOULDER])
	_acao("pausa", [KEY_P, KEY_ESCAPE], [JOY_BUTTON_START])
	_acao("reiniciar", [KEY_R, KEY_ENTER], [JOY_BUTTON_BACK])
	_acao("troca", [KEY_L, KEY_U], [JOY_BUTTON_Y])

func _acao(nome: String, teclas: Array, botoes: Array, eixo: int = -1, sinal: float = 0.0) -> void:
	if not InputMap.has_action(nome):
		InputMap.add_action(nome, 0.2)
	InputMap.action_erase_events(nome)   # evita eventos duplicados a cada partida
	for k in teclas:
		var ev: InputEventKey = InputEventKey.new()
		ev.physical_keycode = int(k) as Key
		InputMap.action_add_event(nome, ev)
	for b in botoes:
		var jb: InputEventJoypadButton = InputEventJoypadButton.new()
		jb.button_index = int(b) as JoyButton
		InputMap.action_add_event(nome, jb)
	if eixo >= 0:
		var jm: InputEventJoypadMotion = InputEventJoypadMotion.new()
		jm.axis = eixo as JoyAxis
		jm.axis_value = sinal
		InputMap.action_add_event(nome, jm)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("reiniciar") and estado == Estado.FIM:
		_fim_confirmado()
	if event is InputEventScreenTouch and estado == Estado.FIM:
		var t: InputEventScreenTouch = event as InputEventScreenTouch
		if t.pressed:
			_fim_confirmado()

func _fim_confirmado() -> void:
	if modo_carreira:
		continuar_pedido.emit()
	else:
		iniciar()

# ----------------------------------------------------------------- montagem
func _escolher_titulares() -> Array:
	## Dos (até) 11 da escalação do clube, escolhe os 7 do FUT7: melhor de cada posição da formação.
	## Quem sobra vai para o banco, junto com as reservas.
	var livres: Array = escalacao_casa.duplicate()
	var escolhidos: Array = []
	# escalação própria do FUT7: cada jogador já vem com o slot escolhido
	if livres.size() == formacao_casa.size():
		var todos: bool = true
		for d in livres:
			if not (d is Dictionary) or not (d as Dictionary).has("slot"):
				todos = false
		if todos:
			escolhidos.resize(livres.size())
			for d in livres:
				escolhidos[int(d["slot"])] = d
			return escolhidos
	for linha in formacao_casa:
		var papel: String = str(linha[0])
		var melhor: int = -1
		var ov: float = -1.0
		for k in livres.size():
			var d: Dictionary = livres[k]
			if str(d.get("cat", "")) == papel and float(d.get("overall", 0)) > ov:
				melhor = k
				ov = float(d.get("overall", 0))
		if melhor < 0 and papel != "GOL":
			for k in livres.size():
				var d2: Dictionary = livres[k]
				if str(d2.get("cat", "")) != "GOL" and float(d2.get("overall", 0)) > ov:
					melhor = k
					ov = float(d2.get("overall", 0))
		if melhor >= 0:
			escolhidos.append(livres[melhor])
			livres.remove_at(melhor)
		else:
			escolhidos.append({})
	for sobra in livres:
		reservas_casa.insert(0, sobra)
	return escolhidos

func _criar_times() -> void:
	var titulares_casa: Array = _escolher_titulares()
	for t in 2:
		var linhas_f: Array = formacao_casa if t == 0 else (formacao_fora if not formacao_fora.is_empty() else FORMACAO)
		for i in linhas_f.size():
			var linha: Array = linhas_f[i]
			var j: Jogador = Jogador.new()
			j.time = t
			j.papel = str(linha[0])
			j.base_norm = Vector2(float(linha[1]), float(linha[2]))
			j.numero = int(linha[3])
			j.nome = str(NOMES_CASA[i % NOMES_CASA.size()]) if t == 0 else "ADV %d" % j.numero
			j.pele = [Color("f1c9a0"), Color("c68b5a"), Color("8d5a36"), Color("f1c9a0")][randi() % 4]
			j.cabelo = [Color("2b1b10"), Color("1d140c"), Color("b5651d"), Color("e6c15a")][randi() % 4]
			var gk: bool = j.papel == "GOL"
			if t == 0:
				j.cor1 = Color("F39C12") if gk else (cor_casa_1 if cor_casa_1.a > 0.0 else Cfg.COR_CASA)
				j.cor2 = Color("111111") if gk else (cor_casa_2 if cor_casa_2.a > 0.0 else Color("7B1E1E"))
			else:
				j.cor1 = Color("D4E157") if gk else (cor_fora_1 if cor_fora_1.a > 0.0 else Cfg.COR_FORA)
				j.cor2 = Color("111111") if gk else (cor_fora_2 if cor_fora_2.a > 0.0 else Color("F5F5F5"))
			j.cor_num = Color.BLACK if gk else Color.WHITE
			var forca: float = forca_casa if t == 0 else forca_fora
			var base: float = 0.84 * forca
			var dados: Dictionary = {}
			if t == 0 and i < titulares_casa.size() and not (titulares_casa[i] as Dictionary).is_empty():
				dados = titulares_casa[i]
				j.nome = str(dados.get("nome", j.nome))
				j.numero = int(dados.get("numero", j.numero))
				var ov: float = float(dados.get("overall", 76))
				var en: float = float(dados.get("energia", 100.0))
				var mo: float = float(dados.get("moral", 60.0))
				# overall 76 ≈ 0.84; 4 pontos de overall ≈ 0.016 (diferença comprimida p/ placares realistas)
				base = (0.84 + (ov - 76.0) * 0.004) * (0.92 + 0.08 * clampf(en, 0.0, 100.0) / 100.0) + (mo - 50.0) * 0.0006
			if t == 0:
				base += forma_casa * 0.012 + extra_prep * 0.004 + bonus_scout
				if not dados.is_empty():
					base += (float(dados.get("tecnica", 60.0)) - 60.0) * 0.0008
					j.fisico = float(dados.get("fisico", 60.0))
					j.tecnica = float(dados.get("tecnica", 60.0))
					j.jid = str(dados.get("id", ""))
					j.moral = float(dados.get("moral", 50.0))
					j.energia_ini = float(dados.get("energia", 100.0))
			j.atributos = _atributos_por_papel(j.papel, base)
			grupo.add_child(j)
			jogadores.append(j)
			times[t].append(j)

func _atributos_por_papel(papel: String, base: float) -> Dictionary:
	var b_chute: float = 0.0
	var b_passe: float = 0.0
	var b_des: float = 0.0
	match papel:
		"ATA":
			b_chute = 0.05
			b_des = -0.04
		"MEI":
			b_passe = 0.05
		"DEF":
			b_des = 0.05
			b_chute = -0.04
	return {
		"velocidade": clampf(base + randf_range(-0.07, 0.07), 0.55, 1.1),
		"chute": clampf(base + b_chute + randf_range(-0.08, 0.06), 0.45, 1.0),
		"passe": clampf(base + b_passe + randf_range(-0.08, 0.06), 0.45, 1.0),
		"desarme": clampf(base + b_des + randf_range(-0.08, 0.06), 0.45, 1.0),
		"drible": clampf(base + randf_range(-0.08, 0.06), 0.45, 1.0),
		"goleiro": clampf(base + 0.04 + randf_range(-0.04, 0.06), 0.5, 1.0),
	}

func _saida(time_da_saida: int) -> void:
	for j in jogadores:
		j.controlado = false      # evita ficar com 2+ jogadores marcados como controlados após a reinício
		j.anel = Color(0, 0, 0, 0)
		j.position = _pos_base(j, true)
		j.vel = Vector2.ZERO
		j.atordoado = 0.0
		j.investida = 0.0
		j.comemorando = 0.0
		j.cd_captura = 0.0
		j.carga = 0.0
		j.mergulhando = false
	bola.vel = Vector2.ZERO
	bola.z = 0.0
	bola.vz = 0.0
	bola.dono = null
	bola.position = Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5)
	var tl: Array = times[time_da_saida] as Array
	var tomador: Jogador = tl[tl.size() - 1] as Jogador
	var d: float = 1.0 if time_da_saida == 0 else -1.0
	tomador.position = Vector2(Cfg.PW * 0.5 - d * 14.0, Cfg.PH * 0.5)
	tomador.face = Vector2(d, 0.0)
	_tomar(tomador)
	estado = Estado.SAIDA
	timer = 1.2
	controlado = null
	_atualizar_controle(0.0)

func _pos_base(j: Jogador, saida: bool = false) -> Vector2:
	var nx: float = j.base_norm.x
	if saida:
		nx = minf(nx, 0.46)
	var x: float = nx * Cfg.PW
	if j.time == 1:
		x = Cfg.PW - x
	return Vector2(x, j.base_norm.y * Cfg.PH)

# ----------------------------------------------------------------- loop
func minuto() -> int:
	return clampi(int(tempo_real / DURACAO_REAL * 90.0), 0, 90)

func _mostrar(titulo: String, sub: String, dur: float) -> void:
	if vis != null:
		vis.banner(titulo, sub, dur)
	mensagem = titulo
	mensagem_sub = sub
	mensagem_t = dur

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("pausa") and estado != Estado.FIM:
		if ajuda_aberta:
			ajuda_aberta = false
			pausado = false
		else:
			pausado = not pausado
	if Input.is_action_just_pressed("ajuda") and estado != Estado.FIM:
		ajuda_aberta = not ajuda_aberta
		pausado = ajuda_aberta
	if Input.is_action_just_pressed("troca"):
		if pausado or estado == Estado.INTERVALO or estado == Estado.PARADO:
			if menu != null:
				menu.call("alternar_sub")
			else:
				substituir_controlado()
		elif estado == Estado.JOGANDO:
			_trocar_manual()
	if mensagem_t > 0.0:
		mensagem_t -= delta
		if mensagem_t <= 0.0:
			mensagem = ""

func _passo_fadiga(delta: float) -> void:
	for t in 2:
		var e: Dictionary = eixos[t]
		var taxa: float = 0.0028 * (1.0 + 0.30 * (int(e["pressao"]) - 1) + 0.15 * (int(e["linha"]) - 1)) * (1.2 if clima == "calor" else 1.0)
		cansaco[t] = minf(1.0, float(cansaco[t]) + taxa * delta)
		transicao[t] = maxf(0.0, float(transicao[t]) - delta)
	if bola.dono != null:
		estat["posse_t"][bola.dono.time] += delta

func _fadiga(p: Jogador) -> float:
	return clampf(float(cansaco[p.time]) + (1.0 - p.energia_ini / 100.0) * 0.5 - (p.fisico - 60.0) * 0.004, 0.0, 1.0)

func _vel_mult(p: Jogador) -> float:
	var m: float = 1.0 - 0.3 * _fadiga(p)
	if p.lesionado:
		m *= 0.7
	if p.papel != "GOL" and p.papel != "DEF" and int((eixos[p.time] as Dictionary)["construcao"]) == 2 and float(transicao[p.time]) > 0.0:
		m *= 1.03
	if p.papel != "GOL" and float(transicao[p.time]) > 0.0:
		m *= 1.0 + 0.05 * float(int((eixos[1 - p.time] as Dictionary)["linha"]) - 1)    # contra-ataque contra defesa adiantada é mais rápido
	return m

func _mult_erro(p: Jogador) -> float:
	## Moral baixa erra mais, moral alta erra menos (0.8 .. 1.25).
	return clampf(1.0 + (50.0 - p.moral) * 0.006, 0.8, 1.25) * (1.12 if clima == "chuva" else 1.0)

func _physics_process(delta: float) -> void:
	if pausado:
		return
	match estado:
		Estado.SAIDA:
			timer -= delta
			_passo_jogadores(delta)
			if timer <= 0.0:
				estado = Estado.JOGANDO
		Estado.JOGANDO:
			graca_fora = maxf(0.0, graca_fora - delta)
			_passo_fadiga(delta)
			tempo_real += delta
			_passo_jogadores(delta)
			_atualizar_bola(delta)
			_regras()
			_relogio()
		Estado.GOL:
			timer -= delta
			_passo_jogadores(delta)
			if timer <= 0.0:
				_saida(1 - _ultimo_marcador)
		Estado.PARADO:
			timer -= delta
			_passo_jogadores(delta)
			if timer <= 0.0:
				if reposicao_tomador != null:
					var dentro2: Vector2 = (Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5) - bola.position).normalized()
					reposicao_tomador.atordoado = 0.0
					reposicao_tomador.position = bola.position + dentro2 * 14.0
					reposicao_tomador.face = dentro2
					_tomar(reposicao_tomador)
					graca_fora = 0.8
				estado = Estado.JOGANDO
		Estado.BOLA_PARADA:
			_passo_bp(delta)
		Estado.INTERVALO:
			timer -= delta
			if timer <= 0.0:
				segundo_tempo = true
				_saida(1)
		Estado.FIM:
			pass

var _ultimo_marcador: int = 0

func _relogio() -> void:
	_substituicao_ia()
	if not segundo_tempo and tempo_real >= DURACAO_REAL * 0.5:
		estado = Estado.INTERVALO
		timer = 3.0
		_mostrar("INTERVALO", "%d - %d" % [int(gols[0]), int(gols[1])], 3.0)
	elif tempo_real >= DURACAO_REAL:
		estado = Estado.FIM
		var r: String = "VITÓRIA!" if int(gols[0]) > int(gols[1]) else ("DERROTA" if int(gols[0]) < int(gols[1]) else "EMPATE")
		_mostrar("FIM DE JOGO", "%s  %d - %d   %s" % [r, int(gols[0]), int(gols[1]), ("(toque para continuar)" if modo_carreira else "(R ou toque para jogar de novo)")], 9999.0)
		partida_terminada.emit(int(gols[0]), int(gols[1]))

func _passo_jogadores(delta: float) -> void:
	_calcular_perseguidores()
	_atualizar_controle(delta)
	for p in jogadores:
		_atualizar_jogador(p, delta)
	_separar()
	if estado == Estado.SAIDA or estado == Estado.PARADO or estado == Estado.GOL:
		_atualizar_bola_parada(delta)

func _separar() -> void:
	for i in range(jogadores.size()):
		var a: Jogador = jogadores[i]
		for k in range(i + 1, jogadores.size()):
			var b: Jogador = jogadores[k]
			var d: Vector2 = a.position - b.position
			var l: float = d.length()
			if l < 28.0 and l > 0.01:
				var empurra: Vector2 = d / l * (28.0 - l) * 0.5
				a.position += empurra
				b.position -= empurra

# ----------------------------------------------------------------- controle
func _time_com_bola() -> int:
	if bola.dono != null:
		return bola.dono.time
	return -1

func _mais_proximo(time: int, ponto: Vector2, so_goleiro: bool = false, incluir_goleiro: bool = false) -> Jogador:
	var melhor: Jogador = null
	var md: float = 1e12
	for q in (times[time] as Array):
		var j: Jogador = q as Jogador
		if so_goleiro and j.papel != "GOL":
			continue
		if not incluir_goleiro and not so_goleiro and j.papel == "GOL":
			continue
		var d: float = j.position.distance_to(ponto)
		if d < md:
			md = d
			melhor = j
	return melhor

func _calcular_perseguidores() -> void:
	marcacao.clear()
	var cb: int = _time_com_bola()
	for t in 2:
		var lista: Array = []
		for q in (times[t] as Array):
			var j: Jogador = q as Jogador
			if j.papel != "GOL":
				lista.append(j)
		lista.sort_custom(func(a: Jogador, b: Jogador) -> bool:
			return a.position.distance_squared_to(bola.position) < b.position.distance_squared_to(bola.position))
		var n: int = 2
		if cb == t:
			n = 0
		elif cb == 1 - t:
			n = 1        # um pressiona; o segundo cobre; os demais marcam
		perseguidores[t] = lista.slice(0, n)
		cobertura[t] = lista[1] if (cb == 1 - t and lista.size() > 1) else null
		if cb != t:
			_atribuir_marcacao(t, lista.slice(n + (1 if cb == 1 - t else 0)))

func _atribuir_marcacao(t: int, livres: Array) -> void:
	## Cada marcador livre fica com o adversário mais perigoso (mais perto do nosso gol) ainda sem marcação.
	if livres.is_empty():
		return
	var gol_p: Vector2 = Vector2(0.0 if t == 0 else Cfg.PW, Cfg.PH * 0.5)
	var rivais: Array = []
	for q in (times[1 - t] as Array):
		var o: Jogador = q as Jogador
		if o.papel != "GOL" and o != bola.dono:
			rivais.append(o)
	rivais.sort_custom(func(a: Jogador, b: Jogador) -> bool:
		return a.position.distance_squared_to(gol_p) < b.position.distance_squared_to(gol_p))
	var disponiveis: Array = livres.duplicate()
	for o in rivais:
		if disponiveis.is_empty():
			break
		var melhor: Jogador = null
		var md: float = 1e12
		for m in disponiveis:
			var dd: float = (m as Jogador).position.distance_squared_to((o as Jogador).position)
			if dd < md:
				md = dd
				melhor = m
		marcacao[melhor] = o
		disponiveis.erase(melhor)

func _atualizar_controle(delta: float) -> void:
	cd_troca -= delta
	var alvo: Jogador = controlado
	if bola.dono != null and bola.dono.time == 0 and bola.dono.papel != "GOL":
		alvo = bola.dono         # o goleiro nunca é controlado pelo jogador
	elif cd_troca <= 0.0 or controlado == null:
		var n: Jogador = _mais_proximo(0, bola.position)
		if controlado == null or controlado.papel == "GOL" or controlado.time != 0:
			alvo = n
		elif n != controlado:
			var dc: float = controlado.position.distance_to(bola.position)
			var dn: float = n.position.distance_to(bola.position)
			if dn + 45.0 < dc:
				alvo = n
		cd_troca = 0.2
	if alvo != controlado:
		if controlado != null:
			controlado.controlado = false
			controlado.carga = 0.0
		controlado = alvo
		controlado.controlado = true
	# anéis: vermelho no controlado, azul no rival mais perto da bola
	for j in jogadores:
		j.anel = Color(0, 0, 0, 0)
	if controlado != null:
		controlado.anel = Color("ff3b3b")
	var rival: Jogador = _mais_proximo(1, bola.position)
	if rival != null:
		rival.anel = Color("4a7bff")

func _mover(p: Jogador, dir: Vector2, vmax: float, delta: float) -> void:
	p.vel = p.vel.move_toward(dir * vmax, 1500.0 * delta)
	p.position += p.vel * delta
	if p.vel.length() > 25.0:
		p.face = p.vel.normalized()
	p.position.x = clampf(p.position.x, -70.0, Cfg.PW + 70.0)
	p.position.y = clampf(p.position.y, -70.0, Cfg.PH + 70.0)

func _atualizar_jogador(p: Jogador, delta: float) -> void:
	p.cd_captura = maxf(0.0, p.cd_captura - delta)
	p.cd_desarme = maxf(0.0, p.cd_desarme - delta)
	p.cd_defesa = maxf(0.0, p.cd_defesa - delta)
	if p.comemorando > 0.0:
		p.comemorando -= delta
		p.vel = Vector2.ZERO
		return
	if p.atordoado > 0.0:
		p.atordoado -= delta
		_mover(p, Vector2.ZERO, 0.0, delta)
		return
	if estado == Estado.INTERVALO or estado == Estado.FIM:
		return
	if p.controlado and not piloto_auto:
		_controle_humano(p, delta)
	elif p.papel == "GOL":
		_ia_goleiro(p, delta)
	else:
		_ia_campo(p, delta)

func _controle_humano(p: Jogador, delta: float) -> void:
	var m: Vector2 = Input.get_vector("esq", "dir", "cima", "baixo")
	var quer_correr: bool = Input.is_action_pressed("correr") and not sem_folego and m.length() > 0.2
	if quer_correr:
		estamina = maxf(0.0, estamina - 0.3 * (1.0 + 0.25 * (int((eixos[0] as Dictionary)["pressao"]) - 1)) * delta)
		if estamina <= 0.0:
			sem_folego = true
	else:
		estamina = minf(1.0, estamina + 0.18 * delta)
		if sem_folego and estamina > 0.3:
			sem_folego = false
	var vmax: float = 300.0 * p.habil("velocidade") * (1.3 if quer_correr else 1.0) * _vel_mult(p)
	if bola.dono == p:
		vmax *= 0.92
	# investida (desarme com deslize)
	if p.investida > 0.0:
		p.investida -= delta
		_mover(p, p.investida_dir, vmax * (1.9 if p.invest_tipo == "carrinho" else 1.35), delta)
		_investida_toca(p)
		if p.investida <= 0.0:
			p.atordoado = RECUPERA_CARRINHO if p.invest_tipo == "carrinho" else RECUPERA_PE      # errou o tempo: fica fora do lance
		return
	_mover(p, m, vmax, delta)
	var aim: Vector2 = m if m.length() > 0.3 else p.face
	if estado != Estado.JOGANDO:
		return
	if bola.dono == p:
		if Input.is_action_just_pressed("passe"):
			_passe(p, aim)
		elif Input.is_action_just_pressed("lob"):
			_passe(p, aim, true)
		elif Input.is_action_pressed("chute"):
			p.carga = minf(1.0, p.carga + 1.5 * delta)
		elif p.carga > 0.0:
			_chute_humano(p, m, p.carga)
			p.carga = 0.0
	else:
		p.carga = 0.0
		if Input.is_action_just_pressed("passe"):
			_trocar_manual()
		elif Input.is_action_just_pressed("chute") and p.cd_desarme <= 0.0:
			_iniciar_investida(p, aim, "pe")          # K sem a bola: desarme em pé
		elif Input.is_action_just_pressed("lob") and p.cd_desarme <= 0.0:
			_iniciar_investida(p, aim, "carrinho")    # I sem a bola: carrinho

func _trocar_manual() -> void:
	var melhor: Jogador = null
	var md: float = 1e9
	for q in (times[0] as Array):
		var j: Jogador = q as Jogador
		if j == controlado or j.papel == "GOL":
			continue
		var d: float = j.position.distance_squared_to(bola.position)
		if d < md:
			md = d
			melhor = j
	if melhor == null:
		return
	if controlado != null:
		controlado.controlado = false
		controlado.carga = 0.0
	controlado = melhor
	controlado.controlado = true
	cd_troca = 0.9

const RECUPERA_PE := 0.22
const RECUPERA_CARRINHO := 0.5
const ALCANCE_PE := 34.0
const ALCANCE_CARRINHO := 42.0

## Começa um desarme. Sem direção nas setas, mira sozinho no portador (ou na bola) quando está perto: o jogador não precisa "acertar" o ângulo.
func _iniciar_investida(p: Jogador, aim: Vector2, tipo: String) -> void:
	var dir: Vector2 = aim
	var alvo: Vector2 = bola.dono.position if (bola.dono != null and bola.dono.time != p.time) else bola.position
	var m: Vector2 = Input.get_vector("esq", "dir", "cima", "baixo")
	if m.length() < 0.3 and p.position.distance_to(alvo) < 170.0:
		dir = (alvo - p.position).normalized()
	elif m.length() >= 0.3 and p.position.distance_to(alvo) < 170.0:
		var ao_alvo: Vector2 = (alvo - p.position).normalized()
		if m.normalized().dot(ao_alvo) > 0.55:
			dir = (m.normalized() * 0.55 + ao_alvo * 0.45).normalized()      # leve ímã para o portador quando você já vai na direção dele
	p.invest_tipo = tipo
	p.investida = 0.34 if tipo == "carrinho" else 0.17
	p.investida_dir = dir.normalized()
	p.cd_desarme = 1.5 if tipo == "carrinho" else 0.55

func _investida_toca(p: Jogador) -> void:
	var carr: bool = p.invest_tipo == "carrinho"
	var alcance: float = ALCANCE_CARRINHO if carr else ALCANCE_PE
	# 1) portador da bola ao alcance: resolve o desarme (limpo, falha ou falta)
	if bola.dono != null and bola.dono.time != p.time and not bola.dono.expulso:
		if p.position.distance_to(bola.dono.position) < alcance:
			p.investida = 0.0
			_resolver_desarme(p, bola.dono, carr)
			return
	# 2) bola solta ao alcance: recupera de graça
	elif bola.dono == null and p.position.distance_to(bola.position) < alcance and bola.z < 40.0:
		_tomar(p)
		_feedback(p, "BOLA!", Color("7BD36B"))
		p.investida = 0.0
		return
	# 3) carrinho não atravessa ninguém: ao derrubar um adversário SEM a bola é falta quase certa
	if carr:
		for q in jogadores:
			var o: Jogador = q as Jogador
			if o.time == p.time or o.expulso or o == bola.dono or o.atordoado > 0.0:
				continue
			if p.position.distance_to(o.position) < 24.0:
				p.investida = 0.0
				o.atordoado = 0.45
				o.vel = o.vel * 0.3 + p.investida_dir * 60.0
				if bola.position.distance_to(o.position) > 60.0 and randf() < 0.75:
					_falta(p, o, 0.7)
				return

## Resolve um desarme contra o portador. A chance depende de desarme × drible, do tipo (carrinho alcança mais mas pune o erro),
## da velocidade do driblador e do ângulo: vir de trás aumenta muito o risco de falta.
func _resolver_desarme(p: Jogador, dono: Jogador, carrinho: bool) -> void:
	var pos_rel: Vector2 = (dono.position - p.position).normalized()
	var por_tras: bool = pos_rel.dot(dono.face) > 0.45        # o portador olha para longe de quem desarma
	var chance: float = 0.5 + 0.3 * p.habil("desarme") - 0.28 * dono.habil("drible")
	if carrinho:
		chance += 0.08
	if dono.vel.length() > 230.0:
		chance -= 0.08                                       # driblador em velocidade é mais difícil de parar
	chance = clampf(chance, 0.15, 0.9)
	if randf() < chance:
		if por_tras and carrinho and randf() < 0.35:
			_falta(p, dono, 0.8)                             # pegou a bola, mas por trás e em carrinho: o árbitro pode marcar
			return
		_roubar(p, dono)
		_feedback(p, "DESARME!", Color("7BD36B"))
		return
	# errou: se a bola ficou com o portador, a falta depende do tipo e do ângulo
	var risco: float = 0.5 if carrinho else 0.16
	if por_tras:
		risco *= 1.6
	if estado == Estado.JOGANDO and randf() < risco:
		_falta(p, dono, (0.5 if carrinho else 0.12) + (0.3 if por_tras else 0.0))
	else:
		_feedback(p, "ERROU!", Color("FF8A5B"))

func _feedback(j: Jogador, txt: String, cor: Color) -> void:
	if vis != null and j.time == 0:
		vis.flutuar(j.position, txt, cor)

func _roubar(ladrao: Jogador, vitima: Jogador) -> void:
	estat["roubos"][ladrao.time] += 1
	vitima.atordoado = 0.35
	vitima.cd_captura = 0.6
	_tomar(ladrao)
	bola.vel = ladrao.face * 90.0

func _tomar(p: Jogador) -> void:
	if bola.ultimo_jogador != null and bola.ultimo_time != p.time:
		transicao[p.time] = 4.0          # recuperou a bola: contra-ataque
	bola.dono = p
	bola.ultimo_time = p.time
	bola.ultimo_jogador = p
	bola.vel = Vector2.ZERO
	bola.z = 0.0
	bola.vz = 0.0
	p.carga = 0.0
	if p.papel == "GOL":
		p.segurando = 2.0                # tempo mínimo para o time se arrumar antes da reposição

# ----------------------------------------------------------------- passe e chute
func _passe(p: Jogador, aim: Vector2, alto: bool = false) -> void:
	var alvo: Jogador = null
	var melhor: float = -999.0
	for q in (times[p.time] as Array):
		var j: Jogador = q as Jogador
		if j == p or j.papel == "GOL":
			continue
		var v: Vector2 = j.position - p.position
		var dist: float = v.length()
		if dist < 70.0 or dist > 1100.0:
			continue
		var cosa: float = aim.normalized().dot(v.normalized())
		if cosa < 0.55:
			continue
		var score: float = cosa * 2.0 - dist / 1200.0
		if score > melhor:
			melhor = score
			alvo = j
	_executar_passe(p, alvo, aim, alto)

func _executar_passe(p: Jogador, alvo: Jogador, aim: Vector2, alto: bool = false) -> void:
	var dir: Vector2 = aim.normalized()
	var dist: float = 500.0
	if alvo != null:
		var mira: Vector2 = alvo.position + alvo.vel * 0.45
		dir = (mira - p.position).normalized()
		dist = p.position.distance_to(mira)
	var passe: float = p.habil("passe")
	var cm: float = 1.0
	if not p.controlado:
		cm = [0.8, 2.0, 1.15][int((eixos[p.time] as Dictionary)["construcao"])]
		if p.time == 0:
			cm *= clampf(1.0 + (60.0 - entrosamento_casa) * 0.004, 0.75, 1.3)
	dir = dir.rotated(randf_range(-1.0, 1.0) * (1.0 - passe) * 0.18 * _mult_erro(p) * cm)
	if alvo != null:
		estat["dist_passes"][p.time] += dist
	var vel: float = clampf(430.0 + dist * 0.75, 500.0, 950.0)
	var vz0: float = 0.0
	if alto:
		vel = clampf(dist / 0.95, 380.0, 1150.0)
		vz0 = 370.0
	bola.chutar(dir, vel, vz0, p)
	estat["passes"][p.time] += 1
	p.cd_captura = 0.35

func _chute_humano(p: Jogador, m: Vector2, carga: float) -> void:
	var gol: Vector2 = Vector2(Cfg.PW if p.time == 0 else 0.0, Cfg.PH * 0.5)
	var para_gol: Vector2 = (gol - p.position).normalized()
	var dir: Vector2 = para_gol
	if m.length() <= 0.3:
		# sem direção: mira no canto oposto ao goleiro
		var gk: Jogador = _mais_proximo(1 - p.time, gol, true)
		var lado: float = -1.0 if gk != null and gk.position.y > Cfg.PH * 0.5 else 1.0
		dir = (Vector2(gol.x, gol.y + lado * 85.0) - p.position).normalized()
	if m.length() > 0.3:
		dir = m.normalized()
		if absf(dir.angle_to(para_gol)) < 1.1:
			dir = dir.lerp(para_gol, 0.4).normalized()
	_disparar(p, dir, carga)

func _disparar(p: Jogador, dir: Vector2, carga: float) -> void:
	var chute: float = p.habil("chute")
	var potencia: float = 0.45 + 0.55 * carga
	var vel: float = (560.0 + 700.0 * potencia) * (0.85 + 0.15 * chute)
	var erro: float = randf_range(-1.0, 1.0) * ((1.0 - chute) * 0.22 + carga * 0.07) * _mult_erro(p) * [1.2, 1.0, 0.88][int((eixos[1 - p.time] as Dictionary)["linha"])] * (0.8 if float(transicao[p.time]) > 0.0 and int((eixos[1 - p.time] as Dictionary)["linha"]) == 2 else 1.0)   # defesa recuada fecha o gol; adiantada sofre no contra-ataque
	var vz: float = 100.0 + 340.0 * pow(carga, 1.5)
	bola.chutar(dir.rotated(erro), vel, vz, p)
	estat["chutes"][p.time] += 1
	p.cd_captura = 0.4

# ----------------------------------------------------------------- IA
func _ia_campo(p: Jogador, delta: float) -> void:
	var vmax: float = 285.0 * p.habil("velocidade") * _vel_mult(p)
	if bola.dono == p:
		if estado != Estado.JOGANDO:
			_mover(p, Vector2.ZERO, 0.0, delta)
			return
		var dir: Vector2 = _ia_com_bola(p, delta)
		_mover(p, dir, vmax * 0.9, delta)
		return
	var com_bola: int = _time_com_bola()
	var alvo: Vector2 = _posicao_tatica(p, com_bola)
	var gk_rival: bool = com_bola >= 0 and com_bola != p.time and bola.dono != null and bola.dono.papel == "GOL"
	if (perseguidores[p.time] as Array).has(p) and not gk_rival:
		alvo = bola.position + bola.vel * 0.2
		if com_bola >= 0 and com_bola != p.time:
			alvo = bola.dono.position + bola.dono.face * 18.0
	var v: Vector2 = alvo - p.position
	var dist: float = v.length()
	var dir2: Vector2 = Vector2.ZERO
	if dist > 8.0:
		dir2 = v.normalized() * minf(1.0, dist / 70.0)
	_mover(p, dir2, vmax, delta)
	# desarme automático da IA (e do jogador quando está marcando sem investida)
	if com_bola >= 0 and com_bola != p.time and p.cd_desarme <= 0.0 and p.papel != "GOL":
		if p.position.distance_to(bola.position) < 28.0:
			p.cd_desarme = 0.6
			var dono: Jogador = bola.dono
			var prs: int = int((eixos[p.time] as Dictionary)["pressao"])
			var chance: float = 0.30 * p.habil("desarme") / maxf(0.45, dono.habil("drible")) * 1.0 * (1.0 + 0.15 * float(prs - 1) * clampf(1.3 - 1.2 * float(cansaco[p.time]), 0.3, 1.3))
			if randf() < chance:
				_roubar(p, dono)
			elif randf() < 0.07 + 0.03 * float(prs - 1) and estado == Estado.JOGANDO:
				_falta(p, dono, 0.12)

func _espaco_livre(p: Jogador, candidatos: Array) -> Vector2:
	## Entre pontos candidatos, o que fica mais longe dos adversários (apoio/desmarque).
	var melhor: Vector2 = candidatos[0]
	var ms: float = -1.0
	for c in candidatos:
		var m: float = 1e9
		for q in (times[1 - p.time] as Array):
			m = minf(m, (q as Jogador).position.distance_to(c))
		if m > ms:
			ms = m
			melhor = c
	return melhor

func _posicao_tatica(p: Jogador, com_bola: int) -> Vector2:
	var t: int = p.time
	var d: float = 1.0 if t == 0 else -1.0
	var cy: float = Cfg.PH * 0.5
	var base: Vector2 = _pos_base(p)
	var nivel: float = float(nivel_ia[t])
	var gol_p: Vector2 = Vector2(0.0 if t == 0 else Cfg.PW, cy)
	var alvo: Vector2 = base
	var pr: int = int((eixos[t] as Dictionary)["pressao"])
	var sc: float = Cfg.PW / 2200.0          # escala do campo (1,0 no FUT7; 1,5 no 11x11)
	if com_bola == t:
		var dono: Jogador = bola.dono
		if dono.papel == "GOL":
			return _posicao_reposicao_goleiro(p, base, d)
		var fator_tat: float = 0.0
		var cache: Array = _ataque_cache.get(p, [])
		if cache.is_empty() or tempo_real - float(cache[1]) > 0.7 or estado != Estado.JOGANDO:
			var pos: Vector2
			if p.papel == "ATA":
				var x: float = clampf(maxf(base.x + d * Cfg.PW * 0.1, dono.position.x + d * 330.0 * sc) if d > 0.0 else minf(base.x + d * Cfg.PW * 0.1, dono.position.x + d * 330.0 * sc), 180.0, Cfg.PW - 180.0)
				pos = _espaco_livre(p, [Vector2(x, cy - 330.0 * sc), Vector2(x, cy), Vector2(x, cy + 330.0 * sc), Vector2(x, dono.position.y)])
			elif p.papel == "MEI":
				var x2: float = clampf(dono.position.x + d * 200.0 * sc + fator_tat, 140.0, Cfg.PW - 140.0)
				var lado: float = -1.0 if base.y < cy - 50.0 else (1.0 if base.y > cy + 50.0 else signf(cy - dono.position.y))
				pos = _espaco_livre(p, [Vector2(x2, clampf(dono.position.y + lado * 300.0 * sc, 120.0, Cfg.PH - 120.0)), Vector2(x2 - d * 90.0 * sc, cy + lado * 160.0 * sc), Vector2(x2 + d * 120.0 * sc, clampf(base.y, 120.0, Cfg.PH - 120.0))])
			else:
				pos = Vector2(clampf(dono.position.x - d * 340.0 * sc, 130.0, Cfg.PW - 130.0), base.y + (dono.position.y - cy) * 0.25)
			if sc > 1.2:     # 11x11: o time mantém a forma (não se amontoa em volta da bola)
				pos = pos.lerp(Vector2(lerpf(base.x, dono.position.x, 0.55), base.y + (dono.position.y - cy) * 0.2), 0.4)
			cache = [pos, tempo_real]
			_ataque_cache[p] = cache
		alvo = cache[0]
	else:
		var comp: Jogador = cobertura[t] as Jogador if cobertura[t] != null else null
		if com_bola >= 0 and comp == p:
			var dono2: Jogador = bola.dono
			alvo = dono2.position + (gol_p - dono2.position).normalized() * (115.0 - 35.0 * nivel - 20.0 * float(pr - 1))
		elif marcacao.has(p):
			var o: Jogador = marcacao[p]
			alvo = o.position + (gol_p - o.position).normalized() * (70.0 - 28.0 * nivel - 16.0 * float(pr - 1))
			alvo = alvo.lerp(bola.position, 0.1)
		else:
			var prog: float = bola.position.x / Cfg.PW if t == 0 else 1.0 - bola.position.x / Cfg.PW
			var fator: float = 0.45 if p.papel == "DEF" else (0.7 if p.papel == "MEI" else 0.9)
			var avance: float = (prog - 0.5) * Cfg.PW * 0.5 * fator - (Cfg.PW * 0.03 if com_bola >= 0 else 0.0)
			alvo = Vector2(base.x + d * avance, base.y + (bola.position.y - cy) * 0.32)
	if p.papel != "GOL":
		var li: int = int((eixos[t] as Dictionary)["linha"])
		alvo.x += d * (float(li - 1) * Cfg.PW * 0.04 if com_bola == t else maxf(0.0, float(li - 1)) * Cfg.PW * 0.035)
		if com_bola == t and int((eixos[t] as Dictionary)["construcao"]) == 2 and float(transicao[t]) > 0.0 and p.papel != "DEF":
			alvo.x += d * Cfg.PW * 0.05          # contra-ataque: sai em velocidade
		if com_bola >= 0 and com_bola != t and bola.dono != null and bola.dono.papel == "GOL":
			# goleiro rival com a bola: o time não invade a área; a linha de pressão depende do eixo "pressão"
			var lim: float = Cfg.PW * [0.58, 0.46, 0.34][pr]
			alvo.x = maxf(alvo.x, lim) if com_bola == 0 else minf(alvo.x, Cfg.PW - lim)
	# disciplina de posição: cada jogador de linha fica numa "coleira" em torno da sua posição na formação (que acompanha a bola),
	# então o time mantém a forma e não se amontoa em volta dela (só o marcador da bola e a cobertura saem da zona)
	if p.papel != "GOL" and not (perseguidores[t] as Array).has(p) and cobertura[t] != p and not (com_bola == t and bola.dono != null and bola.dono.papel == "GOL"):
		var prog2: float = bola.position.x / Cfg.PW if t == 0 else 1.0 - bola.position.x / Cfg.PW
		var rol_f: float = 0.35 if p.papel == "DEF" else (0.55 if p.papel == "MEI" else 0.75)
		var ancora: Vector2 = base + Vector2(d * (prog2 - 0.5) * Cfg.PW * 0.45 * rol_f, 0.0)
		var raio: float = (COLEIRA_DEF if p.papel == "DEF" else (COLEIRA_MEI if p.papel == "MEI" else COLEIRA_ATA)) * sc
		var desvio: Vector2 = alvo - ancora
		if desvio.length() > raio:
			alvo = ancora + desvio.normalized() * raio
	return Vector2(clampf(alvo.x, 70.0, Cfg.PW - 70.0), clampf(alvo.y, 90.0, Cfg.PH - 90.0))

const COLEIRA_DEF := 230.0
const COLEIRA_MEI := 300.0
const COLEIRA_ATA := 360.0

## Goleiro com a bola: cada companheiro procura o espaço livre da sua zona (longe dos adversários).
func _posicao_reposicao_goleiro(p: Jogador, base: Vector2, d: float) -> Vector2:
	if p.papel == "GOL":
		return base
	var cache: Array = _ataque_cache.get(p, [])
	if cache.is_empty() or tempo_real - float(cache[1]) > 0.5:
		var fx: float = base.x + d * Cfg.PW * (0.04 if p.papel == "DEF" else 0.08)
		fx = clampf(fx, 150.0, Cfg.PW - 150.0)
		var cands: Array = []
		for dy in [-190.0, 0.0, 190.0]:
			for dx in [-70.0, 40.0, 150.0]:
				cands.append(Vector2(clampf(fx + d * float(dx), 150.0, Cfg.PW - 150.0), clampf(base.y + float(dy), 120.0, Cfg.PH - 120.0)))
		cache = [_espaco_livre(p, cands), tempo_real]
		_ataque_cache[p] = cache
	return cache[0]

func _oponente_proximo(p: Jogador, raio: float) -> bool:
	for q in (times[1 - p.time] as Array):
		var j: Jogador = q as Jogador
		if j.position.distance_to(p.position) < raio:
			return true
	return false

func _ia_com_bola(p: Jogador, delta: float) -> Vector2:
	p.pensar -= delta
	var gol: Vector2 = Vector2(Cfg.PW if p.time == 0 else 0.0, Cfg.PH * 0.5)
	var para_gol: Vector2 = gol - p.position
	var dist_gol: float = para_gol.length()
	var pressionado: bool = _oponente_proximo(p, 85.0)
	if p.pensar <= 0.0:
		p.pensar = randf_range(0.18, 0.4) * (1.25 - 0.5 * float(nivel_ia[p.time]))
		if dist_gol < 640.0 * (1.0 + 0.8 * (Cfg.PW / 2200.0 - 1.0)) and randf() < (0.8 if Cfg.MODO_11 else 0.62):
			var alvo_gol: Vector2 = gol + Vector2(0.0, randf_range(-95.0, 95.0))
			_disparar(p, (alvo_gol - p.position).normalized(), randf_range(0.3, 0.65))
			return Vector2.ZERO
		if pressionado and randf() < 0.7:
			if _passe_ia(p):
				return Vector2.ZERO
	var dir: Vector2 = para_gol.normalized()
	for q in (times[1 - p.time] as Array):
		var j: Jogador = q as Jogador
		var rel: Vector2 = j.position - p.position
		if rel.length() < 140.0 and rel.dot(dir) > 0.0:
			var lado: float = signf(dir.cross(rel))
			dir = dir.rotated(-lado * 0.55)
	return dir.normalized()

func _passe_ia(p: Jogador) -> bool:
	var d: float = 1.0 if p.time == 0 else -1.0
	var alvo: Jogador = null
	var melhor: float = -999.0
	var cons: int = int((eixos[p.time] as Dictionary)["construcao"])
	var em_trans: bool = cons == 2 and float(transicao[p.time]) > 0.0
	var dmax: float = 1100.0 if cons == 1 else 900.0
	var peso_prog: float = [0.95, 1.2, 1.0][cons] * (1.9 if em_trans else 1.0)
	var peso_dist: float = [900.0, 3200.0, 1500.0][cons]
	for q in (times[p.time] as Array):
		var j: Jogador = q as Jogador
		if j == p or j.papel == "GOL":
			continue
		var dist: float = j.position.distance_to(p.position)
		if dist < 90.0 or dist > dmax:
			continue
		var progresso: float = peso_prog * d * (j.position.x - p.position.x) / 600.0
		var aberto: float = 0.0
		var mais_perto: float = 1e9
		for r in (times[1 - p.time] as Array):
			mais_perto = minf(mais_perto, (r as Jogador).position.distance_to(j.position))
		aberto = minf(mais_perto, 260.0) / 260.0
		var seg: Vector2 = j.position - p.position
		var bloqueado: bool = false
		for r2 in (times[1 - p.time] as Array):
			var o2: Jogador = r2 as Jogador
			var tt: float = clampf((o2.position - p.position).dot(seg) / maxf(seg.length_squared(), 1.0), 0.0, 1.0)
			if (p.position + seg * tt).distance_to(o2.position) < 45.0:
				bloqueado = true
				break
		var score: float = progresso + aberto * 1.4 - dist / peso_dist - (1.3 if bloqueado else 0.0)
		if score > melhor:
			melhor = score
			alvo = j
	if alvo == null:
		return false
	_executar_passe(p, alvo, (alvo.position - p.position))
	return true

func _alvo_livre_goleiro(g: Jogador) -> Jogador:
	## Companheiro livre para a reposição: longe dos marcadores e com a linha de passe desimpedida.
	var melhor: Jogador = null
	var ms: float = 0.45
	for q in (times[g.time] as Array):
		var j: Jogador = q as Jogador
		if j == g or j.papel == "GOL" or j.expulso:
			continue
		var d: float = j.position.distance_to(g.position)
		if d < 150.0 or d > 1200.0:
			continue
		var livre: float = 260.0
		var linha_ok: bool = true
		var seg: Vector2 = j.position - g.position
		for r in (times[1 - g.time] as Array):
			var o: Jogador = r as Jogador
			livre = minf(livre, o.position.distance_to(j.position))
			var t: float = clampf((o.position - g.position).dot(seg) / maxf(seg.length_squared(), 1.0), 0.0, 1.0)
			if (g.position + seg * t).distance_to(o.position) < 55.0:
				linha_ok = false
		if not linha_ok:
			continue
		var score: float = livre / 260.0 + (0.25 if j.papel == "DEF" else 0.0) - d / 3000.0
		if score > ms:
			ms = score
			melhor = j
	return melhor

func _ia_goleiro(p: Jogador, delta: float) -> void:
	var hab: float = p.habil("goleiro")
	if bola.dono == p:
		p.segurando -= delta
		_mover(p, Vector2.ZERO, 0.0, delta)
		reposicao_goleiro = p.time
		if p.segurando <= 0.0 and estado == Estado.JOGANDO:
			var alvo: Jogador = _alvo_livre_goleiro(p)
			if alvo == null and p.segurando > -3.0:
				return          # espera o time se arrumar (até 5 s no total)
			reposicao_goleiro = -1
			if alvo == null:
				alvo = _mais_proximo(p.time, Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5))   # sem opção: bola longa para o meio
			_executar_passe(p, alvo, Vector2(1.0 if p.time == 0 else -1.0, 0.0))
		return
	if reposicao_goleiro == p.time:
		reposicao_goleiro = -1
	var gx: float = 70.0 if p.time == 0 else Cfg.PW - 70.0
	var cy: float = Cfg.PH * 0.5
	var alvo_y: float = cy + (bola.position.y - cy) * 0.32
	var vmax: float = 260.0 * hab
	var antes: bool = p.mergulhando
	p.mergulhando = false
	var rumo: float = -1.0 if p.time == 0 else 1.0
	if bola.dono == null and bola.vel.x * rumo > 120.0:
		var t: float = (gx - bola.position.x) / bola.vel.x
		if t > 0.0 and t < 0.9:
			if not antes:
				p.erro_y = randf_range(-1.0, 1.0) * (1.25 - hab) * 170.0
			alvo_y = bola.position.y + bola.vel.y * t + p.erro_y
			vmax = 400.0 * hab
			p.mergulhando = true
	alvo_y = clampf(alvo_y, cy - 190.0, cy + 190.0)
	var alvo_pos: Vector2 = Vector2(gx, alvo_y)
	if bola.dono == null and bola.vel.length() < 170.0 and bola.position.distance_to(Vector2(gx, cy)) < 320.0:
		alvo_pos = bola.position
	var v: Vector2 = alvo_pos - p.position
	var dir: Vector2 = Vector2.ZERO
	if v.length() > 6.0:
		dir = v.normalized() * minf(1.0, v.length() / 35.0)
	_mover(p, dir, vmax, delta)

# ----------------------------------------------------------------- bola
func _atualizar_bola_parada(delta: float) -> void:
	if bola.dono != null:
		var d: Jogador = bola.dono
		bola.position = bola.position.lerp(d.position + d.face * 16.0, minf(1.0, 18.0 * delta))

func _atualizar_bola(delta: float) -> void:
	if bola.dono != null:
		var d: Jogador = bola.dono
		var alvo: Vector2 = d.position + d.face * 16.0
		bola.position = bola.position.lerp(alvo, minf(1.0, 18.0 * delta))
		bola.vel = d.vel
		bola.z = 0.0
		bola.vz = 0.0
		bola.rot += d.vel.length() * delta * 0.06
		return
	bola.position += bola.vel * delta
	bola.vel = bola.vel.move_toward(Vector2.ZERO, (120.0 + bola.vel.length() * 0.35) * delta)
	bola.rot += bola.vel.length() * delta * 0.06
	bola.z += bola.vz * delta
	bola.vz -= 700.0 * delta
	if bola.z < 0.0:
		bola.z = 0.0
		if absf(bola.vz) > 120.0:
			bola.vz = -bola.vz * 0.5
		else:
			bola.vz = 0.0
	_tentar_captura()

func _tentar_captura() -> void:
	var melhor: Jogador = null
	var md: float = 1e9
	var vb: float = bola.vel.length()
	for q in jogadores:
		var p: Jogador = q
		if p.cd_captura > 0.0 or p.atordoado > 0.0:
			continue
		var gk: bool = p.papel == "GOL"
		var alcance: float = 38.0 if gk else 24.0
		var d: float = p.position.distance_to(bola.position)
		if d > alcance or bola.z > (70.0 if gk else 45.0):
			continue
		if gk:
			if p.cd_defesa > 0.0:
				continue
			p.cd_defesa = 0.7
			var chance: float = clampf(1.1 * p.habil("goleiro") - vb / 1500.0, 0.2, 0.92)
			if randf() < chance:
				estat["defesas"][p.time] += 1
				if vb > 820.0 and randf() < 0.5:
					# defesa difícil: espalma para o lado/escanteio em vez de segurar
					var lado_f: float = 1.0 if p.position.x < Cfg.PW * 0.5 else -1.0
					var lat: float = signf(bola.position.y - Cfg.PH * 0.5)
					if lat == 0.0:
						lat = 1.0 if randf() < 0.5 else -1.0
					bola.vel = Vector2(lado_f * randf_range(120.0, 260.0), lat * randf_range(380.0, 620.0))
					bola.vz = randf_range(60.0, 220.0)
					bola.ultimo_time = p.time
					bola.ultimo_jogador = p
					p.cd_captura = 0.45
				else:
					melhor = p
					md = -1.0
			else:
				var fora: float = 1.0 if p.position.x < Cfg.PW * 0.5 else -1.0
				bola.vel = Vector2(fora * randf_range(180.0, 380.0), randf_range(-320.0, 320.0))
				bola.vz = randf_range(0.0, 200.0)
				bola.ultimo_time = p.time
				bola.ultimo_jogador = p
				p.cd_captura = 0.3
			continue
		if vb > 700.0 and randf() > 0.35:
			continue
		if d < md:
			md = d
			melhor = p
	if melhor != null:
		_tomar(melhor)

# ----------------------------------------------------------------- regras
func _regras() -> void:
	var b: Vector2 = bola.position
	var cy: float = Cfg.PH * 0.5
	if b.x < 0.0 or b.x > Cfg.PW:
		var na_boca: bool = absf(b.y - cy) < Cfg.GOL_METADE and bola.z < Cfg.ALTURA_TRAVE
		if na_boca:
			_gol(1 if b.x < 0.0 else 0)
			return
		if graca_fora > 0.0:
			return
		# linha de fundo
		var esq: bool = b.x < 0.0
		var ult: int = bola.ultimo_time
		if esq:
			if ult == 0:
				_reposicao(1, Vector2(10.0, 10.0 if b.y < cy else Cfg.PH - 10.0), false)
			else:
				_reposicao(0, Vector2(140.0, cy), true)
		else:
			if ult == 1:
				if bp_jogavel:
					estat["fora"] = int(estat["fora"]) + 1
					_iniciar_bp("escanteio", Vector2(Cfg.PW - 10.0, 10.0 if b.y < cy else Cfg.PH - 10.0))
				else:
					_reposicao(0, Vector2(Cfg.PW - 10.0, 10.0 if b.y < cy else Cfg.PH - 10.0), false)
			else:
				_reposicao(1, Vector2(Cfg.PW - 140.0, cy), true)
		return
	if (b.y < 0.0 or b.y > Cfg.PH) and graca_fora <= 0.0:
		var ponto: Vector2 = Vector2(clampf(b.x, 40.0, Cfg.PW - 40.0), 6.0 if b.y < 0.0 else Cfg.PH - 6.0)
		_reposicao(1 - bola.ultimo_time, ponto, false)

func _reposicao(time_bate: int, ponto: Vector2, goleiro: bool) -> void:
	estat["fora"] = int(estat["fora"]) + 1
	estado = Estado.PARADO
	timer = 0.9
	bola.dono = null
	bola.vel = Vector2.ZERO
	bola.z = 0.0
	bola.vz = 0.0
	bola.position = ponto
	var tomador: Jogador = _mais_proximo(time_bate, ponto, goleiro)
	if tomador == null:
		tomador = _mais_proximo(time_bate, ponto, false, true)
	var dentro: Vector2 = (Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5) - ponto).normalized()
	tomador.position = ponto - dentro * 18.0
	tomador.face = dentro
	tomador.vel = Vector2.ZERO
	tomador.atordoado = 0.9
	reposicao_tomador = tomador

func _gol(time_marcador: int) -> void:
	gols[time_marcador] = int(gols[time_marcador]) + 1
	_ultimo_marcador = time_marcador
	estado = Estado.GOL
	timer = 3.2
	var autor: String = "GOL CONTRA"
	if bola.ultimo_jogador != null and bola.ultimo_jogador.time == time_marcador:
		autor = bola.ultimo_jogador.nome
		if time_marcador == 0:
			autores_casa.append(autor)
	bola.dono = null
	bola.vel = Vector2.ZERO
	bola.position.x = clampf(bola.position.x, -Cfg.GOL_PROF + 10.0, Cfg.PW + Cfg.GOL_PROF - 10.0)
	for q in (times[time_marcador] as Array):
		var j: Jogador = q as Jogador
		if j.papel != "GOL":
			j.comemorando = 2.8
	if vis != null:
		vis.gol(time_marcador)
	_mostrar("GOOOL!", "%s  (%d' )   %d - %d" % [autor, minuto(), int(gols[0]), int(gols[1])], 3.0)


# ----------------------------------------------------------------- faltas e cartões
func _falta(faltoso: Jogador, vitima: Jogador, gravidade: float = 0.15) -> void:
	if estado != Estado.JOGANDO or faltoso.papel == "GOL":
		return
	faltas[faltoso.time] = int(faltas[faltoso.time]) + 1
	var ponto: Vector2 = vitima.position
	ultimo_lance = ponto
	ultimo_faltoso = faltoso
	var t_def: int = faltoso.time
	# pênalti: falta dentro da própria área (time 0 defende x<340, time 1 defende x>PW-340)
	var cy: float = Cfg.PH * 0.5
	var na_area: bool = absf(ponto.y - cy) < Cfg.PH * 0.277 and ((t_def == 0 and ponto.x < Cfg.PW * 0.155) or (t_def == 1 and ponto.x > Cfg.PW * (1.0 - 0.155)))
	var cartao: String = _cartao(faltoso, gravidade)
	_talvez_lesao(vitima)
	var sub: String = "%s (%s)" % [faltoso.nome, "CFC" if faltoso.time == 0 else sigla_fora]
	if cartao == "":
		_mostrar("FALTA!", sub, 1.6)
	if na_area:
		_penalti(1 - t_def, vitima)
		return
	ponto.x = clampf(ponto.x, 30.0, Cfg.PW - 30.0)
	ponto.y = clampf(ponto.y, 30.0, Cfg.PH - 30.0)
	if bp_jogavel and vitima.time == 0 and ponto.x > Cfg.PW * 0.64:
		faltoso.atordoado = 0.6
		_iniciar_bp("falta", ponto)
		return
	_reposicao(vitima.time, ponto, false)
	estat["fora"] = int(estat["fora"]) - 1   # falta não conta como bola fora
	faltoso.atordoado = 0.6

## Lesão da vítima de falta (só time da casa): sai por substituição automática ou segue em campo mancando.
func _talvez_lesao(v: Jogador) -> void:
	if v.time != 0 or v.papel == "GOL" or v.lesionado or v.expulso:
		return
	if randf() >= 0.045 + 0.08 * _fadiga(v):
		return
	var r: float = randf()
	var rodadas: int = 1 if r < 0.6 else (2 if r < 0.9 else 3 + randi() % 2)
	lesoes_log.append({"id": v.jid, "nome": v.nome, "rodadas": rodadas})
	var idx: int = -1
	if int(subs_restantes[0]) > 0:
		for i in reservas_casa.size():
			if str(reservas_casa[i].get("cat", "")) == v.papel:
				idx = i
				break
		if idx < 0:
			for i in reservas_casa.size():
				if str(reservas_casa[i].get("cat", "")) != "GOL":
					idx = i
					break
	if idx >= 0 and substituir(v, idx):
		_mostrar("LESÃO!", "%s sai machucado" % str(lesoes_log[lesoes_log.size() - 1]["nome"]), 2.6)
	else:
		v.lesionado = true
		_mostrar("LESÃO!", "%s segue mancando" % v.nome, 2.6)

func _cartao(j: Jogador, gravidade: float = 0.15) -> String:
	# gravidade 0..1: desarme em pé leve quase nunca dá cartão; carrinho por trás é o lance que pode render vermelho
	var r: float = randf()
	var tipo: String = ""
	if r < 0.14 * gravidade * gravidade:
		tipo = "vermelho"
	elif r < 0.05 + 0.40 * gravidade:
		tipo = "amarelo"
	if tipo == "":
		return ""
	var log_tipo: String = "vermelho_direto"
	if tipo == "amarelo":
		j.amarelos += 1
		log_tipo = "amarelo"
		if j.amarelos >= 2:
			tipo = "vermelho"
			log_tipo = "vermelho_2a"
	cartoes_log.append({"id": j.jid, "nome": j.nome, "time": j.time, "tipo": log_tipo})
	if tipo == "amarelo":
		amarelos[j.time] = int(amarelos[j.time]) + 1
		_mostrar("CARTÃO AMARELO", "%s (%s)" % [j.nome, "CFC" if j.time == 0 else sigla_fora], 2.0)
	else:
		vermelhos[j.time] = int(vermelhos[j.time]) + 1
		_mostrar("CARTÃO VERMELHO!", "%s expulso — %s com %d" % [j.nome, "CFC" if j.time == 0 else sigla_fora, (times[j.time] as Array).size() - 1], 2.6)
		_expulsar(j)
	return tipo

func _expulsar(j: Jogador) -> void:
	(times[j.time] as Array).erase(j)
	jogadores.erase(j)
	if bola.dono == j:
		bola.dono = null
	if controlado == j:
		j.controlado = false
		controlado = null
	j.expulso = true
	j.visible = false
	j.set_process(false)

func _penalti(time_bate: int, vitima: Jogador) -> void:
	penaltis[time_bate] = int(penaltis[time_bate]) + 1
	if time_bate == 0 and bp_jogavel:
		_mostrar("PÊNALTI!", "Você cobra", 1.6)
		_iniciar_bp("penalti", Vector2(Cfg.PW * (1.0 - 0.075), Cfg.PH * 0.5))
		return
	var cobrador: Jogador = vitima
	if vitima.time != time_bate:
		cobrador = _mais_proximo(time_bate, bola.position)
	# melhor batedor do time: maior atributo de chute entre os jogadores de linha
	for q in (times[time_bate] as Array):
		var jq: Jogador = q as Jogador
		if jq.papel != "GOL" and jq.habil("chute") > cobrador.habil("chute"):
			cobrador = jq
	var goleiro: Jogador = null
	for q2 in (times[1 - time_bate] as Array):
		if (q2 as Jogador).papel == "GOL":
			goleiro = q2 as Jogador
	var hg: float = goleiro.habil("goleiro") if goleiro != null else 0.5
	var chance: float = clampf(0.76 + 0.30 * (cobrador.habil("chute") - hg), 0.55, 0.92)
	var converteu: bool = randf() < chance
	bola.dono = null
	bola.vel = Vector2.ZERO
	bola.ultimo_time = time_bate
	bola.ultimo_jogador = cobrador
	var lado_x: float = Cfg.PW if time_bate == 0 else 0.0
	_mostrar("PÊNALTI!", "%s vai para a cobrança" % cobrador.nome, 1.8)
	if converteu:
		bola.position = Vector2(lado_x, Cfg.PH * 0.5)
		_gol(time_bate)
	else:
		estat["defesas"][1 - time_bate] += 1
		_mostrar("DEFENDEU!", "Pênalti perdido de %s" % cobrador.nome, 2.0)
		_reposicao(1 - time_bate, Vector2(Cfg.PW - 140.0 if time_bate == 0 else 140.0, Cfg.PH * 0.5), true)

# ----------------------------------------------------------------- bolas paradas jogáveis (Fase 3)
## Pênalti, escanteio e falta perigosa a favor da casa: o jogador mira (setas) e chuta (CHUTE).
## Pênalti/falta: segure CHUTE para carregar a força, solte para bater. Escanteio: aperte CHUTE para cruzar; →/← muda a profundidade.
func _iniciar_bp(tipo: String, ponto: Vector2) -> void:
	var sc: float = Cfg.PW / 2200.0
	var cy: float = Cfg.PH * 0.5
	bp_stats[tipo] = int(bp_stats[tipo]) + 1
	estado = Estado.BOLA_PARADA
	bola.dono = null
	bola.vel = Vector2.ZERO
	bola.z = 0.0
	bola.vz = 0.0
	bola.position = ponto
	var cob: Jogador = null
	for q in (times[0] as Array):
		var jq: Jogador = q as Jogador
		if jq.papel == "GOL" or jq.expulso:
			continue
		if cob == null:
			cob = jq
		elif tipo == "escanteio":
			if jq.position.distance_to(ponto) < cob.position.distance_to(ponto):
				cob = jq
		elif tipo == "penalti":
			if jq.habil("chute") > cob.habil("chute"):
				cob = jq
		elif jq.position.distance_to(ponto) < cob.position.distance_to(ponto):
			cob = jq
	var rumo: Vector2 = (Vector2(Cfg.PW, cy) - ponto).normalized()
	cob.position = ponto - rumo * 40.0
	cob.face = rumo
	for q2 in jogadores:
		var j: Jogador = q2 as Jogador
		j.vel = Vector2.ZERO
		j.controlado = false
		j.atordoado = 0.0
	cob.controlado = true
	controlado = cob
	var box_x: float = Cfg.PW * (1.0 - 0.155)
	var outros0: Array = []
	var outros1: Array = []
	for q3 in jogadores:
		var j3: Jogador = q3 as Jogador
		if j3 == cob or j3.expulso:
			continue
		if j3.papel == "GOL":
			if j3.time == 1:
				j3.position = Vector2(Cfg.PW - 12.0, cy)
			continue
		(outros0 if j3.time == 0 else outros1).append(j3)
	match tipo:
		"penalti":
			for j4 in outros0 + outros1:
				(j4 as Jogador).position.x = minf((j4 as Jogador).position.x, box_x - 70.0 * sc - randf() * 120.0)
		"escanteio":
			var spots: Array = [Vector2(-230.0, -110.0), Vector2(-300.0, 70.0), Vector2(-170.0, 10.0), Vector2(-390.0, -40.0)]
			outros0.sort_custom(func(a, b): return a.position.x > b.position.x)
			outros1.sort_custom(func(a, b): return a.position.x > b.position.x)
			for i in mini(spots.size(), mini(outros0.size() - 2, outros1.size())):
				var sp: Vector2 = Vector2(Cfg.PW, cy) + Vector2((spots[i] as Vector2).x * sc, (spots[i] as Vector2).y * sc)
				(outros0[i] as Jogador).position = sp
				(outros1[i] as Jogador).position = sp + Vector2(26.0 * sc, 18.0 * sc * (1.0 if i % 2 == 0 else -1.0))
		"falta":
			var perp: Vector2 = rumo.orthogonal()
			for i in mini(3, outros1.size()):
				outros1.sort_custom(func(a, b): return a.position.distance_to(ponto + rumo * 180.0 * sc) < b.position.distance_to(ponto + rumo * 180.0 * sc))
				(outros1[i] as Jogador).position = ponto + rumo * 180.0 * sc + perp * (float(i) - 1.0) * 38.0 * sc
	bp = {"tipo": tipo, "cob": cob, "ax": 0.0, "ad": 0.5, "carga": 0.0, "carregando": false, "t": 0.0, "ponto": ponto}

func _passo_bp(delta: float) -> void:
	if bp.is_empty():
		estado = Estado.JOGANDO
		return
	bp["t"] = float(bp["t"]) + delta
	var tipo: String = str(bp["tipo"])
	var auto: bool = piloto_auto
	if auto:
		if float(bp["t"]) > 0.7:
			bp["ax"] = randf_range(-0.8, 0.8)
			bp["ad"] = randf()
			bp["carga"] = 0.75
			_executar_bp()
		return
	var m: Vector2 = Input.get_vector("esq", "dir", "cima", "baixo")
	bp["ax"] = clampf(float(bp["ax"]) + m.y * 1.5 * delta, -1.0, 1.0)
	if tipo == "escanteio":
		bp["ad"] = clampf(float(bp["ad"]) + m.x * 0.9 * delta, 0.0, 1.0)
		if Input.is_action_just_pressed("chute"):
			_executar_bp()
			return
	else:
		if Input.is_action_pressed("chute"):
			bp["carregando"] = true
			bp["carga"] = minf(1.0, float(bp["carga"]) + delta / 1.1)
		elif bool(bp["carregando"]):
			_executar_bp()
			return
	if float(bp["t"]) > 10.0:       # demorou: bate com a mira atual
		if float(bp["carga"]) < 0.3:
			bp["carga"] = 0.6
		_executar_bp()

## Velocidade inicial para a bola cobrir 'dist' em T segundos com o arrasto da Bola.
func _vel_para_alcance(dist: float, T: float) -> float:
	var lo: float = 100.0
	var hi: float = 1800.0
	for i in 18:
		var mid: float = (lo + hi) * 0.5
		var d: float = 0.0
		var v: float = mid
		var t: float = 0.0
		while t < T:
			d += v / 60.0
			v = maxf(0.0, v - (120.0 + 0.35 * v) / 60.0)
			t += 1.0 / 60.0
		if d < dist:
			lo = mid
		else:
			hi = mid
	return (lo + hi) * 0.5

func _executar_bp() -> void:
	var cob: Jogador = bp["cob"]
	var tipo: String = str(bp["tipo"])
	var sc: float = Cfg.PW / 2200.0
	var cy: float = Cfg.PH * 0.5
	var ax: float = float(bp["ax"])
	var origem: Vector2 = bola.position
	cob.position = origem - (Vector2(Cfg.PW, cy) - origem).normalized() * 18.0
	var alvo_ctrl: Vector2 = Vector2.ZERO
	if tipo == "escanteio":
		var alvo: Vector2 = Vector2(Cfg.PW - lerpf(110.0, 440.0, float(bp["ad"])) * sc, cy + ax * Cfg.GOL_METADE * 2.4)
		var dir: Vector2 = (alvo - origem).normalized().rotated(randf_range(-1.0, 1.0) * (1.0 - cob.habil("passe")) * 0.12)
		var vz: float = 380.0
		bola.chutar(dir, _vel_para_alcance(origem.distance_to(alvo), 2.0 * vz / 700.0), vz, cob)
		alvo_ctrl = alvo
		estat["passes"][0] += 1
	else:
		var alvo2: Vector2 = Vector2(Cfg.PW, cy + ax * Cfg.GOL_METADE * 0.9)
		var carga: float = float(bp["carga"])
		var dir2: Vector2 = (alvo2 - origem).normalized()
		_disparar(cob, dir2, carga)
		if carga > 0.92:          # chutou forte demais: tende a ir por cima
			bola.vz += 240.0
	cob.cd_captura = 0.4
	bola.ultimo_time = 0
	bola.ultimo_jogador = cob
	graca_fora = 0.8
	bp = {}
	estado = Estado.JOGANDO
	if tipo == "escanteio":
		var melhor: Jogador = null
		for q in (times[0] as Array):
			var jq: Jogador = q as Jogador
			if jq == cob or jq.papel == "GOL" or jq.expulso:
				continue
			if melhor == null or jq.position.distance_to(alvo_ctrl) < melhor.position.distance_to(alvo_ctrl):
				melhor = jq
		if melhor != null:
			cob.controlado = false
			melhor.controlado = true
			controlado = melhor

# ----------------------------------------------------------------- substituições
func substituir(sai: Jogador, idx: int) -> bool:
	## Substituição escolhida pelo jogador (tela de banco): sai um titular, entra o reserva idx.
	if int(subs_restantes[0]) <= 0 or sai == null or sai.time != 0 or idx < 0 or idx >= reservas_casa.size():
		return false
	var r: Dictionary = reservas_casa[idx]
	var goleiro_res: bool = str(r.get("cat", "")) == "GOL"
	if goleiro_res != (sai.papel == "GOL"):
		return false   # goleiro só é trocado por goleiro
	reservas_casa.remove_at(idx)
	_aplicar_reserva(sai, r)
	subs_restantes[0] = int(subs_restantes[0]) - 1
	_mostrar("SUBSTITUIÇÃO", "Entra %s, sai %s" % [sai.nome, str(r.get("sai_nome", ""))], 2.0)
	return true

func substituir_controlado() -> bool:
	## Troca o jogador controlado (da casa) por um reserva da mesma posição (ou qualquer, se não houver).
	if int(subs_restantes[0]) <= 0 or controlado == null or reservas_casa.is_empty():
		return false
	var sai: Jogador = controlado
	if sai.papel == "GOL" and _mais_proximo(0, bola.position) != null:
		sai = _mais_proximo(0, bola.position)
	var idx: int = -1
	for i in reservas_casa.size():
		if str(reservas_casa[i].get("cat", "")) == sai.papel:
			idx = i
			break
	if idx < 0:
		for i in reservas_casa.size():
			if str(reservas_casa[i].get("cat", "")) != "GOL" and sai.papel != "GOL":
				idx = i
				break
	if idx < 0:
		return false
	var r: Dictionary = reservas_casa[idx]
	reservas_casa.remove_at(idx)
	_aplicar_reserva(sai, r)
	subs_restantes[0] = int(subs_restantes[0]) - 1
	_mostrar("SUBSTITUIÇÃO", "Entra %s, sai %s" % [sai.nome, str(r.get("sai_nome", ""))], 2.0)
	return true

func _aplicar_reserva(j: Jogador, r: Dictionary) -> void:
	r["sai_nome"] = j.nome
	j.nome = str(r.get("nome", j.nome))
	j.numero = int(r.get("numero", j.numero))
	var ov: float = float(r.get("overall", 70))
	var en: float = float(r.get("energia", 100.0))
	var mo: float = float(r.get("moral", 60.0))
	var base: float = (0.84 + (ov - 76.0) * 0.004) * (0.92 + 0.08 * clampf(en, 0.0, 100.0) / 100.0) + (mo - 50.0) * 0.0006
	j.atributos = _atributos_por_papel(j.papel, base + forma_casa * 0.012 + extra_prep * 0.004 + bonus_scout)
	j.jid = str(r.get("id", ""))
	j.fisico = float(r.get("fisico", 60.0))
	j.tecnica = float(r.get("tecnica", 60.0))
	j.lesionado = false
	j.moral = mo
	j.energia_ini = en
	cansaco[0] = maxf(0.0, float(cansaco[0]) - 0.05)   # pernas frescas

func _substituicao_ia() -> void:
	# o adversário faz 1 troca aos 60' e outra aos 75': jogador de linha ganha pernas frescas
	var m: int = minuto()
	for passo in [[60, 0], [75, 1]]:
		if m >= int(passo[0]) and int(_sub_ia_feitas[1]) <= int(passo[1]) and _reservas_fora > 0:
			_sub_ia_feitas[1] = int(passo[1]) + 1
			_reservas_fora -= 1
			var lista: Array = (times[1] as Array).filter(func(q): return (q as Jogador).papel != "GOL")
			if lista.is_empty():
				return
			var j: Jogador = lista[randi() % lista.size()] as Jogador
			var velho: String = j.nome
			j.numero = 12 + int(passo[1])
			j.nome = "ADV %d" % j.numero
			for k in j.atributos.keys():
				j.atributos[k] = minf(1.0, float(j.atributos[k]) + 0.03)
			_mostrar("SUBSTITUIÇÃO", "%s: entra %s, sai %s" % [sigla_fora, j.nome, velho], 1.8)
