extends Control
class_name MenuPartida
## Menu de pausa com botões + tela de substituição: escalação em campo (lista e mini-campo) e banco.
## Só apresentação e escolhas; a troca em si é feita por Partida.substituir().
enum Modo { FECHADO, MENU, SAI, ENTRA }
var p: Partida
var modo: Modo = Modo.FECHADO
var sel: int = 0
var sai_j: Jogador = null
var _pausa_antes: bool = false
var _hit: Array = []         # [Rect2, índice]
var _t: float = 0.0
var _cache: Dictionary = {}
var _confirma_sair: bool = false
var _confirma_reiniciar: bool = false
var _cfg: bool = false      # submenu CONFIGURAÇÕES
var _tat: bool = false      # submenu TÁTICA (3 eixos)
const NOMES_EIXOS := {"pressao": ["BAIXA", "MÉDIA", "ALTA"], "linha": ["RECUADA", "MÉDIA", "ADIANTADA"], "construcao": ["TOQUE CURTO", "BOLA LONGA", "CONTRA-ATAQUE"]}
var _ver: bool = false      # tela de escalação em modo consulta (sem trocas)
var _aviso: String = ""
var _aviso_t: float = 0.0
const ORDEM := {"GOL": 0, "DEF": 1, "MEI": 2, "ATA": 3}
const COR_POS := {"GOL": Color("F2C230"), "DEF": Color("5FA8FF"), "MEI": Color("6BDB7A"), "ATA": Color("FF7A6B")}

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	custom_minimum_size = Vector2(480, 270)
	size = Vector2(480, 270)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _txt(s: String, esc: int, cor: Color, sombra: Color = Color("1F1511")) -> ImageTexture:
	var k: String = "%s|%d|%s" % [s, esc, cor.to_html()]
	if not _cache.has(k):
		if _cache.size() > 300:
			_cache.clear()
		_cache[k] = PixelUI.texto(s, esc, cor, sombra)
	return _cache[k]

# ------------------------------------------------------------------ estado
func titulares() -> Array:
	var l: Array = []
	for q in p.jogadores:
		var j: Jogador = q as Jogador
		if j.time == 0 and not j.expulso:
			l.append(j)
	l.sort_custom(func(a: Jogador, b: Jogador) -> bool:
		var oa: int = int(ORDEM.get(a.papel, 9))
		var ob: int = int(ORDEM.get(b.papel, 9))
		return oa < ob or (oa == ob and a.numero < b.numero))
	return l

func _itens_menu() -> Array:
	var l: Array = _itens_base()
	if not _cfg and not _tat and p.sair_pedido.get_connections().size() > 0:
		l.append({"id": "sair", "txt": "CONFIRMAR: SAIR DA PARTIDA?" if _confirma_sair else "SAIR DA PARTIDA"})
	return l

func _tatica_liberada() -> bool:
	return p.estado == Partida.Estado.INTERVALO or p.estado == Partida.Estado.PARADO or p.estado == Partida.Estado.SAIDA

func _itens_base() -> Array:
	if _tat:
		var e: Dictionary = p.eixos[0]
		return [
			{"id": "t_pressao", "txt": "PRESSÃO: " + str(NOMES_EIXOS["pressao"][int(e["pressao"])])},
			{"id": "t_linha", "txt": "LINHA: " + str(NOMES_EIXOS["linha"][int(e["linha"])])},
			{"id": "t_construcao", "txt": "CONSTRUÇÃO: " + str(NOMES_EIXOS["construcao"][int(e["construcao"])])},
			{"id": "voltar", "txt": "< VOLTAR"},
		]
	if _cfg:
		return [
			{"id": "mao", "txt": "TOQUE: " + Opcoes.rotulo_mao()},
			{"id": "inv", "txt": "PASSE/CHUTE: " + ("INVERTIDO" if Opcoes.invertido else "NORMAL")},
			{"id": "ajuda", "txt": "COMANDOS"},
			{"id": "tela", "txt": "TELA CHEIA (F11)"},
			{"id": "v_geral", "txt": _amb().rotulo_volume("geral").to_upper()},
			{"id": "v_partida", "txt": _amb().rotulo_volume("partida").to_upper()},
			{"id": "mudo", "txt": _amb().rotulo_mudo().to_upper()},
			{"id": "voltar", "txt": "< VOLTAR"},
		]
	var l: Array = [
		{"id": "continuar", "txt": "CONTINUAR"},
		{"id": "sub", "txt": "SUBSTITUIÇÃO  (%d)" % int(p.subs_restantes[0])},
		{"id": "ver", "txt": "ESCALAÇÃO EM CAMPO"},
		{"id": "tat", "txt": "TÁTICA"},
		{"id": "cfg", "txt": "CONFIGURAÇÕES"},
	]
	if p.reiniciar_pedido.get_connections().size() > 0:
		l.append({"id": "reiniciar", "txt": "CONFIRMAR: REINICIAR?" if _confirma_reiniciar else "REINICIAR PARTIDA"})
	return l

func alternar_sub() -> void:
	if modo == Modo.SAI or modo == Modo.ENTRA:
		_fechar_sub()
	else:
		abrir_sub()

func abrir_sub() -> void:
	if modo == Modo.FECHADO:
		_pausa_antes = p.pausado
		p.pausado = true
	modo = Modo.SAI
	_ver = false
	var l: Array = titulares()
	sel = maxi(0, l.find(p.controlado))
	sai_j = null
	mouse_filter = Control.MOUSE_FILTER_STOP

func abrir_ver() -> void:
	abrir_sub()
	_ver = true

func _fechar_sub() -> void:
	_ver = false
	if _pausa_antes:
		modo = Modo.MENU
		sel = 1
	else:
		modo = Modo.FECHADO
		p.pausado = false
		mouse_filter = Control.MOUSE_FILTER_IGNORE

func _avisar(s: String) -> void:
	_aviso = s
	_aviso_t = 1.6

# ------------------------------------------------------------------ laço
func _process(delta: float) -> void:
	if p == null:
		return
	_t += delta
	_aviso_t = maxf(0.0, _aviso_t - delta)
	if modo == Modo.FECHADO:
		if p.pausado and not p.ajuda_aberta and p.estado != Partida.Estado.FIM:
			modo = Modo.MENU
			sel = 0
			mouse_filter = Control.MOUSE_FILTER_STOP
	elif modo == Modo.MENU:
		if not p.pausado or p.ajuda_aberta:
			_confirma_sair = false
			_confirma_reiniciar = false
			if not p.pausado:
				_cfg = false
				_tat = false
			modo = Modo.FECHADO
			mouse_filter = Control.MOUSE_FILTER_IGNORE
	else:
		if not p.pausado or p.estado == Partida.Estado.FIM:
			modo = Modo.FECHADO
			mouse_filter = Control.MOUSE_FILTER_IGNORE
	if modo != Modo.FECHADO:
		_teclas()
	queue_redraw()

func _total() -> int:
	match modo:
		Modo.MENU: return _itens_menu().size()
		Modo.SAI: return titulares().size()
		Modo.ENTRA: return p.reservas_casa.size()
	return 0

func _teclas() -> void:
	var n: int = _total()
	if n <= 0 and modo == Modo.ENTRA:
		_avisar("SEM RESERVAS")
		modo = Modo.SAI
		return
	if Input.is_action_just_pressed("ui_down"):
		sel = (sel + 1) % n
	elif Input.is_action_just_pressed("ui_up"):
		sel = (sel - 1 + n) % n
	if Input.is_action_just_pressed("ui_accept") or Input.is_action_just_pressed("passe"):
		_confirmar()
	elif Input.is_action_just_pressed("chute") and (modo == Modo.SAI or modo == Modo.ENTRA):
		if modo == Modo.ENTRA:
			modo = Modo.SAI
			sel = maxi(0, titulares().find(sai_j))
		else:
			_fechar_sub()
	if modo == Modo.SAI and not _ver and (Input.is_action_just_pressed("ui_right")):
		if not p.reservas_casa.is_empty():
			_confirmar()

func _confirmar() -> void:
	match modo:
		Modo.MENU:
			match str(_itens_menu()[sel]["id"]):
				"continuar": p.pausado = false
				"sub": abrir_sub()
				"ver": abrir_ver()
				"cfg":
					_cfg = true
					sel = 0
				"tat":
					if _tatica_liberada():
						_tat = true
						sel = 0
					else:
						_avisar("TÁTICA SÓ NO INTERVALO OU BOLA PARADA")
				"t_pressao", "t_linha", "t_construcao":
					var k: String = str(_itens_menu()[sel]["id"]).substr(2)
					p.eixos[0][k] = (int(p.eixos[0][k]) + 1) % 3
					p.eixos_definidos = true
					p.mudou_tatica.emit()
				"voltar":
					sel = 3 if _tat else 4
					_cfg = false
					_tat = false
				"reiniciar":
					if _confirma_reiniciar:
						_confirma_reiniciar = false
						p.pausado = false
						p.reiniciar_pedido.emit()
					else:
						_confirma_reiniciar = true
				"ajuda": p.ajuda_aberta = true
				"v_geral": _amb().proximo_volume("geral")
				"v_partida": _amb().proximo_volume("partida")
				"mudo": _amb().alternar_mudo()
				"mao": Opcoes.alternar_mao()
				"inv": Opcoes.alternar_inversao()
				"sair":
					if _confirma_sair:
						_confirma_sair = false
						p.pausado = false
						p.sair_pedido.emit()
					else:
						_confirma_sair = true
				"tela":
					var tc: Node = get_node_or_null("/root/TelaCheia")
					if tc != null:
						tc.call("alternar")
		Modo.SAI:
			var l: Array = titulares()
			if _ver:
				return
			if sel < l.size():
				if int(p.subs_restantes[0]) <= 0:
					_avisar("SEM TROCAS RESTANTES")
				elif p.reservas_casa.is_empty():
					_avisar("BANCO VAZIO")
				else:
					sai_j = l[sel]
					modo = Modo.ENTRA
					sel = _primeiro_compativel()
		Modo.ENTRA:
			if sel < p.reservas_casa.size():
				if p.substituir(sai_j, sel):
					_avisar("SUBSTITUIÇÃO FEITA")
					modo = Modo.SAI
					sel = maxi(0, titulares().find(sai_j))
					sai_j = null
					if int(p.subs_restantes[0]) <= 0 or p.reservas_casa.is_empty():
						_fechar_sub()
				else:
					_avisar("GOLEIRO SÓ POR GOLEIRO" if (sai_j.papel == "GOL" or str(p.reservas_casa[sel].get("cat", "")) == "GOL") else "NÃO FOI POSSÍVEL")

func _compat(r: Dictionary) -> bool:
	return sai_j == null or ((str(r.get("cat", "")) == "GOL") == (sai_j.papel == "GOL"))

func _primeiro_compativel() -> int:
	for i in p.reservas_casa.size():
		if _compat(p.reservas_casa[i]):
			return i
	return 0

func _gui_input(e: InputEvent) -> void:
	if modo == Modo.FECHADO:
		return
	if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
		for h in _hit:
			if (h[0] as Rect2).has_point(e.position):
				var id: int = int(h[1])
				if id == -1:      # voltar
					if modo == Modo.ENTRA:
						modo = Modo.SAI
						sel = maxi(0, titulares().find(sai_j))
					else:
						_fechar_sub()
					return
				if id >= 1000:    # coluna do banco (clique direto)
					if modo == Modo.ENTRA:
						sel = id - 1000
						_confirmar()
					return
				sel = id
				_confirmar()
				return

# ------------------------------------------------------------------ desenho
func _botao(r: Rect2, texto: String, ativo: bool, cor_txt: Color = Color.WHITE, indice: int = 0) -> void:
	draw_rect(r, Color("1F1511"))
	draw_rect(Rect2(r.position + Vector2(1, 1), r.size - Vector2(2, 2)), Color("C94F50") if ativo else Color("3A1E22"))
	draw_rect(Rect2(r.position + Vector2(1, 1), Vector2(r.size.x - 2, 2)), Color("E8847F") if ativo else Color("6B3A40"))
	draw_rect(Rect2(r.position + Vector2(1, r.size.y - 3), Vector2(r.size.x - 2, 2)), Color("8F303A") if ativo else Color("24120F"))
	if ativo:
		draw_rect(r, Color("FFD84A"), false, 1.0)
	var t: ImageTexture = _txt(texto, 1, cor_txt)
	draw_texture(t, Vector2(round(r.position.x + (r.size.x - t.get_width()) * 0.5), round(r.position.y + (r.size.y - t.get_height()) * 0.5)))

func _draw() -> void:
	_hit.clear()
	if modo == Modo.FECHADO or p == null:
		return
	if modo == Modo.MENU:
		_desenhar_menu()
	else:
		_desenhar_sub()
	if _aviso_t > 0.0:
		var a: ImageTexture = _txt(_aviso, 1, Color("1F1511"), Color("FFD84A"))
		draw_rect(Rect2(240 - a.get_width() * 0.5 - 5, 244, a.get_width() + 10, 13), Color("FFD84A"))
		draw_texture(a, Vector2(round(240 - a.get_width() * 0.5), 247))

func _desenhar_menu() -> void:
	var l: ImageTexture = PixelUI.letreiro("CONFIG." if _cfg else ("TÁTICA" if _tat else "PAUSA"), 2)
	draw_texture(l, Vector2(round(240 - l.get_width() * 0.5), 24))
	var itens: Array = _itens_menu()
	var y: float = 66.0
	for i in itens.size():
		var r := Rect2(140, y, 200, 20)
		_botao(r, str(itens[i]["txt"]), i == sel, Color("FFB0A0") if str(itens[i]["id"]) in ["sair", "reiniciar"] else Color.WHITE)
		_hit.append([r, i])
		y += 23.0
	var d: ImageTexture = _txt("SETAS ESCOLHEM  ENTER/J CONFIRMA  P CONTINUA", 1, Color("F7F2E4"))
	draw_texture(d, Vector2(round(240 - d.get_width() * 0.5), 258))

func _fila(r: Rect2, num: int, nome: String, pos: String, extra: String, ativo: bool, dim: bool) -> void:
	draw_rect(r, Color("1F1511"))
	draw_rect(Rect2(r.position + Vector2(1, 1), r.size - Vector2(2, 2)), Color("C94F50") if ativo else Color("4A2328"))
	if ativo:
		draw_rect(r, Color("FFD84A"), false, 1.0)
	var cp: Color = COR_POS.get(pos, Color.WHITE)
	if dim:
		cp = cp.darkened(0.55)
	draw_rect(Rect2(r.position.x + 2, r.position.y + 2, 3, r.size.y - 4), cp)
	var cor: Color = Color("8A97AD") if dim else Color.WHITE
	draw_texture(_txt(str(num), 1, Color("FFD84A") if not dim else Color("8A97AD")), Vector2(r.position.x + 8, r.position.y + 3))
	draw_texture(_txt(nome.substr(0, 11), 1, cor), Vector2(r.position.x + 24, r.position.y + 3))
	var tp: ImageTexture = _txt(pos, 1, cp)
	draw_texture(tp, Vector2(r.position.x + r.size.x - tp.get_width() - 4 - (22 if extra != "" else 0), r.position.y + 3))
	if extra != "":
		var te: ImageTexture = _txt(extra, 1, Color("9BE8A5") if not dim else Color("8A97AD"))
		draw_texture(te, Vector2(r.position.x + r.size.x - te.get_width() - 3, r.position.y + 3))

func _desenhar_sub() -> void:
	draw_rect(Rect2(0, 0, 480, 270), Color("1F1511"))
	draw_rect(Rect2(0, 0, 480, 17), Color("1F1511"))
	draw_rect(Rect2(0, 17, 480, 1), Color("F2C14E"))
	var tit: String = "ESCALAÇÃO EM CAMPO  -  CONSULTA" if _ver else "SUBSTITUIÇÃO  -  ESCOLHA QUEM SAI" if modo == Modo.SAI else "ESCOLHA QUEM ENTRA NO LUGAR DE %s" % (sai_j.nome.to_upper().substr(0, 12) if sai_j != null else "")
	var tt: ImageTexture = _txt(tit, 1, Color("FFD84A"))
	draw_texture(tt, Vector2(round(240 - tt.get_width() * 0.5), 5))
	var tr: ImageTexture = _txt("TROCAS: %d" % int(p.subs_restantes[0]), 1, Color("F7F2E4"))
	draw_texture(tr, Vector2(480 - tr.get_width() - 6, 5))
	# ---- coluna esquerda: titulares
	draw_texture(_txt("EM CAMPO", 1, Color("F7F2E4")), Vector2(8, 22))
	var l: Array = titulares()
	for i in l.size():
		var j: Jogador = l[i]
		var r := Rect2(6, 33 + i * 18, 150, 16)
		var ativo: bool = (modo == Modo.SAI and i == sel) or (modo == Modo.ENTRA and j == sai_j)
		_fila(r, j.numero, j.nome.to_upper(), j.papel, "", ativo, false)
		if modo == Modo.SAI:
			_hit.append([r, i])
	# ---- centro: mini-campo
	var mx: float = 168.0
	var my: float = 40.0
	var mw: float = 150.0
	var mh: float = 140.0
	draw_rect(Rect2(mx - 2, my - 2, mw + 4, mh + 4), Color("1F1511"))
	for k in 7:
		draw_rect(Rect2(mx, my + k * (mh / 7.0), mw, mh / 7.0 + 1.0), Color("2E8B3E") if k % 2 == 0 else Color("37A04A"))
	var lin := Color(1, 1, 1, 0.7)
	draw_rect(Rect2(mx, my, mw, mh), lin, false, 1.0)
	draw_line(Vector2(mx, my + mh * 0.5), Vector2(mx + mw, my + mh * 0.5), lin, 1.0)
	draw_arc(Vector2(mx + mw * 0.5, my + mh * 0.5), 16.0, 0.0, TAU, 24, lin, 1.0)
	draw_rect(Rect2(mx + mw * 0.2, my, mw * 0.6, 22), lin, false, 1.0)
	draw_rect(Rect2(mx + mw * 0.2, my + mh - 22, mw * 0.6, 22), lin, false, 1.0)
	for i in l.size():
		var j2: Jogador = l[i]
		# o mini-campo é girado: o gol da casa fica embaixo, ataque para cima
		var nx: float = j2.position.y / Cfg.PH
		var ny: float = 1.0 - j2.position.x / Cfg.PW
		var c: Vector2 = Vector2(mx + nx * mw, my + ny * mh).round()
		var foco: bool = (modo == Modo.SAI and i == sel) or (modo == Modo.ENTRA and j2 == sai_j)
		var cor: Color = Color("C94F50") if j2.papel != "GOL" else Color("7A2FD0")
		var num: int = j2.numero
		if foco and modo == Modo.ENTRA and sel < p.reservas_casa.size():
			num = int(p.reservas_casa[sel].get("numero", num))
			cor = Color("2DA44E")
		draw_rect(Rect2(c.x - 6, c.y - 6, 13, 13), Color("FFD84A") if (foco and int(_t * 4.0) % 2 == 0) else Color("1F1511"))
		draw_rect(Rect2(c.x - 5, c.y - 5, 11, 11), cor)
		var tn: ImageTexture = _txt(str(num), 1, Color.WHITE)
		draw_texture(tn, Vector2(round(c.x - tn.get_width() * 0.5), c.y - 3))
	var lg: ImageTexture = _txt("SEU ATAQUE ^", 1, Color(1, 1, 1, 0.75))
	draw_texture(lg, Vector2(round(mx + mw * 0.5 - lg.get_width() * 0.5), my - 12))
	# ---- coluna direita: banco
	draw_texture(_txt("BANCO", 1, Color("F7F2E4")), Vector2(326, 22))
	if p.reservas_casa.is_empty():
		draw_texture(_txt("SEM RESERVAS", 1, Color("8A97AD")), Vector2(336, 40))
	for i in p.reservas_casa.size():
		var rs: Dictionary = p.reservas_casa[i]
		var r2 := Rect2(324, 33 + i * 18, 150, 16)
		var dim: bool = modo == Modo.ENTRA and not _compat(rs)
		var ativo2: bool = modo == Modo.ENTRA and i == sel
		_fila(r2, int(rs.get("numero", 0)), str(rs.get("nome", "")).to_upper(), str(rs.get("cat", "")), str(int(rs.get("overall", 0))), ativo2, dim or modo == Modo.SAI)
		if modo == Modo.ENTRA:
			_hit.append([r2, 1000 + i])
	# ---- botão voltar e dica
	var rv := Rect2(168, 192, 150, 18)
	_botao(rv, "< VOLTAR" if modo == Modo.ENTRA else "< FECHAR", false)
	_hit.append([rv, -1])
	var dica: String = "SETAS ESCOLHEM  J/ENTER CONFIRMA  K VOLTA" if modo != Modo.FECHADO else ""
	var d: ImageTexture = _txt(dica, 1, Color("F7F2E4"))
	draw_texture(d, Vector2(round(240 - d.get_width() * 0.5), 258))
	if modo == Modo.SAI and not _ver:
		draw_texture(_txt("PARA O BANCO >", 1, Color("FFD84A")), Vector2(172, 214))

## Autoload de som (acesso por caminho: funciona também em ferramentas que rodam sem autoloads registrados).
func _amb() -> Node:
	return Engine.get_main_loop().root.get_node("Ambiente")
