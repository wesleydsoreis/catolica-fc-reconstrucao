extends Control
## Elenco
## Tela de elenco e escalação. Mostra os 17 atletas, separados em titulares
## (conforme os slots da formação atual) e reservas. Tocar num reserva o
## coloca no primeiro slot compatível vago (ou troca com um titular da mesma
## categoria); tocar num titular o manda para o banco. As formações (4-3-3,
## 4-4-2, 4-2-3-1, 3-5-2, 5-3-2) vêm de GameData.formacoes, extraídas do HTML.
##
## STATUS DESTA ETAPA: a troca é por lista (toque para mover), não por
## arraste no campo 2D como no HTML original — o campo 2D desenhado fica
## para a próxima etapa (ver README.md).

const LABEL_POSICAO := {
	"GOLEIRO": "GOL", "DEFENSOR": "ZAG", "MEIA_DEFENSOR": "VOL",
	"MEIA": "MEI", "MEIA_ATAQUE": "MEA", "ATAQUE": "ATA",
}

@onready var linha_formacoes: HBoxContainer = $Coluna/Scroll/Margem/ColunaConteudo/LinhaFormacoes
@onready var lista_titulares: VBoxContainer = $Coluna/Scroll/Margem/ColunaConteudo/ListaTitulares
@onready var lista_reservas: VBoxContainer = $Coluna/Scroll/Margem/ColunaConteudo/ListaReservas
@onready var botao_continuar_tatica: Button = $Coluna/BotaoContinuarTatica

func _ready() -> void:
	var b_fut7 := Tema.botao("ESCALAÇÃO DA PARTIDA (FUT7)", "ouro", 46)
	b_fut7.pressed.connect(func(): SceneManager.ir_para("escalacao"))
	$Coluna.add_child(b_fut7)
	$Coluna.move_child(b_fut7, 1)
	_montar_botoes_formacao()
	GameState.estado_mudou.connect(_atualizar_listas)
	botao_continuar_tatica.visible = GameState.prep_confirmada
	_atualizar_listas()

func _exit_tree() -> void:
	if GameState.estado_mudou.is_connected(_atualizar_listas):
		GameState.estado_mudou.disconnect(_atualizar_listas)

func _montar_botoes_formacao() -> void:
	for f in GameData.formacoes:
		var botao := Button.new()
		botao.text = f["id"]
		botao.custom_minimum_size = Vector2(64, 40)
		botao.toggle_mode = true
		botao.button_pressed = (f["id"] == GameState.formacao_id)
		Tema.aplicar_botao(botao, "escuro" if f["id"] == GameState.formacao_id else "secundario")
		botao.pressed.connect(func(): GameState.mudar_formacao(f["id"]))
		linha_formacoes.add_child(botao)

func _atualizar_listas() -> void:
	for filho in lista_titulares.get_children():
		filho.queue_free()
	for filho in lista_reservas.get_children():
		filho.queue_free()

	for slot in GameState.slots:
		if slot["jogador_id"] == null:
			lista_titulares.add_child(_criar_linha_vazia(slot))
			continue
		var jogador = _jogador_por_id(slot["jogador_id"])
		if jogador != null:
			lista_titulares.add_child(_criar_linha_jogador(jogador, slot, true))

	var ids_titulares: Array = []
	for slot in GameState.slots:
		if slot["jogador_id"] != null:
			ids_titulares.append(slot["jogador_id"])
	for jogador in GameState.elenco:
		if not ids_titulares.has(jogador["id"]):
			lista_reservas.add_child(_criar_linha_jogador(jogador, null, false))

func _jogador_por_id(id) -> Variant:
	for j in GameState.elenco:
		if j["id"] == id:
			return j
	return null

func _criar_linha_vazia(slot: Dictionary) -> Control:
	var painel := Tema.cartao(Tema.BRANCO if true else Tema.ROSA, 8)
	var label := Label.new()
	label.text = "( %s vazio — toque em um reserva compatível abaixo )" % slot["categoria"]
	label.add_theme_font_size_override("font_size", 12)
	painel.add_child(label)
	return painel

func _criar_linha_jogador(jogador: Dictionary, slot, eh_titular: bool) -> Control:
	var painel := Tema.cartao(Tema.BRANCO if true else Tema.ROSA, 8)
	var linha := HBoxContainer.new()
	linha.add_theme_constant_override("separation", 10)
	painel.add_child(linha)

	var numero := PanelContainer.new()
	numero.add_theme_stylebox_override("panel", Tema.caixa(Color("C94F50") if eh_titular else Color("8A8270"), Tema.TINTA, 3, 20, false, 0))
	numero.custom_minimum_size = Vector2(40, 40)
	var nl := Label.new()
	nl.text = str(jogador.get("numero", "-"))
	nl.add_theme_color_override("font_color", Color.WHITE)
	nl.add_theme_font_size_override("font_size", 16)
	nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	numero.add_child(nl)
	var nc := CenterContainer.new()
	nc.add_child(numero)
	linha.add_child(nc)

	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha.add_child(info)

	var nome := Label.new()
	nome.text = jogador["nome"]
	nome.add_theme_font_size_override("font_size", 15)
	info.add_child(nome)

	var detalhes := Label.new()
	var pos_label: String = LABEL_POSICAO.get(jogador["posicao"], jogador["posicao"])
	detalhes.text = "%s · OVR %d · Energia %d%%" % [pos_label, int(jogador["overall"]), int(jogador["energia"])]
	detalhes.add_theme_font_size_override("font_size", 11)
	info.add_child(detalhes)

	var botao_acao := Button.new()
	botao_acao.custom_minimum_size = Vector2(96, 40)
	if eh_titular:
		botao_acao.text = "Banco"
		botao_acao.pressed.connect(func(): _mandar_para_banco(slot))
	else:
		botao_acao.text = "Escalar"
		Tema.aplicar_botao(botao_acao, "verde")
		botao_acao.pressed.connect(func(): _escalar_jogador(jogador))
	linha.add_child(botao_acao)

	return painel

func _mandar_para_banco(slot: Dictionary) -> void:
	for s in GameState.slots:
		if s["id"] == slot["id"]:
			s["jogador_id"] = null
			break
	GameState.estado_mudou.emit()

## Mesmo mapa POSICOES_CATEGORIAS do HTML original (ver MatchEngine.gd).
const POSICOES_CATEGORIAS := {
	"GOLEIRO": ["GOL"],
	"DEFENSOR": ["DEF"],
	"MEIA": ["MEI"],
	"MEIA_DEFENSOR": ["DEF", "MEI"],
	"MEIA_ATAQUE": ["MEI", "ATA"],
	"ATAQUE": ["ATA"],
}

## Encontra um slot compatível com a posição do jogador (considerando TODAS as
## categorias em que ele pode atuar sem penalidade, ex.: MEIA_DEFENSOR cabe em
## DEF ou MEI). Prioriza slot vazio; se não houver, usa o primeiro ocupado
## dessas categorias e manda quem estava lá para o banco.
func _escalar_jogador(jogador: Dictionary) -> void:
	var categorias_compativeis: Array = POSICOES_CATEGORIAS.get(jogador["posicao"], ["MEI"])
	var slot_vazio = null
	var slot_ocupado = null
	for s in GameState.slots:
		if not categorias_compativeis.has(s["categoria"]):
			continue
		if s["jogador_id"] == null and slot_vazio == null:
			slot_vazio = s
		elif s["jogador_id"] != null and slot_ocupado == null:
			slot_ocupado = s
	var alvo = slot_vazio if slot_vazio != null else slot_ocupado
	if alvo == null:
		return
	alvo["jogador_id"] = jogador["id"]
	GameState.estado_mudou.emit()

func _on_botao_voltar_pressed() -> void:
	SceneManager.voltar()

func _on_botao_continuar_tatica_pressed() -> void:
	SceneManager.ir_para("escalacao")
