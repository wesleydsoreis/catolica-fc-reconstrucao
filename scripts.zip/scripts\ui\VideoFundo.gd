class_name VideoFundo
extends Control
## Componente único de vídeo de fundo (menu, mapa e telas internas).
## Ogg Theora (único formato de vídeo do Godot 4.4), sem áudio, sem controles, em loop, proporção preservada.
## Se o vídeo não carregar, mostra o quadro de reserva e registra um aviso (nunca falha em silêncio).

signal falhou(motivo: String)

var caminho: String = ""
var reserva: Texture2D                      # quadro estático usado só se o vídeo não puder tocar
var cobrir: bool = true                     # true = cobre a tela (corta sobras); false = cabe inteiro (barras)
var proporcao: float = 16.0 / 9.0
var alinhar_topo: bool = true               # se sobrar altura (telas muito largas), corta embaixo e preserva o topo (título)
var _player: VideoStreamPlayer
var _img: TextureRect
var tocando_video: bool = false

static func criar(arquivo: String, quadro_reserva: Texture2D = null, cobre: bool = true) -> VideoFundo:
	var v := VideoFundo.new()
	v.caminho = arquivo
	v.reserva = quadro_reserva
	v.cobrir = cobre
	return v

func _ready() -> void:
	name = "VideoFundo"
	mouse_filter = Control.MOUSE_FILTER_IGNORE      # o cenário nunca captura cliques nem pode ser pausado pelo jogador
	clip_contents = true
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_img = TextureRect.new()
	_img.name = "Reserva"
	_img.texture = reserva
	_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_img.stretch_mode = TextureRect.STRETCH_SCALE
	_img.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_img)
	_player = VideoStreamPlayer.new()
	_player.name = "Player"
	_player.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_player.expand = true
	_player.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_player.loop = true
	_player.volume_db = -80.0                       # vídeos sem trilha; áudio mudo por garantia
	_player.focus_mode = Control.FOCUS_NONE
	add_child(_player)
	var s: Resource = load(caminho) if ResourceLoader.exists(caminho) else null
	if s is VideoStream:
		_player.stream = s
		_player.play()
		tocando_video = true
		_img.visible = false
	else:
		var motivo := "vídeo não encontrado ou formato incompatível: " + caminho
		push_warning("VideoFundo: " + motivo)
		falhou.emit(motivo)
	resized.connect(_ajustar)
	visibility_changed.connect(func(): if _player != null: _player.paused = not is_visible_in_tree())
	_ajustar()

func _ajustar() -> void:
	if _player == null or size.x < 2.0 or size.y < 2.0:
		return
	var w: float = size.x
	var h: float = w / proporcao
	if cobrir:
		if h < size.y:
			h = size.y
			w = h * proporcao
	else:
		if h > size.y:
			h = size.y
			w = h * proporcao
	w = roundf(w); h = roundf(h)                     # tamanhos inteiros: evita reamostragem em meio pixel (tremor)
	var pos := ((size - Vector2(w, h)) * 0.5).round()
	if cobrir and alinhar_topo and h > size.y:
		pos.y = 0.0
	var r := Rect2(pos, Vector2(w, h))
	_player.position = r.position
	_player.size = r.size
	_img.position = r.position
	_img.size = r.size

## Retângulo (em coordenadas deste controle) que o vídeo ocupa, para alinhar elementos à arte.
func area_do_video() -> Rect2:
	return Rect2(_player.position, _player.size) if _player != null else Rect2(Vector2.ZERO, size)

func esta_tocando() -> bool:
	return _player != null and _player.is_playing()

func posicao() -> float:
	return _player.stream_position if _player != null else 0.0

func liberar() -> void:
	if _player != null:
		_player.stop()
		_player.stream = null
	tocando_video = false

func _exit_tree() -> void:
	liberar()
