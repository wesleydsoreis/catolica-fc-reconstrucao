extends Control
## Resultado
## Mostra o resultado real gerado por GameState.simular_partida(): placar,
## tipo de resultado e o extrato financeiro (receitas/despesas) da rodada.

@onready var label_tipo: Label = $Scroll/Centro/Coluna/LabelTipoResultado
@onready var label_placar: Label = $Scroll/Centro/Coluna/LabelPlacar
@onready var lista_extrato: VBoxContainer = $Scroll/Centro/Coluna/CartaoExtrato/ColunaExtrato/ListaExtrato
@onready var label_saldo: Label = $Scroll/Centro/Coluna/CartaoExtrato/ColunaExtrato/LabelSaldo
@onready var label_caixa_final: Label = $Scroll/Centro/Coluna/LabelCaixaFinal

func _ready() -> void:
	$Scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	$Scroll/Centro/Coluna.custom_minimum_size = Vector2(340, 0)
	for l in [label_tipo, label_placar, label_caixa_final]:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(340, 0)
	label_tipo.add_theme_font_size_override("font_size", 20)
	label_placar.add_theme_font_size_override("font_size", 26)
	label_caixa_final.add_theme_font_size_override("font_size", 20)
	_estilizar()
	var r = GameState.resultado_rodada
	if r == null:
		label_tipo.text = "Sem resultado"
		return

	var textos_tipo := {"vitoria": "VITÓRIA!", "empate": "EMPATE", "derrota": "DERROTA"}
	label_tipo.text = textos_tipo.get(r["tipo_resultado"], "")
	var col: Node = $Scroll/Centro/Coluna
	var lman := Tema.rotulo(str(r.get("manchete", "")), 14, Tema.TITULO)
	lman.name = "Manchete"
	lman.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lman.custom_minimum_size = Vector2(340, 0)
	col.add_child(lman)
	col.move_child(lman, label_placar.get_index() + 1)
	var novas: Array = GameState.pegar_conquistas_novas()
	if not novas.is_empty():
		var nomes: Array = []
		for q in Extras.CONQUISTAS:
			if novas.has(q["id"]):
				nomes.append(q["nome"])
		var lq := Tema.rotulo("CONQUISTA: " + ", ".join(nomes) + " (+R$ %d cada)" % Extras.PREMIO_CONQUISTA, 14, Tema.AMARELO)
		lq.name = "ToastConquista"
		lq.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lq.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lq.custom_minimum_size = Vector2(340, 0)
		col.add_child(lq)
		col.move_child(lq, lman.get_index() + 1)
	var bcol := Tema.botao("COLETIVA DE IMPRENSA" + (" ✔" if bool(GameState.coletiva_atual().get("feita", false)) else ""), "secundario", 46)
	bcol.name = "BotaoColetiva"
	bcol.pressed.connect(func(): SceneManager.ir_para("imprensa"))
	col.add_child(bcol)
	col.move_child(bcol, $Scroll/Centro/Coluna/BotaoProximaRodada.get_index())

	var nome_adversario: String = r["adversario"].get("nome", "?")
	if r["em_casa"]:
		label_placar.text = "Católica FC %d x %d %s" % [r["placar_catolica"], r["placar_adversario"], nome_adversario]
	else:
		label_placar.text = "%s %d x %d Católica FC" % [nome_adversario, r["placar_adversario"], r["placar_catolica"]]

	for filho in lista_extrato.get_children():
		filho.queue_free()
	for item in r["receitas"]:
		lista_extrato.add_child(_criar_linha_extrato(item["label"], int(item["valor"]), true))
	for item in r["despesas"]:
		lista_extrato.add_child(_criar_linha_extrato(item["label"], int(item["valor"]), false))

	label_saldo.text = "Saldo da rodada: %s%s" % ["+" if int(r["saldo_rodada"]) >= 0 else "", _formatar_reais(int(r["saldo_rodada"]))]
	label_caixa_final.text = "Caixa atual: %s" % _formatar_reais(int(r["caixa_final"]))
	var nomes_comp := {"universitario": "Campeonato Universitário", "interlajes": "Campeonato InterLajes", "copa": "Copa dos Gigantes"}
	label_tipo.text += "  ·  " + str(nomes_comp.get(r.get("competicao", ""), ""))
	if str(r.get("rodape", "")) != "":
		var aviso := Label.new()
		aviso.text = str(r["rodape"])
		aviso.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		aviso.custom_minimum_size = Vector2(320, 0)
		aviso.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		aviso.add_theme_font_size_override("font_size", 13)
		aviso.add_theme_color_override("font_color", GameData.cor("vinho") if GameData.has_method("cor") else Color.WHITE)
		label_caixa_final.get_parent().add_child(aviso)
		label_caixa_final.get_parent().move_child(aviso, label_caixa_final.get_index() + 1)
	var disc: Array = r.get("disciplina", [])
	if not disc.is_empty():
		var cd := Tema.cartao(Tema.BRANCO, 10)
		cd.name = "CartaoDisciplina"
		var vd := VBoxContainer.new()
		cd.add_child(vd)
		vd.add_child(Tema.rotulo("OCORRÊNCIAS", 12, Tema.TITULO))
		for m in disc:
			var l := Tema.rotulo(str(m), 13)
			l.custom_minimum_size = Vector2(300, 0)
			vd.add_child(l)
		var pai: Node = $Scroll/Centro/Coluna/CartaoExtrato.get_parent()
		pai.add_child(cd)
		pai.move_child(cd, $Scroll/Centro/Coluna/CartaoExtrato.get_index() + 1)
	if GameState.temporada_status != "em_andamento":
		$Scroll/Centro/Coluna/BotaoProximaRodada.text = "VER RESUMO DA TEMPORADA"

func _estilizar() -> void:
	## Etapa 5: mesmo visual das demais telas (cartões creme/branco com borda, botão vermelho/laranja).
	var cor_tipo: Dictionary = {"vitoria": Tema.VERDE.darkened(0.25), "empate": Tema.TINTA, "derrota": Tema.VINHO}
	var r = GameState.resultado_rodada
	label_tipo.add_theme_color_override("font_color", cor_tipo.get(r["tipo_resultado"], Tema.TINTA) if r != null else Tema.TINTA)
	label_placar.add_theme_color_override("font_color", Tema.TEXTO)
	label_placar.add_theme_font_size_override("font_size", 22)
	label_caixa_final.add_theme_color_override("font_color", Tema.VERDE.darkened(0.3))
	$Scroll/Centro/Coluna/CartaoExtrato.add_theme_stylebox_override("panel", Tema.caixa(Tema.BRANCO))
	var tit: Label = $Scroll/Centro/Coluna/CartaoExtrato/ColunaExtrato/LabelExtratoTitulo
	tit.add_theme_color_override("font_color", Tema.TITULO)
	label_saldo.add_theme_color_override("font_color", Tema.TEXTO)
	Tema.aplicar_botao($Scroll/Centro/Coluna/BotaoProximaRodada, "primario")

func _criar_linha_extrato(rotulo: String, valor: int, eh_receita: bool) -> Control:
	var linha := HBoxContainer.new()
	var label_rotulo := Label.new()
	label_rotulo.text = rotulo
	label_rotulo.add_theme_font_size_override("font_size", 12)
	label_rotulo.add_theme_color_override("font_color", Tema.TEXTO)
	label_rotulo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	linha.add_child(label_rotulo)
	var label_valor := Label.new()
	label_valor.text = "%s%s" % ["+" if eh_receita else "-", _formatar_reais(valor)]
	label_valor.add_theme_font_size_override("font_size", 11)
	label_valor.add_theme_color_override("font_color", GameData.cor("oliva") if eh_receita else GameData.cor("vermelho"))
	linha.add_child(label_valor)
	return linha

func _formatar_reais(valor: int) -> String:
	var negativo := valor < 0
	var v := absi(valor)
	var texto := str(v)
	var resultado := ""
	var contagem := 0
	for i in range(texto.length() - 1, -1, -1):
		resultado = texto[i] + resultado
		contagem += 1
		if contagem % 3 == 0 and i != 0:
			resultado = "." + resultado
	return "%sR$ %s" % ["-" if negativo else "", resultado]

func _on_botao_proxima_rodada_pressed() -> void:
	GameState.avancar_rodada()
	if GameState.temporada_status != "em_andamento":
		SceneManager.ir_para("fim_temporada", false)
	else:
		SceneManager.ir_para("hub", false)
