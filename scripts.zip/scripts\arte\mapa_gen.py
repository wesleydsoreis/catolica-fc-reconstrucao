"""Mapa do clube v2 — pixel art original, estilo detalhado (vermelho e creme). Saída: assets/gerado/mapa.png (300x450)."""
from PIL import Image, ImageDraw
import random, math
W, H = 300, 450
random.seed(11)
img = Image.new("RGB", (W, H), (96, 168, 76))
d = ImageDraw.Draw(img)
T = (36, 20, 18)                       # contorno
V = (166, 40, 48); VE = (112, 26, 34); VC = (214, 84, 84)   # vermelho
C = (247, 238, 214); CE = (214, 200, 168)                  # creme
A = (242, 193, 78); AE = (200, 140, 40)                    # amarelo
G1 = (96, 168, 76); G2 = (84, 154, 66); G3 = (122, 192, 92)
PIS = (206, 192, 168); PIS2 = (186, 170, 146)              # calçada
def rect(x0, y0, x1, y1, f, o=None):
    d.rectangle([x0, y0, x1, y1], fill=f, outline=o)
def sombra(x0, y0, x1, y1):
    d.rectangle([x0 + 3, y1 - 1, x1 + 4, y1 + 4], fill=(70, 128, 58))
# gramado texturizado
for y in range(0, H, 6):
    for x in range(0, W, 6):
        if (x // 6 + y // 6) % 2 == 0:
            rect(x, y, x + 5, y + 5, G2)
for _ in range(500):
    x, y = random.randrange(W), random.randrange(H)
    d.point((x, y), fill=random.choice([G3, (70, 136, 60), (240, 232, 150)]))
# calçadas / praça
def calcada(x0, y0, x1, y1):
    rect(x0, y0, x1, y1, PIS)
    for yy in range(y0, y1, 6):
        d.line([(x0, yy), (x1, yy)], fill=PIS2)
    for xx in range(x0, x1, 12):
        d.line([(xx, y0), (xx, y1)], fill=PIS2)
    d.rectangle([x0, y0, x1, y1], outline=(150, 134, 112))
calcada(138, 140, 162, 400)        # eixo central
calcada(30, 205, 270, 228)         # transversal 1
calcada(30, 300, 270, 322)         # transversal 2
calcada(92, 140, 208, 205)         # praça do brasão
# brasão no chão (escudo com C)
cx, cy = 150, 172
d.polygon([(cx-20, cy-20), (cx+20, cy-20), (cx+20, cy+4), (cx, cy+24), (cx-20, cy+4)], fill=T)
d.polygon([(cx-17, cy-17), (cx+17, cy-17), (cx+17, cy+3), (cx, cy+20), (cx-17, cy+3)], fill=V)
d.polygon([(cx-17, cy-17), (cx+17, cy-17), (cx+17, cy-11), (cx-17, cy-11)], fill=VC)
d.arc([cx-10, cy-12, cx+10, cy+10], 40, 320, fill=C, width=4)
d.rectangle([cx+6, cy-8, cx+9, cy-5], fill=A)
# ---------------- árvores / arbustos / postes
def arvore(x, y, r=8):
    d.ellipse([x - r + 2, y + r - 3, x + r + 3, y + r + 3], fill=(66, 124, 56))
    d.rectangle([x - 1, y + r - 3, x + 1, y + r + 2], fill=(92, 58, 30))
    d.ellipse([x - r, y - r, x + r, y + r], fill=T)
    d.ellipse([x - r + 1, y - r + 1, x + r - 1, y + r - 1], fill=(48, 124, 64))
    d.ellipse([x - r + 2, y - r + 2, x + 1, y + 1], fill=(78, 160, 80))
    d.point((x - 3, y - 4), fill=(150, 210, 120))
def arbusto(x, y):
    d.ellipse([x - 5, y - 3, x + 5, y + 3], fill=T)
    d.ellipse([x - 4, y - 3, x + 4, y + 2], fill=(52, 130, 66))
    d.point((x - 2, y - 2), fill=(120, 190, 100))
def poste(x, y):
    d.rectangle([x, y - 12, x + 1, y], fill=T)
    d.rectangle([x - 2, y - 15, x + 3, y - 12], fill=T)
    d.rectangle([x - 1, y - 14, x + 2, y - 13], fill=A)
def bandeira(x, y):
    d.rectangle([x, y - 16, x, y], fill=T)
    d.polygon([(x + 1, y - 16), (x + 9, y - 13), (x + 1, y - 10)], fill=V, outline=T)
# ---------------- ESTÁDIO
def estadio():
    cx, cy = 150, 78
    sombra(cx - 100, cy - 54, cx + 100, cy + 56)
    d.rounded_rectangle([cx - 104, cy - 56, cx + 104, cy + 56], 26, fill=T)
    d.rounded_rectangle([cx - 102, cy - 54, cx + 102, cy + 54], 24, fill=VE)
    d.rounded_rectangle([cx - 98, cy - 50, cx + 98, cy + 50], 22, fill=V)
    # arquibancada (fileiras creme/vermelho)
    d.rounded_rectangle([cx - 90, cy - 42, cx + 90, cy + 42], 18, fill=T)
    for i, r in enumerate(range(0, 9, 2)):
        d.rounded_rectangle([cx - 88 + r, cy - 40 + r, cx + 88 - r, cy + 40 - r], 16 - r // 2, fill=(C if i % 2 == 0 else VC))
    # torcida (pontinhos)
    random.seed(3)
    for _ in range(420):
        x = random.randrange(cx - 86, cx + 86); y = random.randrange(cy - 38, cy + 38)
        if abs(x - cx) > 66 or abs(y - cy) > 26:
            d.point((x, y), fill=random.choice([V, T, A, C, (255, 255, 255), VE]))
    # campo
    rect(cx - 68, cy - 28, cx + 68, cy + 28, T)
    for k in range(10):
        rect(cx - 66 + k * 13.2, cy - 26, cx - 66 + (k + 1) * 13.2, cy + 26, (60, 150, 66) if k % 2 == 0 else (76, 170, 76))
    lc = (255, 252, 240)
    d.rectangle([cx - 64, cy - 24, cx + 64, cy + 24], outline=lc)
    d.line([(cx, cy - 24), (cx, cy + 24)], fill=lc)
    d.ellipse([cx - 8, cy - 8, cx + 8, cy + 8], outline=lc)
    d.rectangle([cx - 64, cy - 11, cx - 50, cy + 11], outline=lc)
    d.rectangle([cx + 50, cy - 11, cx + 64, cy + 11], outline=lc)
    d.rectangle([cx - 68, cy - 5, cx - 64, cy + 5], fill=lc)
    d.rectangle([cx + 64, cy - 5, cx + 68, cy + 5], fill=lc)
    # refletores
    for (lx, ly) in [(cx - 98, cy - 48), (cx + 98, cy - 48), (cx - 98, cy + 40), (cx + 98, cy + 40)]:
        d.rectangle([lx - 1, ly - 10, lx + 1, ly + 8], fill=T)
        d.rectangle([lx - 6, ly - 16, lx + 6, ly - 9], fill=T)
        d.rectangle([lx - 5, ly - 15, lx + 5, ly - 10], fill=(255, 244, 170))
        for q in (-3, 0, 3): d.point((lx + q, ly - 12), fill=(255, 255, 255))
    # faixa do nome
    rect(cx - 36, 14, cx + 36, 26, T); rect(cx - 35, 15, cx + 35, 25, V); rect(cx - 35, 15, cx + 35, 17, VC)
    rect(cx - 34, 24, cx + 34, 24, VE)
estadio()
# ---------------- SEDE E DIRETORIA (esquerda)
def predio(x0, y0, x1, y1, tel, par, faixa=None, janelas=3, toldo=None):
    sombra(x0, y0, x1, y1)
    rect(x0 - 1, y0 - 1, x1 + 1, y1 + 1, T)
    rect(x0, y0 + 10, x1, y1, par)
    rect(x0, y0 + 10, x0 + 2, y1, CE)
    rect(x0 - 2, y0 - 6, x1 + 2, y0 + 12, T)
    rect(x0 - 1, y0 - 5, x1 + 1, y0 + 11, tel)
    rect(x0 - 1, y0 - 5, x1 + 1, y0 - 3, tuple(min(255, c + 36) for c in tel))
    rect(x0 - 1, y0 + 9, x1 + 1, y0 + 11, tuple(max(0, c - 40) for c in tel))
    if faixa: rect(x0 + 1, y0 + 13, x1 - 1, y0 + 17, faixa)
    n = janelas; w = x1 - x0
    for i in range(n):
        jx = x0 + 6 + i * (w - 18) // max(1, n - 1) if n > 1 else x0 + w // 2 - 4
        rect(jx, y0 + 20, jx + 8, y0 + 29, T); rect(jx + 1, y0 + 21, jx + 7, y0 + 28, (150, 200, 230)); d.line([(jx + 4, y0 + 21), (jx + 4, y0 + 28)], fill=T)
    mx = (x0 + x1) // 2
    rect(mx - 5, y1 - 14, mx + 5, y1, T); rect(mx - 4, y1 - 13, mx + 4, y1, (110, 70, 44)); d.point((mx + 2, y1 - 7), fill=A)
    if toldo:
        for i in range(x0, x1, 6):
            rect(i, y0 + 14, min(i + 2, x1), y0 + 22, toldo); rect(i + 3, y0 + 14, min(i + 5, x1), y0 + 22, C)
predio(22, 150, 94, 202, V, C, faixa=A)
rect(48, 138, 68, 148, T); rect(49, 139, 67, 147, V)   # placa
# MERCADO
predio(22, 238, 94, 290, (60, 80, 120) if False else VE, C, janelas=2, toldo=V)
# ---------------- CAMPO DE TREINO (direita)
def campo_treino(x0, y0, x1, y1):
    rect(x0 - 3, y0 - 3, x1 + 3, y1 + 3, T)
    rect(x0, y0, x1, y1, (66, 150, 70))
    for k in range(0, x1 - x0, 14):
        rect(x0 + k, y0, x0 + k + 7, y1, (80, 168, 80))
    lc = (255, 252, 240)
    d.rectangle([x0 + 3, y0 + 3, x1 - 3, y1 - 3], outline=lc)
    d.line([(x0 + 3, (y0 + y1) // 2), (x1 - 3, (y0 + y1) // 2)], fill=lc)
    d.ellipse([(x0 + x1) // 2 - 7, (y0 + y1) // 2 - 7, (x0 + x1) // 2 + 7, (y0 + y1) // 2 + 7], outline=lc)
    for gx in ((x0 + x1) // 2 - 10, (x0 + x1) // 2 + 2):
        rect(gx, y0 + 3, gx + 8, y0 + 8, lc); rect(gx + 1, y0 + 4, gx + 7, y0 + 7, (120, 150, 120))
    for k in range(4):
        d.rectangle([x0 + 8 + k * 7, y0 + 24 + (k % 2) * 3, x0 + 10 + k * 7, y0 + 30 + (k % 2) * 3], fill=A)  # cones
    # alambrado
    for xx in range(x0 - 3, x1 + 4, 5): d.line([(xx, y1 + 3), (xx, y1 + 8)], fill=T)
    d.line([(x0 - 3, y1 + 4), (x1 + 3, y1 + 4)], fill=T)
    # banco de reservas
    rect(x1 - 30, y1 + 8, x1, y1 + 15, T); rect(x1 - 29, y1 + 9, x1 - 1, y1 + 14, V)
campo_treino(176, 150, 270, 200)
# ---------------- PLACAR DO CAMPEONATO (centro)
def placar():
    x0, y0, x1, y1 = 100, 238, 200, 292
    sombra(x0, y0, x1, y1)
    rect(x0 - 3, y0 - 3, x1 + 3, y1 + 3, T)
    rect(x0, y0, x1, y1, VE)
    rect(x0 + 2, y0 + 2, x1 - 2, y0 + 14, V)
    d.ellipse([x0 + 8, y0 + 3, x0 + 18, y0 + 13], fill=A)
    for i in range(5):
        yy = y0 + 20 + i * 6
        rect(x0 + 6, yy, x0 + 42, yy + 3, C if i else A)
        rect(x0 + 46, yy, x0 + 56, yy + 3, CE)
    # chaves
    for i in range(4):
        yy = y0 + 20 + i * 8
        rect(x0 + 64, yy, x0 + 74, yy + 2, C); d.line([(x0 + 74, yy + 1), (x0 + 74, yy + 9)], fill=C)
    d.line([(x0 + 74, y0 + 25), (x0 + 82, y0 + 25)], fill=C)
    d.ellipse([x0 + 82, y0 + 30, x0 + 94, y0 + 42], fill=A, outline=AE)
    # postes
    rect(x0 + 8, y1, x0 + 11, y1 + 6, T); rect(x1 - 11, y1, x1 - 8, y1 + 6, T)
    for i in range(6): arbusto(x0 + 6 + i * 18, y1 + 10)
placar()
# ---------------- OBRAS (direita)
def obras(x0, y0, x1, y1):
    rect(x0 - 2, y0 - 2, x1 + 2, y1 + 2, T)
    rect(x0, y0, x1, y1, (160, 120, 80))
    for i in range(0, 22):
        d.point((x0 + random.randrange(x1 - x0), y0 + random.randrange(y1 - y0)), fill=(120, 86, 54))
    # esqueleto do prédio
    bx = x0 + 10
    for lv in range(3):
        yy = y0 + 8 + lv * 12
        rect(bx, yy, bx + 44, yy + 2, (190, 190, 190))
        for pil in range(4): rect(bx + pil * 14, yy, bx + pil * 14 + 2, yy + 12, (150, 150, 150))
    rect(bx, y0 + 8, bx + 44, y0 + 10, (210, 210, 210))
    # guindaste
    d.line([(x1 - 12, y0 - 14), (x1 - 12, y1 - 6)], fill=T, width=2)
    d.line([(x1 - 12, y0 - 14), (x0 + 10, y0 - 10)], fill=T, width=2)
    d.line([(x1 - 12, y0 - 14), (x1 - 4, y0 - 10)], fill=T)
    rect(x1 - 15, y0 - 18, x1 - 9, y0 - 12, A)
    d.line([(x0 + 14, y0 - 10), (x0 + 14, y0 + 4)], fill=T)
    rect(x0 + 11, y0 + 4, x0 + 17, y0 + 8, A)
    # trator
    rect(x1 - 36, y1 - 14, x1 - 12, y1 - 4, T); rect(x1 - 35, y1 - 13, x1 - 13, y1 - 5, A)
    rect(x1 - 32, y1 - 18, x1 - 24, y1 - 12, T); rect(x1 - 31, y1 - 17, x1 - 25, y1 - 13, (150, 200, 230))
    d.ellipse([x1 - 36, y1 - 7, x1 - 28, y1 - 1], fill=T); d.ellipse([x1 - 20, y1 - 7, x1 - 12, y1 - 1], fill=T)
    # cercas vermelho/creme
    for xx in range(x0 - 2, x1 + 3, 8):
        rect(xx, y1 + 2, xx + 3, y1 + 6, V); rect(xx + 4, y1 + 2, xx + 7, y1 + 6, C)
obras(176, 238, 272, 292)
# ---------------- VESTIÁRIO (esquerda baixo) e VILA (direita baixo)
predio(22, 332, 94, 380, VE, C, faixa=C, janelas=3)
rect(36, 338, 80, 344, T); rect(37, 339, 79, 343, A)
for (hx, hy, tc, w) in [(184, 336, (176, 90, 70), 30), (222, 336, (150, 60, 66), 30), (203, 372, (190, 110, 70), 30)]:
    sombra(hx, hy, hx + w, hy + 26)
    rect(hx - 1, hy - 1, hx + w + 1, hy + 27, T); rect(hx, hy + 8, hx + w, hy + 26, C)
    d.polygon([(hx - 3, hy + 10), (hx + w // 2, hy - 8), (hx + w + 3, hy + 10)], fill=T)
    d.polygon([(hx - 1, hy + 9), (hx + w // 2, hy - 6), (hx + w + 1, hy + 9)], fill=tc)
    rect(hx + w // 2 - 3, hy + 16, hx + w // 2 + 3, hy + 26, (100, 64, 40))
    rect(hx + 4, hy + 12, hx + 9, hy + 17, (150, 200, 230))
# ---------------- ESTACIONAMENTO (esq. centro-baixo)
rect(100, 336, 126, 392, (80, 76, 80), T)
for i in range(5): d.line([(102, 340 + i * 11), (124, 340 + i * 11)], fill=(230, 230, 230))
for (px, py, c) in [(104, 342, V), (114, 342, (240, 240, 240)), (104, 364, (30, 30, 36)), (114, 375, A)]:
    rect(px, py, px + 8, py + 14, T); rect(px + 1, py + 1, px + 7, py + 13, c); rect(px + 2, py + 3, px + 6, py + 6, (150, 200, 230))
# ---------------- PORTÃO + RUA
rect(0, 420, W, 450, (78, 74, 80))
for x in range(4, W, 20): d.line([(x, 436), (x + 10, 436)], fill=(230, 200, 90))
rect(0, 416, W, 420, (160, 150, 140))
rect(110, 392, 190, 420, T)
rect(112, 394, 188, 420, V)
d.pieslice([116, 386, 184, 430], 180, 360, fill=T)
d.pieslice([120, 390, 180, 426], 180, 360, fill=VE)
rect(126, 408, 174, 420, (60, 56, 60))
d.ellipse([142, 396, 158, 410], fill=C, outline=T); d.arc([144, 398, 156, 408], 40, 320, fill=V, width=2)
for xx in (108, 192): rect(xx, 394, xx + 5, 420, T); rect(xx + 1, 395, xx + 4, 419, C)
# faixa de pedestre
for i in range(6): rect(146 + (i % 2) * 0 + i * 0, 424 + i * 0, 146, 424, PIS)
# banner inferior direito
rect(212, 398, 290, 414, T); rect(213, 399, 289, 413, V); rect(213, 399, 289, 401, VC)
# ---------------- decoração
for p in [(12, 30), (14, 110), (10, 215), (12, 316), (10, 395), (288, 30), (288, 120), (288, 215), (288, 312), (286, 392), (108, 224), (196, 224), (108, 318), (196, 318), (26, 140), (100, 130), (200, 130), (130, 396), (170, 396)]:
    arvore(*p, r=8)
for p in [(98, 160), (202, 160), (98, 250), (202, 250), (98, 345), (130, 215), (170, 215)]:
    arbusto(*p)
for p in [(134, 214), (166, 214), (134, 312), (166, 312), (126, 150), (174, 150)]:
    poste(*p)
for p in [(100, 210), (200, 210)]:
    bandeira(*p)
img.save("assets/gerado/mapa.png")
print("ok", img.size)
