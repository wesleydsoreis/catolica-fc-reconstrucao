extends Control
## Desafio
## Primeira etapa do fluxo de rodada: mostra o adversário real do calendário
## e a chance estimada (mesma fórmula usada na simulação de verdade).

@onready var label_rodada: Label = $Centro/Coluna/LabelRodada
@onready var label_mando: Label = $Centro/Coluna/LabelMando
@onready var label_adversario: Label = $Centro/Coluna/LabelAdversario
@onready var label_chances: Label = $Centro/Coluna/CartaoChances/LinhaChances/LabelChances

func _ready() -> void:
	label_rodada.add_theme_color_override("font_color", Tema.TITULO)
	label_mando.add_theme_color_override("font_color", Tema.TEXTO)
	label_adversario.add_theme_color_override("font_color", Tema.TITULO)
	$Centro/Coluna/CartaoChances.add_theme_stylebox_override("panel", Tema.caixa(Tema.BRANCO))
	$Centro/Coluna/CartaoChances/LinhaChances/LabelChancesTitulo.add_theme_color_override("font_color", Tema.TITULO)
	Tema.aplicar_botao($Centro/Coluna/BotaoContinuar, "primario")
	var info = GameState.obter_partida_da_rodada()
	if info == null:
		label_adversario.text = "Sem partida nesta rodada"
		label_chances.text = "A Católica não disputa mais competições nesta temporada."
		return

	var total_rodadas: int = GameData.regras_especiais.get("total_rodadas", 28)
	var nomes_comp := {"universitario": "UNIVERSITÁRIO", "interlajes": "INTERLAJES", "copa": "COPA DOS GIGANTES"}
	label_rodada.text = "%s · RODADA %d DE %d" % [nomes_comp.get(info["competicao"], ""), GameState.rodada_atual, total_rodadas]
	if info["competicao"] == "interlajes":
		label_rodada.text += "\n%s · %s" % [str(info["estagio"]).to_upper(), "IDA" if info["lado"] == "ida" else "VOLTA"]
	label_mando.text = "EM CASA" if info["em_casa"] else "FORA DE CASA"
	label_adversario.text = info["adversario"].get("nome", "?")
	var cl: String = GameState.clima_atual()
	var txt_cl := "Clima: %s — %s" % [Extras.CLIMAS[cl]["nome"], Extras.CLIMAS[cl]["desc"]]
	if GameState.eh_classico(info["adversario"]):
		txt_cl = "CLÁSSICO! Rivalidade contra %s: público +25%%, torcida e diretoria ±3.\n" % GameState.nome_rival() + txt_cl
	var lcl := Tema.rotulo(txt_cl, 13, Tema.TITULO)
	lcl.name = "AvisoClima"
	lcl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lcl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lcl.custom_minimum_size = Vector2(340, 0)
	label_mando.get_parent().add_child(lcl)
	label_mando.get_parent().move_child(lcl, label_adversario.get_index() + 1)
	_cartao_diretor()
	var susp: Array = GameState.suspensos()
	var les: Array = GameState.lesionados()
	if not susp.is_empty() or not les.is_empty():
		var nomes: Array = []
		for j in susp:
			nomes.append(str(j["nome"]) + " (susp.)")
		for j in les:
			nomes.append("%s (lesão %d)" % [j["nome"], int(j.get("lesao", 0))])
		var aviso := Tema.rotulo("Desfalques: " + ", ".join(nomes), 13, Tema.TITULO)
		aviso.name = "AvisoSuspensos"
		aviso.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label_mando.get_parent().add_child(aviso)
		label_mando.get_parent().move_child(aviso, label_adversario.get_index() + 1)

	var penalidades := {"deficit": float(GameState.financas["caixa"]) < 0.0, "salarios_atrasados": false}
	var detalhado: Dictionary = MatchEngine.calcular_forca_detalhada({
		"elenco": GameState.elenco, "slots": GameState.slots, "financas": GameState.financas,
		"tatica_id": GameState.tatica_id, "mando_de_campo": info["em_casa"], "adversario": info["adversario"],
		"forca_extra_preparacao": GameState.forca_extra_preparacao, "penalidades": penalidades,
		"reacao_elenco": 0.0, "clube": GameState.clube, "capitao_id": GameState.capitao_id,
	})
	var probs: Dictionary = MatchEngine.calcular_probabilidades_universitario({
		"overall_catolica": float(detalhado["base"]) + detalhado["bonus_energia"] + detalhado["bonus_moral"],
		"overall_adversario": float(info["adversario"]["forca"]),
		"em_casa": info["em_casa"], "campo_neutro": false,
		"situacao_tatica": detalhado["situacao_tatica"], "fora_de_posicao_qtd": detalhado["fora_de_posicao_qtd"],
		"qtd_preparos_usados": 0, "bonus_energia_pontos": detalhado["bonus_energia"],
		"bonus_moral_pontos": detalhado["bonus_moral"], "nivel_estadio_soma": 0,
		"ultimos_resultados": GameState.ultimos_resultados,
	})
	label_chances.text = "Vitória %d%% · Empate %d%% · Derrota %d%%" % [
		round(probs["vitoria"] * 100), round(probs["empate"] * 100), round(probs["derrota"] * 100)
	]

## Cartão do Desafio do Diretor (opcional, 1 por rodada): resolve com os dados reais e rende bônus de caixa/moral.
func _cartao_diretor() -> void:
	var col: Node = $Centro/Coluna
	var c := Tema.cartao(Tema.AMARELO)
	c.name = "CartaoDiretor"
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	c.add_child(v)
	var area: String = Educacao.area_da_rodada(GameState.competencias, GameState.rodada_atual)
	var feito: bool = GameState.desafio_resolvido()
	v.add_child(Tema.rotulo("DESAFIO DO DIRETOR · " + str(Educacao.AREA_NOME[area]).to_upper(), 12, Tema.TINTA))
	v.add_child(Tema.rotulo(("Resolvido! Volte na próxima rodada." if feito else "Um problema com os números do seu clube. Acertar rende R$ %d no caixa e moral." % Educacao.RECOMPENSA_1A), 13, Tema.TINTA))
	var b := Tema.botao("VER PROBLEMA" if not feito else "REVER EXPLICAÇÃO", "primario", 42)
	b.name = "BotaoDiretor"
	b.pressed.connect(func(): SceneManager.ir_para("diretor"))
	v.add_child(b)
	var bp := Tema.botao("PRANCHETA", "secundario", 38)
	bp.name = "BotaoPranchetaDesafio"
	bp.pressed.connect(func(): SceneManager.ir_para("prancheta"))
	v.add_child(bp)
	col.add_child(c)
	col.move_child(c, $Centro/Coluna/EspacoA.get_index())

func _on_botao_continuar_pressed() -> void:
	SceneManager.ir_para("preparacao")
