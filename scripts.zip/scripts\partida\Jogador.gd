extends Node2D
class_name Jogador
## Jogador desenhado por código (estilo cartoon, vista oblíqua). A origem do nó fica nos pés.

var time: int = 0                 # 0 = Católica (casa), 1 = adversário
var papel: String = "MEI"         # GOL, DEF, MEI, ATA
var numero: int = 1
var nome: String = ""
var base_norm: Vector2 = Vector2.ZERO
var vel: Vector2 = Vector2.ZERO
var face: Vector2 = Vector2.RIGHT
var controlado: bool = false
var anel: Color = Color(0, 0, 0, 0)
var cor1: Color = Color.RED
var cor2: Color = Color.DARK_RED
var cor_num: Color = Color.WHITE
var pele: Color = Color("f1c9a0")
var cabelo: Color = Color("2b1b10")
var atributos: Dictionary = {}
var jid: String = ""              # id do jogador no elenco (disciplina entre partidas)
var moral: float = 50.0
var fisico: float = 60.0           # condição física (treino): reduz o cansaço
var tecnica: float = 60.0
var lesionado: bool = false        # lesionado em jogo sem substituição: corre menos
var energia_ini: float = 100.0

var cd_captura: float = 0.0
var cd_desarme: float = 0.0
var cd_defesa: float = 0.0
var atordoado: float = 0.0
var investida: float = 0.0
var investida_dir: Vector2 = Vector2.ZERO
var invest_tipo: String = ""      # "pe" = desarme em pé (rápido, baixo risco) | "carrinho" = deslize (alcance maior, risco de falta)
var comemorando: float = 0.0
var amarelos: int = 0
var expulso: bool = false
var segurando: float = 0.0
var pensar: float = 0.0
var mergulhando: bool = false
var erro_y: float = 0.0
var carga: float = 0.0
var anim_t: float = 0.0

func habil(nome_atributo: String) -> float:
	return float(atributos.get(nome_atributo, 0.8))

const ESC: float = 1.6
const LARG: int = 48
const ALT: int = 52
static var _labels: Image = null
static var _cache: Dictionary = {}
var _frames: Array = []
var _chave: String = ""

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _process(delta: float) -> void:
	anim_t += delta
	queue_redraw()

static func _imagem_labels() -> Image:
	if _labels == null:
		var tex: Texture2D = load("res://assets/jogadores/labels.png")
		_labels = tex.get_image()
		if _labels.is_compressed():
			_labels.decompress()
		_labels.convert(Image.FORMAT_RGBA8)
	return _labels

func _montar() -> void:
	var chuteira: Color = Color("F39C12") if time == 0 else Color("1A1410")
	var k: String = "%s|%s|%s|%s|%s|%s" % [cor1.to_html(), cor2.to_html(), pele.to_html(), cabelo.to_html(), chuteira.to_html(), str(papel == "GOL")]
	if k == _chave:
		return
	_chave = k
	if _cache.has(k):
		_frames = _cache[k]
		return
	var pal: Dictionary = {
		1: pele, 2: cabelo, 3: cor1, 4: cor2, 5: cor1, 6: chuteira,
		8: Color("1e1612"), 9: pele.lightened(0.12), 10: Color("140e0c"), 11: Color("fffdf8"),
		12: cor1.lightened(0.28), 13: Color("fafafa"), 15: pele.darkened(0.25), 99: Color("120c0a"),
	}
	var src: Image = _imagem_labels()
	var quadros: Array = []
	for f in 6:
		var img := Image.create(LARG, ALT, false, Image.FORMAT_RGBA8)
		for y in ALT:
			for x in LARG:
				var p: Color = src.get_pixel(f * LARG + x, y)
				if p.a < 0.5:
					continue
				var lab: int = int(round(p.r * 255.0))
				var c: Color = pal.get(lab, Color.MAGENTA)
				if p.g > 0.5 and lab >= 1 and lab <= 5:
					c = c.darkened(0.2)
				img.set_pixel(x, y, c)
		quadros.append(ImageTexture.create_from_image(img))
	_cache[k] = quadros
	_frames = quadros

func _draw() -> void:
	_montar()
	# sombra
	draw_set_transform(Vector2(0, 2), 0.0, Vector2(1.0, 0.38))
	draw_circle(Vector2.ZERO, 19.0, Color(0, 0, 0, 0.32))
	if anel.a > 0.0:
		draw_arc(Vector2.ZERO, 28.0, 0.0, TAU, 30, anel, 4.5)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var mov: float = clampf(vel.length() / 200.0, 0.0, 1.0)
	var quadro: int = 0
	var dy: float = 0.0
	if comemorando > 0.0:
		quadro = 5
		dy = -absf(sin(anim_t * 7.0)) * 10.0
	elif (investida > 0.0 and invest_tipo != "pe") or mergulhando:
		quadro = 4
		dy = 9.0 * ESC
	elif carga > 0.05 or cd_desarme > 0.25:
		quadro = 3
	elif mov > 0.1:
		quadro = 1 if int(anim_t * (7.0 + 5.0 * mov)) % 2 == 0 else 2
		dy = -absf(sin(anim_t * 12.0)) * 1.5
	var tex: Texture2D = _frames[quadro]
	var esq: bool = face.x < -0.15
	if esq:
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(-1.0, 1.0))
	draw_texture_rect(tex, Rect2(Vector2(-22.0 * ESC, -49.0 * ESC + dy), Vector2(LARG, ALT) * ESC), false)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if controlado:
		var t1: Texture2D = PixelUI.texto("1P", 2, Color.WHITE)
		var ty: float = -49.0 * ESC - 30.0
		var rw: float = float(t1.get_width()) + 10.0
		draw_rect(Rect2(-rw * 0.5 - 2.0, ty - 2.0, rw + 4.0, 24.0), Color("120c0a"))
		draw_rect(Rect2(-rw * 0.5, ty, rw, 20.0), Color("c93232"))
		draw_colored_polygon(PackedVector2Array([Vector2(-6, ty + 20), Vector2(6, ty + 20), Vector2(0, ty + 27)]), Color("c93232"))
		draw_texture(t1, Vector2(-float(t1.get_width()) * 0.5, ty + 3.0))
