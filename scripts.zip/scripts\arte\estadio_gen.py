"""Gera o fundo do estádio (teto, parede, camarotes, degraus) e a torcida animada (3 frames)."""
import random, os, json
from PIL import Image, ImageDraw
from palette import *
from campo_gen import SW,SH
CROWD_Y=60; CROWD_H=SH-CROWD_Y
def fundo():
    im=Image.new("RGBA",(SW,SH),PAREDE1); d=ImageDraw.Draw(im)
    d.rectangle((0,0,SW,13),fill=CEU1); d.rectangle((0,14,SW,17),fill=CEU2)
    for x in range(30,SW,96): d.rectangle((x,6,x+6,7),fill=(255,255,255,255)); d.rectangle((x+2,9,x+4,9),fill=(255,255,255,255))
    for x in range(0,SW,48): d.line((x,0,x,13),fill=(120,210,255,255))
    d.rectangle((0,18,SW,59),fill=PAREDE1); d.line((0,18,SW,18),fill=PAREDE2)
    # degraus
    for y in range(CROWD_Y,SH):
        c=[DEGRAU1,DEGRAU2][((y-CROWD_Y)//3)%2]
        d.line((0,y,SW,y),fill=c)
    d.line((0,CROWD_Y,SW,CROWD_Y),fill=DEGRAU3)
    # camarotes (molduras e vidro; silhuetas são animadas à parte)
    for gx,n in ((-12,4),(148,6),(378,4)):
        for k in range(n):
            x=gx+k*31
            d.rectangle((x,26,x+31,54),fill=MOLDURA); d.rectangle((x+1,27,x+30,53),fill=VIDRO)
        if True:
            x=gx
            for t in range(10): d.line((x+22-t,27+t*0,x+4-t+10,27+t+0),fill=VIDRO) if False else None
    return im
def reflexos(im):
    d=ImageDraw.Draw(im)
    for gx,n in ((-12,4),(148,6),(378,4)):
        for k in (0,3,5):
            if k>=n: continue
            x=gx+k*31
            for t in range(9): d.point((x+3+t,28+ (8-t)),fill=VIDRO_REFL)
            for t in range(6): d.point((x+22+t,45+ (5-t)),fill=VIDRO_REFL)
def silhuetas():
    """2 frames de 31x27 por painel (teal sobre vidro)"""
    fr=[]
    for f in range(2):
        im=Image.new("RGBA",(31,27),VIDRO); d=ImageDraw.Draw(im)
        for i,cx in enumerate((6,15,24)):
            up=(f+i)%2==0
            d.rectangle((cx-3,12,cx+2,17),fill=SILH)         # cabeça
            d.rectangle((cx-5,18,cx+4,26),fill=SILH)         # corpo
            if up:
                d.rectangle((cx-6,8,cx-5,17),fill=SILH); d.rectangle((cx+5,8,cx+6,17),fill=SILH)
            else:
                d.rectangle((cx-6,19,cx-5,24),fill=SILH); d.rectangle((cx+5,19,cx+6,24),fill=SILH)
        fr.append(im)
    return fr
def pessoa(d,x,y,P,estado,bob):
    pele,cab,camisa,estilo,ba=P
    y+=bob
    esc=tuple(int(v*.78) for v in camisa[:3])+(255,)
    d.rectangle((x-1,y+6,x+6,y+11),fill=camisa); d.rectangle((x+6,y+6,x+6,y+11),fill=esc)
    if estado:
        d.rectangle((x-2,y-3,x-1,y+6),fill=pele); d.rectangle((x+6,y-3,x+7,y+6),fill=pele)
    else:
        d.rectangle((x-2,y+7,x-2,y+10),fill=pele); d.rectangle((x+7,y+7,x+7,y+10),fill=pele)
    d.rectangle((x,y,x+5,y+5),fill=pele)
    d.rectangle((x,y,x+5,y+1),fill=cab)
    if estilo==1: d.rectangle((x-1,y,x+6,y+2),fill=cab)
    if estilo==2: d.rectangle((x,y+2,x,y+3),fill=cab); d.rectangle((x+5,y+2,x+5,y+3),fill=cab)
    d.point((x+1,y+3),fill=CONTORNO); d.point((x+4,y+3),fill=CONTORNO)
    d.point((x+2,y+5) if ba else (x+3,y+5),fill=(150,70,60,255))
def torcida(seed=7):
    rnd=random.Random(seed); linhas=[]
    r=0; y=0
    while y<CROWD_H:
        xs=[]; x=-3+(r%2)*5
        while x<SW+6:
            P=(rnd.choice(PELE[:]*1+[PELE[0]]*2),rnd.choice(CABELOS),rnd.choice(CAMISAS),rnd.choice([0,0,1,2]),rnd.random()<.5)
            xs.append((x+rnd.randint(0,1),P,rnd.random(),rnd.random())); x+=10
        linhas.append((y,xs)); y+=8; r+=1
    sheet=Image.new("RGBA",(SW,CROWD_H*3),(0,0,0,0))
    for f in range(3):
        fr=Image.new("RGBA",(SW,CROWD_H),(0,0,0,0)); d=ImageDraw.Draw(fr)
        for (y,xs) in linhas:
            for (x,P,a,b) in xs:
                estado={0:False,1:a<0.28,2:a<0.78}[f]
                bob=1 if (f==1 and b<0.5) else 0
                pessoa(d,x,y,P,estado,bob)
        sheet.paste(fr,(0,f*CROWD_H))
    return sheet
def main(out):
    im=fundo(); reflexos(im); im.save(os.path.join(out,"estadio_fundo.png"))
    s=silhuetas(); sh=Image.new("RGBA",(31,54)); sh.paste(s[0],(0,0)); sh.paste(s[1],(0,27)); sh.save(os.path.join(out,"camarote_silhuetas.png"))
    torcida().save(os.path.join(out,"torcida_sheet.png"))
    json.dump(dict(CROWD_Y=CROWD_Y,CROWD_H=CROWD_H,grupos=[[-12,4],[148,6],[378,4]]),open(os.path.join(out,"estadio.json"),"w"))
if __name__=="__main__":
    main(os.path.join(os.path.dirname(__file__),"..","..","assets","gerado"))
