extends Node
## SaveSystem
## Salvamento local em user:// (equivalente ao localStorage do jogo web).
## Salva/restaura tudo que está em GameState.

const CAMINHO_SAVE := "user://savegame.json"

func existe_save() -> bool:
	return FileAccess.file_exists(CAMINHO_SAVE)

var _hash_salvo: int = 0            # 0 = nada salvo/carregado nesta sessão

func _montar() -> Dictionary:
	var dados := {
		"temporada": GameState.temporada,
		"rodada_atual": GameState.rodada_atual,
		"fase_rodada": GameState.fase_rodada,
		"temporada_status": GameState.temporada_status,
		"overall_inicial_carreira": GameState.overall_inicial_carreira,
		"elenco": GameState.elenco,
		"formacao_id": GameState.formacao_id,
		"slots": GameState.slots,
		"tatica_id": GameState.tatica_id,
		"tatica_eixos": GameState.tatica_eixos,
		"disciplina": GameState.disciplina,
		"scouting": GameState.scouting,
		"nivel_escolar": GameState.nivel_escolar,
		"metas": GameState.metas,
		"rival_id": GameState.rival_id, "h2h": GameState.h2h, "base_jovens": GameState.base_jovens, "conquistas": GameState.conquistas,
		"conquistas_novas": GameState.conquistas_novas, "metas_pessoais": GameState.metas_pessoais, "dividas_quitadas": GameState.dividas_quitadas,
		"aluno_nome": GameState.aluno_nome,
		"turma_codigo": GameState.turma_codigo,
		"decisoes_log": GameState.decisoes_log,
		"imprensa_estado": GameState.imprensa_estado,
		"manchete_rodada": GameState.manchete_rodada,
		"avaliacao_diretoria": GameState.avaliacao_diretoria,
		"competencias": GameState.competencias,
		"desafio_estado": GameState.desafio_estado,
		"sala_seed": GameState.sala_seed,
		"educacao_log": GameState.educacao_log,
		"agenda_treino": GameState.agenda_treino,
		"treino_foco_id": GameState.treino_foco_id,
		"treino_confirmado": GameState.treino_confirmado,
		"entrosamento": GameState.entrosamento,
		"financas": GameState.financas,
		"clube": GameState.clube,
		"clubes": GameState.clubes,
		"capitao_id": GameState.capitao_id,
		"mercado_jogadores": GameState.mercado_jogadores,
		"calendario": GameState.calendario,
		"ultimos_resultados": GameState.ultimos_resultados,
		"universitario_posicoes": GameState.universitario_posicoes,
		"universitario_g8": GameState.universitario_g8,
		"interlajes": GameState.interlajes,
		"interlajes_eliminada": GameState.interlajes_eliminada,
		"copa": GameState.copa,
		"copa_calendario": GameState.copa_calendario,
		"fora_da_copa": GameState.fora_da_copa,
		"copa_campeao_id": GameState.copa_campeao_id,
		"trofeus": GameState.trofeus,
		"gols_registrados": GameState.gols_registrados,
		"premios_temporada": GameState.premios_temporada,
		"forca_catolica_dinamica": GameState.forca_catolica_dinamica,
		"escalacao_fut7": GameState.escalacao_fut7,
		"tutorial_concluido": GameState.tutorial_concluido,
	}
	return dados

## Há alterações desde o último salvamento/carregamento?
func nao_salvo() -> bool:
	return _montar().hash() != _hash_salvo

func salvar() -> bool:
	var dados: Dictionary = _montar()
	var arquivo := FileAccess.open(CAMINHO_SAVE, FileAccess.WRITE)
	if arquivo == null:
		push_error("SaveSystem: não foi possível abrir %s para escrita" % CAMINHO_SAVE)
		return false
	arquivo.store_string(JSON.stringify(dados, "  "))
	arquivo.close()
	_hash_salvo = dados.hash()
	return true

func carregar() -> bool:
	if not existe_save():
		return false
	var arquivo := FileAccess.open(CAMINHO_SAVE, FileAccess.READ)
	var texto := arquivo.get_as_text()
	arquivo.close()
	var dados = JSON.parse_string(texto)
	if dados == null:
		push_error("SaveSystem: savegame corrompido")
		return false

	GameState.temporada = dados.get("temporada", 1)
	GameState.rodada_atual = dados.get("rodada_atual", 1)
	GameState.fase_rodada = dados.get("fase_rodada", "desafio")
	GameState.temporada_status = dados.get("temporada_status", "em_andamento")
	GameState.overall_inicial_carreira = dados.get("overall_inicial_carreira", 65)
	GameState.elenco = dados.get("elenco", [])
	GameState.formacao_id = dados.get("formacao_id", "4-3-3")
	GameState.slots = dados.get("slots", [])
	GameState.tatica_id = dados.get("tatica_id")
	GameState.tatica_eixos = dados.get("tatica_eixos", {})
	GameState.disciplina = dados.get("disciplina", {})
	GameState.scouting = dados.get("scouting", {})
	GameState.nivel_escolar = dados.get("nivel_escolar", "medio")
	GameState.tutorial_concluido = bool(dados.get("tutorial_concluido", true))   # saves antigos não repetem o tutorial
	GameState.metas = dados.get("metas", [])
	GameState.rival_id = str(dados.get("rival_id", ""))
	GameState.h2h = dados.get("h2h", {})
	GameState.base_jovens = dados.get("base_jovens", [])
	GameState.conquistas = dados.get("conquistas", {})
	GameState.conquistas_novas = dados.get("conquistas_novas", [])
	GameState.metas_pessoais = dados.get("metas_pessoais", [])
	GameState.dividas_quitadas = int(dados.get("dividas_quitadas", 0))
	GameState.aluno_nome = str(dados.get("aluno_nome", ""))
	GameState.turma_codigo = str(dados.get("turma_codigo", ""))
	GameState.decisoes_log = dados.get("decisoes_log", [])
	GameState.imprensa_estado = dados.get("imprensa_estado", {"rodada": -1, "temporada": -1, "feita": false})
	GameState.manchete_rodada = dados.get("manchete_rodada", "")
	GameState.avaliacao_diretoria = dados.get("avaliacao_diretoria", "")
	GameState.competencias = dados.get("competencias", {})
	GameState.desafio_estado = dados.get("desafio_estado", {"rodada": -1, "temporada": -1, "tentativas": 0, "resolvido": false, "acertou": false})
	GameState.sala_seed = int(dados.get("sala_seed", 0))
	GameState.educacao_log = dados.get("educacao_log", [])
	GameState.agenda_treino = dados.get("agenda_treino", ["fisico", "tecnico", "tatico", "recuperacao"])
	GameState.treino_foco_id = dados.get("treino_foco_id", "")
	GameState.treino_confirmado = dados.get("treino_confirmado", false)
	GameState.entrosamento = dados.get("entrosamento", {"0": 60.0, "1": 40.0, "2": 40.0})
	GameState.financas = dados.get("financas", {})
	if not GameState.financas.has("divida"):
		GameState.financas["divida"] = 0.0
	if GameState.rival_id == "" and not GameState.clubes.is_empty():
		GameState.rival_id = Extras.sortear_rival(GameState.clubes.map(func(c): return str(c["id"])), GameState.sala_seed)
	if GameState.base_jovens.is_empty() and not GameState.elenco.is_empty():
		GameState._novos_jovens()
	if GameState.metas_pessoais.is_empty() and not GameState.elenco.is_empty():
		GameState._novas_metas_pessoais()
	if GameState.metas.is_empty() and not GameState.financas.is_empty():
		GameState._novas_metas()
	GameState.clube = dados.get("clube", {})
	GameState.clubes = dados.get("clubes", [])
	GameState.capitao_id = dados.get("capitao_id")
	GameState.mercado_jogadores = dados.get("mercado_jogadores", [])
	GameState.calendario = dados.get("calendario", [])
	GameState.ultimos_resultados = dados.get("ultimos_resultados", [])
	GameState.universitario_posicoes = dados.get("universitario_posicoes", {})
	GameState.universitario_g8 = dados.get("universitario_g8", [])
	GameState.interlajes = dados.get("interlajes", {})
	GameState.interlajes_eliminada = dados.get("interlajes_eliminada", false)
	GameState.copa = dados.get("copa", [])
	GameState.copa_calendario = dados.get("copa_calendario", [])
	GameState.fora_da_copa = dados.get("fora_da_copa", false)
	GameState.copa_campeao_id = dados.get("copa_campeao_id", "")
	GameState.trofeus = dados.get("trofeus", [])
	GameState.gols_registrados = dados.get("gols_registrados", {})
	GameState.premios_temporada = dados.get("premios_temporada", [])
	GameState.forca_catolica_dinamica = dados.get("forca_catolica_dinamica", 60)
	GameState.escalacao_fut7 = dados.get("escalacao_fut7", {})   # saves antigos não têm: é gerada automaticamente
	_hash_salvo = _montar().hash()
	GameState.carreira_ativa = true
	GameState.estado_mudou.emit()
	return true

## Apaga o progresso salvo. Chamado só depois de confirmação explícita na UI
## (ver Painel.gd / diálogo de confirmação) — nunca automaticamente.
func apagar_progresso() -> void:
	if existe_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(CAMINHO_SAVE))
