extends Control
## Configuração da partida avulsa (amistoso): adversário, formação FUT7 e dificuldade.
## A escolha vai para GameState.amistoso (não salvo) e é lida por PartidaJogo.

var _col: VBoxContainer
var _idx: int = 0
var _lista: Array = []

func _ready() -> void:
	GameState.fut7_garantir()
	_lista = GameState.adversarios_amistoso()
	if GameState.amistoso.is_empty():
		GameState.amistoso = {"adversario_id": str(_lista[0]["id"]) if not _lista.is_empty() else "",
			"formacao_id": str(GameState.escalacao_fut7.get("formacao", "")), "dificuldade": "normal"}
	GameState.amistoso["em_jogo"] = false
	for i in _lista.size():
		if _lista[i]["id"] == GameState.amistoso.get("adversario_id"):
			_idx = i
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	mg.add_child(_col)
	_montar()

func _media_casa() -> int:
	var soma := 0.0
	var n := 0
	for j in GameState.fut7_titulares():
		if j != null:
			soma += float(j["overall"])
			n += 1
	return int(round(soma / maxf(1.0, n)))

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	var cfg: Dictionary = GameState.amistoso
	_col.add_child(Tema.titulo_secao("Jogar partida · Amistoso"))
	var aviso := Tema.rotulo("Partida avulsa: não altera tabela, caixa, rodada nem o seu save.", 12, Tema.TEXTO)
	aviso.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_col.add_child(aviso)

	# --- modo
	var fut7: bool = str(cfg.get("modo", "11")) == "7"
	_col.add_child(Tema.rotulo("MODO DE JOGO", 12, Tema.TITULO))
	var lm := HBoxContainer.new()
	lm.add_theme_constant_override("separation", 6)
	for mo in [["11", "11 x 11 (principal)"], ["7", "FUT7 · diversão"]]:
		var bm := Tema.botao(str(mo[1]), "ouro" if str(cfg.get("modo", "11")) == str(mo[0]) else "secundario", 44)
		bm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bm.name = "Modo_" + str(mo[0])
		bm.pressed.connect(func():
			GameState.amistoso["modo"] = str(mo[0])
			_montar.call_deferred())
		lm.add_child(bm)
	_col.add_child(lm)
	if fut7:
		var av := Tema.rotulo("FUT7 é só diversão: você escolhe com qual time jogar.", 12, Tema.TEXTO)
		av.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_col.add_child(av)

	# --- seu time
	var c1 := Tema.cartao(Tema.BRANCO)
	var v1 := VBoxContainer.new()
	c1.add_child(v1)
	v1.add_child(Tema.rotulo("SEU TIME", 12, Tema.TITULO))
	var l1 := HBoxContainer.new()
	l1.add_theme_constant_override("separation", 8)
	var meu: Dictionary = GameState.clube_por_id(str(cfg.get("meu_time_id", "catolica"))) if fut7 else {}
	if fut7:
		var bpm := Tema.botao("◀", "secundario", 44)
		bpm.custom_minimum_size.x = 48
		bpm.name = "MeuAnterior"
		bpm.pressed.connect(func(): _trocar_meu(-1))
		l1.add_child(bpm)
	l1.add_child(_escudo(str(meu.get("cor1", "C94F50")), str(meu.get("cor2", "8F3035"))))
	var n1 := Tema.rotulo(str(meu.get("nome", "Católica FC")), 18)
	n1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	n1.name = "MeuNome"
	l1.add_child(n1)
	l1.add_child(Tema.chip("MÉDIA %d" % (int(meu.get("forca", 0)) if not meu.is_empty() else _media_casa()), Tema.VINHO))
	if fut7:
		var bnm := Tema.botao("▶", "secundario", 44)
		bnm.custom_minimum_size.x = 48
		bnm.name = "MeuProximo"
		bnm.pressed.connect(func(): _trocar_meu(1))
		l1.add_child(bnm)
	v1.add_child(l1)
	_col.add_child(c1)

	# --- adversário
	var c2 := Tema.cartao(Tema.BRANCO)
	var v2 := VBoxContainer.new()
	v2.add_theme_constant_override("separation", 8)
	c2.add_child(v2)
	v2.add_child(Tema.rotulo("ADVERSÁRIO", 12, Tema.TITULO))
	var adv: Dictionary = _lista[_idx] if not _lista.is_empty() else {}
	var l2 := HBoxContainer.new()
	l2.add_theme_constant_override("separation", 6)
	var bp := Tema.botao("◀", "secundario", 44)
	bp.custom_minimum_size.x = 48
	bp.name = "AdvAnterior"
	bp.pressed.connect(func(): _trocar_adv(-1))
	l2.add_child(bp)
	l2.add_child(_escudo(str(adv.get("cor1", "3B6E9E")), str(adv.get("cor2", "FFFDF8"))))
	var n2 := Tema.rotulo(str(adv.get("nome", "?")), 16)
	n2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	n2.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	n2.name = "AdvNome"
	l2.add_child(n2)
	var bn := Tema.botao("▶", "secundario", 44)
	bn.custom_minimum_size.x = 48
	bn.name = "AdvProximo"
	bn.pressed.connect(func(): _trocar_adv(1))
	l2.add_child(bn)
	v2.add_child(l2)
	var l3 := HBoxContainer.new()
	l3.add_theme_constant_override("separation", 6)
	l3.add_child(Tema.chip("FORÇA %d" % int(adv.get("forca", 65)), Tema.AZUL))
	l3.add_child(Tema.chip(str(adv.get("estilo", "equilibrado")).to_upper(), Tema.VERDE))
	v2.add_child(l3)
	_col.add_child(c2)

	# --- formação
	_col.add_child(Tema.rotulo("FORMAÇÃO (7 EM CAMPO)" if fut7 else "FORMAÇÃO: a da sua carreira (%s)" % GameState.formacao_id, 12, Tema.TITULO))
	var lf := HBoxContainer.new()
	lf.add_theme_constant_override("separation", 6)
	for fo in (GameData.formacoes_fut7 if fut7 else []):
		var fid: String = str(fo["id"])
		var b := Tema.botao(str(fo["label"]), "ouro" if fid == str(cfg.get("formacao_id")) else "secundario", 40)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.name = "Formacao_" + fid
		b.pressed.connect(func():
			GameState.amistoso["formacao_id"] = fid
			_montar.call_deferred())
		lf.add_child(b)
	_col.add_child(lf)

	# --- dificuldade
	_col.add_child(Tema.rotulo("DIFICULDADE", 12, Tema.TITULO))
	var ld := HBoxContainer.new()
	ld.add_theme_constant_override("separation", 6)
	for did in ["facil", "normal", "dificil"]:
		var b2 := Tema.botao(str(GameState.DIFICULDADES[did]["nome"]), "ouro" if did == str(cfg.get("dificuldade")) else "secundario", 40)
		b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b2.name = "Dif_" + did
		b2.pressed.connect(func():
			GameState.amistoso["dificuldade"] = did
			_montar.call_deferred())
		ld.add_child(b2)
	_col.add_child(ld)

	# --- ações
	var jogar := Tema.botao("INICIAR PARTIDA", "primario", 54)
	jogar.name = "BotaoIniciar"
	jogar.pressed.connect(iniciar)
	_col.add_child(jogar)
	var esc := Tema.botao("Ver escalação FUT7", "secundario", 42)
	esc.pressed.connect(func(): SceneManager.ir_para("escalacao"))
	_col.add_child(esc)
	var voltar := Tema.botao("VOLTAR", "escuro", 42)
	voltar.name = "BotaoVoltar"
	voltar.pressed.connect(func(): SceneManager.ir_para("inicio", false))
	_col.add_child(voltar)

func _escudo(c1: String, c2: String) -> Control:
	var e := Control.new()
	e.custom_minimum_size = Vector2(34, 38)
	e.draw.connect(func():
		var pts := PackedVector2Array([Vector2(2, 2), Vector2(32, 2), Vector2(32, 22), Vector2(17, 36), Vector2(2, 22)])
		e.draw_colored_polygon(pts, Color(c1))
		e.draw_colored_polygon(PackedVector2Array([Vector2(17, 2), Vector2(32, 2), Vector2(32, 22), Vector2(17, 36)]), Color(c2))
		e.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[4], pts[0]]), Tema.TINTA, 2.5))
	return e

func _trocar_meu(d: int) -> void:
	var todos: Array = [{"id": "catolica"}] + GameState.adversarios_amistoso()
	var atual: int = 0
	for i in todos.size():
		if todos[i]["id"] == str(GameState.amistoso.get("meu_time_id", "catolica")):
			atual = i
	var novo: Dictionary = todos[(atual + d + todos.size()) % todos.size()]
	GameState.amistoso["meu_time_id"] = str(novo["id"])
	if str(novo["id"]) == str(GameState.amistoso.get("adversario_id")):
		_trocar_adv(1)
		return
	_montar.call_deferred()

func _trocar_adv(d: int) -> void:
	if _lista.is_empty():
		return
	_idx = (_idx + d + _lista.size()) % _lista.size()
	if str(_lista[_idx]["id"]) == str(GameState.amistoso.get("meu_time_id", "")):
		_idx = (_idx + d + _lista.size()) % _lista.size()
	GameState.amistoso["adversario_id"] = str(_lista[_idx]["id"])
	_montar.call_deferred()

func iniciar() -> void:
	if GameState.dados_partida_amistoso().is_empty():
		return
	GameState.amistoso["em_jogo"] = true
	SceneManager.ir_para("partida")
