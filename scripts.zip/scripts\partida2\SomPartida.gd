class_name SomPartida
extends Node
## Som da torcida durante a partida, sorteado ao longo do jogo (assets/audio/torcida/*.ogg), no barramento "Partida".
##  - Fundo contínuo: começa com a torcida de abertura (torcida-abertura, ~65 s); quando ela acaba entram, um após o outro, sons
##    sorteados (nunca o mesmo duas vezes seguidas) até o apito final. A emenda é um crossfade de potência igual: sem silêncio entre eles.
##    A intensidade (volume) sobe com a tensão do jogo: bola perto do gol, minutos finais, jogo apertado.
##  - Reações: gol da casa (rugido + torcida do gol), gol sofrido (torcida baixa), chute perigoso e defesa (explosão curta),
##    falta/cartão (cantoria), apito final.
##  - Tudo só depois da primeira interação (política de autoplay) e pausa quando o jogo está pausado ou em segundo plano.
const PASTA := "res://assets/audio/torcida/"
const FUNDO := ["torcida-estadio", "torcida-multidao", "torcida-palmas", "torcida-cantando"]
const VOZES := 3                      # reações simultâneas
const FADE := 0.9
const CRUZA := 2.5                    # duração do crossfade entre sons de fundo (s)
const ABERTURA := "torcida-abertura"

var p: Partida
var _vozes: Array = []
var _cache: Dictionary = {}
var _fundo: Array = []                # 2 vozes alternadas do fundo contínuo
var _g: Array = [0.0, 0.0]            # ganho 0..1 de cada voz (crossfade)
var _alvo_g: Array = [0.0, 0.0]
var _nivel_seg: Array = [0.6, 0.6]    # nível-base do segmento em cada voz
var _voz_atual: int = 0
var _seg_resta: float = 0.0           # segundos até o fim do segmento atual
var _fundo_ativo: bool = false
var _fundo_comecou: bool = false
var _ultimo_fundo: String = ""
var _cool_reacao: float = 0.0
var _gols0: int = 0
var _gols1: int = 0
var _chutes: int = 0
var _defesas: int = 0
var _faltas: int = 0
var _fim_tocado: bool = false
var intensidade: float = 0.4          # 0..1, alvo de volume do fundo
var log_sons: Array = []              # últimos sons sorteados (diagnóstico/testes)
var silencio: bool = false            # testes: não tocar de verdade

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 2:
		var f := AudioStreamPlayer.new()
		f.bus = "Partida"
		f.volume_db = -80.0
		add_child(f)
		_fundo.append(f)
	for i in VOZES:
		var a := AudioStreamPlayer.new()
		a.bus = "Partida"
		a.volume_db = -80.0
		add_child(a)
		_vozes.append(a)

func _stream(nome: String) -> AudioStream:
	if _cache.has(nome):
		return _cache[nome]
	var caminho: String = PASTA + nome + ".ogg"
	var s: AudioStream = load(caminho) if ResourceLoader.exists(caminho) else null
	_cache[nome] = s
	return s

func _amb() -> Node:
	return get_node_or_null("/root/Ambiente")

func _liberado() -> bool:
	var a: Node = _amb()
	return a == null or bool(a.interagiu)

## Toca `nome` numa voz livre. `durar` > 0 corta com fade depois desse tempo; `inicio` < 0 sorteia o ponto de partida.
func tocar(nome: String, db: float = 0.0, durar: float = 0.0, inicio: float = -1.0) -> bool:
	log_sons.append(nome)
	if log_sons.size() > 40:
		log_sons.pop_front()
	var s: AudioStream = _stream(nome)
	if s == null or silencio:
		return false
	var v: AudioStreamPlayer = null
	for q in _vozes:
		if not (q as AudioStreamPlayer).playing:
			v = q
			break
	if v == null:
		v = _vozes[0]                                   # todas ocupadas: reaproveita a mais antiga
	var len_s: float = s.get_length()
	var ini: float = inicio
	if ini < 0.0:
		var folga: float = maxf(0.0, len_s - maxf(durar, 3.0))
		ini = randf() * folga if durar > 0.0 else 0.0
	v.stream = s
	v.volume_db = -80.0
	v.play(ini)
	var dur: float = durar if durar > 0.0 else maxf(0.5, len_s - ini)
	var tw := create_tween()
	tw.tween_property(v, "volume_db", db, minf(FADE, dur * 0.4))
	tw.tween_interval(maxf(0.0, dur - FADE * 1.6))
	tw.tween_property(v, "volume_db", -80.0, FADE)
	tw.tween_callback(v.stop)
	return true

func _process(delta: float) -> void:
	if p == null or not is_instance_valid(p):
		return
	var parar: bool = p.pausado or (_amb() != null and bool(_amb().em_segundo_plano))
	for q in _vozes:
		(q as AudioStreamPlayer).stream_paused = parar
	for q in _fundo:
		(q as AudioStreamPlayer).stream_paused = parar
	if parar or not _liberado():
		return
	_cool_reacao = maxf(0.0, _cool_reacao - delta)
	_intensidade(delta)
	_reagir()
	_fundo_continuo(delta)

## Fundo sem espaço: abertura → sons sorteados emendados por crossfade até o fim da partida.
func _fundo_continuo(delta: float) -> void:
	if p.estado == Partida.Estado.FIM:
		if _fundo_ativo:
			_fundo_ativo = false                          # apito final: o fundo se apaga com fade
			_alvo_g = [0.0, 0.0]
	elif not _fundo_comecou:
		_fundo_comecou = true
		_fundo_ativo = true
		_iniciar_segmento(ABERTURA, 0.62, 0.0)
	elif _fundo_ativo:
		_seg_resta -= delta
		if _seg_resta <= CRUZA:
			_proximo_segmento()
	# ganhos (crossfade de potência igual) e volume pela intensidade
	for i in 2:
		_g[i] = move_toward(float(_g[i]), float(_alvo_g[i]), delta / CRUZA)
		var v: AudioStreamPlayer = _fundo[i]
		var nivel: float = float(_nivel_seg[i])
		if _nome_voz[i] != ABERTURA:
			nivel = lerpf(0.22, 0.7, intensidade)
		v.volume_db = linear_to_db(maxf(sin(float(_g[i]) * PI * 0.5) * nivel, 0.0001))
		if float(_g[i]) <= 0.0 and float(_alvo_g[i]) <= 0.0 and v.playing:
			v.stop()

var _nome_voz: Array = ["", ""]

func _iniciar_segmento(nome: String, nivel: float, inicio: float, durar: float = 0.0) -> void:
	var s: AudioStream = _stream(nome)
	log_sons.append(nome)
	if log_sons.size() > 40:
		log_sons.pop_front()
	if s == null:
		_seg_resta = 3.0                                    # arquivo ausente: tenta outro em seguida
		return
	var antiga: int = _voz_atual
	var nova: int = 1 - _voz_atual
	_voz_atual = nova
	_nome_voz[nova] = nome
	_nivel_seg[nova] = nivel
	var restante: float = s.get_length() - inicio
	var dur: float = restante if durar <= 0.0 else minf(durar, restante)
	_seg_resta = dur
	var v: AudioStreamPlayer = _fundo[nova]
	if not silencio:
		v.stream = s
		v.play(inicio)
	_g[nova] = 1.0 if nome == ABERTURA else 0.0             # a abertura entra direto; os demais emendam por crossfade
	_alvo_g[nova] = 1.0
	_alvo_g[antiga] = 0.0                                   # a anterior sai enquanto a nova entra

func _proximo_segmento() -> void:
	var opcoes: Array = FUNDO.filter(func(n): return n != _ultimo_fundo and _stream(n) != null)
	if opcoes.is_empty():
		_seg_resta = 5.0
		return
	var nome: String = opcoes[randi() % opcoes.size()]
	_ultimo_fundo = nome
	var s: AudioStream = _stream(nome)
	var durar: float = 0.0
	var inicio: float = 0.0
	if s.get_length() > 14.0:                               # sons longos: trecho sorteado de 10–18 s
		durar = randf_range(10.0, 18.0)
		inicio = randf() * maxf(0.0, s.get_length() - durar)
	_iniciar_segmento(nome, 0.5, inicio, durar)

func _intensidade(delta: float) -> void:
	var alvo: float = 0.35
	var gx: float = p.bola.position.x
	var perto_gol: float = maxf(1.0 - gx / (Cfg.PW * 0.28), 1.0 - (Cfg.PW - gx) / (Cfg.PW * 0.28))
	alvo += 0.35 * clampf(perto_gol, 0.0, 1.0)
	if p.minuto() >= 80 and absi(int(p.gols[0]) - int(p.gols[1])) <= 1:
		alvo += 0.2                                       # minutos finais com placar apertado
	intensidade = move_toward(intensidade, clampf(alvo, 0.2, 1.0), delta * 0.35)

func _reagir() -> void:
	# gols
	if int(p.gols[0]) > _gols0:
		_gols0 = int(p.gols[0])
		tocar("torcida-rugido", 0.0, 7.0, 0.0)
		tocar("torcida-gol", -2.0, 0.0, 0.0)
		_cool_reacao = 6.0
	if int(p.gols[1]) > _gols1:
		_gols1 = int(p.gols[1])
		tocar("torcida-gol", -9.0)
		_cool_reacao = 5.0
	# chute / defesa: explosão curta da torcida (com sorteio, para não soar mecânico)
	var chutes: int = int(p.estat["chutes"][0]) + int(p.estat["chutes"][1])
	if chutes > _chutes:
		_chutes = chutes
		if _cool_reacao <= 0.0 and randf() < 0.5:
			tocar("torcida-multidao", linear_to_db(0.6), randf_range(3.0, 4.5))
			_cool_reacao = 7.0
	var defesas: int = int(p.estat["defesas"][0]) + int(p.estat["defesas"][1])
	if defesas > _defesas:
		_defesas = defesas
		if _cool_reacao <= 0.0 and randf() < 0.6:
			tocar("torcida-estadio", linear_to_db(0.7), randf_range(2.5, 4.0))
			_cool_reacao = 6.0
	# faltas: a torcida organizada canta/reclama
	var faltas: int = int(p.faltas[0]) + int(p.faltas[1])
	if faltas > _faltas:
		_faltas = faltas
		if _cool_reacao <= 0.0 and randf() < 0.5:
			tocar("torcida-cantando", linear_to_db(0.55), randf_range(3.0, 5.0))
			_cool_reacao = 8.0
	# apito final
	if p.estado == Partida.Estado.FIM and not _fim_tocado:
		_fim_tocado = true
		tocar("torcida-palmas", linear_to_db(0.8), 6.0, 0.0)
