import json,os,sys
from PIL import Image
here=os.path.dirname(os.path.abspath(__file__)); g=os.path.join(here,"..","..","assets","gerado")
meta=json.load(open(g+"/jogadores_v2.json")); CW,CH=24,28
SK=[(244,200,160),(224,168,120),(180,120,80),(120,78,50),(78,50,34)]
HR=[(36,24,20),(90,56,30),(200,160,70),(30,30,30),(160,60,40),(120,120,120)]
def recolor(im,pele,cab,camisa,calcao,meia,bota,luva,manga):
    im=im.copy(); p=im.load()
    mp={1:pele,2:cab,3:camisa,4:calcao,5:meia,6:bota,7:luva,8:(36,24,18),11:manga,99:(20,16,28)}
    for y in range(im.height):
        for x in range(im.width):
            r,gg,b,a=p[x,y]
            if a and r in mp:
                c=mp[r]
                if gg: c=tuple(int(v*0.82) for v in c)
                p[x,y]=c+(255,)
    return im
sheets=[Image.open(f"{g}/jogadores_v2_e{e}.png") for e in range(6)]
def frame(e,anim,k):
    a=meta["anims"][anim]; return sheets[e].crop((k*CW,a["row"]*CH,(k+1)*CW,(a["row"]+1)*CH))
kit=dict(camisa=(200,30,40),calcao=(250,250,250),meia=(200,30,40),bota=(20,20,20),manga=(240,240,240))
gk=dict(camisa=(240,200,40),calcao=(30,30,30),meia=(30,30,30),bota=(230,230,230),manga=(240,200,40))
nomes=list(meta["anims"]); Z=4
mx=max(a["frames"] for a in meta["anims"].values())
W=mx*CW*Z+10; H=len(nomes)*CH*Z
im=Image.new("RGB",(W,H),(52,128,56))
for r,n in enumerate(nomes):
    a=meta["anims"][n]
    for k in range(a["frames"]):
        e=(r+k)%6 if False else r%6
        isgk=n.startswith("gk")
        f=recolor(frame(e,n,k),SK[r%5],HR[r%6],**(gk if isgk else {**kit,"luva":SK[r%5]}),) if False else None
        kw=dict(gk if isgk else kit); kw["luva"]=(250,250,250) if isgk else SK[r%5]
        f=recolor(frame(e,n,k),SK[r%5],HR[r%6],kw["camisa"],kw["calcao"],kw["meia"],kw["bota"],kw["luva"],kw["manga"])
        f=f.resize((CW*Z,CH*Z),Image.NEAREST); im.paste(f,(k*CW*Z,r*CH*Z),f)
im.save(sys.argv[1] if len(sys.argv)>1 else "/tmp/s2/img/prev_v2_all.png")
# folha de variações: 6 cabelos x 5 peles frente/costas/lado + goleiro
V=Image.new("RGB",(6*CW*Z*3,5*CH*Z),(52,128,56))
for i in range(6):
    for j in range(5):
        for t,(an,k) in enumerate((("idle_f",0),("idle_b",0),("idle_s",0))):
            f=recolor(frame(i,an,k),SK[j],HR[(i+j)%6],kit["camisa"],kit["calcao"],kit["meia"],kit["bota"],SK[j],kit["manga"]).resize((CW*Z,CH*Z),Image.NEAREST)
            V.paste(f,((i*3+t)*CW*Z,j*CH*Z),f)
V.save("/tmp/s2/img/prev_v2_var.png")
