# Paleta única da partida (mesmos valores em scripts/arte/Palette.gd)
def h(s): s=s.lstrip('#'); return tuple(int(s[i:i+2],16) for i in (0,2,4))+(255,)
CEU1=h('E0404A'); CEU2=h('8F1A26')
PAREDE1=h('3A0F18'); PAREDE2=h('5A1420'); SILH=h('7A1E2C')
MUR_BRILHO=h('FFF6E6'); MUR1=h('F7F2E4'); MUR2=h('D8202F'); MUR3=h('8F1A26')
G1=h('1B9B20'); G2=h('18911C'); G3=h('18911C')
BRANCO=h('FFFFFF'); REDE=h('C8D2DC')
PELE=[h('F6C9A2'),h('D98C4E'),h('8A5230'),h('5A3420')]
CAB=[h('241812'),h('6B4423'),h('E0B040')]
CONTORNO=h('14101C'); VERM=h('D8202F'); AMAR=h('FFD84A')
# sub-paleta da torcida (variedade de camisas e cabelos)
CAMISAS=[h('D8202F'),h('F2F2F2'),h('2E6FD6'),h('2DA44E'),h('FFD84A'),h('F39C12'),h('E86AA6'),h('7A3FC0'),h('1B1B24'),h('3FB8FF')]
CABELOS=[h('241812'),h('6B4423'),h('E0B040'),h('B04020'),h('14101C'),h('8A8A90')]
DEGRAU1=h('5C6670'); DEGRAU2=h('7A8590'); DEGRAU3=h('9AA4AE')
VIDRO=h('0E1A28'); VIDRO_REFL=h('C0B8F0'); MOLDURA=h('6A7FA0')
