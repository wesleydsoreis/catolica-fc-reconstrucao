class_name PixelUI
extends RefCounted
## Texto e letreiros em pixel art gerados por código (fonte 5x7 própria), com cache de texturas.

const GLYPHS: Dictionary = {
	",": [".....",".....",".....",".....",".##..","..#..",".#..."],
	"?": [".###.","#...#","....#","...#.","..#..",".....","..#.."],
	"(": ["...#.","..#..",".#...",".#...",".#...","..#..","...#."],
	")": [".#...","..#..","...#.","...#.","...#.","..#..",".#..."],
	"+": [".....","..#..","..#..","#####","..#..","..#..","....."],
	"%": ["##..#","##..#","...#.","..#..",".#...","#..##","#..##"],
	"_": [".....",".....",".....",".....",".....",".....","#####"],
	"A": [".###.","#...#","#...#","#####","#...#","#...#","#...#"],
	"B": ["####.","#...#","#...#","####.","#...#","#...#","####."],
	"C": [".###.","#...#","#....","#....","#....","#...#",".###."],
	"D": ["####.","#...#","#...#","#...#","#...#","#...#","####."],
	"E": ["#####","#....","#....","####.","#....","#....","#####"],
	"F": ["#####","#....","#....","####.","#....","#....","#...."],
	"G": [".####","#....","#....","#..##","#...#","#...#",".###."],
	"H": ["#...#","#...#","#...#","#####","#...#","#...#","#...#"],
	"I": [".###.","..#..","..#..","..#..","..#..","..#..",".###."],
	"J": ["..###","...#.","...#.","...#.","...#.","#..#.",".##.."],
	"K": ["#...#","#..#.","#.#..","##...","#.#..","#..#.","#...#"],
	"L": ["#....","#....","#....","#....","#....","#....","#####"],
	"M": ["#...#","##.##","#.#.#","#.#.#","#...#","#...#","#...#"],
	"N": ["#...#","##..#","#.#.#","#..##","#...#","#...#","#...#"],
	"O": [".###.","#...#","#...#","#...#","#...#","#...#",".###."],
	"P": ["####.","#...#","#...#","####.","#....","#....","#...."],
	"Q": [".###.","#...#","#...#","#...#","#.#.#","#..#.",".##.#"],
	"R": ["####.","#...#","#...#","####.","#.#..","#..#.","#...#"],
	"S": [".####","#....","#....",".###.","....#","....#","####."],
	"T": ["#####","..#..","..#..","..#..","..#..","..#..","..#.."],
	"U": ["#...#","#...#","#...#","#...#","#...#","#...#",".###."],
	"V": ["#...#","#...#","#...#","#...#","#...#",".#.#.","..#.."],
	"W": ["#...#","#...#","#...#","#.#.#","#.#.#","##.##","#...#"],
	"X": ["#...#","#...#",".#.#.","..#..",".#.#.","#...#","#...#"],
	"Y": ["#...#","#...#",".#.#.","..#..","..#..","..#..","..#.."],
	"Z": ["#####","....#","...#.","..#..",".#...","#....","#####"],
	"0": [".###.","#...#","#..##","#.#.#","##..#","#...#",".###."],
	"1": ["..#..",".##..","..#..","..#..","..#..","..#..",".###."],
	"2": [".###.","#...#","....#","...#.","..#..",".#...","#####"],
	"3": ["####.","....#","....#",".###.","....#","....#","####."],
	"4": ["...#.","..##.",".#.#.","#..#.","#####","...#.","...#."],
	"5": ["#####","#....","####.","....#","....#","#...#",".###."],
	"6": ["..##.",".#...","#....","####.","#...#","#...#",".###."],
	"7": ["#####","....#","...#.","..#..",".#...",".#...",".#..."],
	"8": [".###.","#...#","#...#",".###.","#...#","#...#",".###."],
	"9": [".###.","#...#","#...#",".####","....#","...#.",".##.."],
	"-": [".....",".....",".....","#####",".....",".....","....."],
	".": [".....",".....",".....",".....",".....",".##..",".##.."],
	":": [".....","..#..",".....",".....","..#..",".....","....."],
	"!": ["..#..","..#..","..#..","..#..","..#..",".....","..#.."],
	"'": ["..#..","..#..",".....",".....",".....",".....","....."],
	" ": [".....",".....",".....",".....",".....",".....","....."],
	"$": ["..#..",".####","#.#..",".###.","..#.#","####.","..#.."],
	"/": ["....#","...#.","...#.","..#..",".#...",".#...","#...."]
}
const ACC: Dictionary = {"Á":["A","a"],"À":["A","g"],"Ã":["A","t"],"Â":["A","c"],"É":["E","a"],"Ê":["E","c"],"Í":["I","a"],"Ó":["O","a"],"Õ":["O","t"],"Ô":["O","c"],"Ú":["U","a"],"Ç":["C","z"]}
const MARK: Dictionary = {
	"a":[Vector2i(3,-1),Vector2i(2,-2)], "g":[Vector2i(1,-1),Vector2i(2,-2)],
	"t":[Vector2i(1,-1),Vector2i(2,-2),Vector2i(3,-2),Vector2i(4,-1)],
	"c":[Vector2i(1,-1),Vector2i(3,-1),Vector2i(2,-2)], "z":[Vector2i(2,7),Vector2i(1,8)]}
static var _cache: Dictionary = {}

## Retorna {w,h,d} com d = bytes (0/1) já recortado ao conteúdo.
static func mascara(texto: String, esc: int, negrito: bool) -> Dictionary:
	var adv: int = (7 if negrito else 6) * esc
	var n: int = texto.length()
	var w: int = n * adv + 2 * esc
	var h: int = 13 * esc
	var oy: int = 2 * esc
	var d := PackedByteArray()
	d.resize(w * h)
	for i in n:
		var ch: String = texto.substr(i, 1).to_upper()
		var base: String = ch
		var acc: String = ""
		if ACC.has(ch):
			base = ACC[ch][0]
			acc = ACC[ch][1]
		var rows: Array = GLYPHS.get(base, GLYPHS[" "])
		var x0: int = i * adv
		for ry in rows.size():
			var row: String = rows[ry]
			for rx in row.length():
				if row[rx] == "#":
					for dy in esc:
						for dx in esc * (2 if negrito else 1):
							var xx: int = x0 + rx * esc + dx
							var yy: int = oy + ry * esc + dy
							if xx < w and yy < h:
								d[yy * w + xx] = 1
		if acc != "":
			for mk in MARK[acc]:
				for dy in esc:
					for dx in esc:
						var yy2: int = oy + (mk as Vector2i).y * esc + dy
						var xx2: int = x0 + (mk as Vector2i).x * esc + dx
						if yy2 >= 0 and yy2 < h and xx2 < w:
							d[yy2 * w + xx2] = 1
	# recorta
	var x_min: int = w
	var x_max: int = -1
	var y_min: int = h
	var y_max: int = -1
	for y in h:
		for x in w:
			if d[y * w + x] == 1:
				x_min = mini(x_min, x)
				x_max = maxi(x_max, x)
				y_min = mini(y_min, y)
				y_max = maxi(y_max, y)
	if x_max < 0:
		return {"w": 1, "h": 1, "d": PackedByteArray([0])}
	var nw: int = x_max - x_min + 1
	var nh: int = y_max - y_min + 1
	var nd := PackedByteArray()
	nd.resize(nw * nh)
	for y in nh:
		for x in nw:
			nd[y * nw + x] = d[(y + y_min) * w + (x + x_min)]
	return {"w": nw, "h": nh, "d": nd}

## Texto simples (com sombra opcional). Cache por parâmetros.
static func texto(texto_: String, esc: int, cor: Color = Color.WHITE, sombra: Color = Color(0, 0, 0, 0), negrito: bool = false) -> ImageTexture:
	var chave: String = "t|%s|%d|%s|%s|%s" % [texto_, esc, cor.to_html(), sombra.to_html(), str(negrito)]
	if _cache.has(chave):
		return _cache[chave]
	var m: Dictionary = mascara(texto_, esc, negrito)
	var w: int = int(m["w"])
	var h: int = int(m["h"])
	var off: int = maxi(1, esc / 2) if sombra.a > 0.0 else 0
	var img := Image.create(w + off, h + off, false, Image.FORMAT_RGBA8)
	var d: PackedByteArray = m["d"]
	if off > 0:
		for y in h:
			for x in w:
				if d[y * w + x] == 1:
					img.set_pixel(x + off, y + off, sombra)
	for y in h:
		for x in w:
			if d[y * w + x] == 1:
				img.set_pixel(x, y, cor)
	var t: ImageTexture = ImageTexture.create_from_image(img)
	_cache[chave] = t
	return t

static func _dilatar(d: PackedByteArray, w: int, h: int) -> PackedByteArray:
	var o := PackedByteArray()
	o.resize(w * h)
	for y in h:
		for x in w:
			if d[y * w + x] == 1:
				for dy in range(-1, 2):
					for dx in range(-1, 2):
						var xx: int = x + dx
						var yy: int = y + dy
						if xx >= 0 and xx < w and yy >= 0 and yy < h:
							o[yy * w + xx] = 1
	return o

## Letreiro grande: itálico, degradê em duas faixas, contorno escuro e branco.
static func letreiro(texto_: String, esc: int, topo: Color = Color("FFDE59"), base: Color = Color("F08C28"), inclina: float = 0.25) -> ImageTexture:
	var chave: String = "l|%s|%d|%s|%s" % [texto_, esc, topo.to_html(), base.to_html()]
	if _cache.has(chave):
		return _cache[chave]
	var m: Dictionary = mascara(texto_, esc, true)
	var w: int = int(m["w"])
	var h: int = int(m["h"])
	var d: PackedByteArray = m["d"]
	var sh: int = int(h * inclina)
	var pad: int = 6
	var W: int = w + sh + 2 * pad
	var H: int = h + 2 * pad
	var M := PackedByteArray()
	M.resize(W * H)
	for y in h:
		for x in w:
			if d[y * w + x] == 1:
				var nx: int = x + int(float(h - 1 - y) * inclina) + pad
				M[(y + pad) * W + nx] = 1
				# preenche o buraco que a inclinação cria entre pixels vizinhos
				if nx + 1 < W:
					M[(y + pad) * W + nx + 1] = M[(y + pad) * W + nx + 1] | (1 if (x + 1 < w and d[y * w + x + 1] == 1) else 0)
	var d1: PackedByteArray = _dilatar(M, W, H)
	var d2: PackedByteArray = _dilatar(d1, W, H)
	var d3: PackedByteArray = _dilatar(d2, W, H)
	var img := Image.create(W, H, false, Image.FORMAT_RGBA8)
	var mid: float = float(pad) + float(h) * 0.5
	var azul := Color(32.0 / 255.0, 22.0 / 255.0, 56.0 / 255.0)
	for y in H:
		for x in W:
			var i: int = y * W + x
			if M[i] == 1:
				var c: Color = topo if float(y) < mid else base
				if absi(y - int(mid)) <= 1 and (x + y) % 2 == 0:
					c = base
				img.set_pixel(x, y, c)
			elif d2[i] == 1:
				img.set_pixel(x, y, azul)
			elif d3[i] == 1:
				img.set_pixel(x, y, Color.WHITE)
	var t: ImageTexture = ImageTexture.create_from_image(img)
	_cache[chave] = t
	return t

## Escudo em forma de brasão com inicial.
static func escudo(c1: Color, c2: Color, letra: String, w: int = 34, h: int = 40) -> ImageTexture:
	var chave: String = "e|%s|%s|%s|%d|%d" % [c1.to_html(), c2.to_html(), letra, w, h]
	if _cache.has(chave):
		return _cache[chave]
	var img := Image.create(w + 4, h + 4, false, Image.FORMAT_RGBA8)
	var preto := Color("120c0a")
	var esc_l: int = 2 if w >= 30 else 1
	for y in h + 4:
		for x in w + 4:
			var fx: float = float(x)
			var fy: float = float(y)
			var ext: bool = _dentro(fx, fy, 2.0, float(w) + 1.0, float(h), w)
			if not ext:
				continue
			var inn: bool = _dentro(fx, fy, 4.0, float(w) - 1.0, float(h) - 3.0, w) and fy >= 4.0
			if not inn:
				img.set_pixel(x, y, preto)
			elif y <= 10:
				img.set_pixel(x, y, c2)
			elif y <= 13:
				img.set_pixel(x, y, c1.darkened(0.3))
			else:
				img.set_pixel(x, y, c1)
	var mk: Dictionary = mascara(letra, esc_l, true)
	var mw: int = int(mk["w"])
	var mh: int = int(mk["h"])
	var md: PackedByteArray = mk["d"]
	var ox: int = (w + 4 - mw) / 2
	var oy: int = 16 if h >= 30 else 12
	for y in mh:
		for x in mw:
			if md[y * mw + x] == 1 and ox + x < w + 4 and oy + y < h + 4:
				img.set_pixel(ox + x, oy + y, Color("FFFDF8"))
	var t: ImageTexture = ImageTexture.create_from_image(img)
	_cache[chave] = t
	return t

static func _dentro(x: float, y: float, x0: float, x1: float, h: float, w: int) -> bool:
	if y < 2.0 or y > h + 1.0:
		return false
	var meio: float = h * 0.55
	if y <= meio:
		return x >= x0 and x <= x1
	var t: float = (y - meio) / maxf(1.0, (h + 1.0 - meio))
	var cx: float = float(w) / 2.0 + 2.0
	var meia: float = (x1 - x0) * 0.5 * (1.0 - t)
	return absf(x - cx) <= meia
