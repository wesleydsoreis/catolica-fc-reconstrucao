class_name GraficoFuncao
extends Control
## Gráfico de uma função (receita × preço) com marcador do valor atual e do máximo.

var pontos: Array = []          # Array de Vector2 (x, y)
var marcador_x: float = -1.0
var rotulo_x: String = "preço (R$)"
var rotulo_y: String = "receita"

func _init() -> void:
	custom_minimum_size = Vector2(0, 190)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL

func definir(p: Array, mx: float) -> void:
	pontos = p
	marcador_x = mx
	queue_redraw()

func _draw() -> void:
	if pontos.size() < 2:
		return
	var f: Font = ThemeDB.fallback_font
	var x0: float = 38.0
	var y0: float = size.y - 22.0
	var larg: float = size.x - x0 - 8.0
	var alt: float = size.y - 34.0
	var minx: float = (pontos[0] as Vector2).x
	var maxx: float = (pontos[-1] as Vector2).x
	var maxy := 1.0
	var imax := 0
	for i in pontos.size():
		if (pontos[i] as Vector2).y > maxy:
			maxy = (pontos[i] as Vector2).y
			imax = i
	draw_line(Vector2(x0, y0), Vector2(x0 + larg, y0), Tema.TEXTO2, 1.0)
	draw_line(Vector2(x0, y0), Vector2(x0, y0 - alt), Tema.TEXTO2, 1.0)
	var poli := PackedVector2Array()
	for pt in pontos:
		var v: Vector2 = pt
		poli.append(Vector2(x0 + (v.x - minx) / (maxx - minx) * larg, y0 - v.y / maxy * alt))
	draw_polyline(poli, Color("C94F50"), 3.0)
	var pm: Vector2 = poli[imax]
	draw_circle(pm, 5.0, Tema.AMARELO)
	draw_string(f, pm + Vector2(-30, -9), "máx R$ %d" % int((pontos[imax] as Vector2).x), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Tema.AMARELO)
	if marcador_x >= minx and marcador_x <= maxx:
		var mxp: float = x0 + (marcador_x - minx) / (maxx - minx) * larg
		draw_line(Vector2(mxp, y0), Vector2(mxp, y0 - alt), Tema.CREME, 1.0)
		draw_string(f, Vector2(mxp - 14, y0 + 14), "R$ %d" % int(marcador_x), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Tema.CREME)
	draw_string(f, Vector2(x0 + 2, 11), rotulo_y, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Tema.TEXTO)
	draw_string(f, Vector2(x0 + larg - 70, y0 - 3), rotulo_x, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Tema.TEXTO)
