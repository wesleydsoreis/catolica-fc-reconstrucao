extends Control
## Modo professor: sala de aula (mesma semente para a turma) e relatório de desempenho exportável.

var _col: VBoxContainer
var _aluno: LineEdit
var _turma: LineEdit
var _msg: Label

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	mg.add_child(_col)
	_montar()

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_col.add_child(Tema.titulo_secao("Professor · Sala de aula"))
	# --- sala
	var c1 := Tema.cartao(Tema.BRANCO)
	var v1 := VBoxContainer.new()
	v1.add_theme_constant_override("separation", 6)
	c1.add_child(v1)
	v1.add_child(Tema.rotulo("SALA DE AULA", 12, Tema.TITULO))
	var ex := Tema.rotulo("Todos os alunos que digitarem o MESMO código da turma recebem o mesmo elenco, calendário, metas e problemas, e podem comparar decisões. Ativar a sala inicia uma carreira nova.", 13)
	v1.add_child(ex)
	_aluno = LineEdit.new()
	_aluno.name = "CampoAluno"
	_aluno.placeholder_text = "Nome do aluno"
	_aluno.text = GameState.aluno_nome
	_aluno.custom_minimum_size = Vector2(0, 42)
	v1.add_child(_aluno)
	_turma = LineEdit.new()
	_turma.name = "CampoTurma"
	_turma.placeholder_text = "Código da turma (ex.: 2A-2026)"
	_turma.text = GameState.turma_codigo
	_turma.custom_minimum_size = Vector2(0, 42)
	v1.add_child(_turma)
	var st := Tema.rotulo(("Sala ativa: %s · semente %d" % [GameState.turma_codigo, GameState.sala_seed]) if GameState.sala_seed != 0 else "Sem sala ativa (carreira livre).", 13, Tema.AMARELO)
	st.name = "StatusSala"
	v1.add_child(st)
	var lb := HBoxContainer.new()
	lb.add_theme_constant_override("separation", 8)
	var ba := Tema.botao("ATIVAR SALA E INICIAR", "primario", 46)
	ba.name = "BotaoAtivarSala"
	ba.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ba.pressed.connect(func():
		if _turma.text.strip_edges() == "":
			_msg.text = "Digite o código da turma."
			return
		GameState.iniciar_sala(_turma.text, _aluno.text)
		_montar.call_deferred())
	var bs := Tema.botao("SAIR DA SALA", "secundario", 46)
	bs.name = "BotaoSairSala"
	bs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bs.pressed.connect(func():
		GameState.sair_sala()
		_montar.call_deferred())
	lb.add_child(ba)
	lb.add_child(bs)
	v1.add_child(lb)
	_col.add_child(c1)
	# --- relatório
	var r: Dictionary = Relatorio.resumo(GameState)
	var c2 := Tema.cartao(Tema.BRANCO)
	c2.name = "ResumoRelatorio"
	var v2 := VBoxContainer.new()
	v2.add_theme_constant_override("separation", 5)
	c2.add_child(v2)
	v2.add_child(Tema.rotulo("RELATÓRIO DE DESEMPENHO · %s" % str(r["nivel_escolar"]).to_upper(), 12, Tema.TITULO))
	v2.add_child(Tema.rotulo("Aluno: %s · Turma: %s" % [r["aluno"] if r["aluno"] != "" else "—", r["turma"] if r["turma"] != "" else "—"], 14))
	v2.add_child(Tema.rotulo("Desafios resolvidos: %d · Acertos de primeira: %d" % [r["desafios_total"], r["acertos_1a_total"]], 14))
	for a in Educacao.AREAS:
		var d: Dictionary = r["areas"][a]
		v2.add_child(Tema.rotulo("%s: %d desafio(s) · 1ª tentativa %s · tempo médio %ss · %s" % [Educacao.AREA_NOME[a], d["desafios"], Educacao.pct(d["taxa_1a"], 0), Educacao.num(d["tempo_medio"], 0), d["nivel"]], 13))
	v2.add_child(Tema.rotulo("Decisões registradas: %d rodadas" % GameState.decisoes_log.size(), 13, Tema.TEXTO2))
	_col.add_child(c2)
	var le := HBoxContainer.new()
	le.add_theme_constant_override("separation", 8)
	for f in ["csv", "json"]:
		var b := Tema.botao("EXPORTAR " + str(f).to_upper(), "ouro", 46)
		b.name = "Botao" + str(f).to_upper()
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			GameState.aluno_nome = _aluno.text.strip_edges()
			var caminho: String = Relatorio.exportar(GameState, str(f))
			_msg.text = ("Arquivo salvo em: " + caminho) if caminho != "" and not caminho.begins_with("Baixado") else (caminho if caminho != "" else "Não foi possível gravar o arquivo."))
		le.add_child(b)
	_col.add_child(le)
	_msg = Tema.rotulo("", 13, Tema.AMARELO)
	_msg.name = "LabelExport"
	_col.add_child(_msg)
	var bv := Tema.botao("VOLTAR", "secundario", 46)
	bv.name = "BotaoSair"
	bv.pressed.connect(func(): SceneManager.voltar())
	_col.add_child(bv)
