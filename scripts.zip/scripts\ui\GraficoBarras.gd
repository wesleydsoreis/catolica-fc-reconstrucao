class_name GraficoBarras
extends Control
## Gráfico de barras simples (rótulos + valores) com linha opcional de média.

var rotulos: Array = []
var valores: Array = []
var linha_media: float = -1.0
var minimo: float = 0.0
var maximo: float = 100.0
var cor_barra: Color = Color("C94F50")

func _init() -> void:
	custom_minimum_size = Vector2(0, 170)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL

func definir(r: Array, v: Array, media: float = -1.0, mn: float = 0.0, mx: float = 100.0) -> void:
	rotulos = r
	valores = v
	linha_media = media
	minimo = mn
	maximo = mx
	queue_redraw()

func _draw() -> void:
	var n: int = valores.size()
	if n == 0:
		return
	var f: Font = ThemeDB.fallback_font
	var base_y: float = size.y - 20.0
	var alt: float = size.y - 36.0
	var larg: float = size.x / float(n)
	draw_line(Vector2(0, base_y), Vector2(size.x, base_y), Tema.TEXTO2, 1.0)
	for i in n:
		var v: float = float(valores[i])
		var h: float = clampf((v - minimo) / maxf(0.001, maximo - minimo), 0.0, 1.0) * alt
		var r := Rect2(i * larg + larg * 0.15, base_y - h, larg * 0.7, h)
		draw_rect(r, cor_barra)
		draw_rect(r, Color("2A0A10"), false, 1.0)
		draw_string(f, Vector2(i * larg, base_y - h - 3.0), str(int(v)) if is_equal_approx(v, round(v)) else str(snappedf(v, 0.1)), HORIZONTAL_ALIGNMENT_CENTER, larg, 12, Tema.CREME)
		draw_string(f, Vector2(i * larg, size.y - 5.0), str(rotulos[i]).substr(0, 7), HORIZONTAL_ALIGNMENT_CENTER, larg, 11, Tema.TEXTO)
	if linha_media >= 0.0:
		var y: float = base_y - clampf((linha_media - minimo) / maxf(0.001, maximo - minimo), 0.0, 1.0) * alt
		draw_line(Vector2(0, y), Vector2(size.x, y), Tema.AMARELO, 2.0)
		draw_string(f, Vector2(2, y - 3.0), "média", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Tema.AMARELO)
