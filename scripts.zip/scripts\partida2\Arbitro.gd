class_name Arbitro
extends Node2D
## Árbitro em campo (apresentação): acompanha o lance a distância, vai até o local da falta, apita, mostra cartão amarelo/vermelho
## e marca início, intervalo e fim. Não interfere na lógica da partida (não bloqueia bola nem jogadores).
## Reaproveita o sprite de jogador (Player) com o uniforme de árbitro.

const VEL := 215.0                 # um pouco mais lento que os jogadores
var p: Partida
var pl: Player
var pos: Vector2 = Vector2(1650.0, 975.0)         # posição no mundo (mesmo sistema da Partida)
var vel: Vector2 = Vector2.ZERO
var face: Vector2 = Vector2.RIGHT
var _alvo_lance: Vector2 = Vector2.ZERO
var _lance_t: float = 0.0          # tempo restante perto do local do lance
var _cartao: String = ""
var _cartao_t: float = 0.0
var _apito_t: float = 0.0
var _efeitos: Efeitos
var _cenario_mundo: Node2D
static var _som: AudioStreamWAV = null
var _audio: AudioStreamPlayer

static func kit_arbitro() -> Dictionary:
	return {"camisa": Color("F2D33C"), "manga": Color("F2D33C"), "calcao": Color("14101C"), "meia": Color("14101C"), "bota": Color("14101C"), "luva": Color.TRANSPARENT, "gk": false}

func iniciar(partida: Partida, grupo: Node2D, efeitos: Efeitos, mundo: Node2D) -> void:
	p = partida
	_efeitos = efeitos
	_cenario_mundo = mundo
	pl = Player.new()
	grupo.add_child(pl)
	pl.configurar(kit_arbitro(), Color("E0A878"), Color("241812"), 2, 0)
	pos = Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5 + 140.0)
	_audio = AudioStreamPlayer.new()
	_audio.stream = _apito(false)
	_audio.volume_db = -8.0
	_audio.bus = "Partida" if AudioServer.get_bus_index("Partida") >= 0 else "Master"
	add_child(_audio)

## Apito sintetizado (sem arquivo de áudio): ~2,9 kHz com vibrato, curto e seco.
static func apito_som() -> AudioStreamWAV:
	if _som != null:
		return _som
	var taxa: int = 22050
	var n: int = int(taxa * 0.32)
	var d := PackedByteArray()
	d.resize(n * 2)
	for i in n:
		var t: float = float(i) / taxa
		var env: float = minf(1.0, t * 40.0) * minf(1.0, (0.32 - t) * 20.0)
		var f: float = 2900.0 + 180.0 * sin(TAU * 38.0 * t)
		var v: float = (sin(TAU * f * t) * 0.55 + sin(TAU * f * 2.0 * t) * 0.15) * env
		d.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 14000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = taxa
	w.data = d
	_som = w
	return w

## Chamado quando a Partida mostra um aviso (falta, cartão, pênalti, intervalo, fim de jogo).
func evento(titulo: String) -> void:
	var t: String = titulo.to_upper()
	if t.begins_with("FALTA") or t.begins_with("PÊNALTI") or t.begins_with("PENALTI"):
		_ir_ao_lance(p.ultimo_lance, 1.8)
		apitar(1)
	elif t.begins_with("CARTÃO") or t.begins_with("CARTAO"):
		_ir_ao_lance(p.ultimo_lance, 2.6)
		_cartao = "vermelho" if t.contains(" V") else "amarelo"
		_cartao_t = 2.0
		apitar(1)
	elif t.begins_with("INTERVALO") or t.begins_with("FIM"):
		_ir_ao_lance(Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5), 3.0)
		apitar(3 if t.begins_with("FIM") else 2)

func _ir_ao_lance(ponto: Vector2, seg: float) -> void:
	_alvo_lance = ponto + Vector2(-70.0, 60.0)
	_lance_t = maxf(seg, minf(4.5, pos.distance_to(_alvo_lance) / VEL + 1.0))      # tempo para chegar + ficar um pouco

## Apito real (assets/audio/arbitro/): curto para falta/cartão/pênalti, longo para o fim de jogo; sem arquivo, usa o sintetizado.
static func _apito(longo: bool) -> AudioStream:
	var c: String = "res://assets/audio/arbitro/apito-%s.ogg" % ("longo" if longo else "curto")
	if ResourceLoader.exists(c):
		var s: Resource = load(c)
		if s is AudioStream:
			return s
	return apito_som()

var apitos_tocados: int = 0            # contador (diagnóstico/testes)

func apitar(vezes: int) -> void:
	_apito_t = 0.5 * vezes
	apitos_tocados += 1
	if _audio != null:
		_audio.stream = _apito(vezes >= 3)
		_audio.play()
		if vezes == 2:
			get_tree().create_timer(0.9).timeout.connect(func(): if is_instance_valid(_audio): _audio.stream = _apito(false); _audio.play())
	if _efeitos != null and pl != null:
		_efeitos.texto(_tela(pos) + Vector2(0, -44), "PIII!", Color("FFF3B0"))

func _tela(w: Vector2) -> Vector2:
	return Pitch.project(w.x, w.y) + (_cenario_mundo.position if _cenario_mundo != null else Vector2.ZERO)

## Posição de acompanhamento: fica atrás do lance, na diagonal, a uns 260 px da bola.
func _posicao_de_jogo() -> Vector2:
	var b: Vector2 = p.bola.position
	var centro: Vector2 = Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5)
	var rumo: Vector2 = (centro - b)
	var lado: float = 1.0 if b.y < Cfg.PH * 0.5 else -1.0
	var alvo: Vector2 = b + (rumo.normalized() * 220.0 if rumo.length() > 40.0 else Vector2(-200.0, 0.0)) + Vector2(0.0, 140.0 * lado)
	alvo.x = clampf(alvo.x, 120.0, Cfg.PW - 120.0)
	alvo.y = clampf(alvo.y, 120.0, Cfg.PH - 120.0)
	return alvo

func atualizar(delta: float) -> void:
	if p == null or pl == null:
		return
	var alvo: Vector2
	if _lance_t > 0.0:
		_lance_t -= delta
		alvo = _alvo_lance
	else:
		alvo = _posicao_de_jogo()
	var v: Vector2 = alvo - pos
	var d: float = v.length()
	var quer: Vector2 = Vector2.ZERO
	if d > 22.0:
		quer = v.normalized() * minf(VEL, d * 2.0)
	vel = vel.move_toward(quer, 700.0 * delta)
	pos += vel * delta
	if vel.length() > 25.0:
		face = vel.normalized()
	elif p.bola != null:
		face = (p.bola.position - pos).normalized()      # parado: olha para o lance
	_cartao_t = maxf(0.0, _cartao_t - delta)
	_apito_t = maxf(0.0, _apito_t - delta)
	pl.position = Pitch.project(pos.x, pos.y).round()
	pl.esp_forcado = -1
	pl.visual(vel, face, "")
	queue_redraw()
	# o cartão é desenhado pelo próprio nó do árbitro, na posição do sprite
	position = pl.position

func _draw() -> void:
	if _cartao_t > 0.0 and _cartao != "":
		var cor: Color = Color("F6D536") if _cartao == "amarelo" else Color("D8202F")
		var o: Vector2 = Vector2(5, -40)            # mão levantada, acima da cabeça
		draw_rect(Rect2(o + Vector2(-1, -1), Vector2(8, 11)), Color("14101C"))
		draw_rect(Rect2(o, Vector2(6, 9)), cor)
