extends Control
## Tatica
## Escolha entre as 3 táticas reais (data/taticas.json — mesmo pedra-papel-
## tesoura do HTML: ofensivo > pressão, equilibrado > ofensivo, defensivo >
## contra-ataque). Ao confirmar, chama GameState.simular_partida() e vai
## para a tela de Resultado.

@onready var lista_taticas: VBoxContainer = $Coluna/Margem/ListaTaticas
@onready var botao_simular: Button = $Coluna/BotaoSimular
var botao_jogar: Button

const EIXOS := [
	{"id": "pressao", "titulo": "PRESSÃO", "opcoes": ["Baixa", "Média", "Alta"],
		"desc": ["Marca mais longe, poupa o fôlego do time.", "Marcação equilibrada.", "Marca colado e rouba mais, mas cansa mais e faz mais faltas."]},
	{"id": "linha", "titulo": "LINHA DO TIME", "opcoes": ["Recuada", "Média", "Adiantada"],
		"desc": ["Time compacto perto do gol: pouco espaço nas costas, menos ataque.", "Distância normal entre defesa e ataque.", "Time avançado: mais chances criadas, mas deixa espaço para o contra-ataque."]},
	{"id": "construcao", "titulo": "CONSTRUÇÃO", "opcoes": ["Toque curto", "Bola longa", "Contra-ataque"],
		"desc": ["Passes curtos e seguros: erra menos, avança devagar.", "Lançamentos longos: chega rápido ao ataque, mas erra mais passes.", "Espera e sai em velocidade logo após roubar a bola."]},
]
const PRESETS := [
	{"id": "equilibrado", "nome": "Equilibrado"}, {"id": "ofensivo", "nome": "Ofensivo"}, {"id": "defensivo", "nome": "Defensivo"},
]
var _eixos: Dictionary = {}
var _caixa: VBoxContainer

func _ready() -> void:
	_eixos = GameState.eixos_atuais()
	_caixa = lista_taticas
	botao_jogar = Button.new()
	botao_jogar.text = "JOGAR PARTIDA"
	botao_jogar.custom_minimum_size = Vector2(0, 56)
	botao_jogar.pressed.connect(_on_botao_jogar_pressed)
	$Coluna.add_child(botao_jogar)
	$Coluna.move_child(botao_jogar, botao_simular.get_index())
	botao_simular.text = "SIMULAR PARTIDA"
	_montar()

func _montar() -> void:
	for c in _caixa.get_children():
		_caixa.remove_child(c)
		c.queue_free()
	# adversário (estilo conhecido)
	var info = GameState.obter_partida_da_rodada()
	if info != null:
		var est: String = str(info["adversario"].get("estilo", "equilibrado"))
		var ca := Tema.cartao(Tema.AMARELO, 10)
		var va := VBoxContainer.new()
		ca.add_child(va)
		va.add_child(Tema.rotulo("PRÓXIMO ADVERSÁRIO", 12, Tema.TITULO))
		va.add_child(Tema.rotulo("%s · estilo %s" % [info["adversario"].get("nome", "?"), est.replace("_", " ")], 15))
		var adv: Dictionary = info["adversario"]
		var niv: int = GameState.nivel_scouting(str(adv.get("id", "")))
		var rs := Tema.rotulo("Scouting: %s" % ["não observado", "observação básica", "relatório completo"][niv], 12, Tema.TEXTO)
		rs.name = "ScoutNivel"
		va.add_child(rs)
		if niv >= 1:
			var pe: Dictionary = GameState.perfil_adversario(adv)
			var txt := "Pressão %s · Linha %s · Construção %s" % [["baixa", "média", "alta"][int(pe["pressao"])], ["recuada", "média", "adiantada"][int(pe["linha"])], ["toque curto", "bola longa", "contra-ataque"][int(pe["construcao"])]]
			va.add_child(Tema.rotulo(txt, 13))
		if niv >= 2:
			var fz: Dictionary = GameState.fraqueza_adversario(adv)
			var rf := Tema.rotulo("PONTO FRACO: %s. %s" % [fz["titulo"], fz["dica"]], 13)
			rf.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			rf.name = "ScoutFraqueza"
			va.add_child(rf)
		if niv < 2:
			var bo := Tema.botao("OBSERVAR ADVERSÁRIO (R$ %d)" % GameState.SCOUT_CUSTO, "secundario", 40)
			bo.name = "BotaoScouting"
			bo.disabled = float(GameState.financas["caixa"]) < GameState.SCOUT_CUSTO
			bo.pressed.connect(func():
				GameState.observar_adversario(str(adv.get("id", "")))
				_montar.call_deferred())
			va.add_child(bo)
		_caixa.add_child(ca)
	# atalhos
	_caixa.add_child(Tema.rotulo("ESQUEMAS PRONTOS", 12, Tema.TITULO))
	var lp := HBoxContainer.new()
	lp.add_theme_constant_override("separation", 6)
	for pr in PRESETS:
		var b := Tema.botao(str(pr["nome"]), "secundario", 40)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.name = "Preset_" + str(pr["id"])
		var pid: String = str(pr["id"])
		b.pressed.connect(func():
			GameState.escolher_tatica(pid)
			GameState.tatica_eixos = {}
			_eixos = GameState.eixos_atuais()
			_atualizar_botoes()
			_montar.call_deferred())
		lp.add_child(b)
	_caixa.add_child(lp)
	# eixos
	for e in EIXOS:
		var eid: String = str(e["id"])
		var c := Tema.cartao(Tema.BRANCO)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		c.add_child(v)
		v.add_child(Tema.rotulo(str(e["titulo"]), 12, Tema.TITULO))
		var seg := HBoxContainer.new()
		seg.add_theme_constant_override("separation", 5)
		for i in 3:
			var bo := Tema.botao(str(e["opcoes"][i]), "ouro" if int(_eixos[eid]) == i else "secundario", 38)
			bo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			bo.name = "Eixo_%s_%d" % [eid, i]
			bo.add_theme_font_size_override("font_size", 12)
			var idx: int = i
			bo.pressed.connect(func():
				_eixos[eid] = idx
				GameState.escolher_eixos(_eixos)
				_atualizar_botoes()
				_montar.call_deferred())
			seg.add_child(bo)
		v.add_child(seg)
		var d := Tema.rotulo(str(e["desc"][int(_eixos[eid])]), 13)
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(d)
		_caixa.add_child(c)
	if GameState.tatica_id == null:
		GameState.escolher_tatica("equilibrado")
	_atualizar_botoes()

func _atualizar_botoes() -> void:
	var ativo: bool = GameState.tatica_id != null
	botao_simular.disabled = not ativo
	botao_jogar.disabled = not ativo

func _on_botao_simular_pressed() -> void:
	GameState.simular_partida()
	SceneManager.ir_para("resultado")

func _on_botao_jogar_pressed() -> void:
	SceneManager.ir_para("partida")
