class_name Mascote
extends RefCounted
## Gatinho mascote da Católica FC: poses recortadas do modelo oficial (fundo transparente) e humor calculado dos dados reais da carreira.
## Reutilizável em qualquer tela: `Mascote.criar(Mascote.humor_do_clube(), Vector2(96, 110))`.

const PASTA := "res://assets/ui/mascote/poses/gato_%s.png"
const POSES := ["normal", "animado", "confiante", "triste", "bravo", "pensativo", "dormindo", "lesionado", "acenando", "indicando", "costas", "grande_esq", "grande_dir"]

static func textura(humor: String) -> Texture2D:
	var id: String = humor if POSES.has(humor) else "normal"
	return load(PASTA % id) as Texture2D

static func criar(humor: String, tamanho: Vector2) -> TextureRect:
	var t := TextureRect.new()
	t.name = "Mascote"
	t.texture = textura(humor)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.custom_minimum_size = tamanho
	t.size = tamanho
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	t.set_meta("humor", humor)
	return t

## Último resultado da Católica no Universitário: "v", "e", "d" ou "" se ainda não jogou.
static func ultimo_resultado() -> String:
	var r: String = ""
	for rodada in GameState.calendario:
		for m in rodada:
			if not bool(m.get("jogado", false)):
				continue
			var casa: bool = m["mandante_id"] == "catolica"
			if not casa and m["visitante_id"] != "catolica":
				continue
			var a: int = int(m["placar_mandante"] if casa else m["placar_visitante"])
			var b: int = int(m["placar_visitante"] if casa else m["placar_mandante"])
			r = "v" if a > b else ("e" if a == b else "d")
	return r

## Humor do mascote a partir do estado real (prioridade: problemas graves → resultado recente → neutro).
static func humor_do_clube() -> String:
	if float(GameState.financas.get("caixa", 0)) < 0.0:
		return "triste"
	if GameState.lesionados().size() >= 3:
		return "lesionado"
	if int(GameState.financas.get("confianca_diretoria", 70)) < 35:
		return "bravo"
	match ultimo_resultado():
		"v": return "animado"
		"d": return "triste"
		"e": return "pensativo"
	return "normal"
