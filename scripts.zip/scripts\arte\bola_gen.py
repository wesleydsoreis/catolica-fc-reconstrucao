"""Bola 8x8 com 4 quadros de rotação + estrelas de poeira."""
import os, math
from PIL import Image
def quadro(f):
    im=Image.new("RGBA",(8,8),(0,0,0,0)); p=im.load()
    cx=cy=3.5
    for y in range(8):
        for x in range(8):
            d=math.hypot(x-cx,y-cy)
            if d<=3.9: p[x,y]=(246,246,246,255)
            if d>3.0 and d<=3.9: p[x,y]=(20,16,28,255)
            if d<=3.0 and (x+y)%2==1 and x<4: p[x,y]=(222,226,232,255)
    pat=[[(3,3),(4,3),(3,4),(4,4)],[(4,2),(5,3),(4,3),(5,2)],[(3,4),(4,4),(3,5),(4,5)],[(2,3),(3,2),(2,2),(3,3)]][f]
    for (x,y) in pat: p[x,y]=(20,16,28,255)
    extra=[[(1,1),(6,5)],[(1,5),(6,2)],[(5,1),(1,4)],[(6,6),(2,6)]][f]
    for (x,y) in extra: p[x,y]=(20,16,28,255)
    return im
def main(out):
    sh=Image.new("RGBA",(32,8))
    for f in range(4): sh.paste(quadro(f),(f*8,0))
    sh.save(os.path.join(out,"bola_quadros.png"))
if __name__=="__main__": main(os.path.join(os.path.dirname(__file__),"..","..","assets","gerado"))
