extends Control
## Painel do clube no estilo do jogo web: meta, caixa (cartão amarelo), posição,
## barras de elenco/torcida, previsão financeira e próximo adversário.
## Reconstrói sozinho quando GameState muda.

var _col: VBoxContainer

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 12)
	rol.add_child(_col)
	GameState.estado_mudou.connect(_montar)
	_montar()

func _exit_tree() -> void:
	if GameState.estado_mudou.is_connected(_montar):
		GameState.estado_mudou.disconnect(_montar)

func _media(chave: String) -> float:
	if GameState.elenco.is_empty():
		return 0.0
	var s := 0.0
	for j in GameState.elenco:
		s += float(j.get(chave, 0))
	return s / GameState.elenco.size()

func _montar() -> void:
	for f in _col.get_children():
		f.queue_free()
	var cl: Dictionary = GameState.clube_por_id("catolica")
	var caixa: int = int(GameState.financas.get("caixa", 0))
	var total: int = GameData.regras_especiais.get("total_rodadas", 28)

	# ---- meta da diretoria
	var meta := Tema.cartao(Tema.BRANCO)
	var mv := VBoxContainer.new()
	meta.add_child(mv)
	mv.add_child(Tema.titulo_secao("Meta da diretoria"))
	var dir_: int = int(GameState.financas.get("confianca_diretoria", 70))
	for m in GameState.metas:
		mv.add_child(Tema.rotulo("• " + str(m["titulo"]), 14))
	mv.add_child(Tema.barra("Confiança da diretoria", dir_, Tema.AZUL, "%"))
	_col.add_child(meta)

	var bfin := Tema.botao("FINANÇAS E DIRETORIA", "primario", 48)
	bfin.name = "BotaoFinancas"
	bfin.pressed.connect(func(): SceneManager.ir_para("financas"))
	_col.add_child(bfin)
	var bbase := Tema.botao("BASE E EMPRÉSTIMOS", "secundario", 44)
	bbase.name = "BotaoBase"
	bbase.pressed.connect(func(): SceneManager.ir_para("base"))
	_col.add_child(bbase)
	var bconq := Tema.botao("CONQUISTAS (%d/%d)" % [GameState.conquistas.size(), Extras.CONQUISTAS.size()], "secundario", 44)
	bconq.name = "BotaoConquistas"
	bconq.pressed.connect(func(): SceneManager.ir_para("conquistas"))
	_col.add_child(bconq)

	# ---- caixa (amarelo)
	var cx := Tema.cartao(Tema.AMARELO)
	var cv := VBoxContainer.new()
	cx.add_child(cv)
	var ct := Tema.rotulo("CAIXA DO CLUBE", 12, Color("5a3d00"))
	cv.add_child(ct)
	var val := Label.new()
	val.text = Tema.reais(caixa)
	val.add_theme_font_size_override("font_size", 32)
	val.add_theme_color_override("font_color", Tema.TINTA if caixa >= 0 else Color("9a1f1f"))
	cv.add_child(val)
	var folha := 0
	for j in GameState.elenco:
		if int(j.get("emprestado", 0)) <= 0:
			folha += int(j.get("salario", 0))
	cv.add_child(Tema.rotulo("Salários %s/rodada · Estádio %s/rodada" % [Tema.reais(folha), Tema.reais(GameState.manutencao_estadio_total())], 12, Color("5a3d00")))
	_col.add_child(cx)

	# ---- posição / pontos / rodada
	var lin := HBoxContainer.new()
	lin.add_theme_constant_override("separation", 10)
	var pos := _caixinha("POSIÇÃO", "%dº" % _posicao(), "%d pontos" % int(cl.get("pontos", 0)))
	var rod := _caixinha("RODADA", "%d/%d" % [GameState.rodada_atual, total], "Temporada %d" % GameState.temporada)
	lin.add_child(pos)
	lin.add_child(rod)
	_col.add_child(lin)

	# ---- elenco e torcida
	var el := Tema.cartao(Tema.BRANCO)
	var ev := VBoxContainer.new()
	ev.add_theme_constant_override("separation", 8)
	el.add_child(ev)
	var cab := HBoxContainer.new()
	var tt := Tema.titulo_secao("Elenco e torcida")
	tt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cab.add_child(tt)
	var en: float = _media("energia")
	cab.add_child(Tema.chip("SAUDÁVEL" if en >= 70.0 else ("CANSADO" if en >= 45.0 else "EXAUSTO"), Tema.VERDE if en >= 70.0 else (Tema.LARANJA if en >= 45.0 else Color("C94F50"))))
	ev.add_child(cab)
	ev.add_child(Tema.barra("Overall do time", float(GameState.forca_catolica_dinamica), Color("C94F50")))
	ev.add_child(Tema.barra("Moral", _media("moral_individual"), Tema.LARANJA, "%"))
	ev.add_child(Tema.barra("Energia", en, Tema.VERDE, "%"))
	ev.add_child(Tema.barra("Torcida", float(GameState.financas.get("torcida", 0)), Tema.AMARELO, "%"))
	_col.add_child(el)

	# ---- previsão financeira
	var pf := Tema.cartao(Tema.BRANCO)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 4)
	pf.add_child(pv)
	pv.add_child(Tema.titulo_secao("Previsão financeira"))
	var eco: Dictionary = GameData.economia
	var pat: int = int((int(eco["patrocinio_rodada"]["min"]) + int(eco["patrocinio_rodada"]["max"])) / 2)
	var man: int = GameState.manutencao_estadio_total()
	pv.add_child(_linha_valor("Patrocínio médio", "+ " + Tema.reais(pat), Color("3E6B2A")))
	pv.add_child(_linha_valor("Salários", "- " + Tema.reais(folha), Color("9a1f1f")))
	pv.add_child(_linha_valor("Manutenção do estádio", "- " + Tema.reais(man), Color("9a1f1f")))
	var saldo: int = pat - folha - man
	pv.add_child(_linha_valor("Saldo sem bilheteria", Tema.reais(saldo), Color("3E6B2A") if saldo >= 0 else Color("9a1f1f")))
	_col.add_child(pf)

	# ---- próximo adversário
	var info = GameState.obter_partida_da_rodada()
	var pa := Tema.cartao(Tema.ROSA)
	var av := VBoxContainer.new()
	pa.add_child(av)
	av.add_child(Tema.titulo_secao("Próximo adversário"))
	if info == null:
		av.add_child(Tema.rotulo("Sem partida nesta rodada.", 14))
	else:
		var adv: Dictionary = info["adversario"]
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 10)
		var cir := Tema.chip(str(adv.get("nome", "?")).substr(0, 1), Tema.VINHO)
		h.add_child(cir)
		var nome := Tema.rotulo(str(adv.get("nome", "?")), 18)
		h.add_child(nome)
		h.add_child(Tema.chip("CASA" if info["em_casa"] else "FORA", Tema.AZUL if info["em_casa"] else Tema.LARANJA))
		av.add_child(h)
		av.add_child(Tema.barra("Força do adversário", float(adv.get("forca", 60)), Color("C94F50")))
	_col.add_child(pa)

	# ---- ações
	var jogar := Tema.botao("JOGAR PRÓXIMA RODADA", "primario", 56)
	jogar.pressed.connect(func(): SceneManager.ir_para("desafio"))
	_col.add_child(jogar)
	var lb := HBoxContainer.new()
	lb.add_theme_constant_override("separation", 10)
	var sv := Tema.botao("SALVAR PROGRESSO", "secundario", 44)
	sv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sv.pressed.connect(_salvar)
	lb.add_child(sv)
	var vila := Tema.botao("IR PARA O MAPA", "secundario", 44)
	vila.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vila.pressed.connect(func(): SceneManager.ir_para("mapa", false))
	lb.add_child(vila)
	_col.add_child(lb)
	var fim := Control.new()
	fim.custom_minimum_size = Vector2(0, 8)
	_col.add_child(fim)

func _caixinha(titulo: String, grande: String, pequeno: String) -> PanelContainer:
	var c := Tema.cartao(Tema.BRANCO)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	c.add_child(v)
	v.add_child(Tema.titulo_secao(titulo))
	var g := Label.new()
	g.text = grande
	g.add_theme_font_size_override("font_size", 30)
	v.add_child(g)
	v.add_child(Tema.rotulo(pequeno, 12, Tema.TEXTO2))
	return c

func _linha_valor(a: String, b: String, cor: Color) -> HBoxContainer:
	var h := HBoxContainer.new()
	var la := Tema.rotulo(a, 14)
	h.add_child(la)
	var lb := Label.new()
	lb.text = b
	lb.add_theme_font_size_override("font_size", 14)
	lb.add_theme_color_override("font_color", cor)
	h.add_child(lb)
	return h

func _posicao() -> int:
	var main: Node = get_tree().root.get_node_or_null("Main")
	if main != null and main.has_method("_posicao_clube"):
		return int(main.call("_posicao_clube"))
	return 1

func _salvar() -> void:
	var ok: bool = SaveSystem.salvar()
	var aviso := AcceptDialog.new()
	aviso.dialog_text = "Progresso salvo!" if ok else "Não foi possível salvar."
	aviso.title = ""
	add_child(aviso)
	aviso.popup_centered()
	aviso.confirmed.connect(func(): aviso.queue_free())
