extends Control

signal local_destacado(id: String)
## Mapa do clube: centro de gestão ilustrado. A imagem (assets/ui/ref/mapa_ref.png) é o cenário;
## tudo que muda (tabela, próximo jogo, caixa, avisos) é desenhado por cima com dados ao vivo.
## Coordenadas em pixels da imagem original (1280x720); o layout converte para qualquer resolução.

const IMG := Vector2(1280, 720)
const DOURADO := Color("E8B84A")
const BORDO := Color("4B0A12")
const BORDO_ESC := Color("2A0A10")
const VERMELHO := Color("B3202A")
const CREME := Color("F7EFDF")
const MAPA_PNG := "res://assets/ui/novo/mapa_catolica.png"        # quadro de reserva (só aparece se o vídeo falhar)
const VIDEO := "res://assets/video/mapa_animado.ogv"

## id estável (usado por testes/atalhos), área clicável, destino do SceneManager.
const LOCAIS := [
	{"id": "estadio", "nome": "Estádio", "area": Rect2(385, 8, 515, 245), "destino": "desafio"},
	{"id": "sede", "nome": "Secretaria e Diretoria", "area": Rect2(62, 24, 270, 200), "destino": "painel"},
	{"id": "treino", "nome": "Campo de Treinamento", "area": Rect2(922, 12, 340, 238), "destino": "treino"},
	{"id": "mercado", "nome": "Mercado", "area": Rect2(55, 235, 245, 168), "destino": "mercado"},
	{"id": "obras", "nome": "Obras do Estádio", "area": Rect2(922, 232, 345, 270), "destino": "estadio_obras"},
	{"id": "federacao", "nome": "Campeonatos", "area": Rect2(466, 336, 356, 172), "destino": "torneios"},
	{"id": "vestiario", "nome": "Elenco", "area": Rect2(520, 248, 250, 90), "destino": "elenco"},
]
const ATALHOS := [
	["BotaoPrancheta", "PRANCHETA", "prancheta"],
	["BotaoFinancas", "FINANÇAS", "financas"],
	["BotaoBase", "BASE", "base"],
	["BotaoConquistas", "CONQUISTAS", "conquistas"],
]
## A tabela "CAMPEONATO" já vem desenhada (vazia) na arte: 5 linhas de 18 px sob o cabeçalho CLASSIFICAÇÃO / P / J.
const AREA_TABELA := Rect2(474, 401, 176, 91)
const LINHA_TAB := 18.0
const COL_P := 636.0                     # borda direita da coluna P / J na imagem
const COL_J := 656.0
const AREA_DOCK := Rect2(770, 664, 502, 50)
const BARRA_Y := 664.0                   # faixa da estrada: HUD ao vivo

var _bg: ColorRect
var _fundo: VideoFundo
var _botoes: Dictionary = {}
var _brilho: Panel
var _card: PanelContainer
var _card_t: Label
var _card_a: Label
var _card_b: Label
var _card_c: Label
var _cta: PanelContainer
var _cta_t: Label
var _cta_s: Label
var _avisos: Dictionary = {}         # id -> PanelContainer (bolinha de aviso)
var _pill_e: PanelContainer
var _pill_d: PanelContainer
var _lb_sub: Label
var _stats: Dictionary = {}
var _btn_voltar: Button
var _tabela: PanelContainer
var _tab_col: VBoxContainer
var _dock: PanelContainer
var _escalaveis: Array = []          # [Control, tamanho base da fonte]
var _k: float = 1.0
var _org: Vector2 = Vector2.ZERO
var _atual: String = ""
var _tw: Tween
var _pausa: PausaMapa
var _tutorial: TutorialMapa
var _btn_menu: Button
var _btn_ajuda: Button

func _ready() -> void:
	_bg = ColorRect.new()
	_bg.color = BORDO_ESC
	_bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bg)
	_fundo = VideoFundo.criar(VIDEO, load(MAPA_PNG), false)      # vídeo animado em loop; proporção 16:9 preservada (cabe inteiro)
	add_child(_fundo)
	_montar_tabela()          # painel ao vivo que cobre a tabela "pintada" na imagem
	_montar_chips()
	_brilho = Panel.new()
	_brilho.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(DOURADO.r, DOURADO.g, DOURADO.b, 0.16)
	sb.border_color = DOURADO
	sb.set_border_width_all(4)
	sb.set_corner_radius_all(18)
	sb.shadow_color = Color(DOURADO.r, DOURADO.g, DOURADO.b, 0.35)
	sb.shadow_size = 14
	_brilho.add_theme_stylebox_override("panel", sb)
	_brilho.modulate.a = 0.0
	add_child(_brilho)
	move_child(_brilho, _fundo.get_index() + 1)
	for l in LOCAIS:
		var b := Button.new()
		b.name = "Local_" + str(l["id"])
		b.flat = true
		b.focus_mode = Control.FOCUS_ALL
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		var vazio := StyleBoxEmpty.new()
		for e in ["normal", "hover", "pressed", "focus", "disabled"]:
			b.add_theme_stylebox_override(e, vazio)
		b.pressed.connect(_ir.bind(str(l["id"])))
		b.mouse_entered.connect(_mostrar.bind(str(l["id"])))
		b.mouse_exited.connect(_esconder.bind(str(l["id"])))
		b.focus_entered.connect(_mostrar.bind(str(l["id"])))
		b.focus_exited.connect(_esconder.bind(str(l["id"])))
		add_child(b)
		_botoes[str(l["id"])] = b
	_montar_avisos()
	_montar_cartao()
	_montar_hud()
	_montar_dock()
	resized.connect(_layout)
	GameState.estado_mudou.connect(_atualizar)
	_atualizar()
	_layout()
	_layout.call_deferred()
	# entrada da carreira: o mapa aparece com um fade curto
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.3)
	if not GameState.tutorial_concluido:
		abrir_tutorial.call_deferred(true)
	elif SceneManager.tutorial_pendente:
		SceneManager.tutorial_pendente = false
		abrir_tutorial.call_deferred(false)         # revisão pedida na Prancheta: não altera o progresso do tutorial

func _exit_tree() -> void:
	if GameState.estado_mudou.is_connected(_atualizar):
		GameState.estado_mudou.disconnect(_atualizar)

# ------------------------------------------------------------------ construção
func _estilo(fundo: Color, borda: Color, bw: int = 2, raio: int = 10, margem: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fundo
	s.border_color = borda
	s.set_border_width_all(bw)
	s.set_corner_radius_all(raio)
	s.shadow_color = Color(0, 0, 0, 0.45)
	s.shadow_size = 6
	s.shadow_offset = Vector2(0, 3)
	s.content_margin_left = margem
	s.content_margin_right = margem
	s.content_margin_top = margem * 0.5
	s.content_margin_bottom = margem * 0.5
	return s

func _rot(texto: String, base: int, cor: Color = CREME, titulo: bool = false, peso: int = 0) -> Label:
	var l := Label.new()
	l.text = texto
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_color_override("font_color", cor)
	l.add_theme_font_override("font", Fontes.titulo(peso if peso > 0 else 700) if titulo else Fontes.texto(peso if peso > 0 else 500))
	_escalaveis.append([l, base])
	return l

func _montar_chips() -> void:
	# Etiqueta dinâmica logo abaixo do "JOGAR RODADA" da arte: rodada e adversário (muda a cada jogo)
	_cta = PanelContainer.new()
	_cta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cta.add_theme_stylebox_override("panel", _estilo(DOURADO, BORDO_ESC, 2, 8, 8))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", -3)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cta_t = _rot("RODADA 1", 14, BORDO_ESC, true, 700)
	_cta_t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_cta_s = _rot("", 13, BORDO, false, 600)
	_cta_s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_cta_t)
	v.add_child(_cta_s)
	_cta.add_child(v)
	add_child(_cta)

func _montar_avisos() -> void:
	for id in ["treino", "vestiario", "sede"]:
		var p := PanelContainer.new()
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		p.add_theme_stylebox_override("panel", _estilo(VERMELHO, CREME, 3, 20, 6))
		var t := _rot("!", 18, CREME, true)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		t.name = "Texto"
		p.add_child(t)
		p.visible = false
		add_child(p)
		_avisos[id] = p

func _montar_cartao() -> void:
	_card = PanelContainer.new()
	_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_card.add_theme_stylebox_override("panel", _estilo(Color(BORDO.r, BORDO.g, BORDO.b, 0.96), DOURADO, 2, 12, 14))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 1)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_card_t = _rot("", 24, DOURADO, true)
	_card_a = _rot("", 16, CREME)
	_card_b = _rot("", 16, CREME)
	_card_c = _rot("", 15, Color("E3CFC0"), false, 400)
	for l in [_card_t, _card_a, _card_b, _card_c]:
		v.add_child(l)
	_card.add_child(v)
	_card.visible = false
	add_child(_card)

func _pilula() -> PanelContainer:
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_PASS
	p.add_theme_stylebox_override("panel", _estilo(Color(BORDO.r, BORDO.g, BORDO.b, 1.0), DOURADO, 2, 12, 10))
	return p

func _montar_hud() -> void:
	_pill_e = _pilula()
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	_pill_e.add_child(h)
	_btn_voltar = Paleta.botao("☰", "discreto", 22, 34)
	_btn_voltar.name = "BotaoMenuMapa"
	_btn_voltar.tooltip_text = "Menu de pausa (Esc)"
	_btn_voltar.focus_mode = Control.FOCUS_NONE
	_btn_voltar.pressed.connect(abrir_pausa)
	_escalaveis.append([_btn_voltar, 22])
	h.add_child(_btn_voltar)
	var esc := TextureRect.new()
	esc.texture = load("res://assets/ui/ref/escudo.png")
	esc.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	esc.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	esc.custom_minimum_size = Vector2(30, 30)
	esc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	esc.name = "Escudo"
	h.add_child(esc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", -3)
	h.add_child(v)
	v.add_child(_rot("CATÓLICA FC", 19, CREME, true))
	_lb_sub = _rot("", 13, DOURADO, false, 600)
	v.add_child(_lb_sub)
	_btn_ajuda = Paleta.botao("?", "discreto", 20, 34)
	_btn_ajuda.name = "BotaoTutorial"
	_btn_ajuda.tooltip_text = "Rever o tutorial"
	_btn_ajuda.focus_mode = Control.FOCUS_NONE
	_btn_ajuda.pressed.connect(func(): abrir_tutorial(false))
	_escalaveis.append([_btn_ajuda, 20])
	h.add_child(_btn_ajuda)
	add_child(_pill_e)
	_pill_d = _pilula()
	var hd := HBoxContainer.new()
	hd.add_theme_constant_override("separation", 14)
	_pill_d.add_child(hd)
	for k in ["caixa", "torcida", "diretoria", "posicao"]:
		var c := VBoxContainer.new()
		c.add_theme_constant_override("separation", -3)
		var t := _rot(k.to_upper().replace("POSICAO", "POSIÇÃO"), 11, Color("D9B9A5"), false, 600)
		var val := _rot("", 17, CREME, true, 600)
		c.add_child(t)
		c.add_child(val)
		hd.add_child(c)
		_stats[k] = val
	add_child(_pill_d)

func _montar_tabela() -> void:
	_tabela = PanelContainer.new()
	_tabela.name = "TabelaAoVivo"
	_tabela.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vazio := StyleBoxEmpty.new()          # o fundo da tabela é a própria arte; só as linhas são do Godot
	_tabela.add_theme_stylebox_override("panel", vazio)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tab_col = VBoxContainer.new()
	_tab_col.add_theme_constant_override("separation", 1)
	_tab_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tab_col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(_tab_col)
	_tabela.add_child(h)
	add_child(_tabela)

func _montar_dock() -> void:
	_dock = PanelContainer.new()
	_dock.name = "DockAtalhos"
	_dock.mouse_filter = Control.MOUSE_FILTER_PASS
	_dock.add_theme_stylebox_override("panel", _estilo(Color(BORDO.r, BORDO.g, BORDO.b, 1.0), DOURADO, 2, 12, 6))
	var g := HBoxContainer.new()
	g.add_theme_constant_override("separation", 6)
	_dock.add_child(g)
	for a in ATALHOS:
		var b := Button.new()
		b.name = str(a[0])
		b.text = str(a[1])
		b.focus_mode = Control.FOCUS_ALL
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		b.add_theme_font_override("font", Fontes.titulo(700))
		var principal: bool = str(a[0]) == "BotaoPrancheta"      # a Prancheta é o atalho em destaque (dourado), como na arte
		b.add_theme_color_override("font_color", BORDO_ESC if principal else CREME)
		b.add_theme_color_override("font_hover_color", BORDO_ESC)
		b.add_theme_color_override("font_pressed_color", BORDO_ESC)
		b.add_theme_stylebox_override("normal", _estilo(DOURADO if principal else Color("7A1220"), BORDO_ESC if principal else Color("A83040"), 2, 8, 6))
		b.add_theme_stylebox_override("hover", _estilo(Color("F3CB6A"), BORDO_ESC, 2, 8, 6))
		b.add_theme_stylebox_override("pressed", _estilo(Color("C79A38"), BORDO_ESC, 2, 8, 6))
		b.add_theme_stylebox_override("focus", _estilo(Color(0, 0, 0, 0), CREME, 3, 8, 6))
		var destino: String = str(a[2])
		b.pressed.connect(func(): SceneManager.ir_para(destino))
		_escalaveis.append([b, 16])
		g.add_child(b)
	add_child(_dock)

# ------------------------------------------------------------------ layout
func _m(r: Rect2) -> Rect2:
	return Rect2(_org + r.position * _k, r.size * _k)

func _layout() -> void:
	if _fundo == null or size.x < 10.0 or size.y < 10.0:
		return
	_k = minf(size.x / IMG.x, size.y / IMG.y)
	_org = (size - IMG * _k) * 0.5
	for par in _escalaveis.duplicate():
		if not is_instance_valid(par[0]):
			_escalaveis.erase(par)
	for par in _escalaveis:
		(par[0] as Control).add_theme_font_size_override("font_size", maxi(8, int(round(float(par[1]) * _k))))
	for id in _botoes:
		var b: Button = _botoes[id]
		var r: Rect2 = _m(_area(id))
		b.position = r.position
		b.size = r.size
	for p in [_pill_e, _pill_d, _card, _cta, _dock, _tabela]:
		(p as Control).custom_minimum_size = Vector2.ZERO
		(p as Control).reset_size()
	var esc: Control = _pill_e.find_child("Escudo", true, false)
	if esc != null:
		esc.custom_minimum_size = Vector2.ONE * 28.0 * _k
	# barra inferior (estrada): menu/identidade e números à esquerda, atalhos à direita
	_pill_e.reset_size()
	_pill_e.position = _org + Vector2(8, BARRA_Y + (50.0 - _pill_e.size.y / _k) * 0.5) * _k
	_pill_d.reset_size()
	_pill_d.position = Vector2(_pill_e.position.x + _pill_e.size.x + 8.0 * _k, _org.y + (BARRA_Y + (50.0 - _pill_d.size.y / _k) * 0.5) * _k)
	# etiqueta de rodada/adversário logo abaixo do "JOGAR RODADA" desenhado na arte
	_cta.reset_size()
	_cta.position = _org + Vector2(642, 213) * _k - Vector2(_cta.size.x * 0.5, 0.0)
	_posicionar_aviso("treino", Vector2(1128, 56))
	_posicionar_aviso("vestiario", Vector2(742, 262))
	_posicionar_aviso("sede", Vector2(322, 62))
	var rt: Rect2 = _m(AREA_TABELA)
	_tabela.position = rt.position
	_tabela.size = rt.size
	var rd: Rect2 = _m(AREA_DOCK)
	_dock.size = rd.size
	_dock.position = Vector2(rd.end.x - _dock.size.x, rd.position.y)
	if _atual != "":
		_posicionar_cartao(_atual)
	_posicionar_brilho(_atual, false)

func _area(id: String) -> Rect2:
	for l in LOCAIS:
		if l["id"] == id:
			return l["area"]
	return Rect2()

func _posicionar_aviso(id: String, centro: Vector2) -> void:
	var a: PanelContainer = _avisos[id]
	a.reset_size()
	a.position = _org + centro * _k - a.size / 2.0

func _posicionar_cartao(id: String) -> void:
	_card.reset_size()
	var r: Rect2 = _m(_area(id))
	var pos := Vector2(r.position.x + r.size.x * 0.5 - _card.size.x * 0.5, r.end.y + 8.0)
	if pos.y + _card.size.y > size.y - 6.0:
		pos.y = r.position.y - _card.size.y - 8.0
	if pos.y < 6.0:
		pos.y = clampf(r.position.y + r.size.y * 0.5 - _card.size.y * 0.5, 6.0, size.y - _card.size.y - 6.0)
	pos.x = clampf(pos.x, 6.0, size.x - _card.size.x - 6.0)
	_card.position = pos

func _posicionar_brilho(id: String, _animar: bool) -> void:
	if id == "":
		return
	var r: Rect2 = _m(_area(id))
	_brilho.position = r.position
	_brilho.size = r.size

# ------------------------------------------------------------------ interação
func _mostrar(id: String) -> void:
	_atual = id
	local_destacado.emit(id)
	var d: Dictionary = _dados(id)
	_card_t.text = str(d["titulo"])
	_card_a.text = str(d["a"])
	_card_b.text = str(d["b"])
	_card_c.text = str(d.get("c", ""))
	_card_b.visible = _card_b.text != ""
	_card_c.visible = _card_c.text != ""
	_card.visible = true
	_posicionar_cartao(id)
	_card.reset_size.call_deferred()
	_posicionar_cartao.call_deferred(id)
	_posicionar_brilho(id, true)
	if _tw != null:
		_tw.kill()
	_tw = create_tween()
	_tw.tween_property(_brilho, "modulate:a", 1.0, 0.12)

func _esconder(id: String) -> void:
	if _atual != id:
		return
	_atual = ""
	_card.visible = false
	if _tw != null:
		_tw.kill()
	_tw = create_tween()
	_tw.tween_property(_brilho, "modulate:a", 0.0, 0.12)

func _ir(id: String) -> void:
	for l in LOCAIS:
		if l["id"] == id:
			var d: String = l["destino"]
			if d == "desafio" and GameState.temporada_status != "em_andamento":
				d = "fim_temporada"
			SceneManager.ir_para(d)
			return

# ------------------------------------------------------------------ dados dinâmicos
func _milhar(n: int) -> String:
	var t := str(absi(n))
	var r := ""
	while t.length() > 3:
		r = "." + t.substr(t.length() - 3) + r
		t = t.substr(0, t.length() - 3)
	return ("-" if n < 0 else "") + t + r

func _nome_comp(comp: String, info: Variant) -> String:
	match comp:
		"universitario": return "Campeonato Universitário"
		"interlajes": return "InterLajes" + (" · " + str(info.get("estagio", "")).capitalize() if info is Dictionary else "")
		"copa": return "Copa dos Gigantes"
	return "Temporada encerrada"

func _tabela_atual() -> Array:
	var comp: String = Competicoes.competicao_da_rodada(GameState.rodada_atual)
	var src: Array = GameState.copa if comp == "copa" and not GameState.copa.is_empty() else GameState.clubes
	return Competicoes.ordenar_tabela(src)

func _posicao() -> int:
	var t: Array = _tabela_atual()
	for i in t.size():
		if t[i]["id"] == "catolica":
			return i + 1
	return 0

func _dados(id: String) -> Dictionary:
	var f: Dictionary = GameState.financas
	var total: int = GameData.regras_especiais.get("total_rodadas", 28)
	var susp: int = GameState.suspensos().size()
	var les: int = GameState.lesionados().size()
	match id:
		"estadio":
			var info: Variant = GameState.obter_partida_da_rodada()
			if GameState.temporada_status != "em_andamento":
				return {"titulo": "Estádio", "a": "Temporada encerrada", "b": "Toque para ver o balanço do ano."}
			if info == null:
				return {"titulo": "Estádio", "a": "Rodada %d/%d" % [GameState.rodada_atual, total], "b": "Sem jogo da Católica nesta rodada.", "c": "Toque para avançar."}
			var adv: Dictionary = info["adversario"]
			var cl: String = GameState.clima_atual()
			return {"titulo": "Estádio", "a": "%s · rodada %d/%d" % [_nome_comp(str(info["competicao"]), info), GameState.rodada_atual, total],
				"b": "%s%s · %s" % ["CLÁSSICO contra " if GameState.eh_classico(adv) else "vs ", adv.get("nome", "?"), "em casa" if info["em_casa"] else "fora"],
				"c": "Clima: %s · lotação %s" % [Extras.CLIMAS[cl]["nome"], _milhar(int(f.get("capacidade_estadio", 0)))]}
		"sede":
			var dv: int = int(round(float(f.get("divida", 0.0))))
			return {"titulo": "Secretaria e Diretoria", "a": "Confiança da diretoria: %d%%" % int(f.get("confianca_diretoria", 0)),
				"b": "Caixa %s%s" % [Tema.reais(int(f.get("caixa", 0))), ("  ·  dívida " + Tema.reais(dv)) if dv > 0 else ""], "c": "Metas, finanças e relatórios."}
		"treino":
			return {"titulo": "Campo de Treinamento", "a": "Treino da semana: " + ("confirmado" if GameState.treino_confirmado else "pendente"),
				"b": "%d lesionado(s) · %d suspenso(s)" % [les, susp], "c": "Agenda, foco individual e entrosamento."}
		"mercado":
			return {"titulo": "Mercado de Jogadores", "a": "Elenco: %d jogadores" % GameState.elenco.size(), "b": "Caixa %s" % Tema.reais(int(f.get("caixa", 0))), "c": "Contratações e vendas."}
		"obras":
			return {"titulo": "Obras do Estádio", "a": "Nível %d · %s lugares" % [int(f.get("estadio_nivel", 1)), _milhar(int(f.get("capacidade_estadio", 0)))],
				"b": "Ingresso: %s" % Tema.reais(int(f.get("preco_ingresso", 0))), "c": "Melhorias de capacidade e receita."}
		"federacao":
			return {"titulo": "Campeonatos", "a": _nome_comp(Competicoes.competicao_da_rodada(GameState.rodada_atual), null), "b": "Católica FC em %dº lugar" % _posicao(), "c": "Tabelas, calendário, artilharia e troféus."}
		"vestiario":
			return {"titulo": "Elenco e Vestiário", "a": "%d jogadores" % GameState.elenco.size(), "b": "%d suspenso(s) · %d lesionado(s)" % [susp, les], "c": "Escalação, moral e energia."}
	return {"titulo": "", "a": "", "b": ""}

func _atualizar() -> void:
	if _lb_sub == null:
		return
	var f: Dictionary = GameState.financas
	var total: int = GameData.regras_especiais.get("total_rodadas", 28)
	_lb_sub.text = "Temporada %d · Rodada %d/%d%s" % [GameState.temporada, GameState.rodada_atual, total, "" if GameState.treino_confirmado else " · Treino pendente"]
	(_stats["caixa"] as Label).text = Tema.reais(int(f.get("caixa", 0)))
	(_stats["torcida"] as Label).text = "%d%%" % int(round(float(f.get("torcida", 0))))
	(_stats["diretoria"] as Label).text = "%d%%" % int(round(float(f.get("confianca_diretoria", 0))))
	(_stats["posicao"] as Label).text = "%dº" % _posicao()
	var neg: bool = int(f.get("caixa", 0)) < 0
	(_stats["caixa"] as Label).add_theme_color_override("font_color", Color("FF9A8A") if neg else CREME)
	_atualizar_cta()
	_atualizar_avisos()
	_atualizar_tabela()
	_layout.call_deferred()

func _atualizar_cta() -> void:
	if GameState.temporada_status != "em_andamento":
		_cta_t.text = "TEMPORADA ENCERRADA"
		_cta_s.text = "ver balanço"
		return
	var info: Variant = GameState.obter_partida_da_rodada()
	_cta_t.text = "RODADA %d" % GameState.rodada_atual
	if info == null:
		_cta_s.text = "sem jogo · avançar"
	else:
		var adv: Dictionary = info["adversario"]
		_cta_s.text = "%s%s · %s" % ["CLÁSSICO · " if GameState.eh_classico(adv) else "", adv.get("nome", "?"), "casa" if info["em_casa"] else "fora"]

func _atualizar_avisos() -> void:
	var susp: int = GameState.suspensos().size()
	var les: int = GameState.lesionados().size()
	_avisos["treino"].visible = not GameState.treino_confirmado
	_avisos["vestiario"].visible = susp + les > 0
	(_avisos["vestiario"].get_node("Texto") as Label).text = str(susp + les)
	_avisos["sede"].visible = float(GameState.financas.get("divida", 0.0)) > 0.0 or int(GameState.financas.get("caixa", 0)) < 0
	_avisos["treino"].tooltip_text = "Treino pendente"

func _atualizar_tabela() -> void:
	for par in _escalaveis.duplicate():
		if not is_instance_valid(par[0]) or (par[0] as Node).is_queued_for_deletion():
			_escalaveis.erase(par)
	for c in _tab_col.get_children():
		_tab_col.remove_child(c)
		c.queue_free()
	var t: Array = _tabela_atual()
	var pos_c: int = 0
	for i in t.size():
		if t[i]["id"] == "catolica":
			pos_c = i + 1
	var linhas: Array = []
	for i in mini(5, t.size()):
		linhas.append(i)
	if pos_c > 5:
		linhas[4] = pos_c - 1          # a Católica sempre aparece, mesmo fora do top 5
	for i in linhas:
		var c: Dictionary = t[i]
		_tab_col.add_child(_linha_tabela(str(c["nome"]), str(int(c["pontos"])), str(int(c["jogos"])), str(i + 1), c["id"] == "catolica"))
	_layout.call_deferred()

func _linha_tabela(nome: String, p: String, j: String, pos: String, destaque: bool) -> Control:
	var pc := PanelContainer.new()
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.custom_minimum_size = Vector2(0, LINHA_TAB * _k)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(DOURADO.r, DOURADO.g, DOURADO.b, 0.30) if destaque else Color(0, 0, 0, 0)
	sb.set_corner_radius_all(2)
	sb.content_margin_left = 3
	sb.content_margin_right = 0
	sb.content_margin_top = 0
	sb.content_margin_bottom = 0
	pc.add_theme_stylebox_override("panel", sb)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 2)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var cor: Color = DOURADO if destaque else CREME
	var a: Label = _rot(pos, 12, cor, false, 700)
	a.custom_minimum_size = Vector2(11.0 * _k, 0)
	a.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var b: Label = _rot(nome, 12, cor, false, 700 if destaque else 500)
	b.clip_text = true
	b.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var c: Label = _rot(p, 13, cor, false, 700)
	c.custom_minimum_size = Vector2(24.0 * _k, 0)
	c.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	c.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var d: Label = _rot(j, 13, cor, false, 500)
	d.custom_minimum_size = Vector2(24.0 * _k, 0)
	d.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	d.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	for x in [a, b, c, d]:
		h.add_child(x)
	pc.add_child(h)
	return pc

# ------------------------------------------------------------------ pausa e tutorial
func abrir_pausa() -> void:
	if is_instance_valid(_pausa) or is_instance_valid(_tutorial):
		return
	_pausa = PausaMapa.abrir(self)
	_pausa.pediu_tutorial.connect(func(): abrir_tutorial.call_deferred(false))

func abrir_tutorial(auto: bool = false) -> void:
	if is_instance_valid(_tutorial):
		return
	if is_instance_valid(_pausa):
		_pausa.queue_free()
	_tutorial = TutorialMapa.abrir(self, auto)

func pausa_aberta() -> bool:
	return is_instance_valid(_pausa) or is_instance_valid(_tutorial)

## API usada pelo tutorial: destaca um local como se o mouse estivesse sobre ele.
func mostrar_local(id: String) -> void:
	_mostrar(id)

func esconder_local() -> void:
	if _atual != "":
		_esconder(_atual)

## Retângulo (coordenadas da tela) de um local ou do bloco de atalhos.
func rect_alvo(id: String) -> Rect2:
	if id == "dock":
		return _m(AREA_DOCK)
	return _m(_area(id))
