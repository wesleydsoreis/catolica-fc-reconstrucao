extends Node
## MatchEngine
## Porta fiel das fórmulas de força efetiva e probabilidade do Campeonato
## Universitário, extraídas de calcularForcaDetalhada() e
## calcularProbabilidadesUniversitario() no HTML original.
##
## STATUS DESTA ETAPA: a fórmula do Universitário (a mais usada, rodadas 1-11)
## está completa. A fórmula logística da Copa dos Gigantes e a simulação de
## partida animada (eventos minuto a minuto) ficam para a próxima etapa —
## ver README.md, seção "Progresso e pendências".

func _mb() -> Dictionary:
	return GameData.match_balance

## Calcula o bônus por "centro" — mesma curva usada para energia e moral:
## acima do centro, aproxima-se de max; abaixo do centro, aproxima-se de min.
func calcular_bonus_por_centro(valor_atual: float, centro: float, minimo: float, maximo: float) -> float:
	if valor_atual >= centro:
		var t: float = clampf((valor_atual - centro) / (100.0 - centro), 0.0, 1.0)
		return t * maximo
	var t2: float = clampf((centro - valor_atual) / centro, 0.0, 1.0)
	return t2 * minimo

## Mapa exato de POSICOES_CATEGORIAS do HTML original: cada posição pode
## preencher uma ou mais categorias de slot sem ser considerada "fora de posição".
const POSICOES_CATEGORIAS := {
	"GOLEIRO": ["GOL"],
	"DEFENSOR": ["DEF"],
	"MEIA": ["MEI"],
	"MEIA_DEFENSOR": ["DEF", "MEI"],
	"MEIA_ATAQUE": ["MEI", "ATA"],
	"ATAQUE": ["ATA"],
}

## Retorna true se o jogador está fora da posição ideal para a categoria do slot.
func jogador_fora_de_posicao(jogador: Dictionary, categoria_slot: String) -> bool:
	var compativeis: Array = POSICOES_CATEGORIAS.get(jogador["posicao"], [])
	return not compativeis.has(categoria_slot)

## Força efetiva detalhada da Católica para a partida atual.
## Parâmetros:
##   slots, elenco: escalação atual (ver GameState).
##   mando_de_campo: true=casa, false=fora, null=campo neutro (Copa/mata-mata neutro).
##   tatica_id: "ofensivo" | "equilibrado" | "defensivo" | null.
##   situacao_tatica: "vantajosa" | "desfavoravel" | "neutra" (resultado do confronto pedra-papel-tesoura com a tática do adversário).
##   forca_extra_preparacao: bônus 0-4 vindo das cartas de preparação já confirmadas.
##   penalidades: {"deficit": bool, "salarios_atrasados": bool}.
##   reacao_elenco: 0/2/4, conforme derrotas consecutivas.
##   capitao_id: id do capitão, se houver.
func calcular_forca_detalhada(p: Dictionary) -> Dictionary:
	var slots: Array = p["slots"]
	var elenco: Array = p["elenco"]
	var mb := _mb()

	var titulares_info: Array = []
	for s in slots:
		if s["jogador_id"] == null:
			continue
		var jogador = null
		for j in elenco:
			if j["id"] == s["jogador_id"]:
				jogador = j
				break
		if jogador == null:
			continue
		titulares_info.append({"jogador": jogador, "fora_de_posicao": jogador_fora_de_posicao(jogador, s["categoria"])})

	if titulares_info.is_empty():
		return {"base": 30, "bonus_energia": 0.0, "bonus_moral": 0.0, "bonus_entrosamento": 0.0,
			"bonus_preparacao": 0, "bonus_tatica": 0.0, "situacao_tatica": "neutra", "bonus_mando": 0.0,
			"bonus_reacao": 0, "bonus_capitao": 0.0, "capitao_em_campo": false,
			"penalidade_fora_de_posicao": 0.0, "penalidade_financeira": 0, "final": 30, "fora_de_posicao_qtd": 0}

	# overall base: 100% do overall na posição correta, 75% se fora de posição
	var soma_overall := 0.0
	var soma_overall_sem_penalidade := 0.0
	var fora_qtd := 0
	for info in titulares_info:
		var j: Dictionary = info["jogador"]
		var overall_com_efeito: float = float(j["overall"])
		if j.get("efeito_temporario") != null and int(j["efeito_temporario"].get("rodadas_restantes", 0)) > 0:
			overall_com_efeito += float(j["efeito_temporario"].get("overall_temp", 0))
		soma_overall_sem_penalidade += overall_com_efeito
		if info["fora_de_posicao"]:
			soma_overall += overall_com_efeito * float(mb["fora_de_posicao_fator"])
			fora_qtd += 1
		else:
			soma_overall += overall_com_efeito
	var n := float(titulares_info.size())
	var media_overall_base := soma_overall / n
	var media_overall_sem_penalidade := soma_overall_sem_penalidade / n

	# energia e moral médias dos titulares
	var soma_energia := 0.0
	var soma_moral := 0.0
	for info in titulares_info:
		soma_energia += float(info["jogador"]["energia"])
		soma_moral += float(info["jogador"]["moral_individual"])
	var energia_media := soma_energia / n
	var moral_media := soma_moral / n

	var bonus_energia: float = calcular_bonus_por_centro(energia_media, float(mb["energia"]["centro"]), float(mb["energia"]["min"]), float(mb["energia"]["max"]))
	var bonus_moral: float = calcular_bonus_por_centro(moral_media, float(mb["moral"]["centro"]), float(mb["moral"]["min"]), float(mb["moral"]["max"]))

	var capitao_id = p.get("capitao_id")
	var capitao_em_campo := false
	if capitao_id != null:
		for s in slots:
			if s["jogador_id"] == capitao_id:
				capitao_em_campo = true
				break
	var bonus_capitao: float = float(mb["bonus_capitao_em_campo"]) if capitao_em_campo else 0.0

	var entrosamento: float = clampf(float(p.get("clube", {}).get("entrosamento", 55)), 0.0, 100.0)
	var bonus_entrosamento: float = calcular_bonus_por_centro(entrosamento, 55.0, -2.0, 2.0)

	var bonus_preparacao: float = clampf(float(p.get("forca_extra_preparacao", 0)), float(mb["preparacao"]["min"]), float(mb["preparacao"]["max"]))

	var tatica_id = p.get("tatica_id")
	var situacao_tatica := "neutra"
	var bonus_tatica := 0.0
	var adversario: Dictionary = p.get("adversario", {})
	if tatica_id != null and adversario.has("estilo"):
		# pedra-papel-tesoura simplificado: cada tática "contra" um estilo de adversário específico.
		var contra_mapa := {"ofensivo": "pressao", "equilibrado": "ofensivo", "defensivo": "contra_ataque"}
		if contra_mapa.get(tatica_id) == adversario["estilo"]:
			situacao_tatica = "vantajosa"
			bonus_tatica = float(mb["tatica_favoravel"]["max"])
		elif contra_mapa.get(adversario["estilo"]) == tatica_id:
			situacao_tatica = "desfavoravel"
			bonus_tatica = float(mb["tatica_desfavoravel"]["min"])

	var mando_de_campo = p.get("mando_de_campo")
	var bonus_mando := 0.0
	if mando_de_campo != null:
		bonus_mando = float(mb["mando"]["casa"]) if mando_de_campo else float(mb["mando"]["fora"])

	var reacao_elenco: float = float(p.get("reacao_elenco", 0))

	var penalidades: Dictionary = p.get("penalidades", {})
	var penalidade_financeira := 0.0
	if penalidades.get("deficit", false):
		penalidade_financeira += float(mb["financeiro"]["por_problema"])
	if penalidades.get("salarios_atrasados", false):
		penalidade_financeira += float(mb["financeiro"]["por_problema"])
	penalidade_financeira = maxf(penalidade_financeira, float(mb["financeiro"]["max"]))

	var final_forca: float = media_overall_base + bonus_energia + bonus_moral + bonus_entrosamento \
		+ bonus_preparacao + bonus_tatica + bonus_mando + reacao_elenco + penalidade_financeira + bonus_capitao
	final_forca = clampf(final_forca, float(mb["clamp_forca_final"]["min"]), float(mb["clamp_forca_final"]["max"]))

	return {
		"base": round(media_overall_base),
		"bonus_energia": snappedf(bonus_energia, 0.1),
		"bonus_moral": snappedf(bonus_moral, 0.1),
		"bonus_entrosamento": snappedf(bonus_entrosamento, 0.1),
		"bonus_preparacao": bonus_preparacao,
		"bonus_tatica": snappedf(bonus_tatica, 0.1),
		"situacao_tatica": situacao_tatica,
		"bonus_mando": bonus_mando,
		"bonus_reacao": reacao_elenco,
		"bonus_capitao": bonus_capitao,
		"capitao_em_campo": capitao_em_campo,
		"penalidade_fora_de_posicao": snappedf(media_overall_base - media_overall_sem_penalidade, 0.1),
		"penalidade_financeira": penalidade_financeira,
		"final": round(final_forca),
		"fora_de_posicao_qtd": fora_qtd,
	}

## Modificador de forma recente (últimos 5 resultados: "V"/"E"/"D").
func calcular_modificador_forma_recente(ultimos_resultados: Array) -> Dictionary:
	var ultimos5: Array = ultimos_resultados.slice(max(0, ultimos_resultados.size() - 5))
	if ultimos5.is_empty():
		return {"modificador": 0, "label": "Fase neutra"}
	var pontos := 0
	for r in ultimos5:
		if r == "V":
			pontos += 3
		elif r == "E":
			pontos += 1
	if pontos <= 3: return {"modificador": -5, "label": "Péssima fase"}
	if pontos <= 6: return {"modificador": -2, "label": "Fase ruim"}
	if pontos <= 8: return {"modificador": 0, "label": "Fase neutra"}
	if pontos <= 11: return {"modificador": 2, "label": "Boa fase"}
	if pontos <= 13: return {"modificador": 4, "label": "Muito boa fase"}
	return {"modificador": 5, "label": "Excelente fase"}

## Fórmula única de probabilidade do Campeonato Universitário (também usada no InterLajes).
## Retorna {vitoria, empate, derrota} como frações que somam 1.0.
func calcular_probabilidades_universitario(p: Dictionary) -> Dictionary:
	var em_casa = p.get("em_casa")
	var campo_neutro: bool = p.get("campo_neutro", false)
	var base_v: float
	if campo_neutro:
		base_v = 37.0
	elif em_casa:
		base_v = 40.0
	else:
		base_v = 35.0

	var mod_overall: float = clampf(round(float(p["overall_catolica"]) - float(p["overall_adversario"])), -12.0, 12.0)

	var situacao_tatica: String = p.get("situacao_tatica", "neutra")
	var mod_tatica: float = 5.0 if situacao_tatica == "vantajosa" else (-5.0 if situacao_tatica == "desfavoravel" else 0.0)
	var fora_qtd: int = p.get("fora_de_posicao_qtd", 0)
	var mod_escalacao: float = 3.0 if fora_qtd == 0 else clampf(-2.0 * float(fora_qtd), -8.0, 0.0)
	var mod_preparo: float = clampf(float(p.get("qtd_preparos_usados", 0)) * 2.0, 0.0, 4.0)
	var forma := calcular_modificador_forma_recente(p.get("ultimos_resultados", []))
	var soma_vantagens: float = mod_tatica + mod_escalacao + mod_preparo + float(forma["modificador"])
	var mod_vantagens: float = 7.0 if soma_vantagens > 7.0 else soma_vantagens

	var mod_energia_moral: float = clampf(float(p.get("bonus_energia_pontos", 0)) + float(p.get("bonus_moral_pontos", 0)), -5.0, 4.0)
	var mod_estadio: float = 0.0
	if em_casa and not campo_neutro:
		mod_estadio = clampf(float(p.get("nivel_estadio_soma", 0)) * 0.3, 0.0, 3.0)

	var chance_vitoria: float = base_v + mod_overall + mod_vantagens + mod_energia_moral + mod_estadio
	chance_vitoria = clampf(round(chance_vitoria), 20.0, 75.0)

	var chance_empate: float = round(clampf(18.0 - (8.0 / 12.0) * absf(mod_overall), 10.0, 18.0))
	var chance_derrota: float = 100.0 - chance_vitoria - chance_empate

	return {
		"vitoria": chance_vitoria / 100.0,
		"empate": chance_empate / 100.0,
		"derrota": chance_derrota / 100.0,
	}

## Sorteia um resultado ("vitoria"/"empate"/"derrota") a partir das probabilidades.
func sortear_resultado(probs: Dictionary) -> String:
	var r := randf()
	if r < probs["vitoria"]:
		return "vitoria"
	if r < probs["vitoria"] + probs["empate"]:
		return "empate"
	return "derrota"

const PESOS_GOLS := [0, 0, 1, 1, 1, 2, 2, 3]

func _sortear_gols_base() -> int:
	return PESOS_GOLS[randi() % PESOS_GOLS.size()]

## Gera o placar (gols próprios x adversário) coerente com o resultado sorteado.
func gerar_placar_por_resultado(tipo_resultado: String) -> Dictionary:
	if tipo_resultado == "empate":
		var g := _sortear_gols_base()
		return {"proprio": g, "adversario": g}
	var proprio := _sortear_gols_base()
	var adversario := _sortear_gols_base()
	var margem := 1 + (randi() % 2)
	if tipo_resultado == "vitoria":
		if proprio <= adversario:
			proprio = adversario + margem
	else:
		if adversario <= proprio:
			adversario = proprio + margem
	return {"proprio": proprio, "adversario": adversario}
