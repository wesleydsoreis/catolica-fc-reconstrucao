"""Gera os 8 personagens do mundo aberto (pixel art 26x38): idle/walk/interact + retratos.
Saída: assets/gerado/npcs/<id>.png (folha), <id>_retrato.png e npcs.json."""
import json, os
from PIL import Image
W, H = 26, 38
OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'assets', 'gerado', 'npcs')
os.makedirs(OUT, exist_ok=True)
INK = (31, 21, 17, 255)
def C(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)
def dk(c, f=0.8): return (int(c[0]*f), int(c[1]*f), int(c[2]*f), 255)
RED, CREAM, WHITE, YEL = C('C94F50'), C('F7F2E4'), C('FFFDF6'), C('F2C14E')
MAROON = C('8F303A')

CH = {
 'diretor':   dict(nome='DIRETOR',   skin=C('E0AC85'), hair=C('A9A9B0'), style='short', top=C('1F2A44'), trim=WHITE, pants=C('1F2A44'), shoe=INK, acc=['tie','glasses']),
 'treinador': dict(nome='TREINADOR', skin=C('C98E66'), hair=C('2B1B10'), style='cap', top=RED, trim=WHITE, pants=C('2A2A36'), shoe=INK, acc=['cap','whistle','zip'], cap=RED),
 'jogador':   dict(nome='JOGADOR',   skin=C('8D5A3B'), hair=C('1A1210'), style='short', top=RED, trim=WHITE, pants=WHITE, shoe=INK, acc=['shorts','socks'], sock=RED),
 'torcedor':  dict(nome='TORCEDOR',  skin=C('E8B48C'), hair=C('5A3A1E'), style='cap', top=RED, trim=WHITE, pants=C('3B5F8A'), shoe=C('F7F2E4'), acc=['cap','scarf','paint'], cap=WHITE),
 'jornalista':dict(nome='JORNALISTA',skin=C('F0C09A'), hair=C('4A2A18'), style='long', top=C('C9A878'), trim=C('E6D3A8'), pants=C('3B5F8A'), shoe=C('5A3A1E'), acc=['mic']),
 'medico':    dict(nome='MÉDICO',    skin=C('D9A07A'), hair=C('1A1210'), style='short', top=WHITE, trim=C('9EC8D8'), pants=C('3E8FA0'), shoe=WHITE, acc=['coat','cross']),
 'arbitro':   dict(nome='ÁRBITRO',   skin=C('E0AC85'), hair=C('2B1B10'), style='short', top=C('F2D43A'), trim=INK, pants=C('1B1B1F'), shoe=INK, acc=['shorts','socks','whistle'], sock=C('1B1B1F')),
 'goleiro':   dict(nome='GOLEIRO',   skin=C('D9A07A'), hair=C('2B1B10'), style='short', top=C('F39C12'), trim=INK, pants=C('1B1B1F'), shoe=INK, acc=['shorts','socks'], sock=C('1B1B1F')),
 'olheiro':   dict(nome='OLHEIRO',   skin=C('C98E66'), hair=C('3A2A1E'), style='hat', top=C('5E7A3A'), trim=C('8CA45B'), pants=C('4A3A2A'), shoe=INK, acc=['hat','clip'], cap=C('7A5A33')),
}

class Cv:
    def __init__(s): s.im = Image.new('RGBA', (W, H), (0,0,0,0)); s.p = s.im.load()
    def r(s, x0, y0, x1, y1, c):
        for y in range(y0, y1+1):
            for x in range(x0, x1+1):
                if 0 <= x < W and 0 <= y < H: s.p[x, y] = c
    def px(s, x, y, c):
        if 0 <= x < W and 0 <= y < H: s.p[x, y] = c
    def outline(s):
        src = s.im.copy(); sp = src.load()
        for y in range(H):
            for x in range(W):
                if sp[x, y][3] == 0:
                    for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                        nx, ny = x+dx, y+dy
                        if 0 <= nx < W and 0 <= ny < H and sp[nx, ny][3] > 0 and sp[nx, ny] != INK:
                            s.p[x, y] = INK; break
        return s.im

def head_front(cv, d, dy, back=False):
    sk = d['skin']; hr = d['hair']
    cv.r(8, 4+dy, 17, 13+dy, sk)
    for (x, y) in ((8,4),(17,4),(8,13),(17,13)): cv.px(x, y+dy, (0,0,0,0))
    st = d['style']
    if st in ('short', 'cap', 'hat'):
        cv.r(7, 3+dy, 18, 6+dy, hr); cv.r(7, 6+dy, 8, 8+dy, hr); cv.r(17, 6+dy, 18, 8+dy, hr)
    if st == 'long':
        cv.r(7, 3+dy, 18, 6+dy, hr); cv.r(7, 6+dy, 9, 16+dy, hr); cv.r(16, 6+dy, 18, 16+dy, hr)
    if back:
        cv.r(8, 4+dy, 17, 13+dy, hr)
        if st == 'long': cv.r(7, 6+dy, 18, 16+dy, hr)
        return
    if st in ('short', 'long', 'cap', 'hat'):
        cv.r(9, 6+dy, 16, 6+dy, hr)
    cv.px(10, 9+dy, INK); cv.px(15, 9+dy, INK)
    cv.px(10, 8+dy, WHITE); cv.px(15, 8+dy, WHITE)
    cv.r(12, 12+dy, 13, 12+dy, dk(sk, 0.7))
    if 'paint' in d['acc']: cv.px(9, 11+dy, RED); cv.px(16, 11+dy, RED)
    if 'glasses' in d['acc']:
        cv.r(9, 9+dy, 11, 9+dy, INK); cv.r(14, 9+dy, 16, 9+dy, INK); cv.px(12, 9+dy, INK); cv.px(13, 9+dy, INK)
    if 'cap' in d['acc']:
        cv.r(7, 2+dy, 18, 5+dy, d['cap']); cv.r(8, 6+dy, 17, 6+dy, dk(d['cap'], 0.75))
    if 'hat' in d['acc']:
        cv.r(5, 5+dy, 20, 6+dy, d['cap']); cv.r(8, 1+dy, 17, 4+dy, d['cap']); cv.r(8, 4+dy, 17, 4+dy, dk(d['cap'], 0.7))

def torso_front(cv, d, dy):
    t, tr = d['top'], d['trim']
    ac = d['acc']
    cv.r(7, 14+dy, 18, 25+dy, t)
    if 'coat' in ac: cv.r(7, 14+dy, 18, 30, t); cv.r(12, 14+dy, 13, 30, tr)
    if 'zip' in ac: cv.r(12, 14+dy, 13, 25+dy, tr)
    if 'tie' in ac:
        cv.r(11, 14+dy, 14, 15+dy, WHITE); cv.r(12, 15+dy, 13, 22+dy, RED)
    if d is CH['jogador'] or d is CH['torcedor']:
        cv.r(7, 20+dy, 18, 20+dy, WHITE); cv.r(11, 14+dy, 14, 14+dy, WHITE)
    if d is CH['arbitro']: cv.r(7, 14+dy, 8, 25+dy, INK); cv.r(17, 14+dy, 18, 25+dy, INK)
    if d is CH['jornalista']: cv.r(7, 14+dy, 18, 14+dy, tr); cv.r(12, 15+dy, 13, 25+dy, dk(t, 0.8))
    if d is CH['olheiro']: cv.r(7, 18+dy, 9, 20+dy, tr); cv.r(16, 18+dy, 18, 20+dy, tr)
    if 'cross' in ac: cv.r(9, 17+dy, 11, 17+dy, RED); cv.r(10, 16+dy, 10, 18+dy, RED)
    if 'scarf' in ac: cv.r(8, 13+dy, 17, 15+dy, WHITE); cv.r(8, 14+dy, 17, 14+dy, RED); cv.r(15, 15+dy, 16, 19+dy, WHITE)
    if 'whistle' in ac: cv.px(14, 16+dy, WHITE); cv.px(13, 15+dy, WHITE)

def arms_front(cv, d, dy, up=None):
    sl = d['trim'] if d is CH['jogador'] else d['top']
    if d is CH['arbitro']: sl = d['top']
    sk = d['skin']
    long_ = ('coat' in d['acc']) or d in (CH['jornalista'], CH['olheiro'], CH['diretor'], CH['treinador'])
    for side in ('l', 'r'):
        x0, x1 = (5, 6) if side == 'l' else (19, 20)
        if up and (up == 'both' or up == side):
            cv.r(x0, 7+dy, x1, 15+dy, sl if long_ else sk)
            cv.r(x0, 5+dy, x1, 7+dy, sk)
        else:
            cv.r(x0, 15+dy, x1, 23+dy, sl if long_ else sk)
            if not long_: cv.r(x0, 15+dy, x1, 17+dy, sl)
            cv.r(x0, 22+dy, x1, 24+dy, sk)

def legs_front(cv, d, dl=0, dr=0):
    ac = d['acc']; pants = d['pants']
    for (x0, x1, dd) in ((8, 11, dl), (14, 17, dr)):
        end = 32 + dd
        cv.r(x0, 26, x1, end, pants)
        if 'shorts' in ac:
            cv.r(x0, 26, x1, 29, pants)
            sock = d.get('sock')
            if sock: cv.r(x0, 30, x1, end, sock); cv.r(x0, 30, x1, 30, WHITE)
            else: cv.r(x0, 30, x1, end, d['skin'])
        cv.r(x0-1, end+1, x1+1, end+2, d['shoe'])

def front(d, kind='idle', f=0, up=None, prop=None):
    cv = Cv(); dl = dr = 0; dy = 0
    if kind == 'idle': dy = 1 if f == 1 else 0
    if kind == 'walk':
        dl, dr = [(0, 0), (-1, 1), (0, 0), (1, -1)][f]; dy = -1 if f in (1, 3) else 0
    legs_front(cv, d, dl, dr)
    torso_front(cv, d, dy); arms_front(cv, d, dy, up); head_front(cv, d, dy)
    if prop: prop(cv, d, dy, f)
    return cv.outline()

def back(d, kind='idle', f=0):
    cv = Cv(); dl = dr = 0; dy = 0
    if kind == 'idle': dy = 1 if f == 1 else 0
    if kind == 'walk':
        dl, dr = [(0, 0), (-1, 1), (0, 0), (1, -1)][f]; dy = -1 if f in (1, 3) else 0
    legs_front(cv, d, dl, dr)
    t = d['top']
    cv.r(7, 14+dy, 18, 25+dy, t)
    if 'coat' in d['acc']: cv.r(7, 14+dy, 18, 30, t)
    if d is CH['jogador'] or d is CH['torcedor']: cv.r(9, 17+dy, 16, 19+dy, WHITE)
    if 'scarf' in d['acc']: cv.r(8, 13+dy, 17, 15+dy, WHITE)
    arms_front(cv, d, dy); head_front(cv, d, dy, back=True)
    if 'cap' in d['acc']: cv.r(7, 2+dy, 18, 6+dy, d['cap'])
    if 'hat' in d['acc']: cv.r(5, 5+dy, 20, 6+dy, d['cap']); cv.r(8, 1+dy, 17, 4+dy, d['cap'])
    return cv.outline()

def side(d, kind='idle', f=0):
    cv = Cv(); s = 0; dy = 0
    if kind == 'idle': dy = 1 if f == 1 else 0
    if kind == 'walk': s = [-2, 0, 2, 0][f]; dy = -1 if f in (1, 3) else 0
    ac = d['acc']; sk = d['skin']; hr = d['hair']
    for (x, dd, back_) in ((9 - s//2 * 0, s, True), (12, -s, False)):
        x0 = 10 + dd; x1 = x0 + 3
        col = dk(d['pants'], 0.85) if back_ else d['pants']
        cv.r(x0, 26, x1, 32, col)
        if 'shorts' in ac:
            sock = d.get('sock')
            cv.r(x0, 30, x1, 32, sock if sock else sk)
        cv.r(x0, 33, x1 + 2, 34, d['shoe'])
    t = d['top']
    cv.r(9, 14+dy, 16, 25+dy, t)
    if 'coat' in ac: cv.r(9, 14+dy, 16, 30, t)
    if d is CH['jogador'] or d is CH['torcedor']: cv.r(9, 20+dy, 16, 20+dy, WHITE)
    if 'scarf' in ac: cv.r(9, 13+dy, 16, 15+dy, WHITE)
    if d is CH['arbitro']: cv.r(9, 14+dy, 9, 25+dy, INK)
    long_ = ('coat' in ac) or d in (CH['jornalista'], CH['olheiro'], CH['diretor'], CH['treinador'])
    ax = 11 - s // 2
    cv.r(ax, 15+dy, ax + 2, 22+dy, d['top'] if long_ else sk); cv.r(ax, 21+dy, ax + 2, 24+dy, sk)
    if not long_: cv.r(ax, 15+dy, ax + 2, 17+dy, d['trim'] if d is CH['jogador'] else d['top'])
    cv.r(9, 4+dy, 17, 13+dy, sk)
    for (x, y) in ((9,4),(17,4),(9,13),(17,13)): cv.px(x, y+dy, (0,0,0,0))
    cv.r(18, 10+dy, 18, 11+dy, sk)
    cv.r(8, 3+dy, 17, 6+dy, hr); cv.r(8, 6+dy, 11, 9+dy, hr)
    if d['style'] == 'long': cv.r(8, 6+dy, 11, 16+dy, hr)
    cv.px(15, 9+dy, INK); cv.px(15, 8+dy, WHITE)
    if 'glasses' in ac: cv.r(14, 9+dy, 17, 9+dy, INK)
    if 'paint' in ac: cv.px(15, 11+dy, RED)
    if 'cap' in ac: cv.r(8, 2+dy, 17, 5+dy, d['cap']); cv.r(15, 6+dy, 20, 6+dy, dk(d['cap'], 0.75))
    if 'hat' in ac: cv.r(6, 5+dy, 21, 6+dy, d['cap']); cv.r(9, 1+dy, 16, 4+dy, d['cap'])
    return cv.outline()

# adereços de interação
def p_mic(cv, d, dy, f):
    cv.r(21, 8+dy, 21, 14+dy, C('9A9AA5')); cv.r(20, 5+dy, 22, 7+dy, INK)
def p_clip(cv, d, dy, f):
    cv.r(20, 14+dy, 24, 20+dy, C('C9A878')); cv.r(21, 13+dy, 23, 13+dy, C('9A9AA5')); cv.r(21, 16+dy, 23, 16+dy, INK)
def p_bin(cv, d, dy, f):
    cv.r(9, 8+dy, 11, 10+dy, INK); cv.r(14, 8+dy, 16, 10+dy, INK); cv.r(12, 9+dy, 13, 9+dy, INK)
def p_whistle(cv, d, dy, f):
    cv.r(11, 12+dy, 14, 12+dy, WHITE); cv.px(15, 12+dy, WHITE); cv.px(16, 11+dy, YEL)
def p_steth(cv, d, dy, f):
    cv.r(9, 14+dy, 9, 19+dy, INK); cv.r(16, 14+dy, 16, 19+dy, INK); cv.r(10, 20+dy, 15, 20+dy, INK)

PROPS = {'jornalista': (p_mic, 'r'), 'olheiro': (p_bin, 'r'), 'arbitro': (p_whistle, 'r'), 'medico': (p_steth, 'r'),
         'torcedor': (None, 'both'), 'goleiro': (None, 'r'), 'diretor': (None, 'r'), 'treinador': (p_clip, 'l'), 'jogador': (None, 'r')}

ANIMS = [('idle_down', 2, 2.0), ('idle_up', 2, 2.0), ('idle_side', 2, 2.0), ('walk_down', 4, 8.0), ('walk_up', 4, 8.0), ('walk_side', 4, 8.0), ('interact', 2, 4.0)]

def build(cid):
    d = CH[cid]; sheet = Image.new('RGBA', (W * 4, H * len(ANIMS)), (0, 0, 0, 0))
    prop, up = PROPS[cid]
    for row, (name, n, _) in enumerate(ANIMS):
        for f in range(n):
            if name == 'idle_down': im = front(d, 'idle', f)
            elif name == 'idle_up': im = back(d, 'idle', f)
            elif name == 'idle_side': im = side(d, 'idle', f)
            elif name == 'walk_down': im = front(d, 'walk', f)
            elif name == 'walk_up': im = back(d, 'walk', f)
            elif name == 'walk_side': im = side(d, 'walk', f)
            else:
                im = front(d, 'idle', f, up=up if f == 1 or up == 'both' else None, prop=prop)
            sheet.paste(im, (f * W, row * H))
    sheet.save(os.path.join(OUT, cid + '.png'))
    ret = front(d, 'idle', 0).crop((3, 0, 23, 22)).resize((80, 88), Image.NEAREST)
    ret.save(os.path.join(OUT, cid + '_retrato.png'))
    return sheet

if __name__ == '__main__':
    meta = {'largura': W, 'altura': H, 'anims': [{'nome': a, 'quadros': n, 'fps': fps, 'linha': i} for i, (a, n, fps) in enumerate(ANIMS)], 'personagens': {}}
    sheets = []
    for cid, d in CH.items():
        sheets.append(build(cid)); meta['personagens'][cid] = {'nome': d['nome']}
    json.dump(meta, open(os.path.join(OUT, 'npcs.json'), 'w'), ensure_ascii=False, indent=1)
    big = Image.new('RGBA', (W * 4 * 8, H * len(ANIMS)), (247, 242, 228, 255))
    for i, s in enumerate(sheets): big.alpha_composite(s, (i * W * 4, 0))
    big.resize((big.width * 3, big.height * 3), Image.NEAREST).save('/tmp/s2/shots/npcs_prev.png')
    print('ok')
