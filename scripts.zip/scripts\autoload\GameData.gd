extends Node
## GameData
## Autoload responsável por carregar e expor os dados ESTÁTICOS do jogo
## (clubes, elenco inicial, economia, fórmulas de balanceamento, regras especiais).
##
## Todos os valores aqui vêm diretamente da análise do arquivo "CatolicaFC.html"
## (fonte: jogo_sem_imports.jsx / ECONOMY_CONFIG / MATCH_BALANCE / CLUBES_* / ELENCO_INICIAL_BASE).
## Nada foi inventado ou arredondado; onde um valor do pedido do usuário
## divergiu do HTML (ex.: "24 rodadas"), o HTML foi mantido como fonte oficial
## e a divergência está anotada em regras_especiais.json.

var clubes_universitario: Array = []
var clubes_copa: Array = []
var elenco_inicial: Array = []
var economia: Dictionary = {}
var faixas_mercado: Dictionary = {}
var match_balance: Dictionary = {}
var regras_especiais: Dictionary = {}
var cores: Dictionary = {}
var formacoes: Array = []
var formacoes_fut7: Array = []   # formações de 7 (escalação das partidas)
var taticas: Array = []
var slots_iniciais_por_nome: Dictionary = {}
var mercado_catalogo: Array = []
var cartas_preparacao: Array = []

func _ready() -> void:
	clubes_universitario = _carregar_json("res://data/clubes_universitario.json")
	clubes_copa = _carregar_json("res://data/clubes_copa.json")
	elenco_inicial = _carregar_json("res://data/elenco_inicial.json")
	economia = _carregar_json("res://data/economia.json")
	faixas_mercado = _carregar_json("res://data/faixas_mercado.json")
	match_balance = _carregar_json("res://data/match_balance.json")
	regras_especiais = _carregar_json("res://data/regras_especiais.json")
	cores = _carregar_json("res://data/cores.json")
	formacoes = _carregar_json("res://data/formacoes.json")
	formacoes_fut7 = _carregar_json("res://data/formacoes_fut7.json")
	taticas = _carregar_json("res://data/taticas.json")
	slots_iniciais_por_nome = _carregar_json("res://data/slots_iniciais.json")
	mercado_catalogo = _carregar_json("res://data/mercado_catalogo.json")
	cartas_preparacao = _carregar_json("res://data/cartas_preparacao.json")

func _carregar_json(caminho: String):
	if not FileAccess.file_exists(caminho):
		push_error("GameData: arquivo de dados não encontrado: %s" % caminho)
		return null
	var arquivo := FileAccess.open(caminho, FileAccess.READ)
	var texto := arquivo.get_as_text()
	arquivo.close()
	var resultado = JSON.parse_string(texto)
	if resultado == null:
		push_error("GameData: falha ao interpretar JSON em %s" % caminho)
	return resultado

func obter_clube_universitario(id: String) -> Dictionary:
	for c in clubes_universitario:
		if c["id"] == id:
			return c
	return {}

func obter_clube_copa(id: String) -> Dictionary:
	for c in clubes_copa:
		if c["id"] == id:
			return c
	return {}

func cor(nome: String) -> Color:
	if cores.has(nome):
		return Color(cores[nome])
	return Color.WHITE

func obter_formacao(id: String) -> Dictionary:
	for f in formacoes:
		if f["id"] == id:
			return f
	return formacoes[0] if formacoes.size() > 0 else {}

func obter_tatica(id: String) -> Dictionary:
	for t in taticas:
		if t["id"] == id:
			return t
	return {}

## Gera a lista de posições (slots) em campo para uma formação, replicando
## fielmente gerarSlotsPorFormacao() do jogo original: 1 goleiro fixo + linhas
## de defesa/meio/ataque com jogadorId vazio e coordenadas x/y para desenho no campo.
func gerar_slots_por_formacao(formacao_id: String) -> Array:
	var f := obter_formacao(formacao_id)
	var slots: Array = [{"id": "GOL-1", "categoria": "GOL", "jogador_id": null, "x": 50.0, "y": 90.0}]
	_gerar_linha(slots, int(f.get("def", 4)), "DEF", 68.0)
	_gerar_linha(slots, int(f.get("mei", 3)), "MEI", 42.0)
	_gerar_linha(slots, int(f.get("ata", 3)), "ATA", 16.0)
	return slots

func _gerar_linha(slots: Array, qtd: int, categoria: String, y: float) -> void:
	for i in range(qtd):
		var x: float = 50.0 if qtd == 1 else 14.0 + (float(i) * (72.0 / float(qtd - 1)))
		slots.append({"id": "%s-%d" % [categoria, i + 1], "categoria": categoria, "jogador_id": null, "x": x, "y": y})

func obter_carta_preparacao(id: String) -> Dictionary:
	for c in cartas_preparacao:
		if c["id"] == id:
			return c
	return {}

## Porta fiel de gerarCalendario() do HTML: método do círculo (round-robin),
## turno único. Com 12 times gera 11 rodadas de 6 partidas cada.
func gerar_calendario(ids_clubes: Array) -> Array:
	var arr: Array = ids_clubes.duplicate()
	var n: int = arr.size()
	var rodadas: Array = []
	for r in range(n - 1):
		var partidas_rodada: Array = []
		for i in range(n / 2):
			var a = arr[i]
			var b = arr[n - 1 - i]
			var casa_eh_a: bool = (r % 2 == 0)
			partidas_rodada.append({
				"id": "r%d-p%d" % [r + 1, i + 1],
				"mandante_id": a if casa_eh_a else b,
				"visitante_id": b if casa_eh_a else a,
				"jogado": false,
				"placar_mandante": -1,
				"placar_visitante": -1,
			})
		rodadas.append(partidas_rodada)
		var fixo = arr[0]
		var resto: Array = arr.slice(1)
		resto.push_front(resto.pop_back())
		arr = [fixo]
		arr.append_array(resto)
	return rodadas
