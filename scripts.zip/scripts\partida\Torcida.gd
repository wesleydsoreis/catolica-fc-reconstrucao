extends Node2D
class_name Torcida
## Torcida animada (balança, pula e agita bandeiras no gol) + confete da comemoração.

var excitacao: float = 0.0     # 0..1, decai sozinho
var t: float = 0.0
var confete: Array = []        # {p, v, r, vr, cor, vida}
var cor_casa: Color = Color("C94F50")
var cor_fora: Color = Color("3B6E9E")

func gol(time_marcador: int, ponto: Vector2) -> void:
	excitacao = 1.0
	var c: Color = cor_casa if time_marcador == 0 else cor_fora
	var cores: Array = [c, Color("F5E6C8"), Color("FFD400"), Color("F39C12"), c.lightened(0.3)]
	for i in 110:
		confete.append({
			"p": ponto + Vector2(randf_range(-420.0, 420.0), randf_range(-520.0, -120.0)),
			"v": Vector2(randf_range(-60.0, 60.0), randf_range(120.0, 330.0)),
			"r": randf() * TAU, "vr": randf_range(-8.0, 8.0),
			"cor": cores[randi() % cores.size()], "vida": randf_range(1.6, 3.2)})

func _process(delta: float) -> void:
	t += delta
	excitacao = maxf(0.0, excitacao - delta * 0.28)
	for q in confete:
		q["p"] += q["v"] * delta
		q["v"].x += sin(t * 3.0 + q["r"]) * 40.0 * delta
		q["r"] += q["vr"] * delta
		q["vida"] -= delta
	confete = confete.filter(func(q): return q["vida"] > 0.0)
	queue_redraw()

func _draw() -> void:
	var pw: float = Cfg.PW
	var ph: float = Cfg.PH
	var m: float = Cfg.MARGEM
	var n: int = 160
	var cores: Array = [Color("F39C12"), Color("F5E6C8"), Color("C0392B"), Color("2E6FD6"), Color("FFD400")]
	for i in n:
		var x: float = -m + float(i) * (pw + 2.0 * m) / float(n) + 6.0
		var cor: Color = cores[i % 5]
		var fase: float = float(i) * 1.7
		var pulo: float = absf(sin(t * (3.0 + excitacao * 7.0) + fase)) * (2.0 + excitacao * 16.0)
		var linha: float = float(i % 3) * 22.0
		for lado in 2:
			var y: float = (-m - 70.0 - linha) if lado == 0 else (ph + m + 70.0 + linha)
			y -= pulo
			draw_circle(Vector2(x, y + 9.0), 7.0, cor.darkened(0.25))   # corpo
			draw_circle(Vector2(x, y), 8.0, cor)
			draw_circle(Vector2(x, y - 3.0), 4.5, Color("f1c9a0"))
			if excitacao > 0.25 and i % 4 == 0:   # braço levantado com bandeira
				var bx: float = x + sin(t * 9.0 + fase) * 6.0
				draw_line(Vector2(x + 6.0, y), Vector2(bx + 8.0, y - 24.0), Color("2b1b10"), 2.0)
				draw_rect(Rect2(bx + 8.0, y - 30.0, 12.0, 8.0), cor_casa if i % 8 == 0 else cor_fora)
	for q in confete:
		draw_set_transform(q["p"], q["r"], Vector2.ONE)
		draw_rect(Rect2(-4, -2, 8, 4), q["cor"])
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
