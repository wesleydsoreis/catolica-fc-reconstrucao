class_name Calculadora
extends VBoxContainer
## Calculadora da Prancheta do Treinador: + − × ÷, vírgula decimal, parênteses, √ e x².

var _expr: String = ""
var _visor: Label
var _hist: Label

const TECLAS := [["C", "⌫", "(", ")"], ["7", "8", "9", "÷"], ["4", "5", "6", "×"], ["1", "2", "3", "−"], ["0", ",", "=", "+"], ["√", "x²", "ANS", ""]]
var _ans: float = 0.0

func _ready() -> void:
	add_theme_constant_override("separation", 6)
	_hist = Tema.rotulo("", 12, Tema.TEXTO2)
	_hist.name = "CalcHist"
	_hist.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(_hist)
	var pv := PanelContainer.new()
	pv.add_theme_stylebox_override("panel", Tema.caixa(Color("2A0A10"), Tema.AMARELO, 2, 8, false, 8))
	_visor = Tema.rotulo("0", 24, Tema.AMARELO)
	_visor.name = "CalcVisor"
	_visor.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pv.add_child(_visor)
	add_child(pv)
	for linha in TECLAS:
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 6)
		for t in linha:
			if str(t) == "":
				var v := Control.new()
				v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				h.add_child(v)
				continue
			var b := Tema.botao(str(t), "ouro" if str(t) == "=" else "secundario", 40)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.name = "Tecla_" + str(t)
			b.pressed.connect(_tecla.bind(str(t)))
			h.add_child(b)
		add_child(h)

func _tecla(t: String) -> void:
	match t:
		"C":
			_expr = ""
			_hist.text = ""
		"⌫":
			_expr = _expr.substr(0, maxi(0, _expr.length() - 1))
		"=":
			_calcular()
		"√":
			_calcular()
			_ans = sqrt(maxf(0.0, _ans))
			_expr = _fmt(_ans)
		"x²":
			_calcular()
			_ans = _ans * _ans
			_expr = _fmt(_ans)
		"ANS":
			_expr += _fmt(_ans)
		_:
			_expr += t
	_visor.text = _expr if _expr != "" else "0"

func _fmt(v: float) -> String:
	return (("%d" % int(round(v))) if is_equal_approx(v, round(v)) else ("%.4f" % v).rstrip("0")).replace(".", ",")

## Avalia a expressão atual; devolve NAN se for inválida.
static func avaliar(txt: String) -> float:
	var e: String = txt.replace("×", "*").replace("÷", "/").replace("−", "-").replace(",", ".")
	if e.strip_edges() == "":
		return 0.0
	var re := RegEx.new()
	re.compile("\\d+\\.?\\d*")
	var partes: Array = re.search_all(e)
	for i in range(partes.size() - 1, -1, -1):          # números inteiros viram decimais: 6 ÷ 4 = 1,5 (não 1)
		var m: RegExMatch = partes[i]
		if not m.get_string().contains("."):
			e = e.substr(0, m.get_end()) + ".0" + e.substr(m.get_end())
		elif m.get_string().ends_with("."):
			e = e.substr(0, m.get_end()) + "0" + e.substr(m.get_end())
	var ex := Expression.new()
	if ex.parse(e) != OK:
		return NAN
	var r = ex.execute([], null, false)
	if ex.has_execute_failed() or not (r is float or r is int):
		return NAN
	return float(r)

func _calcular() -> void:
	if _expr == "":
		return
	var r: float = avaliar(_expr)
	if is_nan(r) or is_inf(r):
		_visor.text = "erro"
		_expr = ""
		return
	_hist.text = _expr + " ="
	_ans = r
	_expr = _fmt(r)
