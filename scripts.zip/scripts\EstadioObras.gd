extends Control
## EstadioObras: melhorias do estádio (4 categorias × 3 níveis) em cartões no estilo do jogo web.

var _col: VBoxContainer
var _aviso: String = ""

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 12)
	rol.add_child(_col)
	_montar()

func _montar() -> void:
	for f in _col.get_children():
		f.queue_free()
	var caixa: int = int(GameState.financas["caixa"])
	# resumo
	var res := Tema.cartao(Tema.AMARELO)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 2)
	res.add_child(rv)
	rv.add_child(Tema.rotulo("CAIXA DO CLUBE", 12, Color("5a3d00")))
	var vl := Label.new()
	vl.text = Tema.reais(caixa)
	vl.add_theme_font_size_override("font_size", 28)
	rv.add_child(vl)
	rv.add_child(Tema.rotulo("Capacidade %d · Manutenção %s/rodada" % [int(GameState.financas["capacidade_estadio"]), Tema.reais(GameState.manutencao_estadio_total())], 12, Color("5a3d00")))
	_col.add_child(res)
	if _aviso != "":
		_col.add_child(Tema.rotulo(_aviso, 14, Color("9a1f1f")))
	var tit := Tema.titulo_secao("Obras do estádio")
	_col.add_child(tit)
	for chave in GameState.ESTADIO_MELHORIAS.keys():
		var info: Dictionary = GameState.ESTADIO_MELHORIAS[chave]
		var nivel: int = int(GameState.financas["estadio"].get(chave, 0))
		var c := Tema.cartao(Tema.BRANCO)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		c.add_child(v)
		var h := HBoxContainer.new()
		var t := Tema.rotulo(str(info["nome"]), 17)
		t.add_theme_color_override("font_color", Tema.TITULO)
		h.add_child(t)
		h.add_child(Tema.chip("NÍVEL %d/3" % nivel, Tema.VERDE if nivel > 0 else Color("8A8270")))
		v.add_child(h)
		var pb := ProgressBar.new()
		pb.min_value = 0
		pb.max_value = 3
		pb.value = nivel
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(0, 12)
		pb.add_theme_stylebox_override("fill", Tema.caixa(Tema.VERDE, Tema.TINTA, 0, 6, false, 0))
		v.add_child(pb)
		v.add_child(Tema.rotulo("%s: +%d acumulado" % [info["efeito"], GameState.estadio_total(chave, "valor")], 13))
		var b: Button
		if nivel >= 3:
			b = Tema.botao("NÍVEL MÁXIMO", "secundario", 44)
			b.disabled = true
		else:
			var prox: Dictionary = info["niveis"][nivel]
			v.add_child(Tema.rotulo("Próximo: +%d · manutenção +%s/rodada" % [int(prox["valor"]), Tema.reais(int(prox["manut"]))], 12, Tema.TEXTO2))
			b = Tema.botao("CONFIRMAR OBRA · %s" % Tema.reais(int(prox["custo"])), "primario", 46)
			b.disabled = float(caixa) < float(prox["custo"])
			b.pressed.connect(func():
				var erro: String = GameState.comprar_melhoria_estadio(chave)
				_aviso = erro
				_montar())
		v.add_child(b)
		_col.add_child(c)
	var fim := Control.new()
	fim.custom_minimum_size = Vector2(0, 8)
	_col.add_child(fim)
