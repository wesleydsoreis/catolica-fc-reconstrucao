extends Node2D
class_name PartidaVis
## Apresentação da partida no estilo arcade: lê a lógica (Partida) e desenha Cenario, Player,
## BolaVis, HUD e Efeitos. A lógica continua em plano 2D; Pitch.project() converte para a tela.
var p: Partida
var cenario: Cenario
var efeitos: Efeitos
var hud: Hud2
var menu: MenuPartida
var som: SomPartida
var bola_vis: BolaVis
var arbitro: Arbitro
var grupo_vis: Node2D
var _players: Dictionary = {}
var _camada: CanvasLayer
const PELES := [Color("F6C9A2"), Color("E0A878"), Color("B47850"), Color("78502F"), Color("4E3222")]
const CABELOS := [Color("241812"), Color("6B4423"), Color("E0B040"), Color("14101C"), Color("B04020"), Color("8A8A8A")]
var _prev: Dictionary = {}    # estado anterior por jogador, para detectar eventos (visual apenas)
var _dono_ant: Jogador = null
var _chutes_ant: Array = [0, 0]
var _lamento: Dictionary = {}   # jogador -> instante (ms) em que o lamento termina

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	grupo_vis = Node2D.new()
	grupo_vis.y_sort_enabled = true
	cenario.mundo.add_child(grupo_vis)
	bola_vis = BolaVis.new()
	bola_vis.z_index = 1
	grupo_vis.add_child(bola_vis)
	_camada = CanvasLayer.new()
	_camada.layer = 5
	add_child(_camada)
	efeitos = Efeitos.new()
	efeitos.alvo_tremor = cenario
	_camada.add_child(efeitos)
	arbitro = Arbitro.new()
	grupo_vis.add_child(arbitro)
	arbitro.iniciar(p, grupo_vis, efeitos, cenario.mundo)
	hud = Hud2.new()
	_camada.add_child(hud)
	hud.partida = p
	som = SomPartida.new()
	som.p = p
	add_child(som)
	menu = MenuPartida.new()
	menu.p = p
	_camada.add_child(menu)
	p.menu = menu
	hud.casa = {"sigla": p.sigla_casa, "cor1": _cor_casa()[0], "cor2": _cor_casa()[1]}
	var cf: Array = _cor_fora()
	hud.fora = {"sigla": p.sigla_fora, "cor1": cf[0], "cor2": cf[1]}
	bola_vis.quicou.connect(func(pos: Vector2, forca: float): efeitos.poeira(pos + cenario.mundo.position, clampf(forca / 220.0, 0.5, 2.0)))

func _cor_casa() -> Array:
	return [Color("C94F50"), Color("8F3035")]

func _cor_fora() -> Array:
	var c1: Color = p.cor_fora_1 if p.cor_fora_1.a > 0.0 else Cfg.COR_FORA
	var c2: Color = p.cor_fora_2 if p.cor_fora_2.a > 0.0 else Color("FFFDF8")
	# se parecer com a casa, inverte as cores do visitante
	var cc: Color = _cor_casa()[0]
	if absf(c1.r - cc.r) + absf(c1.g - cc.g) + absf(c1.b - cc.b) < 0.55:
		return [c2, c1]
	return [c1, c2]

func _kit(j: Jogador) -> Dictionary:
	var c: Array = _cor_casa() if j.time == 0 else _cor_fora()
	if j.papel == "GOL":
		var k: Dictionary = Player.kit_do_clube(c[0], c[1], true)
		if j.time == 1:
			k["camisa"] = Color("2DA44E"); k["manga"] = Color("1F7A38"); k["calcao"] = Color("143D24"); k["meia"] = Color("143D24")
		return k
	return Player.kit_do_clube(c[0], c[1])

func _aparencia(pl: Player, j: Jogador) -> void:
	var h: int = j.numero * 7 + j.time * 13
	pl.configurar(_kit(j), PELES[h % PELES.size()], CABELOS[(h / 3) % CABELOS.size()], (j.numero * 5 + j.time * 3 + j.numero / 4) % Player.NE, j.numero)

func _player(j: Jogador) -> Player:
	if _players.has(j):
		return _players[j]
	var pl := Player.new()
	grupo_vis.add_child(pl)
	var h: int = j.numero * 7 + j.time * 13
	pl.configurar(_kit(j), PELES[h % PELES.size()], CABELOS[(h / 3) % CABELOS.size()], (j.numero * 5 + j.time * 3 + j.numero / 4) % Player.NE, j.numero)
	_players[j] = pl
	return pl

## Texto flutuante sobre um ponto do mundo (feedback de desarme, apito...).
func flutuar(pos_mundo: Vector2, txt: String, cor: Color) -> void:
	if efeitos != null and cenario != null:
		efeitos.texto(Pitch.project(pos_mundo.x, pos_mundo.y) + cenario.mundo.position + Vector2(0, -50), txt, cor)

func banner(titulo: String, sub: String, dur: float) -> void:
	if arbitro != null:
		arbitro.evento(titulo)
	hud.banner(titulo, sub, dur, titulo.begins_with("CARTÃO V") or titulo.begins_with("CARTAO V"))

func gol(time_marcador: int) -> void:
	efeitos.confete()
	efeitos.flash(0.14)
	efeitos.tremer(2.0, 0.5)
	cenario.estadio.comemorar(4.5)
	cenario.campo.balancar_rede(1 - time_marcador)
	# reação de quem sofreu o gol: o goleiro e os adversários próximos à área lamentam
	var fim: int = Time.get_ticks_msec() + 2600
	for q in p.jogadores:
		var j: Jogador = q
		if j.time == time_marcador:
			continue
		var gol_x: float = 0.0 if time_marcador == 1 else Cfg.PW
		if j.papel == "GOL" or absf(j.position.x - gol_x) < 650.0:
			_lamento[j] = fim

func _estado(j: Jogador) -> String:
	if j.comemorando > 0.0:
		return "festa"
	if _lamento.has(j) and Time.get_ticks_msec() < int(_lamento[j]):
		return "lamento"
	if j.investida > 0.0 and j.invest_tipo != "pe":
		return "carrinho"
	if j.papel == "GOL" and j.mergulhando:
		return "gk_alto" if p.bola.z > 35.0 else "gk_baixo"
	if j.atordoado > 0.25 and j.vel.length() < 20.0:
		return "queda"
	if j.carga > 0.05:
		return "carga"
	return ""

## Deduz eventos pontuais a partir das mudanças de estado da lógica (sem alterar a lógica).
func _eventos() -> void:
	var b: Bola = p.bola
	if _dono_ant != b.dono:
		if _dono_ant != null and b.dono == null and _players.has(_dono_ant):
			var tm: int = _dono_ant.time
			var forte: bool = int(p.estat["chutes"][tm]) > int(_chutes_ant[tm])   # contagem de chutes da lógica
			(_players[_dono_ant] as Player).evento("chute" if forte else "passe")
		elif b.dono != null and _players.has(b.dono) and b.dono != _dono_ant:
			var pr: Player = _players[b.dono]
			if (_dono_ant == null or _dono_ant.time != b.dono.time or _dono_ant != b.dono) and b.dono.papel != "GOL":
				pr.evento("recepcao")
		_dono_ant = b.dono
	_chutes_ant = [int(p.estat["chutes"][0]), int(p.estat["chutes"][1])]
	for q in p.jogadores:
		var j: Jogador = q
		if not _players.has(j):
			continue
		var pl: Player = _players[j]
		var ant: Array = _prev.get(j, [0.0, 0.0, 0.0])
		if j.cd_desarme > ant[0] + 0.2 and (j.investida <= 0.0 or j.invest_tipo == "pe"):
			pl.evento("desarme")
		if j.papel == "GOL":
			if j.cd_defesa > ant[1] + 0.2 and not j.mergulhando:
				pl.evento("gk_defesa")
			if j.segurando > 0.0 and ant[2] <= 0.0:
				pl.evento("gk_reposicao")
		elif b.dono == null and b.vel.length() > 500.0 and b.ultimo_time != j.time and j.investida <= 0.0 \
				and b.z < 60.0 and j.position.distance_to(b.position) < 45.0 and ant[0] <= 0.0:
			pl.evento("bloqueio")
		_prev[j] = [j.cd_desarme, j.cd_defesa, j.segurando]

var _cam: float = -1e9
func _camera(delta: float) -> void:
	var b: Bola = p.bola
	var alvo_x: float = b.position.x + clampf(b.vel.x * 0.35, -380.0, 380.0)
	var alvo: float = Pitch.camera_x(alvo_x)
	if _cam < -1e8:
		_cam = alvo
	_cam = lerpf(_cam, alvo, clampf(delta * 3.2, 0.0, 1.0))
	cenario.mundo.position.x = -roundf(_cam)

func _process(_delta: float) -> void:
	if p == null:
		return
	_eventos()
	_camera(_delta)
	if arbitro != null:
		arbitro.atualizar(_delta)
	for q in p.jogadores:
		var j: Jogador = q
		var pl: Player = _player(j)
		pl.visible = not j.expulso
		if pl.numero != j.numero:
			_aparencia(pl, j)      # entrou um reserva: novo número e novo visual
		pl.position = Pitch.project(j.position.x, j.position.y).round()
		pl.com_bola = p.bola.dono == j
		pl.esp_forcado = -1
		if j.investida > 0.0 and j.invest_tipo != "pe":
			pl.esp_forcado = 1 if j.investida_dir.x < 0.0 else 0
		elif j.papel == "GOL" and j.mergulhando:
			pl.esp_forcado = 1 if p.bola.position.x < j.position.x else 0
		pl.visual(j.vel * (1.0 if j.comemorando <= 0.0 else 0.0), j.face, _estado(j))
		pl.ctrl = j.controlado and not p.piloto_auto
		pl.carga = j.carga
	for j2 in _players.keys():
		if (j2 as Jogador).expulso:
			(_players[j2] as Player).visible = false
	var b: Bola = p.bola
	bola_vis.colocar(b.position.x, b.position.y, b.z, b.vz)
	hud.gols = p.gols
	if p.estado == Partida.Estado.BOLA_PARADA and not p.bp.is_empty():
		var bpd: Dictionary = p.bp
		var cy: float = Cfg.PH * 0.5
		var tipo: String = str(bpd["tipo"])
		var alvo: Vector2 = Vector2(Cfg.PW, cy + float(bpd["ax"]) * Cfg.GOL_METADE * (2.4 if tipo == "escanteio" else 0.9))
		if tipo == "escanteio":
			alvo.x = Cfg.PW - lerpf(110.0, 440.0, float(bpd["ad"])) * Cfg.PW / 2200.0
		hud.bp = {"tipo": tipo, "carga": float(bpd["carga"]), "tela": Pitch.project(alvo.x, alvo.y) - Vector2(roundf(_cam), 0.0)}
	else:
		hud.bp = {}
	hud.tempo_s = float(p.tempo_real) / Partida.DURACAO_REAL * 5400.0
	if p.estado == Partida.Estado.INTERVALO:
		hud.tempo_s = 2700.0
	hud.periodo = "2T" if p.segundo_tempo else "1T"
	var c: Jogador = p.controlado
	hud.nome_ctrl = ("%d %s" % [c.numero, c.nome]) if c != null else ""
	hud.stats = "FALTAS %d-%d" % [p.faltas[0], p.faltas[1]]
	hud.amarelos = p.amarelos
	hud.vermelhos = p.vermelhos
	hud.em_campo = [(p.times[0] as Array).size(), (p.times[1] as Array).size()]
	hud.trocas = p.subs_restantes
	hud.posse = p.bola.dono.time if p.bola.dono != null else (p.bola.ultimo_time if p.bola.ultimo_jogador != null else -1)
	hud.folego = p.estamina
	var ws: Vector2i = DisplayServer.window_get_size()
	hud.retrato = ws.y > ws.x
	hud.pausado = p.pausado
	hud.ajuda = p.ajuda_aberta
	hud.estado_jogando = p.estado == Partida.Estado.JOGANDO
	hud.defendendo = c != null and c.papel != "GOL" and p.bola.dono != null and p.bola.dono.time != c.time
	hud.decorrido = float(p.tempo_real)
	if p.toque != null:
		p.toque.com_bola = c != null and p.bola.dono == c
