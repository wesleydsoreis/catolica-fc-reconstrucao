extends Control
class_name TouchControles
## Joystick virtual (lado esquerdo) e botões (lado direito) para celular.
## Tudo vira ações do Input (esq/dir/cima/baixo/passe/chute/correr), então o jogo trata toque, teclado e controle igual.

var mostrar: bool = false
var toques: Dictionary = {}          # índice do dedo -> "joy" | "passe" | "chute" | "correr"
var joy_centro: Vector2 = Vector2.ZERO
var joy_pos: Vector2 = Vector2.ZERO
var joy_ativo: bool = false

const RAIO_JOY: float = 42.0
var com_bola: bool = true

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	mostrar = OS.has_feature("mobile") \
		or OS.has_feature("web_android") or OS.has_feature("web_ios")

func _x(x: float, larg: float) -> float:
	Opcoes.carregar()
	return larg - x if Opcoes.canhoto else x

func _process(_d: float) -> void:
	if mostrar:
		queue_redraw()

func _botoes() -> Dictionary:
	# botões agrupados perto do polegar (canto inferior), espelhados no modo canhoto
	var s: Vector2 = get_viewport_rect().size
	var cx: float = s.x - 58.0
	var cy: float = s.y - 62.0
	var grande: String = "passe" if Opcoes.invertido else "chute"
	var medio: String = "chute" if Opcoes.invertido else "passe"
	var d: Dictionary = {}
	d[grande] = [Vector2(_x(cx + 18.0, s.x), cy + 10.0), 27.0]
	d[medio] = [Vector2(_x(cx - 30.0, s.x), cy + 22.0), 22.0]
	d["lob"] = [Vector2(_x(cx + 26.0, s.x), cy - 34.0), 19.0]
	d["correr"] = [Vector2(_x(cx - 24.0, s.x), cy - 22.0), 19.0]
	d["troca"] = [Vector2(_x(cx - 78.0, s.x), cy + 2.0), 15.0]
	d["pausa"] = [Vector2(_x(s.x - 22.0, s.x), 28.0), 13.0]
	return d

func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k: InputEventKey = event as InputEventKey
		if k.pressed and not k.echo and k.physical_keycode == KEY_T:
			mostrar = not mostrar
			queue_redraw()
		return
	if not mostrar:
		return
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event as InputEventScreenTouch
		if t.pressed:
			_inicio(t.index, t.position)
		else:
			_fim(t.index)
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event as InputEventScreenDrag
		if toques.get(d.index, "") == "joy":
			_mover_joy(d.position)

func _inicio(indice: int, pos: Vector2) -> void:
	var botoes: Dictionary = _botoes()
	for nome in botoes.keys():
		var info: Array = botoes[nome]
		var c: Vector2 = info[0]
		var r: float = info[1]
		if pos.distance_to(c) <= r * 1.25:
			toques[indice] = nome
			Input.action_press(str(nome))
			queue_redraw()
			return
	var lado_joy: bool = pos.x > get_viewport_rect().size.x * 0.5 if Opcoes.canhoto else pos.x < get_viewport_rect().size.x * 0.5
	if lado_joy and not joy_ativo:
		toques[indice] = "joy"
		joy_ativo = true
		joy_centro = pos
		joy_pos = pos
		queue_redraw()

func _fim(indice: int) -> void:
	if not toques.has(indice):
		return
	var nome: String = str(toques[indice])
	toques.erase(indice)
	if nome == "joy":
		joy_ativo = false
		for a in ["esq", "dir", "cima", "baixo"]:
			Input.action_release(a)
	else:
		Input.action_release(nome)
	queue_redraw()

func _mover_joy(pos: Vector2) -> void:
	var v: Vector2 = pos - joy_centro
	if v.length() > RAIO_JOY:
		v = v.normalized() * RAIO_JOY
	joy_pos = joy_centro + v
	var n: Vector2 = v / RAIO_JOY
	_acao("dir", maxf(n.x, 0.0))
	_acao("esq", maxf(-n.x, 0.0))
	_acao("baixo", maxf(n.y, 0.0))
	_acao("cima", maxf(-n.y, 0.0))
	queue_redraw()

func _acao(nome: String, forca: float) -> void:
	if forca > 0.01:
		Input.action_press(nome, forca)
	else:
		Input.action_release(nome)

func _draw() -> void:
	if not mostrar:
		return
	var f: Font = ThemeDB.fallback_font
	if joy_ativo:
		draw_circle(joy_centro, RAIO_JOY, Color(1, 1, 1, 0.14))
		draw_arc(joy_centro, RAIO_JOY, 0.0, TAU, 40, Color(1, 1, 1, 0.5), 2.0)
		draw_circle(joy_pos, 18.0, Color(1, 1, 1, 0.45))
	else:
		var s: Vector2 = get_viewport_rect().size
		var jx: float = _x(64.0, s.x)
		draw_arc(Vector2(jx, s.y - 62), RAIO_JOY, 0.0, TAU, 40, Color(1, 1, 1, 0.25), 2.0)

	var botoes: Dictionary = _botoes()
	var cores: Dictionary = {"chute": Color("C0392B"), "passe": Color("2E6FD6"), "correr": Color("F39C12"), "troca": Color("2e8b57"), "lob": Color("2DA44E"), "pausa": Color("5b3a8c")}
	var rotulos: Dictionary = {"chute": "CHUTE" if com_bola else "CARRINHO", "passe": "PASSE" if com_bola else "TROCA", "lob": "ALTO", "correr": "CORRER", "troca": "TROCA", "pausa": "II"}
	for nome in botoes.keys():
		var info: Array = botoes[nome]
		var c: Vector2 = info[0]
		var r: float = info[1]
		var ativo: bool = toques.values().has(nome)
		var cor: Color = cores[nome]
		draw_circle(c, r, Color(cor.r, cor.g, cor.b, 0.7 if ativo else 0.28))
		draw_arc(c, r, 0.0, TAU, 36, Color(1, 1, 1, 0.55), 1.0)
		draw_string(f, c + Vector2(-r, 3.0), str(rotulos[nome]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 8, Color.WHITE)
