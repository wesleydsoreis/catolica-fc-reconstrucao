extends Node2D
class_name Bola
## Bola com física simples (arrasto, altura e quique). Quando tem "dono", gruda no pé dele.

var vel: Vector2 = Vector2.ZERO
var z: float = 0.0
var vz: float = 0.0
var dono: Jogador = null
var ultimo_time: int = 0
var ultimo_jogador: Jogador = null
var rot: float = 0.0

func chutar(direcao: Vector2, velocidade: float, impulso_z: float, quem: Jogador) -> void:
	dono = null
	vel = direcao.normalized() * velocidade
	vz = impulso_z
	if quem != null:
		ultimo_time = quem.time
		ultimo_jogador = quem

func _process(_delta: float) -> void:
	queue_redraw()

func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 11.0 + z * 0.03, Color(0, 0, 0, clampf(0.35 - z * 0.002, 0.12, 0.35)))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var c: Vector2 = Vector2(0.0, -12.0 - z)
	draw_circle(c, 12.0, Color.WHITE)
	draw_arc(c, 12.0, 0.0, TAU, 20, Color.BLACK, 2.0)
	for i in 5:
		var a: float = rot + float(i) * TAU / 5.0
		draw_circle(c + Vector2(cos(a), sin(a)) * 7.0, 2.4, Color.BLACK)
	draw_circle(c, 3.2, Color.BLACK)
