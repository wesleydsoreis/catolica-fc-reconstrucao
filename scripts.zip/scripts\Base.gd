extends Control
## Fase 7: categoria de base (promover jovens), empréstimos e metas pessoais.

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	mg.add_child(col)
	_montar(col)

func _voltar(col: Control) -> void:
	var b := Tema.botao("VOLTAR", "primario", 48)
	b.name = "BotaoSair"
	b.pressed.connect(func(): SceneManager.voltar())
	col.add_child(b)

func _recarregar() -> void:
	for c in get_children():
		c.queue_free()
	_ready()

func _montar(col: VBoxContainer) -> void:
	col.add_child(Tema.titulo_secao("Categoria de base"))
	col.add_child(Tema.rotulo("Elenco: %d/%d. Promova jovens promissores e empreste reservas para ganharem experiência." % [GameState.elenco.size(), Extras.LIMITE_ELENCO], 13))
	var msg := Tema.rotulo("", 13, Tema.AMARELO)
	msg.name = "Mensagem"
	col.add_child(msg)
	for i in GameState.base_jovens.size():
		var b: Dictionary = GameState.base_jovens[i]
		var c := Tema.cartao(Tema.BRANCO)
		c.name = "Jovem_%d" % i
		var v := VBoxContainer.new()
		c.add_child(v)
		v.add_child(Tema.rotulo("%s · %s · %d anos" % [b["nome"], str(b["posicao"]).replace("_", " "), b["idade"]], 14, Tema.TITULO))
		v.add_child(Tema.rotulo("Overall %d · Potencial %d · Salário %s/rodada" % [b["overall"], b["potencial"], Tema.reais(int(b["overall"]) * 12)], 13))
		var bt := Tema.botao("PROMOVIDO" if bool(b["promovido"]) else "PROMOVER AO ELENCO", "primario", 44)
		bt.name = "BotaoPromover_%d" % i
		bt.disabled = bool(b["promovido"])
		bt.pressed.connect(func():
			var e: String = GameState.promover_jovem(i)
			if e != "":
				msg.text = e
			else:
				_recarregar())
		v.add_child(bt)
		col.add_child(c)
	col.add_child(Tema.titulo_secao("Empréstimos"))
	var algum := false
	for j in GameState.elenco:
		var emp: int = int(j.get("emprestado", 0))
		if emp <= 0 and not GameState.pode_emprestar(j):
			continue
		algum = true
		var c := Tema.cartao(Tema.BRANCO)
		var v := VBoxContainer.new()
		c.add_child(v)
		v.add_child(Tema.rotulo("%s · overall %d / pot. %d" % [j["nome"], j["overall"], j.get("potencial", j["overall"])], 13, Tema.TITULO))
		if emp > 0:
			v.add_child(Tema.rotulo("Emprestado: volta em %d rodadas (sem salário)." % emp, 13))
		else:
			var bt := Tema.botao("EMPRESTAR POR %d RODADAS" % Extras.RODADAS_EMPRESTIMO, "secundario", 40)
			bt.name = "BotaoEmprestar_" + str(j["id"])
			var jid: String = str(j["id"])
			bt.pressed.connect(func():
				var e: String = GameState.emprestar_jogador(jid)
				if e != "":
					msg.text = e
				else:
					_recarregar())
			v.add_child(bt)
		col.add_child(c)
	if not algum:
		col.add_child(Tema.rotulo("Nenhum reserva disponível para empréstimo.", 13, Tema.TEXTO2))
	col.add_child(Tema.titulo_secao("Metas pessoais"))
	for m in GameState.metas_pessoais:
		var g: int = GameState.gols_meta(m)
		col.add_child(Tema.barra("%s: %d/%d gols%s" % [m["nome"], g, m["alvo"], " (cumprida)" if bool(m["cumprida"]) else ""], minf(100.0, float(g) / float(m["alvo"]) * 100.0), Tema.AMARELO))
	col.add_child(Tema.rotulo("Meta batida: +15 de moral ao jogador e R$ 5.000 de prêmio.", 12, Tema.TEXTO2))
	_voltar(col)
