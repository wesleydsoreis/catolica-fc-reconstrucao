class_name TelaVideo
extends Control
## Casca das telas internas com vídeo animado de fundo (Treino, Secretaria, Mercado, Obras, Classificação).
## O vídeo toca em loop (VideoFundo); sobre ele ficam painéis REAIS do Godot em coordenadas de projeto 1280x720:
## cabeçalho, balão do mascote com mensagem calculada dos dados da carreira, a tela funcional existente (reaproveitada,
## sem mudar suas regras) e a barra inferior com "VOLTAR AO MAPA" + situação do clube. Só cobre o que está gravado no vídeo
## (títulos, balões e dados fictícios); o gatinho e o cenário do vídeo continuam visíveis.

const DESIGN := Vector2(1280, 720)
const TINTA := Color("3A0A10")
const PAPEL := Color("F7EFDF")
const ESCUDO := "res://assets/ui/ref/escudo.png"
const GATO := "res://assets/ui/mascote/gatinho_neutro.png"
const V_MAPA := "res://assets/video/mapa_animado.ogv"

const CFG := {
	"treino": {"video": "res://assets/video/treinamento.ogv", "cena": "res://scenes/Treino.tscn", "titulo": "Campo de Treinamento",
		"sub": "Evoluir é o nosso plano!", "painel": Rect2(888, 296, 386, 352), "msg_card": Rect2(890, 114, 272, 176)},
	"painel": {"video": "res://assets/video/secretaria.ogv", "cena": "res://scenes/Painel.tscn", "titulo": "Secretaria e Diretoria",
		"sub": "Cada decisão molda o futuro do clube", "painel": Rect2(840, 206, 436, 442), "balao": Rect2(878, 103, 258, 95)},
	"mercado": {"video": "res://assets/video/mercado.ogv", "cena": "res://scenes/Mercado.tscn", "titulo": "Mercado",
		"sub": "Reforce o elenco com sabedoria", "painel": Rect2(10, 296, 845, 346), "balao": Rect2(878, 105, 258, 95),
		"lateral": Rect2(862, 232, 412, 372), "placa": Rect2(930, 628, 350, 22)},
	"estadio_obras": {"video": "res://assets/video/obras.ogv", "cena": "res://scenes/EstadioObras.tscn", "titulo": "Obras do Estádio",
		"sub": "Investir hoje, colher amanhã", "painel": Rect2(780, 220, 488, 296), "balao": Rect2(852, 108, 270, 98),
		"inf_e": Rect2(15, 522, 697, 116), "inf_d": Rect2(738, 522, 530, 116)},
	"torneios": {"video": V_MAPA, "cena": "res://scenes/Torneios.tscn", "titulo": "Campeonatos",
		"sub": "Classificação, jogos e artilharia", "painel": Rect2(280, 112, 720, 522), "balao": Rect2(1016, 150, 254, 100), "gato": Rect2(1030, -4, 132, 148)},
}

@export var tela: String = "treino"

var _fundo: VideoFundo
var _palco: Control
var _conteudo: Control
var _hospedada: Node
var _gato: TextureRect
var _gato_y: float = 0.0
var _t: float = 0.0
var _caixa_lb: Label
var _torc_lb: Label
var _dir_lb: Label
var _pos_lb: Label

func _ready() -> void:
	var cfg: Dictionary = CFG[tela]
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var base := ColorRect.new()
	base.color = Color("1A0508")
	base.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(base)
	_fundo = VideoFundo.criar(str(cfg["video"]), null, false)
	_fundo.name = "Fundo"
	add_child(_fundo)
	_palco = Control.new()
	_palco.name = "Palco"
	_palco.size = DESIGN
	_palco.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_palco)
	_conteudo = Control.new()
	_conteudo.size = DESIGN
	_conteudo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_palco.add_child(_conteudo)
	_montar(cfg)
	resized.connect(_ajustar)
	GameState.estado_mudou.connect(_atualizar_hud)
	_ajustar()
	_atualizar_hud()

func _exit_tree() -> void:
	if GameState.estado_mudou.is_connected(_atualizar_hud):
		GameState.estado_mudou.disconnect(_atualizar_hud)

func _ajustar() -> void:
	if _palco == null:
		return
	var k: float = minf(size.x / DESIGN.x, size.y / DESIGN.y)
	if k <= 0.0:
		return
	_palco.scale = Vector2(k, k)
	_palco.position = (size - DESIGN * k) * 0.5

func _process(dt: float) -> void:
	_t += dt
	if is_instance_valid(_gato):
		_gato.position.y = _gato_y + 3.0 * sin(_t * 2.2)

# ------------------------------------------------------------------ montagem
func _montar(cfg: Dictionary) -> void:
	# ordem: avisos/balões/placas primeiro (por baixo), tela funcional depois, cabeçalho e rodapé por cima
	if cfg.has("placa"):
		_placa(cfg["placa"])
	if cfg.has("balao"):
		_balao(cfg["balao"], _mensagem(), tela != "torneios")
	if cfg.has("msg_card"):
		_placa(Rect2(1160, 110, 120, 62))            # cobre o cabeçalho de cartão gravado no vídeo (acima do gatinho)
		_placa(Rect2(888, 286, 392, 12))
		var c: VBoxContainer = _cartao(cfg["msg_card"], "Recado do mascote")
		c.add_child(_texto(_mensagem(), 17, Color("8E1222")))
	if cfg.has("lateral"):
		_lateral_mercado(cfg["lateral"])
	if cfg.has("inf_e"):
		_inferiores_obras(cfg["inf_e"], cfg["inf_d"])
	_hospedar(cfg["cena"], cfg["painel"])
	_cabecalho(str(cfg["titulo"]), str(cfg["sub"]))
	if cfg.has("gato"):
		_gatinho(cfg["gato"])                        # mascote por cima do cabeçalho (só onde o vídeo não traz o gatinho)
	_rodape()

func _hospedar(caminho: String, r: Rect2) -> void:
	var p := PanelContainer.new()
	p.name = "PainelTela"
	p.position = r.position
	p.size = r.size
	p.custom_minimum_size = r.size
	p.clip_contents = true
	p.add_theme_stylebox_override("panel", Paleta.estilo(Color("2E080D"), Paleta.DOURADO, 3, 12, 4))
	_conteudo.add_child(p)
	_hospedada = (load(caminho) as PackedScene).instantiate()
	p.add_child(_hospedada)

func _lateral_mercado(r: Rect2) -> void:
	var c: VBoxContainer = _cartao(r, "Situação do clube")
	c.add_child(_dado("Caixa", "R$ " + _milhar(int(GameState.financas.get("caixa", 0)))))
	c.add_child(_dado("Jogadores no elenco", str(GameState.elenco.size())))
	c.add_child(_dado("Disponíveis no mercado", str(GameState.mercado_jogadores.size())))
	var mais_barato: int = -1
	for j in GameState.mercado_jogadores:
		var pr: int = int(j.get("preco", 0))
		if mais_barato < 0 or pr < mais_barato:
			mais_barato = pr
	if mais_barato >= 0:
		c.add_child(_dado("Contratação mais barata", "R$ " + _milhar(mais_barato)))
	c.add_child(_texto("A contratação desconta do caixa e o jogador entra no elenco na hora. Use os filtros de raridade para comparar.", 16))

func _inferiores_obras(re: Rect2, rd: Rect2) -> void:
	var e: VBoxContainer = _cartao(re, "Custos e manutenção")
	e.add_child(_dado("Capacidade atual", _milhar(int(GameState.financas.get("capacidade_estadio", 0))) + " lugares"))
	e.add_child(_dado("Manutenção por rodada", "R$ " + _milhar(GameState.manutencao_estadio_total())))
	var d: VBoxContainer = _cartao(rd, "Próxima obra mais barata")
	var menor: int = -1
	var nome: String = ""
	for chave in GameState.ESTADIO_MELHORIAS.keys():
		var nivel: int = int(GameState.financas["estadio"].get(chave, 0))
		if nivel >= 3:
			continue
		var custo: int = int(GameState.ESTADIO_MELHORIAS[chave]["niveis"][nivel]["custo"])
		if menor < 0 or custo < menor:
			menor = custo
			nome = str(GameState.ESTADIO_MELHORIAS[chave]["nome"])
	if menor < 0:
		d.add_child(_texto("Todas as obras já estão no nível máximo.", 17))
	else:
		d.add_child(_dado(nome, "R$ " + _milhar(menor)))
		var cx: int = int(GameState.financas.get("caixa", 0))
		d.add_child(_texto("Você tem caixa para ela." if cx >= menor else "Faltam R$ %s no caixa." % _milhar(menor - cx), 16))

# ------------------------------------------------------------------ mensagem contextual do mascote (dados reais)
func _mensagem() -> String:
	var elenco: Array = GameState.elenco
	var n: int = maxi(elenco.size(), 1)
	var caixa: int = int(GameState.financas.get("caixa", 0))
	match tela:
		"treino":
			var les: int = GameState.lesionados().size()
			var en: float = 0.0
			for j in elenco:
				en += float(j.get("energia", 0))
			if GameState.treino_confirmado:
				return "Treino da semana feito! Energia média do elenco: %d%%." % int(round(en / n))
			if les > 0:
				return "Atenção: %d lesionado(s) no elenco. Pegue leve nos turnos!" % les
			return "Monte os 4 turnos da semana. Energia média: %d%%." % int(round(en / n))
		"painel":
			var dir_: int = int(GameState.financas.get("confianca_diretoria", 70))
			if dir_ < 40:
				return "A diretoria está inquieta (%d%%). Cumpra as metas!" % dir_
			return "Confiança da diretoria em %d%%. Vamos cumprir as metas!" % dir_
		"mercado":
			return "Você tem R$ %s em caixa. Vamos reforçar o time?" % _milhar(caixa)
		"estadio_obras":
			return "Capacidade de %s lugares. Obras rendem mais público!" % _milhar(int(GameState.financas.get("capacidade_estadio", 0)))
		"torneios":
			return "A Católica está em %dº lugar. Bora subir na tabela!" % _posicao()
	return ""

func _posicao() -> int:
	var tab: Array = Competicoes.ordenar_tabela(GameState.clubes)
	for k in tab.size():
		if tab[k]["id"] == "catolica":
			return k + 1
	return 1

func _milhar(n: int) -> String:
	var t := str(absi(n))
	var r := ""
	while t.length() > 3:
		r = "." + t.substr(t.length() - 3) + r
		t = t.substr(0, t.length() - 3)
	return ("-" if n < 0 else "") + t + r

# ------------------------------------------------------------------ barra inferior com dados reais
func _rodape() -> void:
	var esq := _placa(Rect2(0, 648, 300, 72))
	esq.name = "PlacaVoltar"
	var voltar: Button = Paleta.botao("‹ VOLTAR AO MAPA", "ouro", 18, 46)
	voltar.name = "Tela_VoltarMapa"
	voltar.pressed.connect(func(): SceneManager.ir_para("mapa", false))
	esq.add_child(voltar)
	var meio := _placa(Rect2(300, 648, 540, 72))
	meio.add_theme_stylebox_override("panel", _lisa())
	var dir := _placa(Rect2(840, 648, 440, 72))
	dir.name = "PlacaClube"
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 18)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dir.add_child(h)
	_caixa_lb = _stat(h, "CAIXA")
	_torc_lb = _stat(h, "TORCIDA")
	_dir_lb = _stat(h, "DIRETORIA")
	_pos_lb = _stat(h, "POSIÇÃO")

func _lisa() -> StyleBoxFlat:
	var sb := Paleta.estilo(Color("8E0F1C"), Paleta.DOURADO, 0, 0, 10, false)
	sb.border_width_top = 3
	return sb

func _stat(pai: HBoxContainer, rot: String) -> Label:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", -2)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_rot(rot, 12, Color("F3D9D2"), false, 600))
	var l := _rot("", 20, Color.WHITE, true)
	v.add_child(l)
	pai.add_child(v)
	return l

func _atualizar_hud() -> void:
	if not is_instance_valid(_caixa_lb):
		return
	_caixa_lb.text = "R$ " + _milhar(int(GameState.financas.get("caixa", 0)))
	_torc_lb.text = "%d%%" % int(GameState.financas.get("torcida", 0))
	_dir_lb.text = "%d%%" % int(GameState.financas.get("confianca_diretoria", 70))
	_pos_lb.text = "%dº" % _posicao()

# ------------------------------------------------------------------ utilidades visuais (mesmo vocabulário do tutorial)
func _rot(texto: String, tam: int, cor: Color, titulo: bool = false, peso: int = 0) -> Label:
	var l := Label.new()
	l.text = texto
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_color_override("font_color", cor)
	l.add_theme_font_override("font", Fontes.titulo(peso if peso > 0 else 700) if titulo else Fontes.texto(peso if peso > 0 else 500))
	l.add_theme_font_size_override("font_size", tam)
	return l

func _texto(texto: String, tam: int = 17, cor: Color = TINTA) -> Label:
	var l := _rot(texto, tam, cor)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

func _dado(rotulo: String, valor: String) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var a := _rot(rotulo, 16, TINTA)
	a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(a)
	h.add_child(_rot(valor, 17, Color("8E1222"), true))
	return h

func _cartao(r: Rect2, titulo: String) -> VBoxContainer:
	var p := PanelContainer.new()
	p.position = r.position
	p.custom_minimum_size = r.size
	p.size = r.size
	p.clip_contents = true
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", Paleta.estilo(PAPEL, Color("7A1220"), 3, 12, 0))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(v)
	var barra := PanelContainer.new()
	barra.mouse_filter = Control.MOUSE_FILTER_IGNORE
	barra.add_theme_stylebox_override("panel", Paleta.estilo(Color("8E1222"), Color("8E1222"), 0, 8, 12, false))
	barra.add_child(_rot(titulo.to_upper(), 20, PAPEL, true))
	v.add_child(barra)
	var m := MarginContainer.new()
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	m.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for lado in ["left", "right"]:
		m.add_theme_constant_override("margin_" + lado, 14)
	m.add_theme_constant_override("margin_top", 8)
	m.add_theme_constant_override("margin_bottom", 6)
	v.add_child(m)
	var corpo := VBoxContainer.new()
	corpo.add_theme_constant_override("separation", 5)
	corpo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	m.add_child(corpo)
	_conteudo.add_child(p)
	return corpo

func _balao(r: Rect2, txt: String, ponta_direita: bool = true) -> void:
	var p := PanelContainer.new()
	p.name = "BalaoMascote"
	p.position = r.position
	p.custom_minimum_size = r.size
	p.size = r.size
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", Paleta.estilo(Color("FBF3E4"), Color("5A2A1A"), 3, 16, 12))
	var l := _texto(txt, 18)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	p.add_child(l)
	_conteudo.add_child(p)
	if ponta_direita:
		var tri := Polygon2D.new()
		var y: float = r.position.y + r.size.y * 0.62
		tri.polygon = PackedVector2Array([Vector2(r.end.x - 2, y - 12), Vector2(r.end.x + 20, y + 14), Vector2(r.end.x - 2, y + 12)])
		tri.color = Color("FBF3E4")
		_conteudo.add_child(tri)

func _placa(r: Rect2) -> PanelContainer:
	var p := PanelContainer.new()
	p.position = r.position
	p.custom_minimum_size = r.size
	p.size = r.size
	p.add_theme_stylebox_override("panel", _lisa())
	_conteudo.add_child(p)
	return p

func _gatinho(r: Rect2) -> void:
	_gato = TextureRect.new()
	_gato.name = "Mascote"
	_gato.texture = Mascote.textura(Mascote.humor_do_clube())
	_gato.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_gato.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_gato.position = r.position
	_gato.size = r.size
	_gato.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_gato_y = r.position.y
	_conteudo.add_child(_gato)

func _cabecalho(local: String, sub: String) -> void:
	var p := PanelContainer.new()
	p.name = "Cabecalho"
	p.custom_minimum_size = Vector2(DESIGN.x, 88)
	p.size = Vector2(DESIGN.x, 88)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := Paleta.estilo(Color("8E0F1C"), Paleta.DOURADO, 0, 0, 0, false)
	sb.border_width_bottom = 4
	p.add_theme_stylebox_override("panel", sb)
	_conteudo.add_child(p)
	var esc := TextureRect.new()
	esc.texture = load(ESCUDO)
	esc.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	esc.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	esc.position = Vector2(22, 10)
	esc.size = Vector2(62, 66)
	esc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_conteudo.add_child(esc)
	var a := _rot("CATÓLICA FC", 34, Color.WHITE, true)
	a.position = Vector2(106, 8)
	_conteudo.add_child(a)
	var total: int = GameData.regras_especiais.get("total_rodadas", 28)
	var b := _rot("Temporada %d · Rodada %d/%d" % [GameState.temporada, GameState.rodada_atual, total], 17, Color("F3D9D2"), false, 600)
	b.position = Vector2(108, 52)
	_conteudo.add_child(b)
	var sep := ColorRect.new()
	sep.color = Color(1, 1, 1, 0.55)
	sep.position = Vector2(385, 14)
	sep.size = Vector2(2, 60)
	sep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_conteudo.add_child(sep)
	var c := _rot(local.to_upper(), 36, Color.WHITE, true)
	c.name = "NomeTela"
	c.position = Vector2(412, 6)
	_conteudo.add_child(c)
	var d := _rot(sub, 18, Color("F3D9D2"), false, 600)
	d.position = Vector2(414, 54)
	_conteudo.add_child(d)
	for x in [905.0, 935.0]:
		var f := Polygon2D.new()
		f.polygon = PackedVector2Array([Vector2(x + 28, 0), Vector2(x + 52, 0), Vector2(x + 24, 84), Vector2(x, 84)])
		f.color = Color(1, 1, 1, 0.85 if x < 910.0 else 0.4)
		_conteudo.add_child(f)
