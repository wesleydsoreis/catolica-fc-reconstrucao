extends Control
## Coletiva de imprensa pós-jogo: manchete do dia e uma pergunta com 3 respostas, cada uma com custo/benefício.

var _col: VBoxContainer
var _resposta: Dictionary = {}

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	mg.add_child(_col)
	_montar()

func _fmt(v: float) -> String:
	return "%+d" % int(v) if v != 0.0 else "0"

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_col.add_child(Tema.titulo_secao("Coletiva de imprensa"))
	var c: Dictionary = GameState.coletiva_atual()
	if c.is_empty():
		_col.add_child(Tema.rotulo("Não há coletiva agora: jogue uma rodada primeiro.", 14))
	else:
		var man := Tema.cartao(Tema.AMARELO)
		var mv := VBoxContainer.new()
		man.add_child(mv)
		mv.add_child(Tema.rotulo("MANCHETE DO DIA", 12, Tema.TINTA))
		var lm := Tema.rotulo(GameState.manchete_rodada, 18, Tema.TINTA)
		lm.name = "Manchete"
		mv.add_child(lm)
		_col.add_child(man)
		var pq := Tema.rotulo(str(c["pergunta"]), 16, Tema.TITULO)
		pq.name = "Pergunta"
		_col.add_child(pq)
		var ops: Array = c["opcoes"]
		for i in ops.size():
			var o: Dictionary = ops[i]
			var b := Tema.botao(str(o["texto"]), "secundario", 54)
			b.name = "Resposta_%d" % i
			b.disabled = bool(c["feita"])
			var idx: int = i
			b.pressed.connect(func():
				_resposta = GameState.responder_coletiva(idx)
				_montar.call_deferred())
			_col.add_child(b)
		if bool(c["feita"]):
			var fb := Tema.cartao(Tema.BRANCO)
			fb.name = "FeedbackImprensa"
			var fv := VBoxContainer.new()
			fb.add_child(fv)
			fv.add_child(Tema.rotulo("A repercussão", 12, Tema.TITULO))
			if not _resposta.is_empty():
				fv.add_child(Tema.rotulo("Moral do elenco %s · Torcida %s · Diretoria %s" % [_fmt(_resposta["moral"]), _fmt(_resposta["torcida"]), _fmt(_resposta["diretoria"])], 14))
			else:
				fv.add_child(Tema.rotulo("Você já deu a coletiva desta rodada.", 14))
			_col.add_child(fv.get_parent())
	var bs := Tema.botao("VOLTAR", "primario", 48)
	bs.name = "BotaoSair"
	bs.pressed.connect(func(): SceneManager.voltar())
	_col.add_child(bs)
