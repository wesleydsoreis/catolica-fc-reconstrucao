class_name Fontes
extends RefCounted
## Tipografia da identidade nova: Barlow Condensed (títulos) e Roboto Condensed (textos).
## A Barlow é usada automaticamente se os arquivos estiverem em assets/fonte/ (ver LEIA-ME.txt);
## sem eles, os títulos usam o Roboto em largura condensada (wdth 75) e peso alto.

const ROBOTO := "res://assets/fonte/RobotoVar.ttf"
const BARLOW_BOLD := "res://assets/fonte/BarlowCondensed-Bold.ttf"
const BARLOW_SEMI := "res://assets/fonte/BarlowCondensed-SemiBold.ttf"

const TAG_WGHT := 2003265652   # "wght"
const TAG_WDTH := 2003072104   # "wdth"

static var _cache: Dictionary = {}

static func _roboto(peso: int, largura: int = 75) -> Font:
	var k := "r%d_%d" % [peso, largura]
	if not _cache.has(k):
		var base: Font = load(ROBOTO)
		if base == null:
			return ThemeDB.fallback_font
		var v := FontVariation.new()
		v.base_font = base
		v.variation_opentype = {TAG_WDTH: largura, TAG_WGHT: peso}
		_cache[k] = v
	return _cache[k]

static func texto(peso: int = 400) -> Font:
	return _roboto(peso, 75)

static func titulo(peso: int = 700) -> Font:
	var arq: String = BARLOW_BOLD if peso >= 700 else BARLOW_SEMI
	if ResourceLoader.exists(arq):
		var k := "b" + arq
		if not _cache.has(k):
			_cache[k] = load(arq)
		return _cache[k]
	var k2 := "t%d" % peso
	if not _cache.has(k2):
		var base: Font = load(ROBOTO)
		if base == null:
			return ThemeDB.fallback_font
		var v := FontVariation.new()
		v.base_font = base
		v.variation_opentype = {TAG_WDTH: 75, TAG_WGHT: maxi(peso, 600)}
		v.spacing_glyph = 1
		_cache[k2] = v
	return _cache[k2]

## Aplica fonte e tamanho a um Label/Button.
static func estilizar(c: Control, tam: int, eh_titulo: bool = false, peso: int = 0) -> void:
	c.add_theme_font_override("font", titulo(peso if peso > 0 else 700) if eh_titulo else texto(peso if peso > 0 else 500))
	c.add_theme_font_size_override("font_size", tam)
