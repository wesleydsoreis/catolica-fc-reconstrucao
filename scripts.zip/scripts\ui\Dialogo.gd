class_name Dialogo
extends CanvasLayer
## Caixa de diálogo reutilizável: retrato, nome, texto com digitação, páginas e opções.
## Uso: Dialogo.abrir(no_pai, {"nome":"DIRETOR","retrato":"res://...png","paginas":["a","b"],
##        "opcoes":[{"txt":"Abrir painel","tela":"painel"}, {"txt":"Fechar"}]})
## Emite `fechado` ao terminar. Uma opção com "tela" navega via SceneManager; com "acao" (Callable) chama a função.

## Créditos do jogo (menu inicial e fim de temporada). Papéis não informados: só o título genérico "Equipe do projeto".
static func abrir_creditos(pai: Node) -> Dialogo:
	var d: Dialogo = Dialogo.abrir(pai, {"nome": "CRÉDITOS", "retrato": "res://assets/ui/ref/npcs/treinador_retrato.png",
		"paginas": ["Católica FC — A Reconstrução. Projeto acadêmico de Engenharia de Software, Católica SC. Feito com Godot 4, GDScript e pixel art.",
			"Equipe do projeto:\nErik Pinheiro\nWesley Reis\nDaniel Trindade"],
		"opcoes": [], "fechar_txt": "Fechar"})
	d.name = "Dialogo"
	return d

signal fechado

var _dados: Dictionary
var _pagina: int = 0
var _texto: Label
var _indic: Label
var _caixa_opcoes: VBoxContainer
var _digitando: bool = false
var _t: float = 0.0
var _opcoes_ativas: bool = false

static func abrir(pai: Node, dados: Dictionary) -> Dialogo:
	var d := Dialogo.new()
	d._dados = dados
	d.layer = 50
	pai.add_child(d)
	return d

func _ready() -> void:
	var raiz := Control.new()
	raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	raiz.theme = Tema.construir()
	raiz.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(raiz)
	var fundo := ColorRect.new()
	fundo.color = Color(0.1, 0.07, 0.06, 0.35)
	fundo.set_anchors_preset(Control.PRESET_FULL_RECT)
	fundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(fundo)
	var margem := MarginContainer.new()
	margem.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	margem.grow_vertical = Control.GROW_DIRECTION_BEGIN
	margem.add_theme_constant_override("margin_left", 12)
	margem.add_theme_constant_override("margin_right", 12)
	margem.add_theme_constant_override("margin_bottom", 12)
	raiz.add_child(margem)
	var centro := CenterContainer.new()
	margem.add_child(centro)
	var cartao := Tema.cartao(Tema.BRANCO, 12)
	cartao.custom_minimum_size = Vector2(minf(560.0, maxf(280.0, get_viewport().get_visible_rect().size.x - 24.0)), 0)
	cartao.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	centro.add_child(cartao)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	cartao.add_child(col)
	var linha := HBoxContainer.new()
	linha.add_theme_constant_override("separation", 12)
	col.add_child(linha)
	# retrato em moldura
	var mold := PanelContainer.new()
	mold.add_theme_stylebox_override("panel", Tema.caixa(Tema.PAINEL2, Tema.PAINEL_BORDA, 3, 10, false, 4))
	mold.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var tr := TextureRect.new()
	var caminho: String = str(_dados.get("retrato", ""))
	if caminho != "" and ResourceLoader.exists(caminho):
		tr.texture = load(caminho)
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tr.custom_minimum_size = Vector2(104, 104)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	mold.add_child(tr)
	linha.add_child(mold)
	var dir_ := VBoxContainer.new()
	dir_.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dir_.add_theme_constant_override("separation", 4)
	linha.add_child(dir_)
	var nome := Tema.rotulo(str(_dados.get("nome", "")).capitalize(), 16, Tema.TITULO)
	dir_.add_child(nome)
	_texto = Tema.rotulo("", 16)
	_texto.custom_minimum_size = Vector2(0, 70)
	dir_.add_child(_texto)
	_indic = Label.new()
	_indic.text = "▼"
	_indic.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_indic.add_theme_color_override("font_color", Tema.TITULO)
	col.add_child(_indic)
	_caixa_opcoes = VBoxContainer.new()
	_caixa_opcoes.add_theme_constant_override("separation", 6)
	col.add_child(_caixa_opcoes)
	_mostrar_pagina()

func _paginas() -> Array:
	return _dados.get("paginas", [""])

func _mostrar_pagina() -> void:
	_texto.text = str(_paginas()[_pagina])
	_texto.visible_ratio = 0.0
	_digitando = true
	_t = 0.0
	_indic.visible = false

func _process(delta: float) -> void:
	if _digitando:
		_t += delta * 70.0
		var n: int = maxi(_texto.text.length(), 1)
		_texto.visible_ratio = clampf(_t / float(n), 0.0, 1.0)
		if _t >= n:
			_fim_digitacao()
	elif _indic.visible:
		_indic.modulate.a = 0.5 + 0.5 * sin(Time.get_ticks_msec() / 150.0)

func _fim_digitacao() -> void:
	_digitando = false
	_texto.visible_ratio = 1.0
	if _pagina < _paginas().size() - 1:
		_indic.visible = true
	else:
		_indic.visible = false
		_mostrar_opcoes()

func _mostrar_opcoes() -> void:
	if _opcoes_ativas:
		return
	_opcoes_ativas = true
	var ops: Array = _dados.get("opcoes", []).duplicate()
	ops.append({"txt": str(_dados.get("fechar_txt", "Tchau"))})
	var primeiro: Button = null
	for o in ops:
		var b := Tema.botao(str(o["txt"]), "secundario" if o == ops[ops.size() - 1] else "primario", 42)
		b.add_theme_font_size_override("font_size", 14)
		b.pressed.connect(func(): _escolher(o))
		_caixa_opcoes.add_child(b)
		if primeiro == null:
			primeiro = b
	if primeiro != null:
		primeiro.grab_focus.call_deferred()

func _escolher(o: Dictionary) -> void:
	var tela: String = str(o.get("tela", ""))
	var acao = o.get("acao", null)
	_fechar()
	if acao is Callable:
		(acao as Callable).call()
	if tela != "":
		SceneManager.ir_para(tela)

func _fechar() -> void:
	fechado.emit()
	queue_free()

func _avancar() -> void:
	if _digitando:
		_fim_digitacao()
	elif _pagina < _paginas().size() - 1:
		_pagina += 1
		_mostrar_pagina()

func _input(e: InputEvent) -> void:
	var avancar: bool = false
	if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
		avancar = not _opcoes_ativas or _digitando
	elif e.is_action_pressed("ui_accept") and not _opcoes_ativas:
		avancar = true
	elif e is InputEventKey and e.pressed and not e.echo and (e.keycode == KEY_E or e.keycode == KEY_SPACE) and not _opcoes_ativas:
		avancar = true
	elif e.is_action_pressed("ui_cancel"):
		_fechar()
		get_viewport().set_input_as_handled()
		return
	if avancar:
		_avancar()
		get_viewport().set_input_as_handled()
