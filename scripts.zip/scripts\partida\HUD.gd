extends Control
class_name HUD
## Placar, relógio, radar, barra de chute e banners no estilo arcade pixel art. Lê os dados do nó da partida.

var p: Node = null
const FUNDO: Color = Color("120f16")
const AMARELO: Color = Color("FAD72A")
const SOMBRA: Color = Color("14081f")

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _process(_delta: float) -> void:
	queue_redraw()

## ancora: 0 esquerda, 1 centro, 2 direita
func _t(texto: String, pos: Vector2, esc: int, cor: Color = Color.WHITE, ancora: int = 0, alpha: float = 1.0) -> void:
	var tex: Texture2D = PixelUI.texto(texto, esc, cor, SOMBRA)
	var x: float = pos.x
	if ancora == 1:
		x -= float(tex.get_width()) * 0.5
	elif ancora == 2:
		x -= float(tex.get_width())
	draw_texture(tex, Vector2(x, pos.y), Color(1, 1, 1, alpha))

func _letreiro(texto: String, centro: Vector2, esc: int, alpha: float = 1.0, topo: Color = Color("FFDE59"), base: Color = Color("F08C28")) -> void:
	var tex: Texture2D = PixelUI.letreiro(texto, esc, topo, base)
	draw_texture(tex, centro - Vector2(tex.get_width(), tex.get_height()) * 0.5, Color(1, 1, 1, alpha))

func _draw() -> void:
	if p == null:
		return
	var s: Vector2 = get_viewport_rect().size
	var gols: Array = p.gols
	var c_casa: Color = Cfg.COR_CASA
	var c_fora: Color = p.cor_fora_1 if p.cor_fora_1.a > 0.0 else Cfg.COR_FORA
	# ---- barra inferior (nome, escudos, placar, relógio)
	var bw: float = minf(s.x - 20.0, 780.0)
	var bx: float = (s.x - bw) * 0.5
	var by: float = s.y - 72.0
	draw_rect(Rect2(bx, by, bw, 72.0), FUNDO)
	var c: Jogador = p.controlado as Jogador
	if c != null:
		_t(c.nome, Vector2(bx + 18.0, by + 12.0), 3, Color("ebebeb"))
		var rot: Dictionary = {"GOL": "GK", "DEF": "DF", "MEI": "MF", "ATA": "FW"}
		_t("%s %d" % [rot.get(c.papel, "MF"), c.numero], Vector2(bx + 18.0, by + 44.0), 2, AMARELO)
	var ec: Texture2D = PixelUI.escudo(c_casa, Color("fffdf8"), str(p.sigla_casa).substr(0, 1), 34, 40)
	var ef: Texture2D = PixelUI.escudo(c_fora, Color("fffdf8"), str(p.sigla_fora).substr(0, 1), 34, 40)
	var cx: float = bx + bw * 0.52
	draw_texture_rect(ec, Rect2(cx - 150.0, by + 8.0, ec.get_width() * 1.3, ec.get_height() * 1.3), false)
	draw_texture_rect(ef, Rect2(cx + 105.0, by + 8.0, ef.get_width() * 1.3, ef.get_height() * 1.3), false)
	_t("%d - %d" % [int(gols[0]), int(gols[1])], Vector2(cx, by + 20.0), 4, AMARELO, 1)
	var tempo: String = "%02d:%02d" % [int(p.minuto()), int(fmod(float(p.tempo_real) * 6.0, 60.0))] if false else "%02d:00" % int(p.minuto())
	_t(tempo, Vector2(bx + bw - 18.0, by + 16.0), 3, Color("ebebeb"), 2)
	_t("1T" if not bool(p.segundo_tempo) else "2T", Vector2(bx + bw - 18.0, by + 46.0), 2, AMARELO, 2)
	# ---- estatísticas (canto superior esquerdo)
	var l1: String = "FALTAS %d-%d" % [int(p.faltas[0]), int(p.faltas[1])]
	var l2: String = "AMARELOS %d-%d  VERMELHOS %d-%d" % [int(p.amarelos[0]), int(p.amarelos[1]), int(p.vermelhos[0]), int(p.vermelhos[1])]
	var l3: String = "TROCAS %d   PENALTIS %d-%d" % [int(p.subs_restantes[0]), int(p.penaltis[0]), int(p.penaltis[1])]
	_t(l1, Vector2(14, 12), 2)
	_t(l2, Vector2(14, 34), 2)
	_t(l3, Vector2(14, 56), 2, Color("8be07a"))
	# ---- radar (canto superior direito)
	var rw: float = 190.0
	var rh: float = rw * Cfg.PH / Cfg.PW * 1.5
	var rx: float = s.x - rw - 14.0
	var ry: float = 14.0
	draw_rect(Rect2(rx - 3, ry - 3, rw + 6, rh + 6), FUNDO)
	draw_rect(Rect2(rx, ry, rw, rh), Color(0.28, 0.5, 0.3, 0.9))
	draw_line(Vector2(rx + rw * 0.5, ry), Vector2(rx + rw * 0.5, ry + rh), Color(1, 1, 1, 0.8), 2.0)
	draw_arc(Vector2(rx + rw * 0.5, ry + rh * 0.5), rh * 0.18, 0.0, TAU, 20, Color(1, 1, 1, 0.8), 2.0)
	for j in p.jogadores:
		var q: Jogador = j as Jogador
		var pos: Vector2 = Vector2(rx + q.position.x / Cfg.PW * rw, ry + q.position.y / Cfg.PH * rh)
		var cor: Color = Color("ff3b3b") if q.time == 0 else Color("4a7bff")
		draw_rect(Rect2(pos - Vector2(2.5, 2.5), Vector2(5, 5)), cor)
		if q.controlado:
			draw_rect(Rect2(pos - Vector2(4.5, 4.5), Vector2(9, 9)), Color.WHITE, false, 1.5)
	var b: Bola = p.bola as Bola
	draw_rect(Rect2(Vector2(rx + b.position.x / Cfg.PW * rw, ry + b.position.y / Cfg.PH * rh) - Vector2(2, 2), Vector2(4, 4)), Color.WHITE)
	# ---- fôlego e carga do chute
	if c != null:
		var bx2: float = bx + 18.0
		var by2: float = by - 16.0
		draw_rect(Rect2(bx2, by2, 150, 9), Color(0, 0, 0, 0.6))
		draw_rect(Rect2(bx2, by2, 150.0 * clampf(float(p.estamina), 0.0, 1.0), 9), Color("7bd36b"))
		if c.carga > 0.01:
			draw_rect(Rect2(bx2, by2 - 14, 150, 9), Color(0, 0, 0, 0.6))
			var cor_c: Color = AMARELO if c.carga < 0.7 else Color("ff5a3b")
			draw_rect(Rect2(bx2, by2 - 14, 150.0 * c.carga, 9), cor_c)
	# ---- banner
	var msg: String = str(p.mensagem)
	if msg != "":
		var a: float = clampf(float(p.mensagem_t) * 1.6, 0.0, 1.0)
		var esc: int = 7 if msg.length() <= 8 else (5 if msg.length() <= 14 else 4)
		var cy: float = s.y * 0.34
		draw_rect(Rect2(0, cy - 70.0, s.x, 190.0), Color(0, 0, 0, 0.35 * a))
		var vermelho: bool = msg.begins_with("CARTÃO V") or msg.begins_with("CARTAO V")
		_letreiro(msg, Vector2(s.x * 0.5, cy), esc, a, Color("FF8A7A") if vermelho else Color("FFDE59"), Color("D6312B") if vermelho else Color("F08C28"))
		_t(str(p.mensagem_sub), Vector2(s.x * 0.5, cy + 74.0), 3, Color("FFBE46"), 1, a)
	# ---- ajuda
	if float(p.tempo_real) < 12.0 and bool(p.pausado) == false:
		_t("WASD MOVER   J PASSE   K CHUTE   SHIFT CORRER   U TROCA   P PAUSA", Vector2(s.x * 0.5, 96.0), 2, Color(1, 1, 1), 1)
	if bool(p.pausado):
		draw_rect(Rect2(0, 0, s.x, s.y), Color(0, 0, 0, 0.4))
		_letreiro("PAUSA", Vector2(s.x * 0.5, s.y * 0.42), 8)
		_t("U OU BOTAO TROCA: SUBSTITUI O JOGADOR CONTROLADO", Vector2(s.x * 0.5, s.y * 0.42 + 80.0), 2, AMARELO, 1)
