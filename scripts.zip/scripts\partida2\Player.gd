extends Node2D
class_name Player
## Apresentação do jogador 24x28 (só visual; a lógica fica na Partida).
## Origem do nó = pés. Folhas por corte de cabelo (jogadores_v2_e0..5.png) + shader de troca de
## paleta (jogador_cores.gdshader). Animações e âncoras em jogadores_v2.json.
const CW := 24
const CH := 28
const NE := 6
static var _meta: Dictionary = {}
static var _folhas: Array = []
static var _shader: Shader = null

var _spr: Sprite2D
var _marca: Node2D
var _num: Node2D
var _sombra: Sprite2D
var _mat: ShaderMaterial
var anim: String = "idle_s"
var _t: float = 0.0
var _os: String = ""        # animação pontual em curso (chute, passe...)
var _os_t: float = 0.0
var _os_dir: String = "s"
var kit: Dictionary = {}
var numero: int = 0
var estilo: int = 0
var ctrl: bool = false      # jogador controlado: seta pulsante
var carga: float = 0.0      # força do chute (0..1)
var com_bola: bool = false
var esp_forcado: int = -1   # -1 = pelo rosto; 0/1 = força espelhamento (carrinho, mergulho)
var _cor_num: Color = Color.WHITE

static func kit_do_clube(cor1: Color, cor2: Color, goleiro: bool = false) -> Dictionary:
	if goleiro:
		return {"camisa": Color("7A2FD0"), "manga": Color("5B1FA0"), "calcao": Color("2B1B60"), "meia": Color("2B1B60"), "bota": Color("F39C12"), "luva": Color("FFD84A"), "gk": true}
	return {"camisa": cor1, "manga": cor2, "calcao": cor2, "meia": cor1, "bota": Color("14101C"), "luva": Color.TRANSPARENT, "gk": false}

static func _carregar() -> void:
	if not _folhas.is_empty():
		return
	_meta = JSON.parse_string(FileAccess.get_file_as_string("res://assets/gerado/jogadores_v2.json"))["anims"]
	for e in NE:
		_folhas.append(load("res://assets/gerado/jogadores_v2_e%d.png" % e))
	_shader = load("res://assets/gerado/jogador_cores.gdshader")

func configurar(k: Dictionary, pele: Color, cabelo: Color, estilo_cabelo: int = 0, num: int = 0) -> void:
	kit = k
	numero = num
	estilo = clampi(estilo_cabelo, 0, NE - 1)
	_carregar()
	_mat = ShaderMaterial.new()
	_mat.shader = _shader
	var luva: Color = k["luva"] if k["luva"].a > 0.0 else pele      # jogador de linha: mão = pele
	_mat.set_shader_parameter("c_pele", pele)
	_mat.set_shader_parameter("c_cabelo", cabelo)
	_mat.set_shader_parameter("c_camisa", k["camisa"])
	_mat.set_shader_parameter("c_calcao", k["calcao"])
	_mat.set_shader_parameter("c_meia", k["meia"])
	_mat.set_shader_parameter("c_bota", k["bota"])
	_mat.set_shader_parameter("c_luva", luva)
	_mat.set_shader_parameter("c_manga", k["manga"])
	var cc: Color = k["camisa"]
	_cor_num = Color("14101C") if (cc.r * 0.3 + cc.g * 0.59 + cc.b * 0.11) > 0.55 else Color("FFF8E0")
	if _spr != null:
		_spr.material = _mat
		_spr.texture = _folhas[estilo]

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_carregar()
	_sombra = Sprite2D.new()
	_sombra.texture = _sombra_tex()
	_sombra.position = Vector2(0, -1)
	add_child(_sombra)
	_spr = Sprite2D.new()
	_spr.region_enabled = true
	_spr.offset = Vector2(0, -CH * 0.5 + 1.0)
	_spr.texture = _folhas[estilo]
	if _mat != null:
		_spr.material = _mat
	add_child(_spr)
	_num = Node2D.new()
	_num.draw.connect(_desenhar_numero)
	add_child(_num)
	_marca = Node2D.new()
	_marca.z_index = 3
	_marca.draw.connect(_desenhar_marca)
	add_child(_marca)

static var _st: Texture2D = null
static func _sombra_tex() -> Texture2D:
	if _st == null:
		var im := Image.create(16, 6, false, Image.FORMAT_RGBA8)
		for y in 6:
			for x in 16:
				var dx: float = (x - 7.5) / 8.0
				var dy: float = (y - 2.5) / 3.0
				if dx * dx + dy * dy <= 1.0:
					im.set_pixel(x, y, Color(0, 0, 0, 0.32))
		_st = ImageTexture.create_from_image(im)
	return _st

# ------------------------------------------------------------------ animação
static func _resolver(base: String, d: String) -> String:
	for suf in [d, "s", "f", "b"]:
		if _meta.has(base + "_" + suf):
			return base + "_" + suf
	return base if _meta.has(base) else "idle_s"

## Dispara uma animação pontual (uma vez), vinda de um evento real da partida.
func evento(base: String) -> void:
	if _meta.is_empty():
		_carregar()
	_os = base
	_os_t = 0.0
	_os_dir = _dir_atual

var _dir_atual: String = "s"

func _dur(nome: String) -> float:
	var i: Dictionary = _meta.get(nome, {})
	if i.is_empty():
		return 0.0
	return float(i["frames"]) / float(i["fps"]) + 0.08

## Escolhe a animação a partir do estado real da partida.
func visual(vel: Vector2, face: Vector2, estado: String = "") -> void:
	var lado: bool = absf(face.x) >= absf(face.y) * 0.8
	var d: String = "s" if lado else ("f" if face.y > 0 else "b")
	_dir_atual = d
	var esp: bool = face.x < -0.15 and lado
	if esp_forcado >= 0:
		esp = esp_forcado == 1
	var v: float = vel.length()
	var nome: String
	var seguro: bool = false      # estados persistentes ignoram a animação pontual
	match estado:
		"festa": nome = "festa"; seguro = true
		"carrinho": nome = "carrinho"; seguro = true
		"queda": nome = "queda"; seguro = true
		"lamento": nome = "lamento"; seguro = true
		"gk_baixo": nome = "gk_mergulho_baixo"; seguro = true
		"gk_alto": nome = "gk_mergulho_alto"; seguro = true
		"carga": nome = _resolver("chute", d); seguro = true
		_:
			nome = ""
	if nome == "" and _os != "":
		if _os_t < _dur(_resolver(_os, _os_dir)):
			nome = _resolver(_os, _os_dir)
			if _os_dir != d and not _meta.has(_os + "_" + d):
				pass
		else:
			_os = ""
	if nome == "":
		if kit.get("gk", false):
			nome = "gk_lateral" if v > 14.0 else ("gk_espera_f" if d != "b" else "gk_espera_b")
			esp = false if v <= 14.0 else esp
		elif v > 270.0:
			nome = _resolver("sprint", d)
		elif v > 110.0:
			nome = _resolver("drible" if com_bola else "run", d)
		elif v > 14.0:
			nome = _resolver("drible" if com_bola else "walk", d)
		else:
			nome = _resolver("idle", d)
	if nome != anim:
		anim = nome
		_t = 0.0
	_spr.flip_h = esp

func _process(delta: float) -> void:
	_marca.queue_redraw()
	_num.queue_redraw()
	_t += delta
	if _os != "":
		_os_t += delta
	var info: Dictionary = _meta.get(anim, _meta["idle_s"])
	var n: int = int(info["frames"])
	var q: int = 0
	if anim.begins_with("chute") and carga > 0.02:
		q = 1 if n > 3 else 0
	elif n > 1:
		var passo: int = int(_t * float(info["fps"]))
		q = (passo % n) if bool(info["loop"]) else mini(passo, n - 1)
	_frame = q
	_spr.region_rect = Rect2(q * CW, int(info["row"]) * CH, CW, CH)

var _frame: int = 0

# ------------------------------------------------------------------ desenho auxiliar
const DIG := {
	"0": [7, 5, 5, 5, 7], "1": [2, 6, 2, 2, 7], "2": [7, 1, 7, 4, 7], "3": [7, 1, 7, 1, 7], "4": [5, 5, 7, 1, 1],
	"5": [7, 4, 7, 1, 7], "6": [7, 4, 7, 5, 7], "7": [7, 1, 1, 2, 2], "8": [7, 5, 7, 5, 7], "9": [7, 5, 7, 1, 7],
}

func _desenhar_numero() -> void:
	if numero <= 0 or kit.get("gk", false) and false:
		return
	var info: Dictionary = _meta.get(anim, {})
	var nums = info.get("num", null)
	if nums == null:
		return
	var a = nums[_frame] if _frame < nums.size() else null
	if a == null:
		return
	var s: String = str(numero)
	var w: int = s.length() * 4 - 1
	var x0: int = int(a[0]) - 12 - w / 2
	var y0: int = int(a[1]) - 27
	for i in s.length():
		var rows: Array = DIG[s[i]]
		for r in 5:
			for c in 3:
				if (int(rows[r]) >> (2 - c)) & 1 == 1:
					_num.draw_rect(Rect2(x0 + i * 4 + c, y0 + r, 1, 1), _cor_num)

func _desenhar_marca() -> void:
	if ctrl:
		var b: float = 1.0 if int(_t * 5.0) % 2 == 0 else 0.0
		var y: float = -CH - 1.0 - b
		var cor := Color("FFD84A")
		_marca.draw_rect(Rect2(-3, y, 7, 1), Color("14101C"))
		_marca.draw_rect(Rect2(-2, y - 1, 5, 1), cor)
		_marca.draw_rect(Rect2(-1, y, 3, 1), cor)
		_marca.draw_rect(Rect2(0, y + 1, 1, 1), cor)
	if carga > 0.02:
		_marca.draw_rect(Rect2(-9, 3, 18, 4), Color("14101C"))
		_marca.draw_rect(Rect2(-8, 4, int(16.0 * carga), 2), Color("FFD84A") if carga < 0.7 else Color("FF5A3B"))
