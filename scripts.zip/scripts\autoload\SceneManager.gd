extends Node
## SceneManager
## Controle central de navegação entre telas, com histórico (pilha) para o
## botão Voltar interno E para o botão/gesto físico de Voltar do Android
## (ver Main.gd, que escuta NOTIFICATION_WM_GO_BACK_REQUEST e chama voltar()).

const CENAS := {
	"inicio": "res://scenes/TelaInicial.tscn",
	"hub": "res://scenes/Mapa.tscn",
	"mapa": "res://scenes/Mapa.tscn",
	"treino": "res://scenes/telas/TelaTreino.tscn",
	"torneios": "res://scenes/telas/TelaTorneios.tscn",
	"estadio_obras": "res://scenes/telas/TelaEstadioObras.tscn",
	"fim_temporada": "res://scenes/FimTemporada.tscn",
	"painel": "res://scenes/telas/TelaPainel.tscn",
	"elenco": "res://scenes/Elenco.tscn",
	"escalacao": "res://scenes/Escalacao.tscn",
	"mercado": "res://scenes/telas/TelaMercado.tscn",
	"desafio": "res://scenes/Desafio.tscn",
	"diretor": "res://scenes/DesafioDiretor.tscn",
	"prancheta": "res://scenes/Prancheta.tscn",
	"financas": "res://scenes/Financas.tscn",
	"competencias": "res://scenes/Competencias.tscn",
	"base": "res://scenes/Base.tscn",
	"conquistas": "res://scenes/Conquistas.tscn",
	"professor": "res://scenes/Professor.tscn",
	"imprensa": "res://scenes/Imprensa.tscn",
	"preparacao": "res://scenes/Preparacao.tscn",
	"tatica": "res://scenes/Tatica.tscn",
	"resultado": "res://scenes/Resultado.tscn",
	"partida": "res://scenes/PartidaJogo.tscn",
	"config_partida": "res://scenes/ConfigPartida.tscn",
	"resultado_amistoso": "res://scenes/ResultadoAmistoso.tscn",
}

var tutorial_pendente: bool = false   # a Prancheta pede para rever o tutorial ao abrir o mapa
var bloqueio_voltar: bool = false   # true durante a partida jogável (Voltar não sai do jogo)
var _historico: Array[String] = []
var _container: Node = null   # definido por Main.gd em _ready()
var _tela_atual: String = ""

func limpar_historico() -> void:
	_historico.clear()

func tela_atual() -> String:
	return _tela_atual

func registrar_container(container: Node) -> void:
	_container = container

## Vai para uma tela nova, empilhando a atual no histórico (para permitir voltar).
func ir_para(nome_tela: String, empilhar: bool = true) -> void:
	if not CENAS.has(nome_tela):
		push_error("SceneManager: tela desconhecida '%s'" % nome_tela)
		return
	if empilhar and _tela_atual != "":
		_historico.append(_tela_atual)
	_trocar_cena(nome_tela)

## Volta para a tela anterior do histórico. Retorna true se havia para onde voltar.
func voltar() -> bool:
	if bloqueio_voltar:
		return true
	if _historico.is_empty():
		return false
	var anterior: String = _historico.pop_back()
	_trocar_cena(anterior)
	return true

func tela_anterior() -> String:
	return _historico.back() if not _historico.is_empty() else ""

func pode_voltar() -> bool:
	return not _historico.is_empty()

func _trocar_cena(nome_tela: String) -> void:
	var amb: Node = get_node_or_null("/root/Ambiente")
	if amb != null:
		amb.tela(nome_tela)                  # som de ambiente da área (o vídeo dela)
	if _container == null:
		push_error("SceneManager: container ainda não registrado")
		return
	for filho in _container.get_children():
		filho.queue_free()
	var cena: PackedScene = load(CENAS[nome_tela])
	var instancia: Node = cena.instantiate()
	_container.add_child(instancia)
	_tela_atual = nome_tela
	var raiz: Node = _container.get_parent()
	if raiz != null and raiz.has_method("ao_trocar"):
		raiz.call("ao_trocar", nome_tela)
