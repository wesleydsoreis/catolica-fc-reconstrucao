extends Node2D
class_name Stadium
## Fundo do estádio: teto, parede, camarotes com silhuetas animadas e torcida em
## 3 frames (parada / balanço / braços para cima). Dividida em faixas verticais com
## fases diferentes para não mexer tudo junto. comemorar() deixa a torcida eufórica.
const CHUNK := 40
var _meta: Dictionary
var _faixas: Array = []        # {sprite, fase}
var _cam: Array = []           # {sprite, fase}
var _t: float = 0.0
var _euforia: float = 0.0

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_meta = JSON.parse_string(FileAccess.get_file_as_string("res://assets/gerado/estadio.json"))
	var fundo := Sprite2D.new()
	fundo.centered = false
	fundo.texture = load("res://assets/gerado/estadio_fundo.png")
	add_child(fundo)
	var sil: Texture2D = load("res://assets/gerado/camarote_silhuetas.png")
	for g in _meta["grupos"]:
		for k in int(g[1]):
			var s := Sprite2D.new()
			s.centered = false
			s.texture = sil
			s.region_enabled = true
			s.region_rect = Rect2(0, 0, 31, 27)
			s.position = Vector2(int(g[0]) + k * 31 + 1, 27)
			add_child(s)
			_cam.append({"s": s, "fase": randf() * 3.0})
	var sheet: Texture2D = load("res://assets/gerado/torcida_sheet.png")
	var ch: float = float(_meta["CROWD_H"])
	for i in range(0, 480, CHUNK):
		var s2 := Sprite2D.new()
		s2.centered = false
		s2.texture = sheet
		s2.region_enabled = true
		s2.region_rect = Rect2(i, 0, CHUNK, ch)
		s2.position = Vector2(i, float(_meta["CROWD_Y"]))
		add_child(s2)
		_faixas.append({"s": s2, "fase": randf() * 4.0, "x": i})

func comemorar(seg: float = 4.0) -> void:
	_euforia = seg

func _process(delta: float) -> void:
	_t += delta
	_euforia = maxf(0.0, _euforia - delta)
	var ch: float = float(_meta["CROWD_H"])
	for f in _faixas:
		var quadro: int
		if _euforia > 0.0:
			quadro = [2, 1, 2, 2][int((_t * 6.0 + f["fase"] * 3.0)) % 4]
		else:
			quadro = [0, 0, 1, 0, 0, 1, 0, 0][int((_t * 1.4 + f["fase"])) % 8]
		var s: Sprite2D = f["s"]
		s.region_rect = Rect2(int(f["x"]), quadro * ch, CHUNK, ch)
	for c in _cam:
		var q: int = int((_t * (3.0 if _euforia > 0.0 else 1.0) + c["fase"] * 2.0)) % 2
		(c["s"] as Sprite2D).region_rect = Rect2(0, q * 27, 31, 27)
