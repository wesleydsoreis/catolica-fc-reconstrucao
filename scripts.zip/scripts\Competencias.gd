extends Control
## Árvore de competências: 5 áreas × 3 níveis (Iniciante, Intermediário, Avançado). Cada nível libera uma ferramenta nova.

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	mg.add_child(col)
	col.add_child(Tema.titulo_secao("Árvore de competências"))
	var info := Tema.rotulo("Acertos de PRIMEIRA nos Desafios do Diretor sobem o nível da área: Intermediário com %d, Avançado com %d. Cada nível libera uma ferramenta nova." % [Educacao.ACERTOS_NIVEL[1], Educacao.ACERTOS_NIVEL[2]], 13)
	col.add_child(info)
	for a in Educacao.AREAS:
		var cm: Dictionary = GameState.competencias.get(a, {"acertos": 0, "total": 0})
		var nv: int = GameState.nivel_area(a)
		var c := Tema.cartao(Tema.BRANCO)
		c.name = "Area_" + a
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 5)
		c.add_child(v)
		v.add_child(Tema.rotulo("%s · %s" % [str(Educacao.AREA_NOME[a]).to_upper(), Educacao.nome_nivel_comp(nv)], 13, Tema.TITULO))
		var prox: int = Educacao.ACERTOS_NIVEL[nv + 1] if nv < 2 else Educacao.ACERTOS_NIVEL[2]
		v.add_child(Tema.barra("%d acertos de primeira (%d desafios)" % [cm["acertos"], cm["total"]], minf(100.0, float(cm["acertos"]) / float(prox) * 100.0), Tema.AMARELO))
		for i in [1, 2]:
			var lib: bool = nv >= i
			var l := Tema.rotulo("%s %s · %s" % ["✔" if lib else "🔒", Educacao.nome_nivel_comp(i), Educacao.DESBLOQUEIOS[a][i]], 13, Tema.CREME if lib else Tema.TEXTO2)
			l.name = "Desbloqueio_%s_%d" % [a, i]
			v.add_child(l)
		col.add_child(c)
	var b := Tema.botao("VOLTAR", "primario", 48)
	b.name = "BotaoSair"
	b.pressed.connect(func(): SceneManager.voltar())
	col.add_child(b)
