class_name TituloPixel
extends Control
## Substitui um Label de título por um letreiro em pixel art que acompanha o texto do Label.

var _label: Label
var _ultimo: String = "\u0001"
var _tex: Texture2D = null
var _larg: int = -1

static func trocar(l: Label) -> void:
	if l.has_meta("pixel_titulo"):
		return
	l.set_meta("pixel_titulo", true)
	var pai: Node = l.get_parent()
	if pai == null:
		return
	var t := TituloPixel.new()
	t._label = l
	t.size_flags_horizontal = l.size_flags_horizontal
	t.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	pai.add_child(t)
	pai.move_child(t, l.get_index())
	l.modulate.a = 0.0
	l.custom_minimum_size = Vector2(0, 0)
	l.add_theme_font_size_override("font_size", 1)
	l.clip_text = true
	l.size_flags_horizontal = 0
	l.size_flags_vertical = 0

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_d: float) -> void:
	if _label == null or not is_instance_valid(_label):
		return
	var larg: int = int(size.x)
	if _label.text != _ultimo or larg != _larg:
		_ultimo = _label.text
		_larg = larg
		var pref: int = 2
		var esc: int = pref
		var piso: int = 2 if _ultimo.length() <= 14 else 1
		while esc > piso:
			var w: int = _ultimo.length() * 7 * esc + 16
			if larg <= 0 or w <= larg:
				break
			esc -= 1
		_tex = PixelUI.letreiro(_ultimo, esc)
		custom_minimum_size = Vector2(0, _tex.get_height())
		queue_redraw()

func _draw() -> void:
	if _tex != null:
		var x: float = maxf(0.0, (size.x - _tex.get_width()) * 0.5)
		draw_texture(_tex, Vector2(x, (size.y - _tex.get_height()) * 0.5))
