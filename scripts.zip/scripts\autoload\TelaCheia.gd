extends Node
## TelaCheia
## Tela cheia no PC (F11 ou Alt+Enter) e, na versão web/celular, tela cheia + travar na horizontal.
## Navegadores só aceitam tela cheia após um toque/clique do jogador; por isso, ao entrar na
## partida, "armamos" o próximo toque para pedir tela cheia e travar a orientação.

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo:
		var k := e as InputEventKey
		if k.keycode == KEY_F11 or (k.keycode == KEY_ENTER and k.alt_pressed):
			alternar()
			get_viewport().set_input_as_handled()

func esta_cheia() -> bool:
	return DisplayServer.window_get_mode() in [DisplayServer.WINDOW_MODE_FULLSCREEN, DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN]

func alternar() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval("(function(){var d=document;if(d.fullscreenElement){d.exitFullscreen();}else{d.documentElement.requestFullscreen();try{screen.orientation.lock('landscape');}catch(e){}}})()")
	elif not OS.has_feature("mobile"):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if esta_cheia() else DisplayServer.WINDOW_MODE_FULLSCREEN)

## Chamado ao entrar na partida.
func entrar_partida() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval("(function(){function f(){var d=document;if(!d.fullscreenElement){try{d.documentElement.requestFullscreen().then(function(){try{screen.orientation.lock('landscape');}catch(e){}}).catch(function(){});}catch(e){}}d.removeEventListener('pointerdown',f,true);d.removeEventListener('keydown',f,true);}document.addEventListener('pointerdown',f,true);document.addEventListener('keydown',f,true);})()")
	elif not OS.has_feature("mobile"):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

## Chamado ao sair da partida (volta ao menu de gestão em janela).
func sair_partida() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval("(function(){try{screen.orientation.unlock();}catch(e){}if(document.fullscreenElement){document.exitFullscreen();}})()")
	elif not OS.has_feature("mobile"):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
