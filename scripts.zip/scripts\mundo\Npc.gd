class_name Npc
extends Node2D
## Personagem do mundo aberto: AnimatedSprite2D com SpriteFrames montado da folha em assets/gerado/npcs.
## Animações: idle_down/up/side, walk_down/up/side e interact. Patrulha opcional entre pontos.

const ESCALA := 1.8
const VEL := 38.0
static var _meta: Dictionary = {}

var id: String = ""
var nome: String = ""
var pos_mundo: Vector2 = Vector2.ZERO
var patrulha: Array = []
var _spr: AnimatedSprite2D
var _alvo_i: int = 0
var _espera: float = 0.0
var _falando: bool = false
var _t_interacao: float = 0.0
var _dir: String = "down"
var _resp: float = 0.0

static func _carregar_meta() -> Dictionary:
	if _meta.is_empty():
		var f := FileAccess.open("res://assets/gerado/npcs/npcs.json", FileAccess.READ)
		_meta = JSON.parse_string(f.get_as_text())
	return _meta

static func montar_frames(cid: String) -> SpriteFrames:
	var m: Dictionary = _carregar_meta()
	var folha: Texture2D = load("res://assets/gerado/npcs/%s.png" % cid)
	var w: int = int(m["largura"])
	var h: int = int(m["altura"])
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for a in m["anims"]:
		var nome_a: String = str(a["nome"])
		sf.add_animation(nome_a)
		sf.set_animation_speed(nome_a, float(a["fps"]))
		sf.set_animation_loop(nome_a, true)
		for q in int(a["quadros"]):
			var at := AtlasTexture.new()
			at.atlas = folha
			at.region = Rect2(q * w, int(a["linha"]) * h, w, h)
			sf.add_frame(nome_a, at)
	return sf

func configurar(cid: String, pos: Vector2, pontos: Array = []) -> void:
	id = cid
	nome = str(NpcDados.NOMES.get(cid, cid))
	pos_mundo = pos
	patrulha = pontos
	position = pos
	z_index = int(pos.y)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_spr = AnimatedSprite2D.new()
	_spr.sprite_frames = montar_frames(cid)
	_spr.scale = Vector2(ESCALA, ESCALA)
	_spr.position = Vector2(0, -float(_carregar_meta()["altura"]) * ESCALA * 0.5 + 4.0)
	var ref: String = "res://assets/ui/ref/npcs/%s.png" % ("funcionario" if cid == "olheiro" else cid)
	if ResourceLoader.exists(ref):
		# arte do modelo: um quadro por animação, com leve "respiração"
		var tex: Texture2D = load(ref)
		var sf2 := SpriteFrames.new()
		sf2.remove_animation("default")
		for a in _carregar_meta()["anims"]:
			sf2.add_animation(str(a["nome"]))
			sf2.set_animation_loop(str(a["nome"]), true)
			sf2.add_frame(str(a["nome"]), tex)
		_spr.sprite_frames = sf2
		var k: float = 92.0 / float(tex.get_height())
		_spr.scale = Vector2(k, k)
		_spr.position = Vector2(0, -92.0 * 0.5 + 4.0)
		_resp = k
	add_child(_spr)
	_spr.play("idle_down")
	if _resp > 0.0:
		var tw := _spr.create_tween().set_loops()
		tw.tween_property(_spr, "scale:y", _resp * 1.03, 0.8)
		tw.tween_property(_spr, "scale:y", _resp, 0.8)
	_espera = randf_range(0.5, 3.0)

func _anim(prefixo: String, dir: String) -> void:
	var lado: bool = dir == "left" or dir == "right"
	var nome_a: String = "%s_%s" % [prefixo, "side" if lado else dir]
	_spr.flip_h = dir == "left"
	if _spr.animation != nome_a:
		_spr.play(nome_a)

func olhar_para(alvo: Vector2) -> void:
	var d: Vector2 = alvo - pos_mundo
	if absf(d.x) > absf(d.y):
		_dir = "right" if d.x > 0 else "left"
	else:
		_dir = "down" if d.y > 0 else "up"
	_anim("idle", _dir)

func falar(alvo: Vector2) -> void:
	_falando = true
	olhar_para(alvo)
	_spr.flip_h = false
	_spr.play("interact")
	_spr.flip_h = _dir == "left"

func parar_de_falar() -> void:
	_falando = false
	_anim("idle", _dir)

func atualizar(delta: float, jogador: Vector2) -> void:
	if _falando:
		return
	if patrulha.size() < 2:
		if pos_mundo.distance_to(jogador) < 90.0:
			olhar_para(jogador)
		return
	if pos_mundo.distance_to(jogador) < 60.0:
		olhar_para(jogador)
		return
	if _espera > 0.0:
		_espera -= delta
		_anim("idle", _dir)
		return
	var alvo: Vector2 = patrulha[_alvo_i]
	var d: Vector2 = alvo - pos_mundo
	if d.length() < 3.0:
		_alvo_i = (_alvo_i + 1) % patrulha.size()
		_espera = randf_range(2.0, 4.5)
		return
	if absf(d.x) > absf(d.y):
		_dir = "right" if d.x > 0 else "left"
	else:
		_dir = "down" if d.y > 0 else "up"
	_anim("walk", _dir)
	pos_mundo += d.normalized() * VEL * delta
	position = pos_mundo
	z_index = int(pos_mundo.y)
