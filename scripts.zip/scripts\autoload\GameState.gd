extends Node
## GameState
## Autoload com o estado MUTÁVEL da partida em andamento (equivalente ao objeto
## de estado do React no HTML original: gerarEstadoInicial()).
## GameData guarda o que é fixo; GameState guarda o que muda durante o jogo.

signal estado_mudou

var temporada: int = 1
var rodada_atual: int = 1
var fase_rodada: String = "desafio"   # desafio | evento | preparacao | escalacao | simulacao | penalti
var temporada_status: String = "em_andamento"
var overall_inicial_carreira: int = 65

var elenco: Array = []            # Array de Dictionary (jogadores)
var formacao_id: String = "4-3-3"
var slots: Array = []             # Array de Dictionary (posições em campo)
var tatica_id = null

var financas: Dictionary = {}
var clube: Dictionary = {}
var clubes: Array = []            # cópia mutável de GameData.clubes_universitario com pontos/jogos
var capitao_id = null
var mercado_jogadores: Array = []  # cópia mutável do catálogo (jogadores contratados saem daqui)

var calendario: Array = []                  # Array de rodadas do Universitário, cada uma Array de partidas
var cartas_preparacao_escolhidas: Array = []
var prep_confirmada: bool = false
var forca_extra_preparacao: float = 0.0
var gasto_preparacao_rodada: int = 0
var resultado_rodada = null
var ultimos_resultados: Array = []          # últimos "V"/"E"/"D", para a fórmula de forma recente
var escolha_viagem: String = "economica"

var caixa_minimo_alerta := 0

# --- Competições (InterLajes e Copa dos Gigantes), troféus e artilharia ---
var universitario_posicoes: Dictionary = {}   # id -> posição final (1..12)
var universitario_g8: Array = []
var interlajes: Dictionary = {}               # {quartas:[], semis:[], final:{}, campeao_id:""}
var interlajes_eliminada: bool = false
var copa: Array = []                          # clubes da Copa com pontos/jogos/...
var copa_calendario: Array = []
var fora_da_copa: bool = false
var copa_campeao_id: String = ""
var trofeus: Array = []
var gols_registrados: Dictionary = {}         # nome do jogador -> gols (artilharia da Católica)
var premios_temporada: Array = []             # [{label, valor, temporada}]
var forca_catolica_dinamica: int = 60
## Escalação das partidas jogáveis (FUT7), separada da escalação de 11 da gestão:
## {"formacao": "2-3-1", "titulares": [id × 7, na ordem dos slots da formação]}. Vazia em saves antigos.
var escalacao_fut7: Dictionary = {}

const MANUTENCAO_BASE_ESTADIO := 4000
const ESTADIO_MELHORIAS := {
	"arquibancada": {"nome": "Arquibancada", "efeito": "Capacidade de público",
		"niveis": [{"custo": 100000, "manut": 1500, "valor": 1500}, {"custo": 200000, "manut": 2500, "valor": 2000}, {"custo": 350000, "manut": 4000, "valor": 3000}]},
	"iluminacao": {"nome": "Iluminação", "efeito": "Confiança da torcida",
		"niveis": [{"custo": 100000, "manut": 1000, "valor": 5}, {"custo": 200000, "manut": 1800, "valor": 5}, {"custo": 350000, "manut": 2800, "valor": 5}]},
	"lanchonete": {"nome": "Lanchonete", "efeito": "Receita por torcedor em casa (R$)",
		"niveis": [{"custo": 100000, "manut": 800, "valor": 3}, {"custo": 200000, "manut": 1400, "valor": 3}, {"custo": 350000, "manut": 2200, "valor": 3}]},
	"centro_treinamento": {"nome": "Centro de Treinamento", "efeito": "Recuperação extra de energia",
		"niveis": [{"custo": 100000, "manut": 1200, "valor": 5}, {"custo": 200000, "manut": 2000, "valor": 5}, {"custo": 350000, "manut": 3200, "valor": 5}]},
}

func estadio_total(chave: String, campo: String) -> int:
	var nivel: int = int(financas.get("estadio", {}).get(chave, 0))
	var soma := 0
	for i in nivel:
		soma += int(ESTADIO_MELHORIAS[chave]["niveis"][i][campo])
	return soma

func manutencao_estadio_total() -> int:
	var total := MANUTENCAO_BASE_ESTADIO
	for k in ESTADIO_MELHORIAS.keys():
		total += estadio_total(k, "manut")
	return total

## Compra o próximo nível de uma melhoria. Retorna "" se deu certo, ou o motivo da falha.
func comprar_melhoria_estadio(chave: String) -> String:
	var est: Dictionary = financas["estadio"]
	var nivel: int = int(est.get(chave, 0))
	if nivel >= 3:
		return "Nível máximo."
	var info: Dictionary = ESTADIO_MELHORIAS[chave]["niveis"][nivel]
	if float(financas["caixa"]) < float(info["custo"]):
		return "Caixa insuficiente."
	financas["caixa"] = float(financas["caixa"]) - float(info["custo"])
	est[chave] = nivel + 1
	if chave == "arquibancada":
		financas["capacidade_estadio"] = int(financas["capacidade_estadio"]) + int(info["valor"])
	estado_mudou.emit()
	return ""

var _contador_id_jogador := 0

var carreira_ativa: bool = false   # true quando o jogador começou/carregou uma carreira nesta sessão (o estado inicial do boot não conta)

func _ready() -> void:
	# GameData já rodou seu _ready antes deste (ordem de autoload = ordem no project.godot).
	novo_jogo()

## Recria o estado inicial do zero, tal como gerarEstadoInicial() no HTML original.
func novo_jogo() -> void:
	if sala_seed != 0:
		seed(sala_seed)        # sala de aula: mesma carreira para toda a turma
	decisoes_log = []
	tutorial_concluido = false
	temporada = 1
	rodada_atual = 1
	fase_rodada = "desafio"
	temporada_status = "em_andamento"
	formacao_id = "4-3-3"
	tatica_id = null
	tatica_eixos = {}
	disciplina = {}
	scouting = {}
	imprensa_estado = {"rodada": -1, "temporada": -1, "feita": false}
	manchete_rodada = ""
	avaliacao_diretoria = ""
	competencias = {}
	desafio_estado = {"rodada": -1, "temporada": -1, "tentativas": 0, "resolvido": false, "acertou": false}
	educacao_log = []
	agenda_treino = ["fisico", "tecnico", "tatico", "recuperacao"]
	treino_foco_id = ""
	treino_confirmado = false
	relatorio_treino = []
	entrosamento = {"0": 60.0, "1": 40.0, "2": 40.0}
	capitao_id = null

	elenco = _gerar_elenco_inicial()
	slots = _gerar_slots_com_escalacao_sugerida()

	var titulares: Array = []
	for s in slots:
		if s["jogador_id"] != null:
			titulares.append(_jogador_por_id(s["jogador_id"]))
	if titulares.size() > 0:
		var soma := 0
		for j in titulares:
			soma += int(j["overall"])
		overall_inicial_carreira = round(float(soma) / float(titulares.size()))
	else:
		overall_inicial_carreira = 65

	var eco: Dictionary = GameData.economia
	financas = {
		"caixa": eco["caixa_inicial"],
		"confianca_diretoria": 70,
		"confianca_patrocinador": 70,
		"estadio_nivel": 1,
		"capacidade_estadio": 5000,
		"preco_ingresso": 25,
		"torcida": 35,
		"divida": 0.0,
		"estadio": {"arquibancada": 0, "iluminacao": 0, "lanchonete": 0, "centro_treinamento": 0},
	}
	clube = {"moral_geral": 60, "entrosamento": 55, "reputacao": 55, "disciplina": 60, "preparacao": 55}
	temporada = 1
	_novas_metas()
	h2h = {}
	conquistas = {}
	conquistas_novas = []
	dividas_quitadas = 0
	_novos_jovens()
	_novas_metas_pessoais()

	clubes = _clonar(GameData.clubes_universitario)
	rival_id = Extras.sortear_rival(clubes.map(func(c): return str(c["id"])), sala_seed)
	for c in clubes:
		c["pontos"] = 0
		c["jogos"] = 0
		c["vitorias"] = 0
		c["empates"] = 0
		c["derrotas"] = 0
		c["gols_pro"] = 0
		c["gols_contra"] = 0

	mercado_jogadores = _clonar(GameData.mercado_catalogo)

	var ids: Array = []
	for c in clubes:
		ids.append(c["id"])
	calendario = GameData.gerar_calendario(ids)

	cartas_preparacao_escolhidas = []
	prep_confirmada = false
	forca_extra_preparacao = 0.0
	gasto_preparacao_rodada = 0
	resultado_rodada = null
	ultimos_resultados = []
	escolha_viagem = "economica"
	universitario_posicoes = {}
	universitario_g8 = []
	interlajes = {}
	interlajes_eliminada = false
	copa = []
	copa_calendario = []
	fora_da_copa = false
	copa_campeao_id = ""
	trofeus = []
	gols_registrados = {}
	premios_temporada = []
	forca_catolica_dinamica = 60

	estado_mudou.emit()

## Gera o elenco titular inicial (17 atletas) a partir de data/elenco_inicial.json,
## replicando fielmente ELENCO_INICIAL do jogo original (mesmos nomes/posições/overalls,
## energia e moral sorteadas dentro da mesma faixa: energia 88-95, moral 60-75).
func _gerar_elenco_inicial() -> Array:
	var resultado: Array = []
	var i := 0
	for base in GameData.elenco_inicial:
		var jogador := {
			"id": "titular_%d_%s" % [i, _slug(base["nome"])],
			"nome": base["nome"],
			"posicao": base["posicao"],
			"overall": int(base["overall"]),
			"salario": int(round(float(base["overall"]) * 30.0)),   # mesma regra do HTML: overall x 30
			"numero": i + 1,
			"energia": 88 + randi() % 8,
			"moral_individual": 60 + randi() % 16,
			"gols_temporada": 0,
			"efeito_temporario": null,
			"treinos_aplicados": 0,
			"suspenso_rodadas": 0,
			"da_peneira": false,
		}
		resultado.append(jogador)
		i += 1
	return resultado

func _gerar_slots_com_escalacao_sugerida() -> Array:
	var novos_slots: Array = GameData.gerar_slots_por_formacao(formacao_id)
	var mapa: Dictionary = GameData.slots_iniciais_por_nome
	for s in novos_slots:
		if mapa.has(s["id"]):
			var nome_sugerido: String = mapa[s["id"]]
			var j = _jogador_por_nome(nome_sugerido)
			if j != null:
				s["jogador_id"] = j["id"]
	return novos_slots

func _jogador_por_id(id) -> Variant:
	for j in elenco:
		if j["id"] == id:
			return j
	return null

func _jogador_por_nome(nome: String) -> Variant:
	for j in elenco:
		if j["nome"] == nome:
			return j
	return null

func _slug(nome: String) -> String:
	var s := nome.to_lower()
	var resultado := ""
	for c in s:
		if (c >= "a" and c <= "z") or (c >= "0" and c <= "9"):
			resultado += c
		else:
			resultado += "_"
	return resultado

func _clonar(valor):
	# Deep copy simples de Array/Dictionary (equivalente a JSON.parse(JSON.stringify(x))).
	return JSON.parse_string(JSON.stringify(valor))

## Titulares atualmente escalados, na ordem dos slots.
func titulares() -> Array:
	var lista: Array = []
	for s in slots:
		if s["jogador_id"] != null:
			var j = _jogador_por_id(s["jogador_id"])
			if j != null:
				lista.append(j)
	return lista

func reservas() -> Array:
	var ids_titulares := []
	for j in titulares():
		ids_titulares.append(j["id"])
	var lista: Array = []
	for j in elenco:
		if not ids_titulares.has(j["id"]):
			lista.append(j)
	return lista

func mudar_formacao(nova_formacao_id: String) -> void:
	var ids_alocados: Array = []
	for s in slots:
		if s["jogador_id"] != null:
			ids_alocados.append(s["jogador_id"])
	var novos_slots: Array = GameData.gerar_slots_por_formacao(nova_formacao_id)
	var idx := 0
	for s in novos_slots:
		if idx < ids_alocados.size():
			s["jogador_id"] = ids_alocados[idx]
			idx += 1
	formacao_id = nova_formacao_id
	slots = novos_slots
	estado_mudou.emit()

## Contrata um jogador do mercado. Retorna uma mensagem de sucesso (para
## mostrar na UI) ou "" se não foi possível (sem saldo ou já contratado).
func contratar_jogador(id_jogador: String) -> String:
	var jogador = null
	var indice := -1
	for i in range(mercado_jogadores.size()):
		if mercado_jogadores[i]["id"] == id_jogador:
			jogador = mercado_jogadores[i]
			indice = i
			break
	if jogador == null:
		return ""
	if float(financas["caixa"]) < float(jogador["preco"]):
		return ""
	var novo_jogador: Dictionary = jogador.duplicate(true)
	novo_jogador["numero"] = elenco.size() + 1
	novo_jogador["energia"] = 90
	novo_jogador["moral_individual"] = 65
	novo_jogador["gols_temporada"] = 0
	novo_jogador["efeito_temporario"] = null
	novo_jogador["treinos_aplicados"] = 0
	novo_jogador["suspenso_rodadas"] = 0
	elenco.append(novo_jogador)
	mercado_jogadores.remove_at(indice)
	financas["caixa"] = float(financas["caixa"]) - float(jogador["preco"])
	estado_mudou.emit()
	return "Novo reforço contratado! %s agora veste a camisa do Católica FC." % jogador["nome"]

## Regras exatas de podeVenderJogador() do HTML: nunca deixar o elenco com
## menos de 11 jogadores, e nunca vender o último goleiro do elenco.
func pode_vender_jogador(id_jogador: String) -> bool:
	var jogador = _jogador_por_id(id_jogador)
	if jogador == null:
		return false
	var restantes: Array = []
	for j in elenco:
		if j["id"] != id_jogador:
			restantes.append(j)
	if restantes.size() < 11:
		return false
	if jogador["posicao"] == "GOLEIRO":
		var tem_outro_goleiro := false
		for j in restantes:
			if j["posicao"] == "GOLEIRO":
				tem_outro_goleiro = true
				break
		if not tem_outro_goleiro:
			return false
	return true

## Vende um jogador do elenco por 60%-70% do valor de mercado (aleatório,
## igual ao HTML). Retorna o valor recebido, ou -1 se a venda não é permitida.
func vender_jogador(id_jogador: String) -> int:
	if not pode_vender_jogador(id_jogador):
		return -1
	var jogador = _jogador_por_id(id_jogador)
	var percentual: float = 0.6 + randf() * 0.1
	var valor_venda: int = round(float(jogador["valor_mercado"]) * percentual)
	elenco = elenco.filter(func(j): return j["id"] != id_jogador)
	for s in slots:
		if s["jogador_id"] == id_jogador:
			s["jogador_id"] = null
	if capitao_id == id_jogador:
		capitao_id = null
	financas["caixa"] = float(financas["caixa"]) + float(valor_venda)
	estado_mudou.emit()
	return valor_venda

func _categoria_de_posicao(pos: String) -> String:
	if pos == "GOLEIRO":
		return "GOL"
	if pos == "DEFENSOR":
		return "DEF"
	if pos == "ATAQUE":
		return "ATA"
	return "MEI"   # MEIA, MEIA_DEFENSOR, MEIA_ATAQUE


# ---------------------------------------------------------------- escalação FUT7
func fut7_formacao(id: String) -> Dictionary:
	for f in GameData.formacoes_fut7:
		if f["id"] == id:
			return f
	return GameData.formacoes_fut7[1] if GameData.formacoes_fut7.size() > 1 else {}

func fut7_formacao_atual() -> Dictionary:
	return fut7_formacao(str(escalacao_fut7.get("formacao", "2-3-1")))

## Quão natural é o jogador no slot: 0 = posição própria, maiores = mais improvisado (-1 = não serve, ex.: goleiro na linha).
const FUT7_AFINIDADE := {
	"GOL": [["GOLEIRO"]],
	"DEF": [["DEFENSOR"], ["MEIA_DEFENSOR"], ["MEIA"], ["MEIA_ATAQUE"], ["ATAQUE"]],
	"MEI": [["MEIA", "MEIA_DEFENSOR", "MEIA_ATAQUE"], ["DEFENSOR", "ATAQUE"]],
	"ATA": [["ATAQUE"], ["MEIA_ATAQUE"], ["MEIA"], ["MEIA_DEFENSOR"], ["DEFENSOR"]],
}

func fut7_afinidade(j: Dictionary, cat: String) -> int:
	var pos: String = str(j.get("posicao", "MEIA"))
	var tiers: Array = FUT7_AFINIDADE[cat]
	for t in tiers.size():
		if (tiers[t] as Array).has(pos):
			return t
	return -1

func _fut7_score(j: Dictionary) -> float:
	return float(j["overall"]) - 0.25 * maxf(0.0, 60.0 - float(j.get("energia", 100)))

## Monta/valida a escalação: `manter` são ids preferidos (mantidos nos slots de mesma categoria).
func fut7_sugerir(formacao_id: String, manter: Array = []) -> void:
	var f: Dictionary = fut7_formacao(formacao_id)
	if f.is_empty() or elenco.is_empty():
		return
	var slots_f: Array = f["slots"]
	var escolha: Array = []
	escolha.resize(slots_f.size())
	var usados: Array = []
	for i in slots_f.size():
		for id in manter:
			if usados.has(id):
				continue
			var j = _jogador_por_id(id)
			if j != null and _categoria_de_posicao(str(j.get("posicao", "MEIA"))) == str(slots_f[i]["cat"]):
				escolha[i] = id
				usados.append(id)
				break
	var ordem: Array = range(slots_f.size())
	ordem.sort_custom(func(a, b): return (0 if slots_f[a]["cat"] == "GOL" else 1) < (0 if slots_f[b]["cat"] == "GOL" else 1))
	for i in ordem:
		if escolha[i] != null:
			continue
		var cat: String = str(slots_f[i]["cat"])
		var melhor = null
		for tier in range(FUT7_AFINIDADE[cat].size() if cat != "GOL" else 1):
			var melhor_s: float = -1000.0
			for jj in elenco:
				if usados.has(jj["id"]):
					continue
				if fut7_afinidade(jj, cat) != tier:
					continue
				var sc: float = _fut7_score(jj)
				if sc > melhor_s:
					melhor_s = sc
					melhor = jj
			if melhor != null:
				break
		if melhor == null and cat == "GOL":
			for jj in elenco:
				if not usados.has(jj["id"]) and (melhor == null or _fut7_score(jj) > _fut7_score(melhor)):
					melhor = jj
		if melhor != null:
			escolha[i] = melhor["id"]
			usados.append(melhor["id"])
	escalacao_fut7 = {"formacao": formacao_id, "titulares": escolha}

## Garante escalação válida (7 jogadores existentes, sem repetição). Chamado antes de usar.
func fut7_garantir() -> void:
	var f: Dictionary = fut7_formacao_atual()
	if f.is_empty():
		return
	var ids: Array = escalacao_fut7.get("titulares", [])
	var valida: bool = ids.size() == f["slots"].size()
	if valida:
		for k in ids.size():
			if ids[k] == null or _jogador_por_id(ids[k]) == null or ids.find(ids[k]) != k:
				valida = false
				break
	if not valida:
		fut7_sugerir(str(f["id"]), ids)

func fut7_mudar_formacao(formacao_id: String) -> void:
	var antigos: Array = escalacao_fut7.get("titulares", []).duplicate()
	fut7_sugerir(formacao_id, antigos)
	estado_mudou.emit()

## Põe `id_novo` no slot `idx`. Se já era titular em outro slot, os dois trocam de lugar.
func fut7_trocar(idx: int, id_novo: String) -> void:
	fut7_garantir()
	var t: Array = escalacao_fut7["titulares"]
	var onde: int = t.find(id_novo)
	if onde >= 0:
		t[onde] = t[idx]
	t[idx] = id_novo
	estado_mudou.emit()

func fut7_titulares() -> Array:
	fut7_garantir()
	var r: Array = []
	for id in escalacao_fut7.get("titulares", []):
		r.append(_jogador_por_id(id))
	return r

func fut7_banco() -> Array:
	fut7_garantir()
	var ids: Array = escalacao_fut7.get("titulares", [])
	var r: Array = []
	for j in elenco:
		if not ids.has(j["id"]):
			r.append(j)
	r.sort_custom(func(a, b): return int(a["overall"]) > int(b["overall"]))
	return r

## Dados para a partida jogável: 7 titulares FUT7 (escalação própria) e o banco; "escalacao" vem na ordem dos slots.
func dados_partida_jogavel(adv_override: Variant = null, onze: bool = true) -> Dictionary:
	var info = obter_partida_da_rodada()
	if adv_override != null:
		info = {"competicao": "amistoso", "adversario": adv_override, "em_casa": true}
	if info == null:
		return {}
	var ordem := {"GOL": 0, "DEF": 1, "MEI": 2, "ATA": 3}
	var lista: Array = []
	for s in slots:
		if s["jogador_id"] == null:
			continue
		var j = _jogador_por_id(s["jogador_id"])
		if j == null:
			continue
		lista.append({"id": j["id"], "fisico": fisico_de(j), "tecnica": tecnica_de(j), "cat": s["categoria"], "nome": j["nome"], "overall": j["overall"],
			"energia": j["energia"], "moral": j["moral_individual"], "numero": j.get("numero", 0)})
	lista.sort_custom(func(a, b): return ordem.get(a["cat"], 9) < ordem.get(b["cat"], 9))
	var reservas_lista: Array = []
	for r in reservas():
		if adv_override == null and indisponivel(str(r["id"])):
			continue
		reservas_lista.append({"id": r["id"], "fisico": fisico_de(r), "tecnica": tecnica_de(r), "cat": _categoria_de_posicao(str(r.get("posicao", "MEIA"))), "nome": r["nome"], "overall": r["overall"],
			"energia": r["energia"], "moral": r["moral_individual"], "numero": r.get("numero", 0)})
	reservas_lista.sort_custom(func(a, b): return a["overall"] > b["overall"])
	var resultado: Dictionary = {"entrosamento": entrosamento_atual(), "tatica_eixos": eixos_atuais(), "forma": forma_recente(), "extra_prep": forca_extra_preparacao,
		"reservas": reservas_lista.slice(0, 7), "escalacao": lista, "adversario": info["adversario"], "em_casa": info["em_casa"],
		"tatica_id": tatica_id if tatica_id != null else "equilibrado"}
	resultado["bonus_scout"] = bonus_scouting(info["adversario"]) * 0.004
	resultado["clima"] = clima_atual() if adv_override == null else "sol"
	resultado["adv_eixos"] = perfil_adversario(info["adversario"])
	if onze:
		_completar_dados_11(resultado, adv_override == null)
		return resultado
	var f7: Dictionary = fut7_formacao_atual()
	if not f7.is_empty() and not elenco.is_empty():
		fut7_garantir()
		var l7: Array = []
		var linhas: Array = []
		var ids7: Array = escalacao_fut7.get("titulares", []).duplicate()
		if adv_override == null:
			ids7 = _fut7_sem_suspensos(ids7, f7)
		for i in f7["slots"].size():
			var sl: Dictionary = f7["slots"][i]
			var jj = _jogador_por_id(ids7[i])
			if jj == null:
				continue
			l7.append({"id": jj["id"], "fisico": fisico_de(jj), "tecnica": tecnica_de(jj), "cat": sl["cat"], "slot": i, "nome": jj["nome"], "overall": jj["overall"], "energia": jj["energia"],
				"moral": jj["moral_individual"], "numero": jj.get("numero", sl["num"])})
			linhas.append([sl["cat"], sl["x"], sl["y"], sl["num"]])
		if l7.size() == f7["slots"].size():
			var banco: Array = []
			for r in fut7_banco():
				if (adv_override == null and indisponivel(str(r["id"]))) or ids7.has(r["id"]):
					continue
				banco.append({"id": r["id"], "fisico": fisico_de(r), "tecnica": tecnica_de(r), "cat": _categoria_de_posicao(str(r.get("posicao", "MEIA"))), "nome": r["nome"], "overall": r["overall"],
					"energia": r["energia"], "moral": r["moral_individual"], "numero": r.get("numero", 0)})
			resultado["escalacao"] = l7
			resultado["reservas"] = banco.slice(0, 7)
			resultado["formacao_linhas"] = linhas
			resultado["formacao_fut7"] = f7["id"]
	return resultado

## 11x11 (modo principal): os 11 da gestão (sem suspensos/lesionados), na ordem dos slots, com a formação da carreira.
func _completar_dados_11(res: Dictionary, aplicar_indisponiveis: bool) -> void:
	var sl: Array = slots_efetivos() if aplicar_indisponiveis else slots
	var l11: Array = []
	var usados: Array = []
	for s in sl:
		if s["jogador_id"] == null:
			continue
		var j = _jogador_por_id(s["jogador_id"])
		if j == null:
			continue
		usados.append(j["id"])
		l11.append({"id": j["id"], "fisico": fisico_de(j), "tecnica": tecnica_de(j), "cat": s["categoria"], "slot": l11.size(), "nome": j["nome"], "overall": j["overall"],
			"energia": j["energia"], "moral": j["moral_individual"], "numero": j.get("numero", 0)})
	var linhas: Array = Partida.formacao_11(formacao_id)
	if l11.size() == linhas.size():
		for i in l11.size():
			linhas[i][3] = int(l11[i]["numero"]) if int(l11[i]["numero"]) > 0 else linhas[i][3]
		res["formacao_linhas"] = linhas
		res["escalacao"] = l11
	var banco: Array = []
	for r in elenco:
		if usados.has(r["id"]) or (aplicar_indisponiveis and indisponivel(str(r["id"]))):
			continue
		banco.append({"id": r["id"], "fisico": fisico_de(r), "tecnica": tecnica_de(r), "cat": _categoria_de_posicao(str(r.get("posicao", "MEIA"))), "nome": r["nome"], "overall": r["overall"],
			"energia": r["energia"], "moral": r["moral_individual"], "numero": r.get("numero", 0)})
	banco.sort_custom(func(a, b): return int(a["overall"]) > int(b["overall"]))
	res["reservas"] = banco.slice(0, 7)
	res["modo11"] = true

# ------------------------------------------------------------------ diretoria, economia, torcida e imprensa (Fase 5)
var metas: Array = []
var tutorial_concluido: bool = true      # novo_jogo() liga o tutorial; saves antigos não o repetem
var rival_id: String = ""
var h2h: Dictionary = {}                   # id do rival -> {"v","e","d"}
var base_jovens: Array = []
var conquistas: Dictionary = {}            # id -> {"temporada","rodada"}
var conquistas_novas: Array = []           # ids ainda não mostrados ao jogador
var metas_pessoais: Array = []
var dividas_quitadas: int = 0

# ---- Fase 7
func clima_atual() -> String:
	return Extras.clima(sala_seed, temporada, rodada_atual)

func eh_classico(adv: Dictionary) -> bool:
	return rival_id != "" and str(adv.get("id", "")) == rival_id

func nome_rival() -> String:
	return str(clube_por_id(rival_id).get("nome", "—")) if rival_id != "" else "—"

func _novos_jovens() -> void:
	base_jovens = Extras.gerar_jovens(temporada, sala_seed, elenco.map(func(j): return str(j["nome"])))

func promover_jovem(idx: int) -> String:
	if idx < 0 or idx >= base_jovens.size() or bool(base_jovens[idx]["promovido"]):
		return "Jovem indisponível."
	if elenco.size() >= Extras.LIMITE_ELENCO:
		return "Elenco cheio (%d). Libere uma vaga." % Extras.LIMITE_ELENCO
	var b: Dictionary = base_jovens[idx]
	var usados: Array = elenco.map(func(j): return int(j.get("numero", 0)))
	var n := 30
	while usados.has(n):
		n += 1
	elenco.append({"id": str(b["id"]), "nome": str(b["nome"]), "posicao": str(b["posicao"]), "overall": int(b["overall"]), "potencial": int(b["potencial"]),
		"salario": int(round(float(b["overall"]) * 12.0)), "numero": n, "energia": 95, "moral_individual": 70, "gols_temporada": 0, "efeito_temporario": null,
		"treinos_aplicados": 0, "suspenso_rodadas": 0, "da_peneira": true, "idade": int(b["idade"])})
	b["promovido"] = true
	_checar_conquistas()
	estado_mudou.emit()
	return ""

func _eh_titular(id) -> bool:
	for s in slots:
		if s["jogador_id"] == id:
			return true
	return false

func pode_emprestar(j: Dictionary) -> bool:
	return not _eh_titular(j["id"]) and int(j.get("emprestado", 0)) <= 0 and int(j.get("lesao", 0)) <= 0 and elenco.size() > 14

func emprestar_jogador(id: String) -> String:
	var j = _jogador_por_id(id)
	if j == null or not pode_emprestar(j):
		return "Só reservas fora da escalação podem ser emprestados (elenco mínimo de 14)."
	j["emprestado"] = Extras.RODADAS_EMPRESTIMO
	estado_mudou.emit()
	return ""

## Semana fechada: o emprestado ganha experiência (+2 se jovem com potencial, senão +1) e volta ao fim do prazo.
func _fechar_semana_emprestimos() -> void:
	for j in elenco:
		if int(j.get("emprestado", 0)) > 0:
			j["emprestado"] = int(j["emprestado"]) - 1
			if int(j["emprestado"]) == 0:
				var pot: int = int(j.get("potencial", int(j["overall"]) + 5))
				j["overall"] = mini(pot, int(j["overall"]) + (2 if pot - int(j["overall"]) >= 4 else 1))
				j["salario"] = int(round(float(j["overall"]) * 12.0)) if bool(j.get("da_peneira", false)) else int(round(float(j["overall"]) * 30.0))

func _novas_metas_pessoais() -> void:
	metas_pessoais = []
	var cand: Array = []
	for j in titulares():
		if str(j["posicao"]) in ["ATAQUE", "MEIA_ATAQUE", "MEIA"]:
			cand.append(j)
	cand.sort_custom(func(a, b): return int(a["overall"]) > int(b["overall"]))
	for j in cand.slice(0, 3):
		var alvo: int = 5 if str(j["posicao"]) == "ATAQUE" else 3
		metas_pessoais.append({"jid": str(j["id"]), "nome": str(j["nome"]), "alvo": alvo, "base": int(gols_registrados.get(str(j["nome"]), 0)), "cumprida": false})

func gols_meta(m: Dictionary) -> int:
	return int(gols_registrados.get(str(m["nome"]), 0)) - int(m["base"])

func _checar_conquistas() -> void:
	var c: Dictionary = clube_por_id("catolica")
	var sem_perder := 0
	var a := 0
	for r in ultimos_resultados:
		a = a + 1 if r != "D" else 0
		sem_perder = maxi(sem_perder, a)
	var cond: Dictionary = {
		"primeira_vitoria": int(c.get("vitorias", 0)) > 0 or decisoes_log.any(func(d): return d["resultado"] == "vitoria"),
		"sequencia3": _sequencia_vitorias_max() >= 3, "invicto5": sem_perder >= 5,
		"goleada": decisoes_log.any(func(d): var p: PackedStringArray = str(d["placar"]).split("-"); return d["resultado"] == "vitoria" and int(p[0]) - int(p[1]) >= 3),
		"classico": rival_id != "" and int(h2h.get(rival_id, {}).get("v", 0)) > 0,
		"artilheiro": gols_registrados.values().any(func(g): return int(g) >= 5),
		"matematico": competencias.values().reduce(func(acc, x): return acc + int(x.get("acertos", 0)), 0) >= 5,
		"mestre": Educacao.AREAS.any(func(ar): return nivel_area(ar) >= 2),
		"quitou": dividas_quitadas > 0, "torcida80": float(financas["torcida"]) >= 80.0,
		"diretoria90": float(financas["confianca_diretoria"]) >= 90.0,
		"base": base_jovens.any(func(b): return bool(b["promovido"])),
		"meta_pessoal": metas_pessoais.any(func(m): return bool(m["cumprida"])),
		"campeao": not trofeus.is_empty()}
	for k in cond:
		if bool(cond[k]) and not conquistas.has(k):
			conquistas[k] = {"temporada": temporada, "rodada": rodada_atual}
			conquistas_novas.append(k)
			financas["caixa"] = float(financas["caixa"]) + Extras.PREMIO_CONQUISTA
	for m in metas_pessoais:
		if not bool(m["cumprida"]) and gols_meta(m) >= int(m["alvo"]):
			m["cumprida"] = true
			var j = _jogador_por_id(str(m["jid"]))
			if j != null:
				j["moral_individual"] = clampf(float(j["moral_individual"]) + 15.0, 0.0, 100.0)
			financas["caixa"] = float(financas["caixa"]) + 5000.0
			if not conquistas.has("meta_pessoal"):
				conquistas["meta_pessoal"] = {"temporada": temporada, "rodada": rodada_atual}
				conquistas_novas.append("meta_pessoal")

func pegar_conquistas_novas() -> Array:
	var l: Array = conquistas_novas.duplicate()
	conquistas_novas = []
	return l
var aluno_nome: String = ""
var turma_codigo: String = ""
var decisoes_log: Array = []               # uma linha por rodada jogada: decisões e resultado (relatório do professor)
var _desafio_t0: int = 0

func nivel_area(area: String) -> int:
	return Educacao.nivel_competencia(int(competencias.get(area, {}).get("acertos", 0)))

## Modo sala de aula: o mesmo código gera a mesma carreira (elenco, calendário), as mesmas metas e os mesmos problemas.
func iniciar_sala(codigo: String, nome: String) -> void:
	carreira_ativa = true
	var c: String = codigo.strip_edges()
	turma_codigo = c
	aluno_nome = nome.strip_edges()
	sala_seed = (absi(c.hash()) % 2000000000) + 1 if c != "" else 0
	novo_jogo()

func sair_sala() -> void:
	sala_seed = 0
	turma_codigo = ""

func iniciar_cronometro_desafio() -> void:
	if _desafio_t0 == 0:
		_desafio_t0 = Time.get_ticks_msec()

func _registrar_decisao(r: Dictionary) -> void:
	var e: Dictionary = eixos_atuais()
	decisoes_log.append({"temporada": temporada, "rodada": rodada_atual, "adversario": str(r["adversario"].get("nome", "?")), "em_casa": bool(r["em_casa"]),
		"resultado": str(r["tipo_resultado"]), "placar": "%d-%d" % [int(r["placar_catolica"]), int(r["placar_adversario"])], "formacao": formacao_id,
		"pressao": int(e["pressao"]), "linha": int(e["linha"]), "construcao": int(e["construcao"]), "preco_ingresso": int(financas["preco_ingresso"]),
		"scouting": nivel_scouting(str(r["adversario"].get("id", ""))), "divida": int(divida()), "caixa": int(float(financas["caixa"])), "coletiva": -1})
var imprensa_estado: Dictionary = {"rodada": -1, "temporada": -1, "feita": false}
var manchete_rodada: String = ""
var avaliacao_diretoria: String = ""       # veredito do fim de temporada

func posicao_catolica() -> int:
	var lista: Array = clubes.duplicate()
	lista.sort_custom(func(a, b):
		var da: int = int(a["gols_pro"]) - int(a["gols_contra"])
		var db: int = int(b["gols_pro"]) - int(b["gols_contra"])
		if int(a["pontos"]) != int(b["pontos"]): return int(a["pontos"]) > int(b["pontos"])
		return da > db)
	for i in lista.size():
		if lista[i]["id"] == "catolica":
			return i + 1
	return 1

func divida() -> float:
	return float(financas.get("divida", 0.0))

func definir_preco_ingresso(p: int) -> void:
	financas["preco_ingresso"] = clampi(p, Gestao.PRECO_MIN, Gestao.PRECO_MAX)
	estado_mudou.emit()

## Previsão do próximo jogo em casa (ou do adversário da rodada) com o preço atual ou um preço hipotético.
func previsao_bilheteria(preco: int, forca_adv: float = 70.0) -> Dictionary:
	var torc: float = clampf(float(financas["torcida"]) + float(estadio_total("iluminacao", "valor")), 0.0, 100.0)
	var pub: int = Gestao.publico(float(financas["capacidade_estadio"]), torc, forca_adv, float(preco))
	return {"publico": pub, "receita": pub * preco}

func tomar_emprestimo(v: int) -> String:
	if v <= 0:
		return "Valor inválido."
	if divida() + v > Gestao.LIMITE_DIVIDA:
		return "Limite de dívida: %s." % Educacao.rs(Gestao.LIMITE_DIVIDA)
	financas["divida"] = divida() + v
	financas["caixa"] = float(financas["caixa"]) + v
	estado_mudou.emit()
	return ""

func pagar_divida(v: int) -> String:
	var pag: float = minf(float(v), minf(divida(), float(financas["caixa"])))
	if pag <= 0.0:
		return "Nada a pagar (sem dívida ou sem caixa)."
	financas["divida"] = maxf(0.0, divida() - pag)
	if divida() <= 0.0:
		dividas_quitadas += 1
		_checar_conquistas()
	financas["caixa"] = float(financas["caixa"]) - pag
	estado_mudou.emit()
	return ""

func _aproveitamento_atual() -> float:
	var c: Dictionary = clube_por_id("catolica")
	var j: int = int(c.get("jogos", 0))
	return float(c.get("pontos", 0)) / float(3 * j) * 100.0 if j > 0 else 0.0

func _sequencia_vitorias_max() -> int:
	var m := 0
	var a := 0
	for r in ultimos_resultados:
		a = a + 1 if r == "V" else 0
		m = maxi(m, a)
	return m

## Situação de uma meta: {atual, texto, ok}. "ok" nas metas de fim de temporada = no caminho agora.
func situacao_meta(m: Dictionary) -> Dictionary:
	var alvo: float = float(m["alvo"])
	match str(m["id"]):
		"posicao":
			var pos: int = posicao_catolica()
			return {"atual": pos, "texto": "Posição atual: %dº" % pos, "ok": pos <= int(alvo)}
		"aproveitamento":
			var ap: float = _aproveitamento_atual()
			return {"atual": ap, "texto": "Aproveitamento: %s" % Educacao.pct(ap, 0), "ok": ap >= alvo and int(clube_por_id("catolica").get("jogos", 0)) > 0}
		"caixa":
			return {"atual": float(financas["caixa"]), "texto": "Caixa: %s" % Educacao.rs(float(financas["caixa"])), "ok": float(financas["caixa"]) >= alvo}
		"divida":
			return {"atual": divida(), "texto": "Dívida: %s" % Educacao.rs(divida()), "ok": divida() <= 0.5}
		"torcida":
			var t: float = float(financas["torcida"])
			return {"atual": t, "texto": "Torcida: %d%%" % int(t), "ok": t >= alvo}
		_:
			var sq: int = _sequencia_vitorias_max()
			return {"atual": sq, "texto": "Maior sequência: %d" % sq, "ok": sq >= int(alvo) or bool(m["cumprida"])}

func _novas_metas() -> void:
	metas = Gestao.sortear_metas(temporada, float(financas["caixa"]), sala_seed)

## Fim da rodada: confiança da diretoria, torcida, juros da dívida, metas e manchete.
func _pos_rodada_gestao(tipo: String, gp: int, gc: int, adv: String, em_casa: bool, classico: bool = false) -> void:
	var d: float = float(financas.get("confianca_diretoria", 70))
	d += 2.0 if tipo == "vitoria" else (-2.0 if tipo == "derrota" else 0.0)
	if divida() > 200000.0:
		d -= 1.0
	if float(financas["caixa"]) < 0.0:
		d -= 2.0
	var t: float = float(financas["torcida"])
	t += 2.0 if tipo == "vitoria" else (-2.0 if tipo == "derrota" else 0.0)
	if em_casa:
		var p: int = int(financas["preco_ingresso"])
		if p > 45:
			t -= 1.0
		elif p <= 20:
			t += 1.0
	financas["torcida"] = clampf(t, 0.0, 100.0)
	if divida() > 0.0:
		financas["divida"] = Gestao.divida_apos(divida(), 1)      # juros compostos
	for m in metas:
		if not bool(m["cumprida"]) and not bool(Gestao.MODELOS[m["id"]]["fim"]) and bool(situacao_meta(m)["ok"]):
			m["cumprida"] = true
			m["paga"] = true
			financas["caixa"] = float(financas["caixa"]) + Gestao.BONUS_META
			d += 4.0
	financas["confianca_diretoria"] = clampf(d, 0.0, 100.0)
	manchete_rodada = Gestao.manchete(tipo, gp, gc, adv, em_casa, _sequencia_vitorias_max() if tipo == "vitoria" else 0)
	if classico:
		manchete_rodada = "CLÁSSICO! " + manchete_rodada
		var dd: float = 3.0 if tipo == "vitoria" else (-3.0 if tipo == "derrota" else 0.0)
		financas["torcida"] = clampf(float(financas["torcida"]) + dd, 0.0, 100.0)
		financas["confianca_diretoria"] = clampf(float(financas["confianca_diretoria"]) + dd, 0.0, 100.0)
		var reg: Dictionary = h2h.get(rival_id, {"v": 0, "e": 0, "d": 0})
		reg["v" if tipo == "vitoria" else ("e" if tipo == "empate" else "d")] += 1
		h2h[rival_id] = reg

## Veredito de fim de temporada: nunca demite, mas o clima muda (ultimato = confiança baixa).
func avaliar_diretoria_fim() -> Dictionary:
	var ok := 0
	var lista: Array = []
	for m in metas:
		var sit: Dictionary = situacao_meta(m)
		var cumpriu: bool = bool(m["cumprida"]) or bool(sit["ok"])
		if cumpriu:
			ok += 1
			if not bool(m["paga"]):
				m["paga"] = true
				m["cumprida"] = true
				financas["caixa"] = float(financas["caixa"]) + Gestao.BONUS_META
				financas["confianca_diretoria"] = clampf(float(financas["confianca_diretoria"]) + 4.0, 0.0, 100.0)
		lista.append({"titulo": m["titulo"], "ok": cumpriu, "texto": sit["texto"]})
	var conf: float = float(financas["confianca_diretoria"])
	avaliacao_diretoria = "Ultimato: a diretoria exige reação na próxima temporada." if conf < 30.0 else ("Renovação com elogios." if ok >= 2 and conf >= 60.0 else "Renovação normal.")
	return {"metas": lista, "cumpridas": ok, "confianca": conf, "veredito": avaliacao_diretoria}

func coletiva_atual() -> Dictionary:
	var r = resultado_rodada
	if r == null:
		return {}
	var c: Dictionary = (Gestao.COLETIVAS[str(r["tipo_resultado"])] as Dictionary).duplicate(true)
	c["tipo"] = str(r["tipo_resultado"])
	c["feita"] = bool(imprensa_estado["feita"]) and int(imprensa_estado["rodada"]) == rodada_atual and int(imprensa_estado["temporada"]) == temporada
	return c

func responder_coletiva(idx: int) -> Dictionary:
	var c: Dictionary = coletiva_atual()
	if c.is_empty() or bool(c["feita"]) or idx < 0 or idx >= (c["opcoes"] as Array).size():
		return {}
	var o: Dictionary = c["opcoes"][idx]
	for j in elenco:
		j["moral_individual"] = clampf(float(j["moral_individual"]) + float(o["moral"]), 0.0, 100.0)
	financas["torcida"] = clampf(float(financas["torcida"]) + float(o["torcida"]), 0.0, 100.0)
	financas["confianca_diretoria"] = clampf(float(financas["confianca_diretoria"]) + float(o["diretoria"]), 0.0, 100.0)
	imprensa_estado = {"rodada": rodada_atual, "temporada": temporada, "feita": true}
	if not decisoes_log.is_empty():
		decisoes_log[-1]["coletiva"] = idx
	estado_mudou.emit()
	return o

## Chances de vitória/empate/derrota da próxima rodada (a mesma conta mostrada no Desafio e usada nos problemas de probabilidade).
func chances_proxima_rodada() -> Dictionary:
	var info = obter_partida_da_rodada()
	if info == null:
		return {}
	var penalidades := {"deficit": float(financas["caixa"]) < 0.0, "salarios_atrasados": false}
	var detalhado: Dictionary = MatchEngine.calcular_forca_detalhada({
		"elenco": elenco, "slots": slots, "financas": financas, "tatica_id": tatica_id, "mando_de_campo": info["em_casa"], "adversario": info["adversario"],
		"forca_extra_preparacao": forca_extra_preparacao, "penalidades": penalidades, "reacao_elenco": 0.0, "clube": clube, "capitao_id": capitao_id})
	return MatchEngine.calcular_probabilidades_universitario({
		"overall_catolica": float(detalhado["base"]) + detalhado["bonus_energia"] + detalhado["bonus_moral"],
		"overall_adversario": float(info["adversario"]["forca"]), "em_casa": info["em_casa"], "campo_neutro": false,
		"situacao_tatica": detalhado["situacao_tatica"], "fora_de_posicao_qtd": detalhado["fora_de_posicao_qtd"],
		"qtd_preparos_usados": 0, "bonus_energia_pontos": detalhado["bonus_energia"], "bonus_moral_pontos": detalhado["bonus_moral"],
		"nivel_estadio_soma": 0, "ultimos_resultados": ultimos_resultados})

# ------------------------------------------------------------------ camada educacional (Fase 4)
var nivel_escolar: String = "medio"            # fund2 | medio | superior
var competencias: Dictionary = {}              # area -> {"acertos": int, "total": int}
var desafio_estado: Dictionary = {"rodada": -1, "temporada": -1, "tentativas": 0, "resolvido": false, "acertou": false}
var sala_seed: int = 0                         # 0 = aleatório por carreira; ≠0 = mesma sequência para a turma (Fase 6)
var educacao_log: Array = []                   # [{rodada, area, nivel, acertou, tentativas}]

func _temporada_n() -> int:
	return temporada

func _estado_desafio_valido() -> bool:
	return int(desafio_estado["rodada"]) == rodada_atual and int(desafio_estado["temporada"]) == _temporada_n()

## Problema da rodada (o mesmo enquanto a rodada não avança), com os dados reais da carreira.
func desafio_atual() -> Dictionary:
	var area: String = Educacao.area_da_rodada(competencias, rodada_atual)
	var ctx: Dictionary = Educacao.contexto(self)
	return Educacao.gerar(area, nivel_escolar, ctx, Educacao.semente(rodada_atual, _temporada_n(), area, nivel_escolar, sala_seed))

func desafio_resolvido() -> bool:
	return _estado_desafio_valido() and bool(desafio_estado["resolvido"])

## Responde ao desafio. Acertar de primeira rende mais; errar mostra a explicação e permite tentar de novo.
func responder_desafio(idx: int) -> Dictionary:
	var p: Dictionary = desafio_atual()
	if not _estado_desafio_valido():
		desafio_estado = {"rodada": rodada_atual, "temporada": _temporada_n(), "tentativas": 0, "resolvido": false, "acertou": false}
	if bool(desafio_estado["resolvido"]):
		return {"ja_resolvido": true, "correto": bool(desafio_estado["acertou"])}
	desafio_estado["tentativas"] = int(desafio_estado["tentativas"]) + 1
	var tempo_s: float = float(Time.get_ticks_msec() - _desafio_t0) / 1000.0 if _desafio_t0 > 0 else 0.0
	var area: String = str(p["area"])
	var c: Dictionary = competencias.get(area, {"acertos": 0, "total": 0})
	var certo: bool = idx == int(p["correta"])
	var premio := 0
	if certo:
		premio = Educacao.RECOMPENSA_1A if int(desafio_estado["tentativas"]) == 1 else Educacao.RECOMPENSA_2A
		financas["caixa"] = float(financas["caixa"]) + premio
		if int(desafio_estado["tentativas"]) == 1:
			clube["moral_geral"] = mini(100, int(clube["moral_geral"]) + 2)
		c["acertos"] = int(c["acertos"]) + (1 if int(desafio_estado["tentativas"]) == 1 else 0)
	if certo or int(desafio_estado["tentativas"]) >= 2:
		desafio_estado["resolvido"] = true
		desafio_estado["acertou"] = certo
		c["total"] = int(c["total"]) + 1
		educacao_log.append({"rodada": rodada_atual, "temporada": _temporada_n(), "area": area, "nivel": nivel_escolar, "acertou": certo, "tentativas": int(desafio_estado["tentativas"]), "tempo_s": snappedf(tempo_s, 0.1), "semente": sala_seed})
		_desafio_t0 = 0
	competencias[area] = c
	estado_mudou.emit()
	return {"correto": certo, "premio": premio, "tentativas": int(desafio_estado["tentativas"]), "resolvido": bool(desafio_estado["resolvido"])}

func definir_nivel_escolar(n: String) -> void:
	if Educacao.NIVEIS.has(n):
		nivel_escolar = n
		estado_mudou.emit()

# ------------------------------------------------------------------ adversários com identidade e scouting (Fase 3)
var scouting: Dictionary = {}           # id do clube -> nível 0..2 (zera a cada rodada)
const SCOUT_CUSTO := 300
const ESTILOS_EIXOS := {
	"equilibrado": {"pressao": 1, "linha": 1, "construcao": 0}, "ofensivo": {"pressao": 2, "linha": 2, "construcao": 0},
	"defensivo": {"pressao": 0, "linha": 0, "construcao": 2}, "pressao": {"pressao": 2, "linha": 1, "construcao": 0},
	"contra_ataque": {"pressao": 0, "linha": 0, "construcao": 2}}

## Eixos do adversário: base do estilo + uma variação fixa por clube (cada clube tem identidade própria).
func perfil_adversario(adv: Dictionary) -> Dictionary:
	var e: Dictionary = (ESTILOS_EIXOS.get(str(adv.get("estilo", "equilibrado")), ESTILOS_EIXOS["equilibrado"]) as Dictionary).duplicate()
	var h: int = absi(hash(str(adv.get("id", "")))) % 7
	if h == 0 and int(e["linha"]) < 2:
		e["linha"] = int(e["linha"]) + 1
	elif h == 1 and int(e["linha"]) > 0:
		e["linha"] = int(e["linha"]) - 1
	elif h == 2 and int(e["pressao"]) < 2:
		e["pressao"] = int(e["pressao"]) + 1
	elif h == 3 and int(e["pressao"]) > 0:
		e["pressao"] = int(e["pressao"]) - 1
	return e

## Ponto fraco: o contra do traço mais marcante do adversário.
func fraqueza_adversario(adv: Dictionary) -> Dictionary:
	var e: Dictionary = perfil_adversario(adv)
	if int(e["linha"]) == 2:
		return {"titulo": "Defesa adiantada", "dica": "Sofre nas costas dos zagueiros: jogue no contra-ataque.", "eixo": "construcao", "valor": 2}
	if int(e["linha"]) == 0:
		return {"titulo": "Defesa muito recuada", "dica": "Entrega o meio-campo: pressão alta prende o time dele.", "eixo": "pressao", "valor": 2}
	if int(e["pressao"]) == 2:
		return {"titulo": "Pressão desgastante", "dica": "Pula a marcação com bola longa.", "eixo": "construcao", "valor": 1}
	return {"titulo": "Pouca pressão na saída", "dica": "Dá tempo para o toque curto circular.", "eixo": "construcao", "valor": 0}

func nivel_scouting(id: String) -> int:
	return int(scouting.get(id, 0))

func observar_adversario(id: String) -> bool:
	if nivel_scouting(id) >= 2 or float(financas["caixa"]) < SCOUT_CUSTO:
		return false
	financas["caixa"] = float(financas["caixa"]) - SCOUT_CUSTO
	scouting[id] = nivel_scouting(id) + 1
	estado_mudou.emit()
	return true

## Bônus (em pontos de overall) por ter estudado o adversário e jogar contra o ponto fraco dele. Nunca decisivo sozinho (máx. 2,5).
func bonus_scouting(adv: Dictionary) -> float:
	var n: int = nivel_scouting(str(adv.get("id", "")))
	if n <= 0:
		return 0.0
	var f: Dictionary = fraqueza_adversario(adv)
	return (1.5 if n == 1 else 2.5) if int(eixos_atuais()[f["eixo"]]) == int(f["valor"]) else 0.0

# ------------------------------------------------------------------ tática de 3 eixos e disciplina (Fase 1)
var tatica_eixos: Dictionary = {}       # {} = deriva de tatica_id; senão {pressao, linha, construcao} (0..2)
var disciplina: Dictionary = {}         # id do jogador -> {"amarelos": int, "suspenso": int}
const AMARELOS_PARA_SUSPENSAO := 3

func eixos_atuais() -> Dictionary:
	if not tatica_eixos.is_empty():
		return tatica_eixos.duplicate()
	var presets := {"equilibrado": {"pressao": 1, "linha": 1, "construcao": 0}, "ofensivo": {"pressao": 2, "linha": 2, "construcao": 0},
		"defensivo": {"pressao": 0, "linha": 0, "construcao": 2}}
	return (presets.get(str(tatica_id) if tatica_id != null else "equilibrado", presets["equilibrado"]) as Dictionary).duplicate()

## Tática equivalente (ofensivo/equilibrado/defensivo) dos eixos, para o "Simular partida" ficar coerente com o jogado.
func tatica_para_simulacao():
	if tatica_id == null or tatica_eixos.is_empty():
		return tatica_id
	var score: int = (int(tatica_eixos["pressao"]) - 1) + (int(tatica_eixos["linha"]) - 1) + (1 if int(tatica_eixos["construcao"]) == 1 else 0) - (1 if int(tatica_eixos["construcao"]) == 2 else 0)
	return "ofensivo" if score >= 2 else ("defensivo" if score <= -2 else "equilibrado")

func escolher_eixos(e: Dictionary) -> void:
	tatica_eixos = {"pressao": clampi(int(e.get("pressao", 1)), 0, 2), "linha": clampi(int(e.get("linha", 1)), 0, 2), "construcao": clampi(int(e.get("construcao", 0)), 0, 2)}
	if tatica_id == null:
		tatica_id = "equilibrado"
	estado_mudou.emit()

## Forma recente do time: média dos últimos 5 resultados (V=+1, E=0, D=-1), de -1 a 1.
func forma_recente() -> float:
	if ultimos_resultados.is_empty():
		return 0.0
	var l: Array = ultimos_resultados.slice(maxi(0, ultimos_resultados.size() - 5))
	var soma := 0.0
	for r in l:
		soma += 1.0 if r == "V" else (-1.0 if r == "D" else 0.0)
	return soma / float(l.size())

func jogo_suspenso(id: String) -> bool:
	return int((disciplina.get(id, {}) as Dictionary).get("suspenso", 0)) > 0

func amarelos_acumulados(id: String) -> int:
	return int((disciplina.get(id, {}) as Dictionary).get("amarelos", 0))

func suspensos() -> Array:
	var l: Array = []
	for j in elenco:
		if jogo_suspenso(str(j["id"])):
			l.append(j)
	return l

## Melhor jogador disponível (não suspenso, fora de `usados`) para a categoria; sem ninguém na categoria, pega o melhor de linha.
func _melhor_disponivel(cat: String, usados: Array) -> Variant:
	var melhor = null
	var fora = null
	for j in elenco:
		var id: String = str(j["id"])
		if usados.has(id) or indisponivel(id):
			continue
		var c: String = _categoria_de_posicao(str(j.get("posicao", "MEIA")))
		if c == cat:
			if melhor == null or int(j["overall"]) > int(melhor["overall"]):
				melhor = j
		elif (c == "GOL") == (cat == "GOL") and (fora == null or int(j["overall"]) > int(fora["overall"])):
			fora = j
	return melhor if melhor != null else fora

func _fut7_sem_suspensos(ids: Array, f7: Dictionary) -> Array:
	var r: Array = ids.duplicate()
	for i in r.size():
		if indisponivel(str(r[i])):
			var sub = _melhor_disponivel(str(f7["slots"][i]["cat"]), r)
			if sub != null:
				r[i] = sub["id"]
	return r

## Slots da gestão (11) sem os suspensos: o melhor reserva disponível ocupa a vaga (sem alterar a escalação salva).
func slots_efetivos() -> Array:
	var novos: Array = slots.duplicate(true)
	var usados: Array = []
	for s in novos:
		if s["jogador_id"] != null:
			usados.append(str(s["jogador_id"]))
	for s in novos:
		if s["jogador_id"] != null and indisponivel(str(s["jogador_id"])):
			var sub = _melhor_disponivel(str(s["categoria"]), usados)
			if sub != null:
				s["jogador_id"] = sub["id"]
				usados.append(str(sub["id"]))
	return novos

## Cartões de uma partida simulada (a partida jogável traz os seus em `cartoes_log`).
func _cartoes_simulados(slots_ef: Array) -> Array:
	var log: Array = []
	for s in slots_ef:
		if s["jogador_id"] == null:
			continue
		var j = _jogador_por_id(s["jogador_id"])
		if j == null:
			continue
		var r: float = randf()
		if r < 0.008:
			log.append({"id": j["id"], "nome": j["nome"], "time": 0, "tipo": "vermelho_direto"})
		elif r < 0.09:
			log.append({"id": j["id"], "nome": j["nome"], "time": 0, "tipo": "amarelo"})
	return log

## Cumpre suspensões da rodada e aplica os cartões novos. Retorna mensagens para a tela de resultado.
func _processar_disciplina(log: Array) -> Array:
	var msgs: Array = []
	for id in disciplina.keys():
		var d: Dictionary = disciplina[id]
		if int(d.get("suspenso", 0)) > 0:
			d["suspenso"] = int(d["suspenso"]) - 1
	var vermelho_2a: Array = []
	for c in log:
		if c["tipo"] == "vermelho_2a":
			vermelho_2a.append(str(c["id"]))
	for c in log:
		if int(c.get("time", 0)) != 0 or str(c["id"]) == "":
			continue
		var id: String = str(c["id"])
		var d: Dictionary = disciplina.get(id, {"amarelos": 0, "suspenso": 0})
		var nome: String = str(c["nome"])
		match str(c["tipo"]):
			"amarelo":
				if vermelho_2a.has(id):
					continue       # os 2 amarelos da mesma partida viram vermelho e não acumulam
				d["amarelos"] = int(d["amarelos"]) + 1
				if int(d["amarelos"]) >= AMARELOS_PARA_SUSPENSAO:
					d["amarelos"] = 0
					d["suspenso"] = int(d["suspenso"]) + 1
					msgs.append("%s: 3º amarelo acumulado — suspenso por 1 jogo." % nome)
				else:
					msgs.append("%s: cartão amarelo (%d/%d)." % [nome, d["amarelos"], AMARELOS_PARA_SUSPENSAO])
			"vermelho_2a", "vermelho_direto":
				d["suspenso"] = int(d["suspenso"]) + 1
				msgs.append("%s: expulso — suspenso por 1 jogo." % nome)
		disciplina[id] = d
	return msgs

# ------------------------------------------------------------------ treino, entrosamento e lesões (Fase 2)
const TURNOS_TREINO := 4
const TIPOS_TREINO := {
	"fisico": {"nome": "Físico", "desc": "+1,2 de condição física em todo o elenco (mais fôlego). Gasta 5 de energia.", "cor": "AZUL"},
	"tecnico": {"nome": "Técnico", "desc": "+0,9 de técnica em todos e +2,0 extra no jogador em foco (passe e chute). Gasta 3 de energia.", "cor": "VINHO"},
	"tatico": {"nome": "Tático", "desc": "+6 de entrosamento no estilo de construção escolhido. Gasta 3 de energia.", "cor": "LARANJA"},
	"recuperacao": {"nome": "Recuperação", "desc": "+12 de energia e menos risco de lesão. Com 2 turnos, lesionados voltam 1 rodada antes.", "cor": "VERDE"},
	"folga": {"nome": "Folga", "desc": "+5 de moral e +6 de energia.", "cor": "AMARELO"},
}
var agenda_treino: Array = ["fisico", "tecnico", "tatico", "recuperacao"]
var treino_foco_id: String = ""
var treino_confirmado: bool = false
var relatorio_treino: Array = []
var entrosamento: Dictionary = {"0": 60.0, "1": 40.0, "2": 40.0}   # por estilo de construção (0 curto, 1 longa, 2 contra-ataque)

func fisico_de(j) -> float:
	return float(j.get("fisico", clampf(float(j["overall"]) - 12.0, 40.0, 90.0)))

func tecnica_de(j) -> float:
	return float(j.get("tecnica", clampf(float(j["overall"]) - 14.0, 40.0, 90.0)))

func entrosamento_atual() -> float:
	return float(entrosamento.get(str(int(eixos_atuais()["construcao"])), 50.0))

func jogo_lesionado(id: String) -> bool:
	var j = _jogador_por_id(id)
	return j != null and int(j.get("lesao", 0)) > 0

func indisponivel(id: String) -> bool:
	var jj = _jogador_por_id(id)
	return jogo_suspenso(id) or jogo_lesionado(id) or (jj != null and int(jj.get("emprestado", 0)) > 0)

func lesionados() -> Array:
	var l: Array = []
	for j in elenco:
		if int(j.get("lesao", 0)) > 0:
			l.append(j)
	return l

## Risco de lesão de um jogador no treino: sobe com a carga (turnos intensos) e a energia baixa; recuperação reduz.
func risco_lesao_treino(agenda: Array, j) -> float:
	var carga := 0
	var rec := 0
	for a in agenda:
		if a == "fisico" or a == "tecnico" or a == "tatico":
			carga += 1
		elif a == "recuperacao":
			rec += 1
	return clampf(0.012 * maxf(0.0, float(carga - 1)) + 0.0007 * maxf(0.0, 70.0 - float(j["energia"])) - 0.012 * float(rec), 0.0, 0.25)

## Prévia (sem aplicar): números esperados da agenda.
func previa_treino(agenda: Array, foco_id: String) -> Dictionary:
	var n := {"fisico": 0, "tecnico": 0, "tatico": 0, "recuperacao": 0, "folga": 0}
	for a in agenda:
		n[a] = int(n[a]) + 1
	var energia_delta: float = -5.0 * n["fisico"] - 3.0 * n["tecnico"] - 3.0 * n["tatico"] + 12.0 * n["recuperacao"] + 6.0 * n["folga"]
	var soma_r := 0.0
	var disponiveis := 0
	for j in elenco:
		soma_r += risco_lesao_treino(agenda, j)
		disponiveis += 1
	var est: String = str(int(eixos_atuais()["construcao"]))
	return {"fisico": 1.2 * n["fisico"], "tecnica": 0.9 * n["tecnico"], "tecnica_foco": 2.0 * n["tecnico"], "entrosamento": 6.0 * n["tatico"],
		"entrosamento_de": float(entrosamento.get(est, 50.0)), "energia": energia_delta, "moral": 5.0 * n["folga"],
		"risco_medio": soma_r / maxf(1.0, disponiveis), "lesoes_esperadas": soma_r}

func confirmar_treino(agenda: Array, foco_id: String) -> void:
	if treino_confirmado or agenda.size() != TURNOS_TREINO:
		return
	agenda_treino = agenda.duplicate()
	treino_foco_id = foco_id
	relatorio_treino = []
	var est: String = str(int(eixos_atuais()["construcao"]))
	var rec := 0
	for a in agenda:
		if a == "recuperacao":
			rec += 1
	# risco calculado com a energia de ANTES do treino
	var riscos: Dictionary = {}
	for j in elenco:
		riscos[j["id"]] = risco_lesao_treino(agenda, j)
	for a in agenda:
		for j in elenco:
			match a:
				"fisico":
					j["fisico"] = minf(95.0, fisico_de(j) + 1.2)
					j["energia"] = clampf(float(j["energia"]) - 5.0, 0.0, 100.0)
				"tecnico":
					var extra: float = 2.0 if str(j["id"]) == foco_id else 0.0
					j["tecnica"] = minf(95.0, tecnica_de(j) + 0.9 + extra)
					j["energia"] = clampf(float(j["energia"]) - 3.0, 0.0, 100.0)
				"tatico":
					j["energia"] = clampf(float(j["energia"]) - 3.0, 0.0, 100.0)
				"recuperacao":
					j["energia"] = clampf(float(j["energia"]) + 12.0, 0.0, 100.0)
				"folga":
					j["moral_individual"] = clampf(float(j["moral_individual"]) + 5.0, 0.0, 100.0)
					j["energia"] = clampf(float(j["energia"]) + 6.0, 0.0, 100.0)
		if a == "tatico":
			entrosamento[est] = minf(100.0, float(entrosamento.get(est, 50.0)) + 6.0)
	# recuperação dupla: lesionados voltam 1 rodada antes
	if rec >= 2:
		for j in elenco:
			if int(j.get("lesao", 0)) > 1:
				j["lesao"] = int(j["lesao"]) - 1
	# sorteio de lesões de treino
	for j in elenco:
		if int(j.get("lesao", 0)) > 0:
			continue
		if randf() < float(riscos[j["id"]]):
			var dur: int = _duracao_lesao()
			j["lesao"] = dur
			relatorio_treino.append("%s se lesionou no treino (%d %s)." % [j["nome"], dur, "rodada" if dur == 1 else "rodadas"])
	var n_fis: int = agenda.count("fisico")
	if n_fis > 0:
		relatorio_treino.append("Condição física +%.1f no elenco." % (1.2 * n_fis))
	if agenda.count("tecnico") > 0:
		relatorio_treino.append("Técnica +%.1f no elenco (+%.1f no jogador em foco)." % [0.9 * agenda.count("tecnico"), 2.0 * agenda.count("tecnico")])
	if agenda.count("tatico") > 0:
		relatorio_treino.append("Entrosamento do estilo atual: %d." % int(entrosamento[est]))
	treino_confirmado = true
	estado_mudou.emit()

func _duracao_lesao() -> int:
	var r: float = randf()
	return 1 if r < 0.6 else (2 if r < 0.9 else 3 + randi() % 2)

## Registra uma lesão ocorrida na partida; a duração conta a partir da PRÓXIMA rodada.
func registrar_lesao(id: String, rodadas: int) -> void:
	var j = _jogador_por_id(id)
	if j != null:
		j["lesao"] = maxi(int(j.get("lesao", 0)), rodadas)
		j["lesao_nova"] = true

func _lesoes_simuladas(slots_ef: Array) -> Array:
	var l: Array = []
	for s in slots_ef:
		if s["jogador_id"] != null and randf() < 0.015:
			var j = _jogador_por_id(s["jogador_id"])
			if j != null:
				l.append({"id": j["id"], "nome": j["nome"], "rodadas": _duracao_lesao()})
	return l

func _fechar_semana_lesoes() -> void:
	for j in elenco:
		if j.get("lesao_nova", false):
			j["lesao_nova"] = false
		elif int(j.get("lesao", 0)) > 0:
			j["lesao"] = int(j["lesao"]) - 1

# ------------------------------------------------------------------ amistoso (Etapa 5)
## Configuração da partida avulsa. NÃO é salva e não toca tabela/caixa/rodada.
var amistoso: Dictionary = {}              # {adversario_id, formacao_id, dificuldade}
var amistoso_resultado: Dictionary = {}    # {adversario, gc, ga, autores, dificuldade, formacao_id}
const DIFICULDADES := {"facil": {"nome": "FÁCIL", "ajuste": -6.0}, "normal": {"nome": "NORMAL", "ajuste": 0.0}, "dificil": {"nome": "DIFÍCIL", "ajuste": 8.0}}

func adversarios_amistoso() -> Array:
	var l: Array = []
	for c in clubes:
		if c["id"] != "catolica":
			l.append(c)
	for c in copa:
		if c["id"] != "catolica":
			l.append(c)
	return l

## Dados da partida amistosa; a formação escolhida vale só para este jogo (a escalação da carreira não muda).
func dados_partida_amistoso() -> Dictionary:
	if amistoso.is_empty() or elenco.is_empty():
		return {}
	var adv: Dictionary = clube_por_id(str(amistoso.get("adversario_id", ""))).duplicate(true)
	if adv.is_empty():
		return {}
	var dif: Dictionary = DIFICULDADES.get(str(amistoso.get("dificuldade", "normal")), DIFICULDADES["normal"])
	adv["forca"] = float(adv.get("forca", 65)) + float(dif["ajuste"])
	var backup: Dictionary = escalacao_fut7.duplicate(true)
	var fid: String = str(amistoso.get("formacao_id", ""))
	if fid != "" and fid != str(backup.get("formacao", "")):
		fut7_sugerir(fid, backup.get("titulares", []).duplicate())
	var onze: bool = str(amistoso.get("modo", "11")) != "7"
	var d: Dictionary = dados_partida_jogavel(adv, onze)
	escalacao_fut7 = backup
	d["modo11"] = onze
	if not onze:
		var meu: String = str(amistoso.get("meu_time_id", "catolica"))
		if meu != "catolica" and meu == str(adv.get("id", "")):
			return {}
		if meu != "catolica":
			_aplicar_time_escolhido(d, clube_por_id(meu))
	return d

## FUT7 de diversão: joga com outro clube. Jogadores genéricos com a força/cores do clube escolhido.
func _aplicar_time_escolhido(d: Dictionary, c: Dictionary) -> void:
	if c.is_empty():
		return
	var f: float = float(c.get("forca", 70))
	var nomes := ["Gomes", "Lima", "Souza", "Rocha", "Alves", "Pires", "Costa", "Dias", "Melo", "Reis", "Nunes"]
	var esc: Array = []
	var cats: Array = (d.get("formacao_linhas", []) as Array).map(func(x): return x[0])
	if cats.is_empty():
		cats = ["GOL", "DEF", "DEF", "MEI", "MEI", "MEI", "ATA"]
	for i in cats.size():
		esc.append({"id": "x%d" % i, "fisico": f, "tecnica": f, "cat": cats[i], "slot": i, "nome": nomes[i % nomes.size()].to_upper(), "overall": f, "energia": 100.0, "moral": 60.0, "numero": i + 1})
	d["escalacao"] = esc
	d["reservas"] = []
	d["time_casa"] = {"nome": str(c.get("nome_curto", c.get("nome", "TIME"))).to_upper(), "sigla": str(c.get("sigla", "TIM")), "cor1": c.get("cor1", ""), "cor2": c.get("cor2", "")}
	d["entrosamento"] = 70.0
	d["forma"] = 0.0
	d["extra_prep"] = 0.0

func clube_por_id(id: String) -> Dictionary:
	for c in clubes:
		if c["id"] == id:
			return c
	for c in copa:
		if c["id"] == id:
			return c
	return {}

## Retorna a partida da Católica na rodada atual (só Campeonato Universitário
## nesta etapa — InterLajes e Copa continuam pendentes, ver README.md).
## null se não houver partida (não deveria acontecer dentro das rodadas 1-11).
func obter_partida_da_rodada() -> Variant:
	if temporada_status != "em_andamento":
		return null
	var comp: String = Competicoes.competicao_da_rodada(rodada_atual)
	if comp == "interlajes":
		if interlajes.is_empty() or interlajes_eliminada:
			return null
		var o: int = rodada_atual - Competicoes.R_INTERLAJES_INI
		var estagio: String = "quartas" if o < 2 else ("semis" if o < 4 else "final")
		var lado: String = "ida" if o % 2 == 0 else "volta"
		var lista: Array = [interlajes["final"]] if estagio == "final" else interlajes[estagio]
		var tie: Dictionary = Competicoes.tie_da_catolica(lista)
		if tie.is_empty():
			return null
		var id_adv: String = tie["idB"] if tie["idA"] == "catolica" else tie["idA"]
		var casa: bool = (lado == "ida" and tie["idA"] == "catolica") or (lado == "volta" and tie["idB"] == "catolica")
		return {"competicao": "interlajes", "estagio": estagio, "lado": lado, "tie": tie,
			"adversario": clube_por_id(id_adv), "em_casa": casa}
	if comp == "copa":
		if copa_calendario.is_empty() or fora_da_copa:
			return null
		var idx: int = rodada_atual - Competicoes.R_COPA_INI
		if idx < 0 or idx >= copa_calendario.size():
			return null
		var rd: Array = copa_calendario[idx]
		for pc in rd:
			if pc["mandante_id"] == "catolica" or pc["visitante_id"] == "catolica":
				var casa2: bool = pc["mandante_id"] == "catolica"
				var adv_id: String = pc["visitante_id"] if casa2 else pc["mandante_id"]
				return {"competicao": "copa", "partida": pc, "adversario": clube_por_id(adv_id),
					"em_casa": casa2, "rodada_dados": rd, "indice_rodada": idx}
		return null
	if comp != "universitario":
		return null
	var indice: int = rodada_atual - 1
	if indice < 0 or indice >= calendario.size():
		return null
	var rodada_dados: Array = calendario[indice]
	var partida = null
	for p in rodada_dados:
		if p["mandante_id"] == "catolica" or p["visitante_id"] == "catolica":
			partida = p
			break
	if partida == null:
		return null
	var em_casa: bool = partida["mandante_id"] == "catolica"
	var adversario_id: String = partida["visitante_id"] if em_casa else partida["mandante_id"]
	return {
		"competicao": "universitario",
		"partida": partida,
		"adversario": clube_por_id(adversario_id),
		"em_casa": em_casa,
		"rodada_dados": rodada_dados,
		"indice_rodada": indice,
	}

func alternar_carta_preparacao(id_carta: String) -> void:
	if prep_confirmada:
		return
	if cartas_preparacao_escolhidas.has(id_carta):
		cartas_preparacao_escolhidas.erase(id_carta)
	elif cartas_preparacao_escolhidas.size() < 2:
		cartas_preparacao_escolhidas.append(id_carta)
	estado_mudou.emit()

## Aplica as cartas escolhidas (custo, força extra, efeitos), igual a
## confirmarPreparacao() do HTML. Protegido contra cobrança duplicada.
func confirmar_preparacao() -> void:
	if prep_confirmada:
		return
	var cartas: Array = []
	for id_carta in cartas_preparacao_escolhidas:
		var c: Dictionary = GameData.obter_carta_preparacao(id_carta)
		if not c.is_empty():
			cartas.append(c)
	var custo_total := 0
	for c in cartas:
		custo_total += int(c["custo"])
	if float(financas["caixa"]) < float(custo_total):
		return

	financas["caixa"] = float(financas["caixa"]) - float(custo_total)
	var extra := 0.0
	for c in cartas:
		extra += float(c.get("forca_extra", 0))
		if c.has("energia_bonus"):
			for j in elenco:
				j["energia"] = clampf(float(j["energia"]) + float(c["energia_bonus"]), 0.0, 100.0)
		if c.has("moral_bonus"):
			for j in elenco:
				j["moral_individual"] = clampf(float(j["moral_individual"]) + float(c["moral_bonus"]), 0.0, 100.0)
		if c.has("torcida_bonus"):
			financas["torcida"] = clampf(float(financas["torcida"]) + float(c["torcida_bonus"]), 0.0, 100.0)
		if c.has("estadio_nivel_bonus"):
			financas["estadio_nivel"] = int(financas["estadio_nivel"]) + int(c["estadio_nivel_bonus"])
			financas["capacidade_estadio"] = int(financas["capacidade_estadio"]) + int(c.get("capacidade_bonus", 0))

	var mb := GameData.match_balance
	forca_extra_preparacao = clampf(extra, float(mb["preparacao"]["min"]), float(mb["preparacao"]["max"]))
	gasto_preparacao_rodada = custo_total
	prep_confirmada = true
	estado_mudou.emit()

func escolher_tatica(id_tatica: String) -> void:
	tatica_id = id_tatica
	estado_mudou.emit()

## Simula a partida da rodada atual usando as fórmulas fiéis do MatchEngine,
## calcula o resultado financeiro básico (patrocínio, bilheteria, prêmio,
## salários, manutenção — sem estádio/produtos, que ainda não têm tela) e
## guarda tudo em resultado_rodada para a tela de Resultado exibir.
## placar_jogado: null = simula pelas fórmulas; ou {"proprio": int, "adversario": int}
## vindo da partida jogável (o placar jogado vira o resultado oficial; finanças,
## desgaste, tabela e sequência de forma seguem a mesma lógica).
func simular_partida(placar_jogado = null) -> void:
	var info = obter_partida_da_rodada()
	if info == null:
		return
	var adversario: Dictionary = info["adversario"]
	var em_casa: bool = info["em_casa"]
	var slots_ef: Array = slots_efetivos()

	var penalidades := {"deficit": float(financas["caixa"]) < 0.0, "salarios_atrasados": false}
	var contexto := {
		"elenco": elenco, "slots": slots_ef, "financas": financas, "tatica_id": tatica_para_simulacao(),
		"mando_de_campo": em_casa, "adversario": adversario, "forca_extra_preparacao": forca_extra_preparacao + bonus_scouting(adversario),
		"penalidades": penalidades, "reacao_elenco": 0.0, "clube": clube, "capitao_id": capitao_id,
	}
	var detalhado: Dictionary = MatchEngine.calcular_forca_detalhada(contexto)

	var qtd_preparos_usados: int = mini(2, cartas_preparacao_escolhidas.size())
	var probs: Dictionary = MatchEngine.calcular_probabilidades_universitario({
		"overall_catolica": float(detalhado["base"]) + detalhado["bonus_energia"] + detalhado["bonus_moral"],
		"overall_adversario": float(adversario["forca"]),
		"em_casa": em_casa, "campo_neutro": false,
		"situacao_tatica": detalhado["situacao_tatica"], "fora_de_posicao_qtd": detalhado["fora_de_posicao_qtd"],
		"qtd_preparos_usados": qtd_preparos_usados,
		"bonus_energia_pontos": detalhado["bonus_energia"], "bonus_moral_pontos": detalhado["bonus_moral"],
		"nivel_estadio_soma": 0, "ultimos_resultados": ultimos_resultados,
	})
	var tipo_resultado: String
	var placar: Dictionary
	if placar_jogado != null:
		placar = {"proprio": int(placar_jogado["proprio"]), "adversario": int(placar_jogado["adversario"])}
		if placar["proprio"] > placar["adversario"]:
			tipo_resultado = "vitoria"
		elif placar["proprio"] < placar["adversario"]:
			tipo_resultado = "derrota"
		else:
			tipo_resultado = "empate"
	else:
		tipo_resultado = MatchEngine.sortear_resultado(probs)
		placar = MatchEngine.gerar_placar_por_resultado(tipo_resultado)

	# --- financeiro (subconjunto fiel: patrocínio, bilheteria, prêmio, salários, manutenção, viagem) ---
	var eco: Dictionary = GameData.economia
	var receitas: Array = []
	var despesas: Array = []
	var patrocinio: int = randi_range(int(eco["patrocinio_rodada"]["min"]), int(eco["patrocinio_rodada"]["max"]))
	receitas.append({"label": "Patrocínio da rodada", "valor": patrocinio})

	var publico := 0
	if em_casa:
		var torcida_efetiva: float = clampf(float(financas["torcida"]) + float(estadio_total("iluminacao", "valor")), 0.0, 100.0)
		var fator_torcida: float = 0.22 + (torcida_efetiva / 100.0) * 0.5
		var fator_adversario: float = 0.85 + (clampf(float(adversario["forca"]), 50.0, 90.0) / 90.0) * 0.3
		publico = Gestao.publico(float(financas["capacidade_estadio"]), torcida_efetiva, float(adversario["forca"]), float(financas["preco_ingresso"]))
		publico = clampi(int(round(float(publico) * float(Extras.CLIMAS[clima_atual()]["publico"]) * (1.25 if eh_classico(adversario) else 1.0))), 0, int(financas["capacidade_estadio"]))
		var bilheteria: int = publico * int(financas["preco_ingresso"])
		if bilheteria > 0:
			receitas.append({"label": "Bilheteria (%d torcedores)" % publico, "valor": bilheteria})
		var lanche: int = publico * estadio_total("lanchonete", "valor")
		if lanche > 0:
			receitas.append({"label": "Lanchonete", "valor": lanche})

	if info["competicao"] == "copa":
		receitas.append({"label": "Cota da Copa dos Gigantes", "valor": int(eco["copa"]["cota_por_partida"])})
	elif info["competicao"] == "interlajes":
		pass   # InterLajes só premia avanço de fase e título (ver _atualizar_competicao)
	elif tipo_resultado == "vitoria":
		receitas.append({"label": "Premiação por vitória", "valor": int(eco["universitario"]["vitoria"])})
	elif tipo_resultado == "empate":
		receitas.append({"label": "Premiação por empate", "valor": int(eco["universitario"]["empate"])})
	else:
		receitas.append({"label": "Participação (derrota)", "valor": int(eco["universitario"]["participacao_derrota"])})

	var salarios := 0
	for j in elenco:
		if int(j.get("emprestado", 0)) <= 0:
			salarios += int(j["salario"])
	despesas.append({"label": "Salários do elenco", "valor": salarios})

	if gasto_preparacao_rodada > 0:
		despesas.append({"label": "Preparação da rodada", "valor": gasto_preparacao_rodada})

	var manutencao_estadio: int = manutencao_estadio_total()
	despesas.append({"label": "Manutenção do estádio", "valor": manutencao_estadio})

	if not em_casa:
		var custo_viagem: int = randi_range(int(eco["viagem"]["economica_min"]), int(eco["viagem"]["economica_max"]))
		despesas.append({"label": "Viagem", "valor": custo_viagem})

	_atualizar_competicao(info, placar, tipo_resultado, receitas, int(detalhado["final"]))
	_registrar_gols(placar_jogado, int(placar["proprio"]))

	var total_receitas := 0
	for r in receitas:
		total_receitas += int(r["valor"])
	var total_despesas := 0
	for d in despesas:
		total_despesas += int(d["valor"])
	var saldo_rodada: int = total_receitas - total_despesas
	financas["caixa"] = float(financas["caixa"]) + float(saldo_rodada)

	# --- desgaste/moral pós-partida (titulares apenas) ---
	var tatica: Dictionary = GameData.obter_tatica(tatica_id) if tatica_id != null else {}
	var desgaste_base: int = 12 + int(tatica.get("desgaste_extra", 0))
	var ids_titulares: Array = []
	for s in slots_ef:
		if s["jogador_id"] != null:
			ids_titulares.append(s["jogador_id"])
	var energia_extra: float = float(estadio_total("centro_treinamento", "valor"))
	for j in elenco:
		if ids_titulares.has(j["id"]):
			j["energia"] = clampf(float(j["energia"]) - float(desgaste_base) + energia_extra, 0.0, 100.0)
			var delta_moral: float = 5.0 if tipo_resultado == "vitoria" else (-5.0 if tipo_resultado == "derrota" else 0.0)
			j["moral_individual"] = clampf(float(j["moral_individual"]) + delta_moral, 0.0, 100.0)
		else:
			j["energia"] = clampf(float(j["energia"]) + 10.0 + energia_extra, 0.0, 100.0)

	var log_cartoes: Array = placar_jogado["cartoes"] if (placar_jogado != null and placar_jogado.has("cartoes")) else _cartoes_simulados(slots_ef)
	var msgs_disc: Array = _processar_disciplina(log_cartoes)
	var lista_les: Array = placar_jogado["lesoes"] if (placar_jogado != null and placar_jogado.has("lesoes")) else _lesoes_simuladas(slots_ef)
	for l in lista_les:
		registrar_lesao(str(l["id"]), int(l["rodadas"]))
		msgs_disc.append("%s: lesão (%d %s fora)." % [l["nome"], int(l["rodadas"]), "rodada" if int(l["rodadas"]) == 1 else "rodadas"])
	var est_jogo: String = str(int(eixos_atuais()["construcao"]))
	entrosamento[est_jogo] = minf(100.0, float(entrosamento.get(est_jogo, 50.0)) + 2.0)
	var letra_resultado: String = "V" if tipo_resultado == "vitoria" else ("E" if tipo_resultado == "empate" else "D")
	ultimos_resultados.append(letra_resultado)

	resultado_rodada = {
		"competicao": info["competicao"], "rodape": _rodape_competicao,
		"adversario": adversario, "em_casa": em_casa, "tipo_resultado": tipo_resultado,
		"placar_catolica": int(placar["proprio"]), "placar_adversario": int(placar["adversario"]),
		"receitas": receitas, "despesas": despesas, "saldo_rodada": saldo_rodada,
		"caixa_final": financas["caixa"], "forca_final": detalhado["final"], "disciplina": msgs_disc,
	}
	_pos_rodada_gestao(tipo_resultado, int(placar["proprio"]), int(placar["adversario"]), str(adversario.get("nome", "?")), em_casa, eh_classico(adversario))
	resultado_rodada["manchete"] = manchete_rodada
	_registrar_decisao(resultado_rodada)
	resultado_rodada["classico"] = eh_classico(adversario)
	resultado_rodada["clima"] = clima_atual()
	_checar_conquistas()
	_rodape_competicao = ""
	fase_rodada = "simulacao"
	estado_mudou.emit()

var _rodape_competicao: String = ""

func _atualizar_tabela(id_clube: String, gols_pro: int, gols_contra: int) -> void:
	var c := clube_por_id(id_clube)
	if c.is_empty():
		return
	c["jogos"] = int(c["jogos"]) + 1
	c["gols_pro"] = int(c["gols_pro"]) + gols_pro
	c["gols_contra"] = int(c["gols_contra"]) + gols_contra
	if gols_pro > gols_contra:
		c["vitorias"] = int(c["vitorias"]) + 1
		c["pontos"] = int(c["pontos"]) + 3
	elif gols_pro == gols_contra:
		c["empates"] = int(c["empates"]) + 1
		c["pontos"] = int(c["pontos"]) + 1
	else:
		c["derrotas"] = int(c["derrotas"]) + 1

## As demais partidas da rodada (que não envolvem a Católica) são resolvidas
## de forma simplificada, só pela força-base de cada clube, para manter a
## tabela de classificação coerente. (O HTML usa uma fórmula própria mais
## detalhada para isso — ver simularOutrasPartidas — que fica para refinar
## numa próxima etapa; aqui o resultado ainda respeita força maior = mais
## chance de vencer, só que com uma curva mais simples.)
func _simular_outras_partidas_da_rodada(rodada_dados: Array, id_partida_catolica: String) -> void:
	for p in rodada_dados:
		if p["id"] == id_partida_catolica:
			continue
		var mandante := clube_por_id(p["mandante_id"])
		var visitante := clube_por_id(p["visitante_id"])
		if mandante.is_empty() or visitante.is_empty():
			continue
		var diferenca: float = (float(mandante["forca"]) + 1.5) - float(visitante["forca"])
		var chance_vitoria_mandante: float = clampf(0.40 + diferenca * 0.02, 0.15, 0.75)
		var r := randf()
		var gm := 0
		var gv := 0
		if r < chance_vitoria_mandante:
			gm = 1 + (randi() % 3)
			gv = randi() % gm
		elif r < chance_vitoria_mandante + 0.20:
			gm = randi() % 3
			gv = gm
		else:
			gv = 1 + (randi() % 3)
			gm = randi() % gv
		p["jogado"] = true
		p["placar_mandante"] = gm
		p["placar_visitante"] = gv
		_atualizar_tabela(mandante["id"], gm, gv)
		_atualizar_tabela(visitante["id"], gv, gm)

# ---------------------------------------------------------------- competições
func _premio(receitas: Array, rotulo: String, valor: int) -> void:
	receitas.append({"label": rotulo, "valor": valor})
	premios_temporada.append({"label": rotulo, "valor": valor, "temporada": temporada})

func _clube_copa(id: String) -> Dictionary:
	for c in copa:
		if c["id"] == id:
			return c
	return {}

func _forca_clube(id: String) -> float:
	if id == "catolica":
		return float(forca_catolica_dinamica)
	var c: Dictionary = clube_por_id(id)
	return float(c.get("forca", 60))

func _atualizar_competicao(info: Dictionary, placar: Dictionary, tipo: String, receitas: Array, forca_final: int) -> void:
	forca_catolica_dinamica = forca_final
	var gp: int = int(placar["proprio"])
	var gc: int = int(placar["adversario"])
	var adv: Dictionary = info["adversario"]
	var em_casa: bool = info["em_casa"]
	match info["competicao"]:
		"universitario":
			var partida: Dictionary = info["partida"]
			partida["jogado"] = true
			partida["placar_mandante"] = gp if em_casa else gc
			partida["placar_visitante"] = gc if em_casa else gp
			_atualizar_tabela("catolica", gp, gc)
			_atualizar_tabela(adv["id"], gc, gp)
			_simular_outras_partidas_da_rodada(info["rodada_dados"], partida["id"])
			if rodada_atual == Competicoes.R_UNIV_FIM:
				_fechar_universitario(receitas)
		"interlajes":
			_jogar_leg_interlajes(info, gp, gc, receitas)
		"copa":
			var pc: Dictionary = info["partida"]
			pc["jogado"] = true
			pc["placar_mandante"] = gp if em_casa else gc
			pc["placar_visitante"] = gc if em_casa else gp
			Competicoes.aplicar_resultado(_clube_copa("catolica"), gp, gc)
			Competicoes.aplicar_resultado(_clube_copa(adv["id"]), gc, gp)
			for q in info["rodada_dados"]:
				if q["id"] == pc["id"]:
					continue
				var m: Dictionary = _clube_copa(q["mandante_id"])
				var v: Dictionary = _clube_copa(q["visitante_id"])
				var ps: Vector2i = Competicoes.placar_sim(float(m["forca"]), float(v["forca"]))
				q["jogado"] = true
				q["placar_mandante"] = ps.x
				q["placar_visitante"] = ps.y
				Competicoes.aplicar_resultado(m, ps.x, ps.y)
				Competicoes.aplicar_resultado(v, ps.y, ps.x)
			if rodada_atual == Competicoes.R_COPA_FIM:
				_fechar_copa(receitas)

func _fechar_universitario(receitas: Array) -> void:
	var ordem: Array = Competicoes.ordenar_tabela(clubes)
	universitario_posicoes = {}
	universitario_g8 = []
	for i in ordem.size():
		universitario_posicoes[ordem[i]["id"]] = i + 1
		if i < 8:
			universitario_g8.append(ordem[i]["id"])
	var pos: int = int(universitario_posicoes.get("catolica", 99))
	var eco: Dictionary = GameData.economia["universitario"]
	if pos == 1:
		_premio(receitas, "Campeão do Universitário", int(eco["titulo"]))
		trofeus.append({"competicao": "Campeonato Universitário", "titulo": "Campeão", "temporada": temporada})
	elif pos == 2:
		_premio(receitas, "Vice do Universitário", int(eco["vice"]))
	elif pos == 3:
		_premio(receitas, "3º lugar no Universitário", int(eco["terceiro"]))
	interlajes = {"quartas": Competicoes.quartas(universitario_g8, universitario_posicoes), "semis": [], "final": {}, "campeao_id": ""}
	interlajes_eliminada = not universitario_g8.has("catolica")
	_rodape_competicao = "Universitário encerrado: Católica em %dº lugar." % pos
	if interlajes_eliminada:
		_encerrar_sem_catolica()

func _jogar_leg_interlajes(info: Dictionary, gp: int, gc: int, receitas: Array) -> void:
	var estagio: String = info["estagio"]
	var lado: String = info["lado"]
	var lista: Array = [interlajes["final"]] if estagio == "final" else interlajes[estagio]
	var minha: Dictionary = info["tie"]
	var cat_a: bool = minha["idA"] == "catolica"
	minha[lado] = [gp, gc] if cat_a else [gc, gp]
	for t in lista:
		if t == minha:
			continue
		var fa: float = _forca_clube(t["idA"])
		var fb: float = _forca_clube(t["idB"])
		if lado == "ida":
			var p1: Vector2i = Competicoes.placar_sim(fa, fb)
			t["ida"] = [p1.x, p1.y]
		else:
			var p2: Vector2i = Competicoes.placar_sim(fb, fa)
			t["volta"] = [p2.y, p2.x]
	if lado != "volta":
		return
	for t in lista:
		Competicoes.resolver_tie(t, _forca_clube(t["idA"]), _forca_clube(t["idB"]))
	var venceu: bool = minha["vencedor_id"] == "catolica"
	var pen: String = (" nos pênaltis (%s)" % minha["penaltis"]) if minha["penaltis"] != "" else ""
	if not venceu:
		interlajes_eliminada = true
		_rodape_competicao = "Eliminada do InterLajes%s. A temporada termina aqui." % pen
		_proximas_fases_sem_catolica()
		_encerrar_sem_catolica()
		return
	var eco: Dictionary = GameData.economia["interlajes"]
	var vencedores: Array = []
	for t in lista:
		vencedores.append(t["vencedor_id"])
	if estagio == "quartas":
		interlajes["semis"] = [Competicoes.tie_por_seed(vencedores[0], vencedores[3], universitario_posicoes),
			Competicoes.tie_por_seed(vencedores[1], vencedores[2], universitario_posicoes)]
		_premio(receitas, "Classificação para a semifinal do InterLajes", int(eco["avanco_semifinal"]))
		_rodape_competicao = "Classificada para a semifinal do InterLajes%s!" % pen
	elif estagio == "semis":
		interlajes["final"] = Competicoes.tie_por_seed(vencedores[0], vencedores[1], universitario_posicoes)
		_premio(receitas, "Classificação para a final do InterLajes", int(eco["avanco_final"]))
		_rodape_competicao = "Na final do InterLajes%s!" % pen
	else:
		interlajes["campeao_id"] = "catolica"
		_premio(receitas, "Campeão do InterLajes", int(eco["titulo"]))
		trofeus.append({"competicao": "Campeonato InterLajes", "titulo": "Campeão", "temporada": temporada})
		clube["reputacao"] = clampf(float(clube["reputacao"]) + 15.0, 0.0, 100.0)
		_rodape_competicao = "CAMPEÃ DO INTERLAJES%s! Vem aí a Copa dos Gigantes." % pen
		_montar_copa()

func _proximas_fases_sem_catolica() -> void:
	## Completa o chaveamento simulando tudo que falta (Católica já eliminada).
	for fase in ["quartas", "semis", "final"]:
		var lista: Array = [interlajes["final"]] if fase == "final" else interlajes[fase]
		if lista.is_empty() or (fase == "final" and interlajes["final"].is_empty()):
			var anterior: Array = interlajes["quartas"] if fase == "semis" else interlajes["semis"]
			var v: Array = []
			for t in anterior:
				v.append(t["vencedor_id"])
			if fase == "semis":
				interlajes["semis"] = [Competicoes.tie_por_seed(v[0], v[3], universitario_posicoes), Competicoes.tie_por_seed(v[1], v[2], universitario_posicoes)]
				lista = interlajes["semis"]
			elif fase == "final":
				interlajes["final"] = Competicoes.tie_por_seed(v[0], v[1], universitario_posicoes)
				lista = [interlajes["final"]]
		for t in lista:
			if t["vencedor_id"] == "":
				Competicoes.simular_tie(t, _forca_clube(t["idA"]), _forca_clube(t["idB"]))
	interlajes["campeao_id"] = interlajes["final"]["vencedor_id"]

func _encerrar_sem_catolica() -> void:
	if interlajes.get("campeao_id", "") == "":
		_proximas_fases_sem_catolica()
	fora_da_copa = true
	# a Copa é jogada "no fundo" entre o campeão do InterLajes e os 11 profissionais
	var campeao: Dictionary = clube_por_id(interlajes["campeao_id"]).duplicate(true)
	_montar_copa(campeao)
	for rd in copa_calendario:
		for q in rd:
			var m: Dictionary = _clube_copa(q["mandante_id"])
			var v: Dictionary = _clube_copa(q["visitante_id"])
			var ps: Vector2i = Competicoes.placar_sim(float(m["forca"]), float(v["forca"]))
			q["jogado"] = true
			q["placar_mandante"] = ps.x
			q["placar_visitante"] = ps.y
			Competicoes.aplicar_resultado(m, ps.x, ps.y)
			Competicoes.aplicar_resultado(v, ps.y, ps.x)
	copa_campeao_id = Competicoes.ordenar_tabela(copa)[0]["id"]
	temporada_status = "encerrada"

func _montar_copa(primeiro_clube = null) -> void:
	copa = []
	if primeiro_clube == null:
		var c: Dictionary = {"id": "catolica", "nome": "Católica FC", "nome_curto": "Católica", "sigla": "CFC",
			"cor1": "#C94F50", "cor2": "#8F3035", "forca": forca_catolica_dinamica, "estilo": "equilibrado"}
		copa.append(Competicoes.zerar_clube(c))
	else:
		copa.append(Competicoes.zerar_clube(primeiro_clube))
	for pro in GameData.clubes_copa:
		var d: Dictionary = _clonar(pro)
		if not d.has("nome_curto"):
			d["nome_curto"] = d["nome"]
		copa.append(Competicoes.zerar_clube(d))
	var ids: Array = []
	for c2 in copa:
		ids.append(c2["id"])
	copa_calendario = GameData.gerar_calendario(ids)

func _fechar_copa(receitas: Array) -> void:
	var ordem: Array = Competicoes.ordenar_tabela(copa)
	copa_campeao_id = ordem[0]["id"]
	var pos := 1
	for i in ordem.size():
		if ordem[i]["id"] == "catolica":
			pos = i + 1
	var eco: Dictionary = GameData.economia["copa"]
	if pos == 1:
		_premio(receitas, "Campeão da Copa dos Gigantes", int(eco["titulo"]))
		clube["reputacao"] = clampf(float(clube["reputacao"]) + 25.0, 0.0, 100.0)
		trofeus.append({"competicao": "Copa dos Gigantes", "titulo": "Campeão", "temporada": temporada})
	elif pos == 2:
		_premio(receitas, "Vice da Copa dos Gigantes", int(eco["vice"]))
	elif pos == 3:
		_premio(receitas, "3º lugar na Copa dos Gigantes", int(eco["terceiro"]))
	_rodape_competicao = "Copa dos Gigantes encerrada: Católica em %dº lugar." % pos
	temporada_status = "encerrada"

## Artilharia: gols da Católica por jogador (partida jogável informa os autores; na simulação sorteia por posição).
func _registrar_gols(placar_jogado, gols: int) -> void:
	var autores: Array = []
	if placar_jogado != null and placar_jogado.has("autores"):
		autores = placar_jogado["autores"]
	else:
		var pesos := {"ATAQUE": 28, "MEIA_ATAQUE": 18, "MEIA": 14, "MEIA_DEFENSOR": 10, "DEFENSOR": 5, "GOLEIRO": 1}
		var ts: Array = titulares()
		for i in gols:
			var total := 0
			for j in ts:
				total += int(pesos.get(j["posicao"], 5))
			var sorteio: int = randi() % maxi(1, total)
			for j in ts:
				sorteio -= int(pesos.get(j["posicao"], 5))
				if sorteio < 0:
					autores.append(j["nome"])
					break
	for nome in autores:
		gols_registrados[nome] = int(gols_registrados.get(nome, 0)) + 1

func artilharia(limite: int = 10) -> Array:
	var lista: Array = []
	for k in gols_registrados.keys():
		lista.append({"nome": k, "gols": int(gols_registrados[k])})
	lista.sort_custom(func(a, b): return a["gols"] > b["gols"])
	return lista.slice(0, limite)

func nova_temporada() -> void:
	temporada += 1
	_novas_metas()
	_novos_jovens()
	_novas_metas_pessoais()
	avaliacao_diretoria = ""
	for id in disciplina.keys():
		(disciplina[id] as Dictionary)["amarelos"] = 0      # amarelos zeram a cada temporada; suspensões pendentes continuam
	rodada_atual = 1
	temporada_status = "em_andamento"
	fase_rodada = "desafio"
	tatica_id = null
	resultado_rodada = null
	ultimos_resultados = []
	premios_temporada = []
	universitario_posicoes = {}
	universitario_g8 = []
	interlajes = {}
	interlajes_eliminada = false
	copa = []
	copa_calendario = []
	fora_da_copa = false
	copa_campeao_id = ""
	clubes = _clonar(GameData.clubes_universitario)
	for c in clubes:
		Competicoes.zerar_clube(c)
	var ids: Array = []
	for c in clubes:
		ids.append(c["id"])
	calendario = GameData.gerar_calendario(ids)
	for j in elenco:
		j["energia"] = 100.0
	var eco: Dictionary = GameData.economia
	if float(financas["caixa"]) < float(eco["caixa_minimo_nova_temporada"]):
		financas["caixa"] = float(financas["caixa"]) + float(eco["apoio_nova_temporada"])
	estado_mudou.emit()

## Fecha a rodada atual e avança para a próxima, resetando as flags de
## preparação/tática (evitando cobrança duplicada ou tática "grudada").
func avancar_rodada() -> void:
	scouting = {}
	_fechar_semana_lesoes()
	_fechar_semana_emprestimos()
	treino_confirmado = false
	relatorio_treino = []
	rodada_atual += 1
	fase_rodada = "desafio"
	tatica_id = null
	cartas_preparacao_escolhidas = []
	prep_confirmada = false
	forca_extra_preparacao = 0.0
	gasto_preparacao_rodada = 0
	resultado_rodada = null
	estado_mudou.emit()
