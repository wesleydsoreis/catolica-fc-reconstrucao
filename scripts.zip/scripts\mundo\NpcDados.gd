class_name NpcDados
extends RefCounted
## Conteúdo dos diálogos dos personagens do mundo. Tudo vem do estado real do jogo (GameState/GameData);
## as opções levam às telas reais de gestão.

const RETRATO := "res://assets/gerado/npcs/%s_retrato.png"
const RETRATO_REF := "res://assets/ui/ref/npcs/%s_retrato.png"

static func retrato(id: String) -> String:
	var r: String = RETRATO_REF % id
	return r if ResourceLoader.exists(r) else RETRATO % id
const NOMES := {"diretor": "DIRETOR", "treinador": "TREINADOR", "jogador": "JOGADOR", "torcedor": "TORCEDOR",
	"jornalista": "JORNALISTA", "medico": "MÉDICO", "arbitro": "ÁRBITRO", "olheiro": "OLHEIRO"}

static func _posicao() -> int:
	var raiz: Node = Engine.get_main_loop().root
	var m: Node = raiz.get_node_or_null("Main")
	if m != null and m.has_method("_posicao_clube"):
		return int(m.call("_posicao_clube"))
	return 1

static func _media(chave: String) -> float:
	var el: Array = GameState.elenco
	if el.is_empty():
		return 0.0
	var s := 0.0
	for j in el:
		s += float(j.get(chave, 0))
	return s / el.size()

static func _ultimo() -> String:
	var u: Array = GameState.ultimos_resultados
	if u.is_empty():
		return ""
	return str(u[u.size() - 1])

static func dialogo(id: String) -> Dictionary:
	var d: Dictionary = {"nome": NOMES.get(id, id.to_upper()), "retrato": retrato(id), "paginas": [], "opcoes": []}
	match id:
		"diretor": _diretor(d)
		"treinador": _treinador(d)
		"jogador": _jogador(d)
		"torcedor": _torcedor(d)
		"jornalista": _jornalista(d)
		"medico": _medico(d)
		"arbitro": _arbitro(d)
		"olheiro": _olheiro(d)
		_: d["paginas"] = ["..."]
	return d

static func _diretor(d: Dictionary) -> void:
	var caixa: int = int(GameState.financas.get("caixa", 0))
	var conf: int = int(GameState.financas.get("confianca_diretoria", 70))
	var folha := 0
	for j in GameState.elenco:
		folha += int(j.get("salario", 0))
	var p: Array = ["Bem-vindo à secretaria. O caixa está em %s e a confiança da diretoria em %d%%." % [Tema.reais(caixa), conf]]
	if caixa < 0:
		p.append("Estamos no vermelho. Corte gastos antes de contratar qualquer coisa.")
	else:
		p.append("A folha custa %s por rodada e a manutenção do estádio %s. A meta é terminar entre os 8 primeiros." % [Tema.reais(folha), Tema.reais(GameState.manutencao_estadio_total())])
	d["paginas"] = p
	d["opcoes"] = [{"txt": "Abrir o painel do clube", "tela": "painel"}, {"txt": "Ver as obras do estádio", "tela": "estadio_obras"}]

static func _treinador(d: Dictionary) -> void:
	var tat: String = "ainda não escolhi a tática"
	if GameState.tatica_id != null:
		tat = "tática %s" % str(GameData.obter_tatica(str(GameState.tatica_id)).get("nome", "")).to_lower()
	d["paginas"] = [
		"Nosso time está com força %d, na formação %s, e %s." % [GameState.forca_catolica_dinamica, GameState.formacao_id, tat],
		"Lembre da regra: ofensivo vence pressão, equilibrado vence ofensivo e defensivo vence contra-ataque. Em campo jogam 7, os melhores da escalação."]
	d["opcoes"] = [{"txt": "Escalação da partida (FUT7)", "tela": "escalacao"}, {"txt": "Elenco completo", "tela": "elenco"}]

static func _jogador(d: Dictionary) -> void:
	var tit: Array = GameState.titulares()
	var melhor: Dictionary = {}
	for j in tit:
		if melhor.is_empty() or int(j["overall"]) > int(melhor["overall"]):
			melhor = j
	var p: Array = []
	if melhor.is_empty():
		p.append("Estamos sem escalação definida. Fala com o treinador!")
	else:
		p.append("Eu sou %s, o camisa %s. Nosso melhor jogador é o %s, com overall %d." % [str(tit[0]["nome"]), str(tit[0].get("numero", "-")), str(melhor["nome"]), int(melhor["overall"])])
	var art: Array = GameState.artilharia(1)
	if art.is_empty():
		p.append("Ninguém marcou ainda nesta temporada. Está na hora de abrir o placar!")
	else:
		p.append("O artilheiro é o %s, com %d gol(s)." % [str(art[0]["nome"]), int(art[0]["gols"])])
	d["paginas"] = p
	d["opcoes"] = [{"txt": "Ver o elenco", "tela": "elenco"}]

static func _torcedor(d: Dictionary) -> void:
	var torcida: int = int(GameState.financas.get("torcida", 0))
	var u: String = _ultimo()
	var p: Array = ["A torcida da Católica está em %d%% de animação. Conta comigo!" % torcida]
	match u:
		"V": p.append("Que vitória na última rodada! Estamos em %dº lugar." % _posicao())
		"D": p.append("A última derrota doeu, mas a gente volta. Estamos em %dº." % _posicao())
		"E": p.append("O empate foi pouco. Precisamos vencer. Estamos em %dº." % _posicao())
		_: p.append("Ainda não vimos o time jogar nesta temporada. Quero ver o estádio cheio!")
	d["paginas"] = p
	d["opcoes"] = [{"txt": "Ver a tabela", "tela": "torneios"}]

static func _jornalista(d: Dictionary) -> void:
	var p: Array = []
	var info = GameState.obter_partida_da_rodada()
	if info == null:
		p.append("A Católica não tem jogo nesta rodada. Alguma notícia do clube?")
	else:
		var nomes := {"universitario": "Universitário", "interlajes": "InterLajes", "copa": "Copa dos Gigantes"}
		p.append("Próximo jogo pelo %s: contra %s, %s." % [nomes.get(info["competicao"], ""), str(info["adversario"].get("nome", "?")), "em casa" if info["em_casa"] else "fora de casa"])
	p.append("O time está em %dº lugar, com %d ponto(s). Qual é a meta da temporada?" % [_posicao(), int(GameState.clube_por_id("catolica").get("pontos", 0))])
	d["paginas"] = p
	d["opcoes"] = [{"txt": "Classificação e artilharia", "tela": "torneios"}]

static func _medico(d: Dictionary) -> void:
	var en: float = _media("energia")
	var lista: Array = GameState.elenco.duplicate()
	lista.sort_custom(func(a, b): return float(a["energia"]) < float(b["energia"]))
	var cansados: Array = []
	for j in lista.slice(0, 3):
		cansados.append("%s (%d%%)" % [str(j["nome"]), int(j["energia"])])
	var p: Array = ["A energia média do elenco é %d%%. Os mais cansados: %s." % [int(en), ", ".join(cansados)]]
	if en < 60.0:
		p.append("Está baixo. Escolha 'Recuperação Física' na preparação e poupe quem está no limite.")
	else:
		p.append("O grupo está bem. Mesmo assim, jogadores com energia baixa rendem menos em campo.")
	d["paginas"] = p
	d["opcoes"] = [{"txt": "Ver o elenco", "tela": "elenco"}]

static func _arbitro(d: Dictionary) -> void:
	d["paginas"] = [
		"Regras da casa: jogo de 7 contra 7, dois tempos, cada time com no máximo 3 trocas.",
		"Cartão amarelo avisa; vermelho tira o jogador, e o time segue com menos um. Carrinho sem bola é falta."]
	d["opcoes"] = [{"txt": "Ver a tabela", "tela": "torneios"}]

static func _olheiro(d: Dictionary) -> void:
	var caixa: float = float(GameState.financas.get("caixa", 0))
	var melhor: Dictionary = {}
	for j in GameState.mercado_jogadores:
		if float(j["preco"]) <= caixa and (melhor.is_empty() or int(j["overall"]) > int(melhor["overall"])):
			melhor = j
	var p: Array = []
	if melhor.is_empty():
		p.append("Tem talento no mercado, mas nada que caiba no seu caixa agora. Junte dinheiro.")
	else:
		p.append("Dentro do seu caixa, o melhor do mercado é %s, overall %d, por %s." % [str(melhor["nome"]), int(melhor["overall"]), Tema.reais(int(melhor["preco"]))])
		p.append("Confira a posição antes de contratar, para não pagar por quem não joga.")
	d["paginas"] = p
	d["opcoes"] = [{"txt": "Ir ao mercado", "tela": "mercado"}]
