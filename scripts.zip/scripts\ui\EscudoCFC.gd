extends Control
## Escudo do Católica FC (arte do modelo: escudo vermelho com "C" creme). Redimensiona pelo tamanho do nó.

@export var mostrar_tracos: bool = false
static var _tex: Texture2D

func _draw() -> void:
	if _tex == null:
		_tex = load("res://assets/ui/ref/escudo.png")
	var lado: float = minf(size.x, size.y)
	draw_texture_rect(_tex, Rect2((size - Vector2(lado, lado)) / 2.0, Vector2(lado, lado)), false)
