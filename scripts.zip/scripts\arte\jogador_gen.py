"""Gera a folha de ETIQUETAS dos jogadores chibi (célula 24x28, contorno automático).
Pixel = (R=etiqueta, G=sombra 0/1, A=255). Etiquetas: 1 pele, 2 cabelo, 3 camisa, 4 calção,
5 meia, 6 chuteira, 7 luva, 8 olho/sobrancelha, 11 manga/gola, 13 branco, 99 contorno.
O Godot recolore por clube (Player.gd). Também exporta preview colorido."""
import os, json
from PIL import Image
CW,CH=24,28
ANIMS=[]   # (nome, [frames])
def novo(): return Image.new("RGBA",(CW,CH),(0,0,0,0))
def pt(im,x,y,l,s=0):
    if 0<=x<CW and 0<=y<CH: im.putpixel((x,y),(l,s,0,255))
def re(im,x,y,w,h,l,s=0):
    for j in range(h):
        for i in range(w): pt(im,x+i,y+j,l,s)
def contorno(im):
    p=im.load(); out=im.copy(); q=out.load()
    for y in range(CH):
        for x in range(CW):
            if p[x,y][3]==0:
                for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
                    X,Y=x+dx,y+dy
                    if 0<=X<CW and 0<=Y<CH and p[X,Y][3]==255 and p[X,Y][0]!=99:
                        q[x,y]=(99,0,0,255); break
    return out
# ---------------------------------------------------------------- frente / costas
def fb(costas,pose='idle',t=0,gk=False):
    im=novo(); y0=2
    bob=1 if (pose=='run' and t in(1,3)) else 0
    y0+=bob
    L=lambda x,y,w,h,l,s=0: re(im,x,y,w,h,l,s)
    # pernas (antes do corpo)
    lv=[0,0]; ab=[0,0]
    if pose=='run':
        lv=[[0,0],[2,0],[0,0],[0,2]][t]; ab=[[0,0],[2,-2],[0,0],[-2,2]][t]
    if pose=='chute': lv=[0,3]
    ye=lambda i: y0+23-lv[i]
    for i,x in enumerate((8,14)):
        L(x,y0+19,3,3,4)                       # coxa/calção
        L(x,y0+22,3,max(1,3-lv[i]),5)           # meia
        L(x,y0+22+max(1,3-lv[i]),3,2,6)         # chuteira
    # tronco
    L(8,y0+11,8,8,3); L(15,y0+11,1,8,3,1); L(8,y0+18,8,1,3,1)
    L(8,y0+11,8,1,11)
    L(8,y0+19,8,3,4); L(15,y0+19,1,3,4,1); L(11,y0+20,2,2,4,1)
    # braços
    def braco(x,dy,lado):
        manga=11
        if pose=='festa':
            xx=x-1 if lado<0 else x
            L(xx,y0+5,3,6,manga); L(xx,y0+1,3,4,7 if gk else 1); L(xx+(0 if lado<0 else 2),y0+1,1,4,1,1); return
        L(x,y0+11+dy,2,3,manga); L(x,y0+14+dy,2,3,7 if gk else 1)
    braco(6,ab[0],-1); braco(16,ab[1],1)
    # cabeça
    L(7,y0+1,10,10,1); L(16,y0+2,1,8,1,1); L(7,y0+10,10,1,1,1); L(7,y0+1,10,1,1)
    if costas:
        L(7,y0,10,9,2); L(7,y0+8,10,1,2,1); L(6,y0+2,1,4,2); L(17,y0+2,1,4,2); L(9,y0+9,6,1,1,1)
    else:
        L(7,y0,10,3,2); L(6,y0+1,1,4,2); L(17,y0+1,1,4,2); L(9,y0-1,6,1,2); L(13,y0-1,3,1,2)
        L(8,y0+4,3,1,8); L(13,y0+4,3,1,8); L(10,y0+5,1,1,8); L(13,y0+5,1,1,8)     # sobrancelhas bravas
        L(9,y0+6,2,2,8); L(13,y0+6,2,2,8)                                          # olhos
        if pose=='festa': L(10,y0+9,4,1,8)
    return im
# ---------------------------------------------------------------- lado (virado para a direita)
def lado(pose='idle',t=0,gk=False):
    im=novo(); y0=2
    bob=1 if (pose=='run' and t in(1,3)) else 0
    y0+=bob
    L=lambda x,y,w,h,l,s=0: re(im,x,y,w,h,l,s)
    # (perna_trás_x, perna_frente_x, levantar_trás, levantar_frente)
    cfg=(0,0,0,0)
    if pose=='run': cfg=[(-3,3,0,0),(-1,1,2,0),(3,-3,0,0),(1,-1,0,2)][t]
    if pose=='chute': cfg=[(-5,-2,3,0),(-1,6,0,2)][t]   # [0]=preparar [1]=bater
    bx,fx,bl,fl=cfg
    def perna(cx,dx,lev,frente):
        L(cx,y0+19,3,3,4)
        for k in range(3):
            xx=cx+int(dx*(k+1)/3)
            yy=y0+22+k - (lev if k==2 else 0)
            L(xx,yy,3,1,5)
        xx=cx+dx
        L(xx+(1 if dx>=0 else 0),y0+24-lev,4,2,6)
    perna(10,bx,bl,False)
    # tronco (inclinado se chute)
    inc=-1 if pose=='chute' and t==1 else 0
    L(9+inc,y0+11,7,8,3); L(15+inc,y0+11,1,8,3,1); L(9+inc,y0+18,7,1,3,1); L(9+inc,y0+11,7,1,11)
    L(9,y0+19,7,3,4); L(15,y0+19,1,3,4,1)
    perna(13,fx,fl,True)
    # braço
    sw={'idle':(0,2),'run':[(-3,1),(0,3),(3,1),(0,3)][t] if pose=='run' else (0,2),'chute':(-3,1) if t==0 else (3,1)}[pose] if pose in('idle','chute') else [(-3,1),(0,3),(3,1),(0,3)][t]
    ax=12+sw[0]; ay=y0+12
    L(ax,ay,2,3,11); L(ax+(1 if sw[0]>0 else 0),ay+3,2,3,7 if gk else 1)
    # cabeça (perfil à direita)
    L(8+inc,y0+1,9,10,1); L(16+inc,y0+3,1,6,1,1); L(8+inc,y0+10,9,1,1,1)
    L(17+inc,y0+6,1,2,1,1)                          # nariz
    L(7+inc,y0,10,3,2); L(7+inc,y0+3,3,5,2); L(9+inc,y0-1,6,1,2); L(14+inc,y0-1,3,1,2)
    L(13+inc,y0+4,3,1,8); L(14+inc,y0+5,2,2,8)
    return im
def carrinho():
    im=novo(); L=lambda x,y,w,h,l,s=0: re(im,x,y,w,h,l,s)
    # cabeça à esquerda, corpo deitado, pés à direita
    L(1,16,8,8,1); L(1,16,8,3,2); L(1,19,2,4,2); L(8,18,1,5,1,1); L(5,20,2,1,8); L(3,20,1,1,8)
    L(9,17,8,6,3); L(9,22,8,1,3,1); L(9,17,8,1,11)
    L(17,17,4,5,4); L(17,21,4,1,4,1)
    L(20,18,3,2,5); L(22,18,2,3,6)               # perna frente erguida
    L(18,22,4,2,5); L(21,22,3,2,6)
    L(7,15,4,2,11); L(10,14,3,2,1)               # braço para trás/cima
    return im
def queda():
    im=novo(); L=lambda x,y,w,h,l,s=0: re(im,x,y,w,h,l,s)
    L(1,19,8,7,1); L(1,19,8,3,2); L(1,22,2,3,2); L(5,22,1,1,8); L(3,22,1,1,8); L(8,21,1,4,1,1)
    L(9,20,8,6,3); L(9,25,8,1,3,1); L(9,20,8,1,11)
    L(17,21,4,4,4); L(20,22,4,2,5); L(22,21,2,4,6)
    L(10,18,4,2,11); L(13,17,3,2,1)
    return im
def gk_dive(alto):
    im=novo(); L=lambda x,y,w,h,l,s=0: re(im,x,y,w,h,l,s)
    y=8 if alto else 16
    # corpo horizontal, olhando para a direita
    L(0,y+3,4,3,5); L(0,y+4,2,3,6)                 # pernas
    L(3,y+2,5,5,4)
    L(7,y+1,7,6,3); L(7,y+6,7,1,3,1); L(7,y+1,7,1,11)
    L(14,y,6,6,1); L(14,y-1,6,3,2); L(18,y+2,2,1,8); L(17,y+3,1,2,8); L(20,y+2,1,2,1,1)
    L(12,y+2,9,2,11); L(20,y+1,4,3,7)              # braço estendido com luva
    L(10,y-2,4,3,11); L(13,y-4,4,3,7)              # braço de cima
    return im
def festa(t):
    im=fb(False,'festa',t)
    if t==1:
        out=novo(); out.paste(im,(0,-1),im); return out
    return im
def montar():
    A=[]
    A.append(("idle_f",[fb(False)])); A.append(("idle_b",[fb(True)])); A.append(("idle_s",[lado()]))
    A.append(("run_f",[fb(False,'run',t) for t in range(4)]))
    A.append(("run_b",[fb(True,'run',t) for t in range(4)]))
    A.append(("run_s",[lado('run',t) for t in range(4)]))
    A.append(("chute_s",[lado('chute',0),lado('chute',1)]))
    A.append(("chute_f",[fb(False,'chute',0)])); A.append(("chute_b",[fb(True,'chute',0)]))
    A.append(("carrinho",[carrinho()])); A.append(("queda",[queda()]))
    A.append(("festa",[festa(0),festa(1)]))
    A.append(("gk_baixo",[gk_dive(False)])); A.append(("gk_alto",[gk_dive(True)]))
    return [(n,[contorno(f) for f in fr]) for n,fr in A]
def exportar(out):
    A=montar(); linhas=len(A); larg=max(len(f) for _,f in A)
    sh=Image.new("RGBA",(larg*CW,linhas*CH),(0,0,0,0)); meta={}
    for r,(n,fr) in enumerate(A):
        meta[n]={"linha":r,"quadros":len(fr)}
        for i,f in enumerate(fr): sh.paste(f,(i*CW,r*CH))
    sh.save(os.path.join(out,"jogadores_labels.png")); json.dump(dict(cw=CW,ch=CH,anims=meta),open(os.path.join(out,"jogadores.json"),"w"))
    return sh
def recolor(sh,pal):
    o=sh.copy(); p=o.load()
    for y in range(o.height):
        for x in range(o.width):
            r,g,b,a=p[x,y]
            if a==0: continue
            c=pal[r]
            if g: c=tuple(int(v*.82) for v in c)
            p[x,y]=c+(255,)
    return o
def h(s): s=s.lstrip('#'); return tuple(int(s[i:i+2],16) for i in (0,2,4))
def paleta(camisa,manga,calcao,meia,bota,pele,cab,luva='#f2f2f2'):
    return {1:h(pele),2:h(cab),3:h(camisa),4:h(calcao),5:h(meia),6:h(bota),7:h(luva),8:(36,24,18),11:h(manga),13:(255,255,255),99:(20,16,28)}
if __name__=="__main__":
    out=os.path.join(os.path.dirname(__file__),"..","..","assets","gerado"); sh=exportar(out)
    pal=paleta('#D8202F','#F2C81C','#F0F0F0','#F0F0F0','#1B1B24','#D98C4E','#241812')
    pv=recolor(sh,pal)
    bg=Image.new("RGBA",pv.size,(18,160,18,255)); bg.alpha_composite(pv)
    bg.resize((pv.width*5,pv.height*5),Image.NEAREST).convert("RGB").save("/tmp/s2/img/e4_folha.png")
