extends Control
## Torneios: tabelas do Universitário e da Copa, chaveamento do InterLajes e artilharia.

var _abas: TabContainer

func _ready() -> void:
	var raiz := VBoxContainer.new()
	raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	raiz.add_theme_constant_override("separation", 8)
	add_child(raiz)
	raiz.add_child(Tema.titulo_secao("Federação · Temporada %d" % GameState.temporada))
	_abas = TabContainer.new()
	_abas.name = "Abas"
	_abas.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_abas.add_theme_stylebox_override("panel", Tema.caixa(Tema.BRANCO, Tema.TINTA, 3, 8, true, 8))
	raiz.add_child(_abas)
	_abas.add_child(_aba_tabela("Univ.", GameState.clubes, 8))
	_abas.add_child(_aba_calendario())
	_abas.add_child(_aba_interlajes())
	_abas.add_child(_aba_tabela("Copa", GameState.copa, 0))
	_abas.add_child(_aba_artilharia())
	_abas.add_child(_aba_trofeus())
	var nomes := ["Univ.", "Jogos", "InterLajes", "Copa", "Artilharia", "Troféus"]
	for i in nomes.size():
		_abas.set_tab_title(i, nomes[i])
	var voltar := Tema.botao("VOLTAR", "escuro", 46)
	voltar.pressed.connect(func(): SceneManager.voltar())
	raiz.add_child(voltar)

func _rolagem(nome: String) -> Array:
	var rol := ScrollContainer.new()
	rol.name = nome
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 5)
	rol.add_child(col)
	return [rol, col]

## Linha em cartão: o destaque (Católica) fica amarelo, com borda fina de tinta.
func _linha(textos: Array, larguras: Array, destaque: bool = false, cabecalho: bool = false) -> Control:
	var pc := PanelContainer.new()
	if cabecalho:
		pc.add_theme_stylebox_override("panel", StyleBoxEmpty.new())
	else:
		pc.add_theme_stylebox_override("panel", Tema.caixa(Tema.AMARELO if destaque else Tema.CREME, Tema.TINTA, 2, 6, false, 5))
	var h := HBoxContainer.new()
	pc.add_child(h)
	for i in textos.size():
		var l := Label.new()
		l.text = str(textos[i])
		l.custom_minimum_size = Vector2(larguras[i], 0)
		l.add_theme_font_size_override("font_size", 12 if cabecalho else 13)
		if i == 1:
			l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			l.clip_text = true
		else:
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_color_override("font_color", Tema.TITULO if cabecalho else Tema.TINTA)
		h.add_child(l)
	return pc

func _aba_tabela(nome: String, lista: Array, corte: int) -> Control:
	var rc: Array = _rolagem(nome)
	var col: VBoxContainer = rc[1]
	if lista.is_empty():
		col.add_child(_aviso("A Copa dos Gigantes só é disputada pelo campeão do InterLajes."))
		return rc[0]
	var larg: Array = [26, 100, 34, 28, 28, 28, 28]
	col.add_child(_linha(["#", "Clube", "Pts", "J", "V", "E", "D"], larg, false, true))
	var ordem: Array = Competicoes.ordenar_tabela(lista)
	for i in ordem.size():
		var c: Dictionary = ordem[i]
		col.add_child(_linha([i + 1, c.get("nome_curto", c["nome"]), c["pontos"], c["jogos"], c["vitorias"], c["empates"], c["derrotas"]], larg, c["id"] == "catolica"))
		if corte > 0 and i + 1 == corte:
			var z := Tema.chip("ZONA DE CLASSIFICAÇÃO AO INTERLAJES (G8)", Tema.VERDE)
			z.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
			col.add_child(z)
	return rc[0]

func _aviso(t: String) -> Label:
	var l := Label.new()
	l.text = t
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", 13)
	l.add_theme_color_override("font_color", Tema.TEXTO)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l

## Calendário do Universitário: jogos da Católica rodada a rodada + resumo de campanha.
func _aba_calendario() -> Control:
	var rc: Array = _rolagem("Jogos")
	var col: VBoxContainer = rc[1]
	var v := 0
	var e := 0
	var d := 0
	var gp := 0
	var gc := 0
	var linhas: Array = []
	for r in GameState.calendario.size():
		for m in GameState.calendario[r]:
			if m["mandante_id"] != "catolica" and m["visitante_id"] != "catolica":
				continue
			var casa: bool = m["mandante_id"] == "catolica"
			var adv: String = _nome(m["visitante_id"] if casa else m["mandante_id"])
			var res := "—"
			var cor: Color = Tema.CREME
			if m["jogado"]:
				var a: int = int(m["placar_mandante"] if casa else m["placar_visitante"])
				var b: int = int(m["placar_visitante"] if casa else m["placar_mandante"])
				gp += a
				gc += b
				res = "%d x %d" % [a, b]
				if a > b:
					v += 1
					cor = Tema.VERDE.lightened(0.45)
				elif a == b:
					e += 1
					cor = Tema.AMARELO.lightened(0.5)
				else:
					d += 1
					cor = Tema.ROSA
			elif r + 1 == GameState.rodada_atual and GameState.temporada_status == "em_andamento":
				cor = Tema.AMARELO
			linhas.append([r + 1, ("vs " if casa else "@ ") + adv, res, cor])
	var resumo := Tema.cartao(Tema.BRANCO, 8)
	var hr := HBoxContainer.new()
	hr.alignment = BoxContainer.ALIGNMENT_CENTER
	hr.add_theme_constant_override("separation", 6)
	hr.add_child(Tema.chip("%dV" % v, Tema.VERDE))
	hr.add_child(Tema.chip("%dE" % e, Tema.LARANJA))
	hr.add_child(Tema.chip("%dD" % d, Tema.VINHO))
	hr.add_child(Tema.chip("GOLS %d-%d" % [gp, gc], Tema.AZUL))
	resumo.add_child(hr)
	col.add_child(resumo)
	for l in linhas:
		var pc := PanelContainer.new()
		pc.add_theme_stylebox_override("panel", Tema.caixa(l[3], Tema.TINTA, 2, 6, false, 6))
		var h := HBoxContainer.new()
		pc.add_child(h)
		var r := Tema.rotulo("R%d" % l[0], 12, Tema.TITULO)
		r.custom_minimum_size.x = 34
		r.size_flags_horizontal = Control.SIZE_FILL
		r.autowrap_mode = TextServer.AUTOWRAP_OFF
		h.add_child(r)
		var n := Tema.rotulo(str(l[1]), 14)
		n.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		n.autowrap_mode = TextServer.AUTOWRAP_OFF
		n.clip_text = true
		h.add_child(n)
		var rs := Tema.rotulo(str(l[2]), 14)
		rs.size_flags_horizontal = Control.SIZE_FILL
		rs.autowrap_mode = TextServer.AUTOWRAP_OFF
		h.add_child(rs)
		col.add_child(pc)
	var nota := _aviso("Depois da 11ª rodada: InterLajes (mata-mata dos 8 primeiros) e Copa dos Gigantes para o campeão.")
	col.add_child(nota)
	return rc[0]

func _nome(id: String) -> String:
	var c: Dictionary = GameState.clube_por_id(id)
	return str(c.get("nome_curto", c.get("nome", id)))

func _tie_texto(t: Dictionary) -> String:
	var ida: String = "-" if int(t["ida"][0]) < 0 else "%d-%d" % [t["ida"][0], t["ida"][1]]
	var volta: String = "-" if int(t["volta"][0]) < 0 else "%d-%d" % [t["volta"][0], t["volta"][1]]
	var s := "%s x %s\n   Ida %s · Volta %s" % [_nome(t["idA"]), _nome(t["idB"]), ida, volta]
	if t["vencedor_id"] != "":
		s += "\n   ✔ %s (agregado %d-%d%s)" % [_nome(t["vencedor_id"]), t["agregado_a"], t["agregado_b"], (" · pên. " + t["penaltis"]) if t["penaltis"] != "" else ""]
	return s

func _aba_interlajes() -> Control:
	var rc: Array = _rolagem("InterLajes")
	var col: VBoxContainer = rc[1]
	if GameState.interlajes.is_empty():
		col.add_child(_aviso("A chave do InterLajes será definida ao final da 11ª rodada do Universitário, com os 8 primeiros colocados."))
		return rc[0]
	col.add_child(ChaveInterlajes.new())
	return rc[0]

func _aba_artilharia() -> Control:
	var rc: Array = _rolagem("Artilharia")
	var col: VBoxContainer = rc[1]
	var lista: Array = GameState.artilharia(12)
	if lista.is_empty():
		col.add_child(_aviso("Ainda não há gols registrados."))
	col.add_child(_linha(["#", "Jogador", "Gols"], [26, 100, 44], false, true)) if not lista.is_empty() else null
	for i in lista.size():
		col.add_child(_linha([i + 1, lista[i]["nome"], lista[i]["gols"]], [26, 100, 44], i == 0))
	return rc[0]

func _aba_trofeus() -> Control:
	var rc: Array = _rolagem("Troféus")
	var col: VBoxContainer = rc[1]
	if GameState.trofeus.is_empty():
		col.add_child(_aviso("Nenhum troféu ainda. Bora buscar o primeiro!"))
	for t in GameState.trofeus:
		var c := Tema.cartao(Tema.AMARELO, 8)
		c.add_child(Tema.rotulo("🏆 %s — %s (T%d)" % [t["competicao"], t["titulo"], t["temporada"]], 14))
		col.add_child(c)
	return rc[0]
