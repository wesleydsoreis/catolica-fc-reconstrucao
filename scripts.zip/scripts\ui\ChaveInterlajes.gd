class_name ChaveInterlajes
extends Control
## Chaveamento do InterLajes (quartas, semifinal e final) em pixel art, ligado ao GameState.

const VERDE: Color = Color("8F303A")
const PONTO: Color = Color("A5434D")
const PRETO: Color = Color("120c0a")

func _ready() -> void:
	custom_minimum_size = Vector2(0, 640)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _crest(id: String, esc: float = 1.0) -> Array:
	if id == "":
		return []
	var c: Dictionary = GameState.clube_por_id(id)
	var sigla: String = str(c.get("sigla", id))
	return [PixelUI.escudo(Color(str(c.get("cor1", "#888888"))), Color(str(c.get("cor2", "#ffffff"))), sigla.substr(0, 1), 30, 36), esc]

func _desenha_crest(id: String, pos: Vector2, dest: bool, opaco: bool = true) -> void:
	var cr: Array = _crest(id)
	if cr.is_empty():
		draw_rect(Rect2(pos, Vector2(34, 40)), Color("46464c"))
		draw_rect(Rect2(pos, Vector2(34, 40)), PRETO, false, 2.0)
		draw_rect(Rect2(pos + Vector2(2, 2), Vector2(30, 5)), Color("6e6e76"))
		return
	var tex: Texture2D = cr[0]
	draw_texture(tex, pos, Color(1, 1, 1, 1.0 if opaco else 0.4))
	if dest:
		draw_rect(Rect2(pos - Vector2(3, 3), Vector2(tex.get_width() + 6, tex.get_height() + 6)), Color("ffee3c"), false, 3.0)

func _vencedor(t: Dictionary) -> String:
	return str(t.get("vencedor_id", "")) if not t.is_empty() else ""

func _draw() -> void:
	var s: Vector2 = size
	draw_rect(Rect2(Vector2.ZERO, s), VERDE)
	for y in range(0, int(s.y), 6):
		for x in range((y / 6 % 2) * 6, int(s.x), 12):
			draw_rect(Rect2(x, y, 2, 2), PONTO)
	var il: Dictionary = GameState.interlajes
	if il.is_empty():
		return
	var tt: Texture2D = PixelUI.letreiro("INTERLAJES", 3 if s.x < 600.0 else 4)
	draw_texture(tt, Vector2((s.x - tt.get_width()) * 0.5, 4))
	var quartas: Array = il.get("quartas", [])
	var semis: Array = il.get("semis", [])
	var fin: Dictionary = il.get("final", {})
	var topo: float = tt.get_height() + 26.0
	var passo: float = (s.y - topo - 14.0) / 4.0
	var xq: float = 14.0
	var xs: float = s.x * 0.40
	var xf: float = s.x * 0.74
	var cent_q: Array = []
	for i in 4:
		var y: float = topo + passo * float(i) + 4.0
		var t: Dictionary = quartas[i] if i < quartas.size() else {}
		var ida: String = str(t.get("idA", ""))
		var idb: String = str(t.get("idB", ""))
		var venc: String = _vencedor(t)
		_desenha_crest(ida, Vector2(xq, y), venc == ida and venc != "", venc == "" or venc == ida)
		_desenha_crest(idb, Vector2(xq, y + 42.0), venc == idb and venc != "", venc == "" or venc == idb)
		cent_q.append(y + 40.0)
		if not t.is_empty():
			var a: Array = t["ida"]
			var b: Array = t["volta"]
			var l1: String = "IDA %s" % ("-" if int(a[0]) < 0 else "%d-%d" % [a[0], a[1]])
			var l2: String = "VOLTA %s" % ("-" if int(b[0]) < 0 else "%d-%d" % [b[0], b[1]])
			draw_texture(PixelUI.texto(l1, 1, Color.WHITE, Color("0a3a14")), Vector2(xq + 42.0, y + 8.0))
			draw_texture(PixelUI.texto(l2, 1, Color.WHITE, Color("0a3a14")), Vector2(xq + 42.0, y + 22.0))
			if venc != "":
				draw_texture(PixelUI.texto("AGR %d-%d" % [t["agregado_a"], t["agregado_b"]], 1, Color("ffee3c"), Color("0a3a14")), Vector2(xq + 42.0, y + 50.0))
		# ligação até a semifinal
		draw_line(Vector2(xq + 36.0 + 70.0, y + 40.0), Vector2(xs - 8.0, y + 40.0), PRETO, 3.0)
	var cent_s: Array = []
	for i in 2:
		var ys: float = (float(cent_q[i * 2]) + float(cent_q[i * 2 + 1])) * 0.5
		cent_s.append(ys)
		draw_line(Vector2(xs - 8.0, float(cent_q[i * 2])), Vector2(xs - 8.0, float(cent_q[i * 2 + 1])), PRETO, 3.0)
		var ts: Dictionary = semis[i] if i < semis.size() else {}
		var a_id: String = str(ts.get("idA", ""))
		var b_id: String = str(ts.get("idB", ""))
		if ts.is_empty():
			var qa: Dictionary = quartas[i * 2] if i * 2 < quartas.size() else {}
			var qb: Dictionary = quartas[i * 2 + 1] if i * 2 + 1 < quartas.size() else {}
			a_id = _vencedor(qa)
			b_id = _vencedor(qb)
		var vs: String = _vencedor(ts)
		draw_line(Vector2(xs - 8.0, ys), Vector2(xs, ys), PRETO, 3.0)
		_desenha_crest(a_id, Vector2(xs, ys - 42.0), vs == a_id and vs != "", vs == "" or vs == a_id)
		_desenha_crest(b_id, Vector2(xs, ys + 2.0), vs == b_id and vs != "", vs == "" or vs == b_id)
		draw_line(Vector2(xs + 38.0, ys), Vector2(xf - 8.0, ys), PRETO, 3.0)
	var yf: float = (float(cent_s[0]) + float(cent_s[1])) * 0.5
	draw_line(Vector2(xf - 8.0, float(cent_s[0])), Vector2(xf - 8.0, float(cent_s[1])), PRETO, 3.0)
	draw_line(Vector2(xf - 8.0, yf), Vector2(xf, yf), PRETO, 3.0)
	var fa: String = str(fin.get("idA", ""))
	var fb: String = str(fin.get("idB", ""))
	if fin.is_empty():
		for i in 2:
			var ts2: Dictionary = semis[i] if i < semis.size() else {}
			if i == 0:
				fa = _vencedor(ts2)
			else:
				fb = _vencedor(ts2)
	var vf: String = _vencedor(fin)
	_desenha_crest(fa, Vector2(xf, yf - 42.0), vf == fa and vf != "", vf == "" or vf == fa)
	_desenha_crest(fb, Vector2(xf, yf + 2.0), vf == fb and vf != "", vf == "" or vf == fb)
	draw_texture(PixelUI.texto("FINAL", 1, Color.WHITE, Color("0a3a14")), Vector2(xf, yf - 56.0))
	draw_texture(PixelUI.texto("SEMI", 1, Color.WHITE, Color("0a3a14")), Vector2(xs, float(cent_s[0]) - 56.0))
	draw_texture(PixelUI.texto("QUARTAS", 1, Color.WHITE, Color("0a3a14")), Vector2(xq, topo - 12.0))
	var camp: String = str(il.get("campeao_id", ""))
	if camp != "":
		var cn: Texture2D = PixelUI.letreiro("CAMPEAO", 2)
		draw_texture(cn, Vector2(s.x * 0.5 - cn.get_width() * 0.5 + 40.0, s.y - 52.0))
		_desenha_crest(camp, Vector2(s.x * 0.5 - cn.get_width() * 0.5 - 4.0, s.y - 56.0), true)
