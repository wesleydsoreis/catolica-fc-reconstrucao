extends Node2D
class_name BolaVis
## Apresentação da bola: 4 quadros de rotação, sombra no chão que se afasta com a altura,
## quique e poeira. Recebe a posição lógica (x, y, z) e projeta para a tela.
signal quicou(pos_tela: Vector2, forca: float)
const ESC_Z := 0.14
var _spr: Sprite2D
var _sombra: Sprite2D
var _rot: float = 0.0
var _z_ant: float = 0.0
var _vz_ant: float = 0.0
var _pos_ant: Vector2 = Vector2.ZERO

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_sombra = Sprite2D.new()
	_sombra.texture = Player._sombra_tex()
	_sombra.scale = Vector2(0.6, 0.6)
	add_child(_sombra)
	_spr = Sprite2D.new()
	_spr.texture = load("res://assets/gerado/bola_quadros.png")
	_spr.region_enabled = true
	_spr.region_rect = Rect2(0, 0, 8, 8)
	add_child(_spr)

func colocar(x: float, y: float, z: float, vz: float = 0.0) -> void:
	var s: Vector2 = Pitch.project(x, y)
	position = s.round()
	var alt: float = z * ESC_Z
	_spr.position = Vector2(0, -4 - alt).round()
	_sombra.position = Vector2(0, -1)
	var k: float = clampf(1.0 - z * 0.004, 0.45, 1.0)
	_sombra.scale = Vector2(0.6 * k, 0.6 * k)
	_sombra.modulate.a = clampf(1.0 - z * 0.005, 0.4, 1.0)
	var d: float = (s - _pos_ant).length()
	_rot += d * 0.45
	_pos_ant = s
	_spr.region_rect = Rect2((int(_rot) % 4) * 8, 0, 8, 8)
	if _z_ant > 2.0 and z <= 0.5 and _vz_ant < -40.0:
		quicou.emit(s, absf(_vz_ant))
	_z_ant = z
	_vz_ant = vz
