class_name Tema
extends RefCounted
## Identidade visual das telas de gestão (inspirada no jogo web original):
## fundo creme, cartões com contorno grosso e sombra dura, títulos em vinho,
## botões laranja e abas escuras, barras com contorno.

const CREME := Color("F7F2E4")
const TINTA := Color("1F1511")
const VINHO := Color("8F303A")
const AMARELO := Color("F2C14E")
const LARANJA := Color("F28C28")
const VERDE := Color("8CA45B")
const AZUL := Color("3B6E9E")
const BRANCO := Color("FFFDF6")
const ROSA := Color("F0D2CF")
const PAINEL := Color("5A1420")       # painéis escuros (modelo)
const PAINEL2 := Color("6E1B28")
const PAINEL_BORDA := Color("8A3340")
const TEXTO := Color("F7F2E4")
const TEXTO2 := Color("D9C3B0")
const TITULO := Color("F2C14E")
const LARGURA_MAX := 980.0     # largura da "coluna de celular" em telas largas

static func caixa(fundo: Color, borda: Color = TINTA, bw: int = 3, raio: int = 8, sombra: bool = true, margem: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	if fundo == BRANCO:
		fundo = PAINEL
	elif fundo == ROSA:
		fundo = PAINEL2
	if borda == TINTA and (fundo == PAINEL or fundo == PAINEL2):
		borda = PAINEL_BORDA
	s.bg_color = fundo
	s.border_color = borda
	s.set_border_width_all(bw)
	s.set_corner_radius_all(raio)
	if sombra:
		s.shadow_color = Color(TINTA.r, TINTA.g, TINTA.b, 0.9)
		s.shadow_offset = Vector2(3, 4)
		s.shadow_size = 0
	s.content_margin_left = margem
	s.content_margin_right = margem
	s.content_margin_top = margem * 0.8
	s.content_margin_bottom = margem * 0.8
	return s

static func _botao_estilos(fundo: Color, claro: Color) -> Dictionary:
	var n: StyleBoxFlat = caixa(fundo, TINTA, 3, 8, true, 10)
	n.border_width_bottom = 6
	var h: StyleBoxFlat = caixa(claro, TINTA, 3, 8, true, 10)
	h.border_width_bottom = 6
	var p: StyleBoxFlat = caixa(fundo.darkened(0.12), TINTA, 3, 8, false, 10)
	p.border_width_top = 6
	p.shadow_size = 0
	var d: StyleBoxFlat = caixa(Color("46141C"), Color("2A0A10"), 3, 8, false, 10)
	return {"normal": n, "hover": h, "pressed": p, "disabled": d, "focus": caixa(Color(0, 0, 0, 0), AMARELO, 3, 8, false, 10)}

static func aplicar_botao(b: Button, estilo: String = "primario") -> void:
	var fundo: Color = LARANJA
	var claro: Color = Color("F9A24A")
	var txt: Color = Color("2A130A")
	match estilo:
		"secundario": fundo = PAINEL2; claro = Color("84243A"); txt = TEXTO
		"escuro": fundo = Color("45141E"); claro = Color("5A1C28"); txt = TEXTO
		"perigo": fundo = Color("C94F50"); claro = Color("DE6A6B"); txt = BRANCO
		"ouro": fundo = AMARELO; claro = Color("F8D77A")
		"verde": fundo = VERDE; claro = Color("A3BC72")
	var st: Dictionary = _botao_estilos(fundo, claro)
	for k in st.keys():
		b.add_theme_stylebox_override(k, st[k])
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(c, txt)
	b.add_theme_color_override("font_disabled_color", Color("9C7E78"))

static func construir() -> Theme:
	var t := Theme.new()
	t.default_font_size = 15
	var st: Dictionary = _botao_estilos(LARANJA, Color("F9A24A"))
	for k in st.keys():
		t.set_stylebox(k, "Button", st[k])
	t.set_color("font_color", "Button", Color("2A130A"))
	t.set_color("font_hover_color", "Button", Color("2A130A"))
	t.set_color("font_pressed_color", "Button", Color("2A130A"))
	t.set_color("font_focus_color", "Button", Color("2A130A"))
	t.set_color("font_disabled_color", "Button", Color("9C7E78"))
	t.set_font_size("font_size", "Button", 14)
	t.set_color("font_color", "Label", TEXTO)
	t.set_font_size("font_size", "Label", 15)
	t.set_stylebox("panel", "PanelContainer", caixa(BRANCO))
	t.set_stylebox("panel", "Panel", caixa(BRANCO))
	var barra_fundo: StyleBoxFlat = caixa(Color("2A0A10"), TINTA, 2, 8, false, 0)
	t.set_stylebox("background", "ProgressBar", barra_fundo)
	var barra_cheia: StyleBoxFlat = caixa(VINHO, TINTA, 0, 6, false, 0)
	t.set_stylebox("fill", "ProgressBar", barra_cheia)
	t.set_stylebox("normal", "LineEdit", caixa(Color("2A0A10"), TINTA, 3, 8, false, 10))
	t.set_stylebox("focus", "LineEdit", caixa(BRANCO, LARANJA, 3, 8, false, 10))
	t.set_color("font_color", "LineEdit", TEXTO)
	var sl: StyleBoxFlat = caixa(CREME, TINTA, 2, 6, false, 0)
	t.set_stylebox("slider", "HSlider", sl)
	t.set_stylebox("grabber_area", "HSlider", caixa(VINHO, TINTA, 2, 6, false, 0))
	t.set_stylebox("grabber_area_highlight", "HSlider", caixa(VINHO, TINTA, 2, 6, false, 0))
	t.set_stylebox("panel", "PopupPanel", caixa(BRANCO))
	t.set_stylebox("panel", "AcceptDialog", caixa(BRANCO))
	t.set_color("font_color", "CheckBox", TEXTO)
	var ts: StyleBoxFlat = caixa(TINTA, TINTA, 3, 8, false, 8)
	ts.corner_radius_bottom_left = 0
	ts.corner_radius_bottom_right = 0
	var tu: StyleBoxFlat = caixa(PAINEL2, TINTA, 3, 8, false, 8)
	tu.corner_radius_bottom_left = 0
	tu.corner_radius_bottom_right = 0
	for n in ["TabContainer", "TabBar"]:
		t.set_stylebox("tab_selected", n, ts)
		t.set_stylebox("tab_unselected", n, tu)
		t.set_stylebox("tab_hovered", n, tu)
		t.set_color("font_selected_color", n, BRANCO)
		t.set_color("font_unselected_color", n, TEXTO)
		t.set_color("font_hovered_color", n, TEXTO)
		t.set_font_size("font_size", n, 13)
	return t

# ---------------------------------------------------------------- componentes
## Texto escuro dentro de cartões amarelos (destaque do modelo).
static func texto_escuro(n: Node) -> void:
	for c in n.get_children():
		if c is Label:
			(c as Label).add_theme_color_override("font_color", TINTA)
		texto_escuro(c)

static func cartao(fundo: Color = BRANCO, margem: int = 12) -> PanelContainer:
	var p := PanelContainer.new()
	if fundo == AMARELO:
		p.tree_entered.connect(func(): texto_escuro.call_deferred(p))
	p.add_theme_stylebox_override("panel", caixa(fundo, TINTA, 3, 10, true, margem))
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return p

static func titulo_secao(texto: String) -> Label:
	var l := Label.new()
	l.text = texto.to_upper()
	l.add_theme_color_override("font_color", TITULO)
	l.add_theme_font_size_override("font_size", 15)
	return l

static func rotulo(texto: String, tam: int = 14, cor: Color = TEXTO) -> Label:
	var l := Label.new()
	l.text = texto
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", tam)
	l.add_theme_color_override("font_color", cor)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

static func botao(texto: String, estilo: String = "primario", altura: float = 46.0) -> Button:
	var b := Button.new()
	b.text = texto
	b.custom_minimum_size = Vector2(0, altura)
	b.clip_text = true
	aplicar_botao(b, estilo)
	return b

static func chip(texto: String, cor: Color = VERDE, cor_txt: Color = BRANCO) -> PanelContainer:
	var p := PanelContainer.new()
	var s: StyleBoxFlat = caixa(cor, TINTA, 2, 14, false, 8)
	s.content_margin_top = 2
	s.content_margin_bottom = 2
	p.add_theme_stylebox_override("panel", s)
	var l := Label.new()
	l.text = texto
	l.add_theme_font_size_override("font_size", 11)
	l.add_theme_color_override("font_color", cor_txt)
	p.add_child(l)
	return p

## Linha "Título ........ valor" com barra de progresso (0..100) como no painel web.
static func barra(titulo: String, valor: float, cor: Color, sufixo: String = "") -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 3)
	var h := HBoxContainer.new()
	var a := Label.new()
	a.text = titulo
	a.add_theme_font_size_override("font_size", 14)
	a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b := Label.new()
	b.text = "%d%s" % [int(round(valor)), sufixo]
	b.add_theme_font_size_override("font_size", 14)
	h.add_child(a)
	h.add_child(b)
	v.add_child(h)
	var pb := ProgressBar.new()
	pb.min_value = 0
	pb.max_value = 100
	pb.value = clampf(valor, 0.0, 100.0)
	pb.show_percentage = false
	pb.custom_minimum_size = Vector2(0, 14)
	pb.add_theme_stylebox_override("fill", caixa(cor, TINTA, 0, 6, false, 0))
	v.add_child(pb)
	return v

static func reais(v: int) -> String:
	var tx := str(absi(v))
	var r := ""
	for i in range(tx.length() - 1, -1, -1):
		r = tx[i] + r
		if (tx.length() - i) % 3 == 0 and i != 0:
			r = "." + r
	return ("-" if v < 0 else "") + "R$ " + r

static func fundo_pontilhado() -> ImageTexture:
	var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	img.fill(Color("2C0A11"))
	for y in range(0, 16, 8):
		for x in range(0, 16, 8):
			var o: int = 4 if (y / 8) % 2 == 1 else 0
			img.set_pixel(x + o, y, Color("38101A"))
			img.set_pixel(x + o + 1, y, Color("38101A"))
			img.set_pixel(x + o, y + 1, Color("38101A"))
			img.set_pixel(x + o + 1, y + 1, Color("38101A"))
	return ImageTexture.create_from_image(img)
