extends Control
## Desafio do Diretor: um problema por rodada, gerado com os dados reais da carreira. Errar mostra o passo a passo e permite nova tentativa.

var _col: VBoxContainer
var _prob: Dictionary = {}
var _calc: Calculadora = null
var _dica_aberta: bool = false
var _ultima: Dictionary = {}

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	mg.add_child(_col)
	GameState.iniciar_cronometro_desafio()
	_montar()

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_calc = null
	_prob = GameState.desafio_atual()
	_col.add_child(Tema.titulo_secao("Desafio do Diretor · Rodada %d" % GameState.rodada_atual))
	# nível escolar
	var ln := HBoxContainer.new()
	ln.add_theme_constant_override("separation", 6)
	for n in Educacao.NIVEIS:
		var b := Tema.botao(str(Educacao.NIVEL_NOME[n]), "ouro" if GameState.nivel_escolar == n else "secundario", 36)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.name = "Nivel_" + str(n)
		b.add_theme_font_size_override("font_size", 12)
		b.disabled = GameState.desafio_resolvido() or int(GameState.desafio_estado["tentativas"]) > 0 and GameState.desafio_estado["rodada"] == GameState.rodada_atual
		b.pressed.connect(func():
			GameState.definir_nivel_escolar(str(n))
			_montar.call_deferred())
		ln.add_child(b)
	_col.add_child(ln)
	var cc := Tema.cartao(Tema.AMARELO)
	var vc := VBoxContainer.new()
	vc.add_theme_constant_override("separation", 6)
	cc.add_child(vc)
	vc.add_child(Tema.rotulo("%s · %s" % [str(Educacao.AREA_NOME[_prob["area"]]).to_upper(), str(_prob["titulo"]).to_upper()], 12, Tema.TINTA))
	var en := Tema.rotulo(str(_prob["enunciado"]), 16, Tema.TINTA)
	en.name = "Enunciado"
	vc.add_child(en)
	for d in (_prob["dados"] as Array):
		var h := HBoxContainer.new()
		var a := Tema.rotulo(str(d["rotulo"]), 13, Tema.TINTA)
		var v := Tema.rotulo(str(d["valor"]), 13, Tema.TINTA)
		v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		h.add_child(a)
		h.add_child(v)
		vc.add_child(h)
	_col.add_child(cc)
	var resolvido: bool = GameState.desafio_resolvido()
	var ops: Array = _prob["opcoes"]
	for i in ops.size():
		var b2 := Tema.botao(str(ops[i]), "secundario", 48)
		b2.name = "Opcao_%d" % i
		b2.disabled = resolvido
		var idx: int = i
		b2.pressed.connect(func(): _responder(idx))
		_col.add_child(b2)
	var lf := HBoxContainer.new()
	lf.add_theme_constant_override("separation", 6)
	var bd := Tema.botao("DICA", "secundario", 40)
	bd.name = "BotaoDica"
	bd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bd.pressed.connect(func():
		_dica_aberta = not _dica_aberta
		_montar.call_deferred())
	lf.add_child(bd)
	var bc := Tema.botao("CALCULADORA", "secundario", 40)
	bc.name = "BotaoCalculadora"
	bc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bc.pressed.connect(_alternar_calc)
	lf.add_child(bc)
	var bp := Tema.botao("PRANCHETA", "secundario", 40)
	bp.name = "BotaoPrancheta"
	bp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bp.pressed.connect(func(): SceneManager.ir_para("prancheta"))
	lf.add_child(bp)
	_col.add_child(lf)
	if _dica_aberta:
		var dl := Tema.rotulo("Dica: " + str(_prob["dica"]), 14, Tema.TITULO)
		dl.name = "TextoDica"
		_col.add_child(dl)
	if not _ultima.is_empty() or resolvido:
		_feedback()
	var bs := Tema.botao("VOLTAR" if resolvido or int(GameState.desafio_estado["tentativas"]) > 0 else "PULAR ESTA RODADA", "primario", 48)
	bs.name = "BotaoSair"
	bs.pressed.connect(func(): SceneManager.voltar())
	_col.add_child(bs)

func _alternar_calc() -> void:
	if _calc != null:
		_calc.queue_free()
		_calc = null
		return
	_calc = Calculadora.new()
	_calc.name = "Calculadora"
	_col.add_child(_calc)
	_col.move_child(_calc, _col.get_child_count() - 2)

func _responder(idx: int) -> void:
	_ultima = GameState.responder_desafio(idx)
	_montar.call_deferred()

func _feedback() -> void:
	var certo: bool = bool(GameState.desafio_estado["acertou"]) if GameState.desafio_resolvido() else bool(_ultima.get("correto", false))
	var c := Tema.cartao(Tema.BRANCO)
	c.name = "Feedback"
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 5)
	c.add_child(v)
	var t: String
	if certo:
		t = "CERTO!" + ("  +%s no caixa" % Educacao.rs(float(_ultima.get("premio", 0))) if _ultima.has("premio") and int(_ultima["premio"]) > 0 else "")
	elif GameState.desafio_resolvido():
		t = "Não foi dessa vez. A resposta era: " + str(_prob["opcoes"][int(_prob["correta"])])
	else:
		t = "Quase! Veja o raciocínio e tente de novo."
	v.add_child(Tema.rotulo(t, 16, Tema.TITULO))
	if GameState.desafio_resolvido() or not certo:
		v.add_child(Tema.rotulo("PASSO A PASSO", 12, Tema.TITULO))
		for p in (_prob["passos"] as Array):
			v.add_child(Tema.rotulo("• " + str(p), 14))
	_col.add_child(c)
