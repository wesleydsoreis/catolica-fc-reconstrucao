extends Control
## PartidaJogo
## Envolve a partida jogável (Etapa 1) dentro do jogo de gestão:
## monta a escalação/tática/adversário a partir do GameState, vira a tela para
## paisagem durante o jogo e, ao final, grava o placar como resultado oficial.

const LARGURA := 480
const ALTURA := 270
const ESCALA_JANELA := 3

var _partida: Partida = null
var _viewport_antes: Vector2i
var _janela_antes: Vector2i
var _orient_antes: int = 0
var _aspecto_antes: int = 0
var _terminou: bool = false
var _amistoso: bool = false     # partida avulsa: não registra resultado, permite reiniciar

func _ready() -> void:
	_amistoso = bool(GameState.amistoso.get("em_jogo", false))
	var dados: Dictionary = GameState.dados_partida_amistoso() if _amistoso else GameState.dados_partida_jogavel()
	if dados.is_empty():
		_amistoso = false
		SceneManager.bloqueio_voltar = false
		SceneManager.voltar()
		return
	SceneManager.bloqueio_voltar = true
	_entrar_paisagem()
	_dados = dados
	_montar_partida()

var _dados: Dictionary = {}

func _montar_partida() -> void:
	var dados: Dictionary = _dados
	var adv: Dictionary = dados["adversario"]
	Cfg.usar_modo(bool(dados.get("modo11", true)))      # carreira = 11x11; amistoso escolhe 11x11 ou FUT7
	_partida = Partida.new()
	_partida.modo_carreira = true
	_partida.nome_casa = "CATÓLICA FC"
	_partida.sigla_casa = "CFC"
	_partida.nome_fora = str(adv.get("nome_curto", adv.get("nome", "ADV"))).to_upper()
	_partida.sigla_fora = str(adv.get("sigla", "ADV"))
	_partida.tatica_casa = str(dados["tatica_id"])
	if dados.has("time_casa"):
		var tc: Dictionary = dados["time_casa"]
		_partida.nome_casa = str(tc["nome"])
		_partida.sigla_casa = str(tc["sigla"])
		if str(tc.get("cor1", "")) != "":
			_partida.cor_casa_1 = Color(str(tc["cor1"]))
		if str(tc.get("cor2", "")) != "":
			_partida.cor_casa_2 = Color(str(tc["cor2"]))
	_partida.escalacao_casa = dados["escalacao"]
	_partida.reservas_casa = dados.get("reservas", [])
	if dados.has("formacao_linhas"):
		_partida.formacao_casa = dados["formacao_linhas"]
	if dados.has("tatica_eixos"):
		_partida.eixos[0] = dados["tatica_eixos"]
		_partida.eixos_definidos = true
	_partida.eixos[1] = (Partida.PRESETS_TATICA.get(str(adv.get("estilo", "equilibrado")), Partida.PRESETS_TATICA["equilibrado"]) as Dictionary).duplicate()
	if dados.has("adv_eixos"):
		_partida.eixos[1] = (dados["adv_eixos"] as Dictionary).duplicate()
	_partida.bonus_scout = float(dados.get("bonus_scout", 0.0))
	_partida.clima = str(dados.get("clima", "sol"))
	_partida.forma_casa = float(dados.get("forma", 0.0))
	_partida.entrosamento_casa = float(dados.get("entrosamento", 60.0))
	_partida.extra_prep = float(dados.get("extra_prep", 0.0))
	_partida.forca_fora = (0.84 + (float(adv.get("forca", 65)) - 76.0) * 0.004) / 0.84   # mesma escala dos atributos da casa
	_partida.forca_casa = 1.0
	if adv.has("cor1"):
		_partida.cor_fora_1 = Color(str(adv["cor1"]))
	if adv.has("cor2"):
		_partida.cor_fora_2 = Color(str(adv["cor2"]))
	_partida.continuar_pedido.connect(_concluir)
	_partida.sair_pedido.connect(_abandonar)
	if _amistoso:
		_partida.reiniciar_pedido.connect(_reiniciar, CONNECT_DEFERRED)
	add_child(_partida)

func _reiniciar() -> void:
	## Só amistoso: descarta a partida atual e começa outra com a mesma configuração.
	if _terminou or not _amistoso or _partida == null:
		return
	_partida.queue_free()
	_partida = null
	await get_tree().process_frame
	_dados = GameState.dados_partida_amistoso()
	_montar_partida()

func _entrar_paisagem() -> void:
	var w: Window = get_window()
	_viewport_antes = w.content_scale_size
	_janela_antes = w.size
	_orient_antes = DisplayServer.screen_get_orientation()
	_aspecto_antes = w.content_scale_aspect
	if OS.has_feature("mobile"):
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR_LANDSCAPE)
	else:
		w.size = Vector2i(LARGURA * ESCALA_JANELA, ALTURA * ESCALA_JANELA)
	TelaCheia.entrar_partida()
	w.content_scale_size = Vector2i(LARGURA, ALTURA)
	w.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP

func _sair_paisagem() -> void:
	var w: Window = get_window()
	TelaCheia.sair_partida()
	if OS.has_feature("mobile"):
		DisplayServer.screen_set_orientation(_orient_antes)
	else:
		w.size = _janela_antes
	w.content_scale_size = _viewport_antes
	w.content_scale_aspect = _aspecto_antes as Window.ContentScaleAspect

func _abandonar() -> void:
	## Sai da partida pelo menu de pausa: nada é registrado e o jogo volta ao menu de gestão.
	if _terminou:
		return
	_terminou = true
	_sair_paisagem()
	SceneManager.bloqueio_voltar = false
	if _amistoso:
		GameState.amistoso["em_jogo"] = false
		SceneManager.ir_para("config_partida", false)
	else:
		SceneManager.ir_para("hub", false)

func _concluir() -> void:
	if _terminou:
		return
	_terminou = true
	var gc: int = int(_partida.gols[0])
	var ga: int = int(_partida.gols[1])
	_sair_paisagem()
	SceneManager.bloqueio_voltar = false
	if _amistoso:
		GameState.amistoso["em_jogo"] = false
		GameState.amistoso_resultado = {"adversario": GameState.clube_por_id(str(GameState.amistoso.get("adversario_id", ""))), "gc": gc, "ga": ga,
			"autores": _partida.autores_casa.duplicate(), "dificuldade": GameState.amistoso.get("dificuldade", "normal"),
			"formacao_id": GameState.amistoso.get("formacao_id", "")}
		SceneManager.ir_para("resultado_amistoso", false)
		return
	GameState.simular_partida({"proprio": gc, "adversario": ga, "autores": _partida.autores_casa, "cartoes": _partida.cartoes_log.duplicate(true), "lesoes": _partida.lesoes_log.duplicate(true)})
	# substitui a tela da partida pelo resultado (não deixa "partida" no histórico)
	SceneManager.ir_para("resultado", false)

func _exit_tree() -> void:
	if _amistoso:
		GameState.amistoso["em_jogo"] = false
	# segurança: se a cena for removida por outro caminho, restaura o estado
	if not _terminou and SceneManager.bloqueio_voltar:
		SceneManager.bloqueio_voltar = false
		_sair_paisagem()
