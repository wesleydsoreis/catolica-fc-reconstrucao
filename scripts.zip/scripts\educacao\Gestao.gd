class_name Gestao
extends RefCounted
## Fase 5: diretoria (metas e confiança), economia (demanda por preço, dívida com juros compostos), torcida e imprensa.
## Tudo usa funções que o aluno também estuda: afim (preço × público), quadrática (receita) e exponencial (juros).

const PRECO_BASE := 25.0
const K_PRECO := 0.018            # cada R$ 1 acima de 25 tira 1,8% do público (função afim decrescente)
const PRECO_MIN := 10
const PRECO_MAX := 60
const TAXA_DIVIDA := 0.03         # juros compostos por rodada
const LIMITE_DIVIDA := 300000
const BONUS_META := 15000

static func fator_preco(preco: float) -> float:
	return clampf(1.0 - K_PRECO * (preco - PRECO_BASE), 0.25, 1.6)

## Público de um jogo em casa. Mesma conta da simulação (ver GameState.simular_partida).
static func publico(capacidade: float, torcida_ef: float, forca_adv: float, preco: float) -> int:
	var fator_torcida: float = 0.22 + (torcida_ef / 100.0) * 0.5
	var fator_adv: float = 0.85 + (clampf(forca_adv, 50.0, 90.0) / 90.0) * 0.3
	return clampi(int(round(capacidade * fator_torcida * fator_adv * fator_preco(preco))), 0, int(capacidade))

static func divida_apos(divida: float, rodadas: int) -> float:
	return divida * pow(1.0 + TAXA_DIVIDA, rodadas)

# ------------------------------------------------------------------ metas da diretoria
const MODELOS := {
	"posicao": {"titulo": "Terminar entre os %d primeiros do Universitário", "fim": true},
	"aproveitamento": {"titulo": "Aproveitamento de pelo menos %d%% dos pontos", "fim": true},
	"caixa": {"titulo": "Encerrar a temporada com caixa de pelo menos %s", "fim": true},
	"divida": {"titulo": "Encerrar a temporada sem dívida", "fim": true},
	"torcida": {"titulo": "Levar a torcida a %d%% ou mais", "fim": true},
	"sequencia": {"titulo": "Vencer %d jogos seguidos", "fim": false},
}

static func sortear_metas(temporada: int, caixa: float, sala: int) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("metas|%d|%d" % [temporada, sala])
	var ids: Array = MODELOS.keys()
	var esc: Array = []
	while esc.size() < 3:
		var id: String = ids.pop_at(rng.randi() % ids.size())
		esc.append(id)
	var metas: Array = []
	for id in esc:
		var alvo: float = 0.0
		var titulo: String = str(MODELOS[id]["titulo"])
		match id:
			"posicao":
				alvo = 8.0 if temporada <= 1 else maxf(3.0, 8.0 - temporada)
				titulo = titulo % int(alvo)
			"aproveitamento":
				alvo = minf(70.0, 45.0 + 3.0 * temporada)
				titulo = titulo % int(alvo)
			"caixa":
				alvo = roundf(caixa * 1.1 / 10000.0) * 10000.0
				titulo = titulo % Educacao.rs(alvo)
			"torcida":
				alvo = minf(90.0, 55.0 + 5.0 * temporada)
				titulo = titulo % int(alvo)
			"sequencia":
				alvo = 3.0
				titulo = titulo % 3
		metas.append({"id": id, "titulo": titulo, "alvo": alvo, "cumprida": false, "paga": false})
	return metas

# ------------------------------------------------------------------ imprensa
const COLETIVAS := {
	"vitoria": {"pergunta": "A Católica venceu. A imprensa pergunta: qual o segredo do resultado?", "opcoes": [
		{"texto": "Foi mérito do elenco, trabalhamos duro.", "moral": 2.0, "torcida": 1.0, "diretoria": 0.0},
		{"texto": "Foi o planejamento da comissão técnica.", "moral": -1.0, "torcida": 0.0, "diretoria": 2.0},
		{"texto": "A torcida empurrou o time o jogo inteiro!", "moral": 0.0, "torcida": 3.0, "diretoria": 0.0}]},
	"empate": {"pergunta": "Empate no placar. Ficou a sensação de que faltou algo?", "opcoes": [
		{"texto": "Faltou capricho no último passe, vamos corrigir.", "moral": -1.0, "torcida": 0.0, "diretoria": 1.0},
		{"texto": "Foi um ponto importante fora da zona de risco.", "moral": 1.0, "torcida": -1.0, "diretoria": 1.0},
		{"texto": "Merecíamos mais, o time foi corajoso.", "moral": 2.0, "torcida": 1.0, "diretoria": -1.0}]},
	"derrota": {"pergunta": "Derrota. O torcedor está chateado: o que você diz a ele?", "opcoes": [
		{"texto": "Assumo a responsabilidade pela derrota.", "moral": 2.0, "torcida": 1.0, "diretoria": -1.0},
		{"texto": "Vamos cobrar mais intensidade dos jogadores.", "moral": -3.0, "torcida": 1.0, "diretoria": 2.0},
		{"texto": "A arbitragem influenciou o resultado.", "moral": 1.0, "torcida": 2.0, "diretoria": -3.0}]},
}

static func manchete(tipo: String, gp: int, gc: int, adv: String, em_casa: bool, sequencia: int) -> String:
	if tipo == "vitoria":
		if gp - gc >= 3:
			return "GOLEADA! Católica passa por cima do %s por %d a %d" % [adv, gp, gc]
		if sequencia >= 3:
			return "%d vitórias seguidas! Católica embala no campeonato" % sequencia
		return "Católica vence o %s por %d a %d %s" % [adv, gp, gc, "em casa" if em_casa else "fora de casa"]
	if tipo == "empate":
		return "Católica e %s ficam no %d a %d" % [adv, gp, gc]
	if gc - gp >= 3:
		return "Noite para esquecer: %s goleia a Católica por %d a %d" % [adv, gc, gp]
	return "%s derrota a Católica por %d a %d" % [adv, gc, gp]
