extends RefCounted
class_name Opcoes
## Opções do jogador (gravadas em user://opcoes.cfg): mão do controle de toque e inversão passe/chute.
static var canhoto: bool = false      # joystick à direita e botões à esquerda
static var invertido: bool = false    # troca passe <-> chute (teclado, controle e toque)
static var _carregado: bool = false

static func carregar() -> void:
	if _carregado:
		return
	_carregado = true
	var cf := ConfigFile.new()
	if cf.load("user://opcoes.cfg") == OK:
		canhoto = bool(cf.get_value("controles", "canhoto", false))
		invertido = bool(cf.get_value("controles", "invertido", false))

static func salvar() -> void:
	var cf := ConfigFile.new()
	cf.set_value("controles", "canhoto", canhoto)
	cf.set_value("controles", "invertido", invertido)
	cf.save("user://opcoes.cfg")

static func alternar_mao() -> void:
	carregar()
	canhoto = not canhoto
	salvar()

static func alternar_inversao() -> void:
	carregar()
	invertido = not invertido
	salvar()
	aplicar()

## Chamar depois de registrar as ações do InputMap: troca os eventos de passe e chute se pedido.
static func aplicar() -> void:
	carregar()
	if not InputMap.has_action("passe") or not InputMap.has_action("chute"):
		return
	# base fixa: passe = J/Z/A, chute = K/X/B; invertido => ao contrário
	var base: Dictionary = {"passe": [KEY_J, KEY_Z, JOY_BUTTON_A], "chute": [KEY_K, KEY_X, JOY_BUTTON_B]}
	for nome in ["passe", "chute"]:
		InputMap.action_erase_events(nome)
		var origem: String = nome
		if invertido:
			origem = "chute" if nome == "passe" else "passe"
		var lista: Array = base[origem]
		for i in 2:
			var ev := InputEventKey.new()
			ev.physical_keycode = int(lista[i]) as Key
			InputMap.action_add_event(nome, ev)
		var jb := InputEventJoypadButton.new()
		jb.button_index = int(lista[2]) as JoyButton
		InputMap.action_add_event(nome, jb)

static func rotulo_mao() -> String:
	carregar()
	return "CANHOTO" if canhoto else "DESTRO"
