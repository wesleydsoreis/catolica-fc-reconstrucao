extends Control
## FimTemporada: resumo do ano (posições, troféus, prêmios) e botão de nova temporada.

func _ready() -> void:
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	mg.add_child(col)
	col.add_child(Tema.titulo_secao("Temporada %d encerrada" % GameState.temporada))

	var pos: int = int(GameState.universitario_posicoes.get("catolica", 0))
	var c1 := Tema.cartao(Tema.AMARELO, 12)
	var v1 := VBoxContainer.new()
	c1.add_child(v1)
	v1.add_child(Tema.rotulo("RESUMO DO ANO", 12, Tema.TITULO))
	v1.add_child(_linha("Universitário", ("%dº lugar" % pos) if pos > 0 else "—"))
	var il := "não disputado"
	if not GameState.interlajes.is_empty():
		il = "campeã" if not GameState.interlajes_eliminada else ("eliminada" if pos <= 8 else "fora do G8")
	v1.add_child(_linha("InterLajes", il))
	var copa := "não disputada"
	if not (GameState.copa_calendario.is_empty() or GameState.fora_da_copa):
		var ordem: Array = Competicoes.ordenar_tabela(GameState.copa)
		for i in ordem.size():
			if ordem[i]["id"] == "catolica":
				copa = "%dº lugar" % (i + 1)
	v1.add_child(_linha("Copa dos Gigantes", copa))
	var art: Array = GameState.artilharia(1)
	if not art.is_empty():
		v1.add_child(_linha("Artilheiro", "%s (%d gols)" % [art[0]["nome"], art[0]["gols"]]))
	col.add_child(c1)

	var c2 := Tema.cartao(Tema.BRANCO, 12)
	var v2 := VBoxContainer.new()
	c2.add_child(v2)
	v2.add_child(Tema.rotulo("PRÊMIOS DA TEMPORADA", 12, Tema.TITULO))
	var total := 0
	for p in GameState.premios_temporada:
		if int(p["temporada"]) == GameState.temporada:
			v2.add_child(_linha(str(p["label"]), Tema.reais(int(p["valor"]))))
			total += int(p["valor"])
	v2.add_child(_linha("Total em prêmios", Tema.reais(total)))
	col.add_child(c2)
	var av: Dictionary = GameState.avaliar_diretoria_fim()
	var c3 := Tema.cartao(Tema.BRANCO, 12)
	c3.name = "AvaliacaoDiretoria"
	var v3 := VBoxContainer.new()
	c3.add_child(v3)
	v3.add_child(Tema.rotulo("AVALIAÇÃO DA DIRETORIA · %d de %d metas" % [av["cumpridas"], (av["metas"] as Array).size()], 12, Tema.TITULO))
	for m in av["metas"]:
		v3.add_child(_linha(("✔ " if m["ok"] else "✘ ") + str(m["titulo"]), str(m["texto"])))
	v3.add_child(Tema.rotulo(str(av["veredito"]), 14, Tema.AMARELO))
	col.add_child(c3)
	var caixa := Tema.chip("CAIXA ATUAL " + Tema.reais(int(GameState.financas["caixa"])), Tema.VERDE)
	caixa.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(caixa)

	var b := Tema.botao("INICIAR TEMPORADA %d" % (GameState.temporada + 1), "primario", 56)
	b.name = "BotaoNovaTemporada"
	b.pressed.connect(func():
		GameState.nova_temporada()
		SceneManager.ir_para("hub", false))
	col.add_child(b)
	var bc := Tema.botao("CRÉDITOS", "secundario", 40)
	bc.name = "BotaoCreditos"
	bc.pressed.connect(func(): Dialogo.abrir_creditos(self))
	col.add_child(bc)

func _linha(a: String, b: String) -> Control:
	var h := HBoxContainer.new()
	var l := Tema.rotulo(a, 14)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	var r := Tema.rotulo(b, 14, Tema.TITULO)
	r.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(r)
	return h
