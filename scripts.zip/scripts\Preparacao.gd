extends Control
## Preparacao
## Semana de preparação: até 2 cartas (de data/cartas_preparacao.json, iguais
## ao CARTAS_PREPARACAO do HTML). GameState.confirmar_preparacao() já protege
## contra cobrança duplicada — aqui só desabilitamos a UI depois de confirmado.

@onready var lista_cartas: VBoxContainer = $Coluna/Scroll/Margem/ListaCartas
@onready var botao_confirmar: Button = $Coluna/BotaoConfirmar

func _ready() -> void:
	_montar_lista()
	GameState.estado_mudou.connect(_atualizar)
	_atualizar()

func _exit_tree() -> void:
	if GameState.estado_mudou.is_connected(_atualizar):
		GameState.estado_mudou.disconnect(_atualizar)

func _montar_lista() -> void:
	for carta in GameData.cartas_preparacao:
		var painel := PanelContainer.new()
		painel.add_theme_stylebox_override("panel", Tema.caixa(Tema.BRANCO))
		var linha := HBoxContainer.new()
		linha.add_theme_constant_override("separation", 10)
		painel.add_child(linha)

		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		linha.add_child(info)

		var nome := Label.new()
		nome.text = "%s — %s" % [carta["nome"], _formatar_reais(int(carta["custo"]))]
		nome.add_theme_font_size_override("font_size", 14)
		nome.add_theme_color_override("font_color", Tema.TITULO)
		info.add_child(nome)

		var beneficio := Label.new()
		beneficio.text = carta["beneficio"]
		beneficio.autowrap_mode = TextServer.AUTOWRAP_WORD
		beneficio.add_theme_font_size_override("font_size", 12)
		beneficio.add_theme_color_override("font_color", Tema.TEXTO)
		info.add_child(beneficio)

		var botao := Button.new()
		botao.toggle_mode = true
		botao.custom_minimum_size = Vector2(90, 44)
		botao.name = "botao_%s" % carta["id"]
		var id_carta: String = carta["id"]
		botao.pressed.connect(func(): GameState.alternar_carta_preparacao(id_carta))
		linha.add_child(botao)

		lista_cartas.add_child(painel)

func _atualizar() -> void:
	for painel in lista_cartas.get_children():
		var linha: HBoxContainer = painel.get_child(0)
		var botao: Button = linha.get_child(1)
		var id_carta: String = botao.name.replace("botao_", "")
		var selecionada: bool = GameState.cartas_preparacao_escolhidas.has(id_carta)
		botao.button_pressed = selecionada
		botao.text = "Marcada" if selecionada else "Escolher"
		botao.disabled = GameState.prep_confirmada or (
			not selecionada and GameState.cartas_preparacao_escolhidas.size() >= 2
		)
	botao_confirmar.disabled = GameState.prep_confirmada
	botao_confirmar.text = "PREPARAÇÃO CONFIRMADA" if GameState.prep_confirmada else "CONFIRMAR PREPARAÇÃO"

func _formatar_reais(valor: int) -> String:
	if valor == 0:
		return "grátis"
	var texto := str(valor)
	var resultado := ""
	var contagem := 0
	for i in range(texto.length() - 1, -1, -1):
		resultado = texto[i] + resultado
		contagem += 1
		if contagem % 3 == 0 and i != 0:
			resultado = "." + resultado
	return "R$ %s" % resultado

func _on_botao_confirmar_pressed() -> void:
	GameState.confirmar_preparacao()
	SceneManager.ir_para("escalacao")
