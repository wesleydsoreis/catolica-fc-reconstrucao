"""Gera o campo 480x270 (gramado em losangos em perspectiva, linhas, mureta curva,
bandeirinhas) e os gols. A projeção é a MESMA usada no Godot (Pitch.gd)."""
import math, json, os
from PIL import Image, ImageDraw
from palette import *
import sys
MODOS={"11":dict(PW=3300.0,PH=1950.0,KX=0.20,YF=96.0,YN=266.0,GOL_M=150.0),
       "7":dict(PW=2200.0,PH=1300.0,KX=0.185,YF=96.0,YN=266.0,GOL_M=125.0)}
MARG=150.0
SH=270
GOL_P,GOL_ALT=80.0,26.0
# parâmetros do modo (preenchidos por configurar())
PW=PH=KX=KY=YF=YN=GOL_M=SW=0
def configurar(m):
    global PW,PH,KX,KY,YF,YN,GOL_M,SW
    c=MODOS[m]; PW,PH,KX,YF,YN,GOL_M=c["PW"],c["PH"],c["KX"],c["YF"],c["YN"],c["GOL_M"]
    KY=(YN-YF)/PH
    SW=int(round((PW+2*MARG)*KX))
def proj(x,y):
    return ((x+MARG)*KX, YF+y*KY)
def inv(sx,sy):
    return (sx/KX-MARG, (sy-YF)/KY)
def gramado(im):
    p=im.load()
    for sy in range(SH):
        for sx in range(SW):
            x,y=inv(sx+.5,sy+.5)
            par=int(math.floor(x/(PW/12.0)))%2
            cor=G1 if par==0 else G2
            if (sx*3+sy*5)%11==0: cor=G3
            p[sx,sy]=cor
def sdist(x,y,x0,x1,ytop,rx,ry):
    """distância (aprox., >0 fora) até o retângulo arredondado aberto embaixo"""
    if x<x0+rx: cx=x0+rx; dx=(x-cx)/rx
    elif x>x1-rx: cx=x1-rx; dx=(x-cx)/rx
    else: dx=0
    if y<ytop+ry and (x<x0+rx or x>x1-rx):
        dy=(y-(ytop+ry))/ry
        r=math.hypot(dx,dy); return (r-1)*min(rx,ry)
    if x<x0+rx or x>x1-rx:
        return abs(dx)*rx-rx if x>=x0 and x<=x1 else (x0-x if x<x0 else x-x1)
    return ytop-y
def mureta(im):
    p=im.load()
    for sy in range(SH):
        for sx in range(SW):
            if sy<YF-9:
                p[sx,sy]=(0,0,0,0); continue
            if sy<YF-3:
                k=(sx//10)%2
                p[sx,sy]=MUR1 if sy==int(YF-9) else (MUR2 if k==0 else MUR3)
                if sy==int(YF-4): p[sx,sy]=CONTORNO
                continue
            if sx<8 or sx>SW-9 or sy>SH-5:
                edge = sx in (7,SW-9) or sy==SH-5
                p[sx,sy]=MUR_BRILHO if edge else (MUR2 if ((sx+sy)//10)%2==0 else MUR3)
def linhas(im):
    KS=PW/2200.0; KT=PH/1300.0
    d=ImageDraw.Draw(im); L=BRANCO
    def pl(pts,w=1):
        d.line([proj(*q) for q in pts],fill=L,width=w,joint=None)
    def arc(cx,cy,r,a0,a1,n=60):
        pl([(cx+r*math.cos(a0+(a1-a0)*i/n),cy+r*math.sin(a0+(a1-a0)*i/n)) for i in range(n+1)])
    cy=PH/2
    pl([(0,0),(PW,0),(PW,PH),(0,PH),(0,0)])
    pl([(PW/2,0),(PW/2,PH)])
    arc(PW/2,cy,170*KS,0,2*math.pi,90)
    for lado in (0,1):
        sg=1 if lado==0 else -1; x0=0 if lado==0 else PW
        pl([(x0,cy-360*KT),(x0+sg*340*KS,cy-360*KT),(x0+sg*340*KS,cy+360*KT),(x0,cy+360*KT)])
        pl([(x0,cy-190*KT),(x0+sg*130*KS,cy-190*KT),(x0+sg*130*KS,cy+190*KT),(x0,cy+190*KT)])
        a0=-0.93 if lado==0 else math.pi-0.93
        arc(x0+sg*230*KS,cy,170*KS,a0,a0+1.86,30)
        px,py=proj(x0+sg*230*KS,cy); d.rectangle((px-1,py-1,px,py),fill=L)
    px,py=proj(PW/2,cy); d.rectangle((px-1,py-1,px,py),fill=L)
    for cxn,cyn in ((0,0),(PW,0),(0,PH),(PW,PH)):
        px,py=proj(cxn,cyn); sx=1 if cxn==0 else -1; sy=1 if cyn==0 else -1
        r=5 if cyn==PH else 3
        for k in range(r+1):
            ang=k/r*math.pi/2
            d.point((px+sx*r*math.cos(ang)*(1 if k else 1),py+sy*r*math.sin(ang)),fill=L)
    # pontos de pênalti
def bandeira(im,px,py,alt):
    d=ImageDraw.Draw(im)
    d.line((px,py,px,py-alt),fill=BRANCO)
    d.polygon([(px+1,py-alt),(px+1+alt*0.45,py-alt+alt*0.2),(px+1,py-alt+alt*0.4)],fill=VERM)
def gol(lado):
    sg=-1 if lado==0 else 1; xg=0 if lado==0 else PW; cy=PH/2
    def P(dx,y,alt): 
        sx,sy=proj(xg+sg*dx,y); return (sx,sy-alt)
    fa=P(0,cy-GOL_M,0); fb=P(0,cy+GOL_M,0); ba=P(GOL_P,cy-GOL_M,0); bb=P(GOL_P,cy+GOL_M,0)
    fat=P(0,cy-GOL_M,GOL_ALT); fbt=P(0,cy+GOL_M,GOL_ALT); bat=P(GOL_P,cy-GOL_M,GOL_ALT); bbt=P(GOL_P,cy+GOL_M,GOL_ALT)
    pts=[fa,fb,ba,bb,fat,fbt,bat,bbt]
    x0=int(min(q[0] for q in pts))-3; y0=int(min(q[1] for q in pts))-3
    x1=int(max(q[0] for q in pts))+4; y1=int(max(q[1] for q in pts))+4
    w,h=x1-x0,y1-y0
    im=Image.new("RGBA",(w,h),(0,0,0,0)); mk=Image.new("L",(w,h),0); md=ImageDraw.Draw(mk)
    sh=lambda q:(q[0]-x0,q[1]-y0)
    faces=[[bat,bbt,bb,ba],[bat,fat,fa,ba],[bbt,fbt,fb,bb],[fat,bat,bbt,fbt]]
    for f in faces: md.polygon([sh(q) for q in f],fill=255)
    pm=mk.load(); pi=im.load()
    for y in range(h):
        for x in range(w):
            if pm[x,y]:
                if (x+y)%2==0: pi[x,y]=REDE if (x//2+y//2)%2 else BRANCO
                elif (x%3==0 and y%3==0): pi[x,y]=(70,90,110,255)
    d=ImageDraw.Draw(im)
    for a,b in [(fat,fbt),(fat,bat),(fbt,bbt),(bat,bbt),(bat,ba),(bbt,bb)]:
        d.line([sh(a),sh(b)],fill=REDE)
    # frente do gol: traves brancas
    for a,b in [(fa,fat),(fb,fbt),(fat,fbt)]:
        d.line([sh(a),sh(b)],fill=BRANCO,width=2)
    # base
    d.line([sh(fa),sh(ba)],fill=REDE); d.line([sh(fb),sh(bb)],fill=REDE)
    return im,(x0,y0)
def main(out,m):
    global SH
    configurar(m)
    os.makedirs(out,exist_ok=True)
    im=Image.new("RGBA",(SW,SH),G1); gramado(im); mureta(im); linhas(im)
    for cxn,cyn,alt in ((0,0,9),(PW,0,9),(0,PH,15),(PW,PH,15)):
        px,py=proj(cxn,cyn); bandeira(im,round(px),round(py),alt)
    im.save(os.path.join(out,"campo_%s.png"%m))
    meta={}
    for lado,n in ((0,"gol_esq"),(1,"gol_dir")):
        g,(ox,oy)=gol(lado); g.save(os.path.join(out,"%s_%s.png"%(n,m))); meta[n]=[ox,oy]
    json.dump(dict(PW=PW,PH=PH,SW=SW,SH=SH,YF=YF,YN=YN,KX=KX,KY=KY,MARG=MARG,gols=meta),open(os.path.join(out,"projecao_%s.json"%m),"w"))
if __name__=="__main__":
    d=os.path.join(os.path.dirname(__file__),"..","..","assets","gerado")
    for m in ("11","7"): main(d,m)
