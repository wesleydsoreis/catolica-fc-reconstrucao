class_name Relatorio
extends RefCounted
## Relatório do professor: desempenho por área, desafios (acertos, tentativas, tempo) e decisões por rodada, exportável em CSV ou JSON.

static func resumo(gs: Node) -> Dictionary:
	var areas: Dictionary = {}
	for a in Educacao.AREAS:
		areas[a] = {"desafios": 0, "acertos_1a": 0, "acertos_2a": 0, "erros": 0, "tempo_total": 0.0}
	for e in gs.educacao_log:
		var a: String = str(e["area"])
		if not areas.has(a):
			continue
		areas[a]["desafios"] += 1
		if bool(e["acertou"]):
			if int(e["tentativas"]) == 1:
				areas[a]["acertos_1a"] += 1
			else:
				areas[a]["acertos_2a"] += 1
		else:
			areas[a]["erros"] += 1
		areas[a]["tempo_total"] += float(e.get("tempo_s", 0.0))
	var tot := 0
	var ac := 0
	for a in areas:
		var d: Dictionary = areas[a]
		d["taxa_1a"] = float(d["acertos_1a"]) / float(d["desafios"]) * 100.0 if int(d["desafios"]) > 0 else 0.0
		d["tempo_medio"] = float(d["tempo_total"]) / float(d["desafios"]) if int(d["desafios"]) > 0 else 0.0
		d["nivel"] = Educacao.nome_nivel_comp(gs.nivel_area(a))
		tot += int(d["desafios"])
		ac += int(d["acertos_1a"])
	return {"aluno": gs.aluno_nome, "turma": gs.turma_codigo, "nivel_escolar": str(Educacao.NIVEL_NOME[gs.nivel_escolar]), "semente_sala": gs.sala_seed,
		"temporada": gs.temporada, "rodada": gs.rodada_atual, "desafios_total": tot, "acertos_1a_total": ac, "areas": areas}

static func _q(v) -> String:
	var t: String = str(v).replace("\"", "\"\"")
	return "\"%s\"" % t if t.contains(";") or t.contains("\"") or t.contains("\n") else t

static func csv(gs: Node) -> String:
	var r: Dictionary = resumo(gs)
	var L: Array = []
	L.append("RELATORIO DO PROFESSOR - Catolica FC A Reconstrucao")
	L.append("aluno;%s" % _q(r["aluno"]))
	L.append("turma;%s" % _q(r["turma"]))
	L.append("nivel_escolar;%s" % _q(r["nivel_escolar"]))
	L.append("semente_sala;%d" % int(r["semente_sala"]))
	L.append("")
	L.append("RESUMO POR AREA")
	L.append("area;nivel_competencia;desafios;acertos_1a_tentativa;acertos_2a_tentativa;erros;taxa_1a_%;tempo_medio_s")
	for a in Educacao.AREAS:
		var d: Dictionary = r["areas"][a]
		L.append("%s;%s;%d;%d;%d;%d;%.1f;%.1f" % [Educacao.AREA_NOME[a], d["nivel"], d["desafios"], d["acertos_1a"], d["acertos_2a"], d["erros"], d["taxa_1a"], d["tempo_medio"]])
	L.append("")
	L.append("DESAFIOS")
	L.append("temporada;rodada;area;nivel_escolar;acertou;tentativas;tempo_s")
	for e in gs.educacao_log:
		L.append("%d;%d;%s;%s;%s;%d;%.1f" % [int(e.get("temporada", 1)), int(e["rodada"]), Educacao.AREA_NOME.get(str(e["area"]), str(e["area"])), Educacao.NIVEL_NOME.get(str(e["nivel"]), str(e["nivel"])), "sim" if bool(e["acertou"]) else "nao", int(e["tentativas"]), float(e.get("tempo_s", 0.0))])
	L.append("")
	L.append("DECISOES POR RODADA")
	L.append("temporada;rodada;adversario;mando;resultado;placar;formacao;pressao;linha;construcao;preco_ingresso;scouting;divida;caixa;resposta_coletiva")
	for d in gs.decisoes_log:
		L.append("%d;%d;%s;%s;%s;%s;%s;%d;%d;%d;%d;%d;%d;%d;%d" % [int(d["temporada"]), int(d["rodada"]), _q(d["adversario"]), "casa" if bool(d["em_casa"]) else "fora", d["resultado"], d["placar"], d["formacao"], d["pressao"], d["linha"], d["construcao"], d["preco_ingresso"], d["scouting"], d["divida"], d["caixa"], d["coletiva"]])
	return "\n".join(L) + "\n"

static func json(gs: Node) -> String:
	var r: Dictionary = resumo(gs)
	r["desafios"] = gs.educacao_log
	r["decisoes"] = gs.decisoes_log
	return JSON.stringify(r, "  ")

## Grava o relatório. No navegador, baixa o arquivo; no computador/celular, grava em Documentos (ou na pasta do jogo) e devolve o caminho.
static func exportar(gs: Node, formato: String) -> String:
	var conteudo: String = csv(gs) if formato == "csv" else json(gs)
	var base: String = (gs.turma_codigo if gs.turma_codigo != "" else "turma") + "_" + (gs.aluno_nome if gs.aluno_nome != "" else "aluno")
	var nome: String = ("relatorio_%s.%s" % [base, formato]).replace(" ", "_").replace("/", "-")
	var bytes: PackedByteArray = conteudo.to_utf8_buffer()
	if formato == "csv":
		bytes = PackedByteArray([0xEF, 0xBB, 0xBF]) + bytes       # BOM: o Excel abre acentos corretamente
	if OS.has_feature("web"):
		JavaScriptBridge.download_buffer(bytes, nome, "text/csv" if formato == "csv" else "application/json")
		return "Baixado pelo navegador: " + nome
	var destinos: Array = []
	var docs: String = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
	if docs != "":
		destinos.append(docs.path_join(nome))
	destinos.append("user://" + nome)
	for d in destinos:
		var f := FileAccess.open(d, FileAccess.WRITE)
		if f != null:
			f.store_buffer(bytes)
			f.close()
			return ProjectSettings.globalize_path(d) if str(d).begins_with("user://") else str(d)
	return ""
