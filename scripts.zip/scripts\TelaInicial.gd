extends Control
## Menu principal: cenário do estádio ao pôr do sol (arte nova da Católica FC, extraída do vídeo do menu).
## Opções: Jogar · Continuar carreira · Nova carreira · Configurações · Sair.
## Configurações reúne também os recursos que já existiam (partida rápida, modo professor, créditos, apagar progresso).
## Teclado (setas/Enter/Esc), mouse e toque.

var _modo: String = "menu"      # menu | config
var _opcoes: Array = []
var _sel: int = 0
var _confirma_apagar: bool = false
var _lista: VBoxContainer
var _botoes: Array = []
var _t: float = 0.0
var _t_inicio: bool = false

const REF := Vector2(1280, 720)
const VIDEO := "res://assets/video/menu_animado.ogv"
const FUNDO_PNG := "res://assets/ui/novo/menu_catolica.png"       # quadro de reserva (só aparece se o vídeo falhar)
const FONTE_PIXEL := "res://assets/fonte/pixel2.fnt"
const PAINEL_REF := Rect2(34, 244, 300, 396)       # coluna de botões sobre a árvore (a arte original tinha 4 botões aqui)
const VERMELHO := Color("D91E26")
const VERMELHO_CLARO := Color("F0454B")
const CONTORNO := Color("1B0507")

var _fundo: VideoFundo
var _painel: PanelContainer
var _fonte: Font

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS
	_fonte = load(FONTE_PIXEL)
	_fundo = VideoFundo.criar(VIDEO, load(FUNDO_PNG), true)       # vídeo animado em loop, cobrindo a tela sem distorcer
	add_child(_fundo)
	_painel = PanelContainer.new()
	_painel.name = "PainelMenu"
	var sp := StyleBoxFlat.new()
	sp.bg_color = Color(0.14, 0.03, 0.07, 0.97)
	sp.border_color = Color(1, 1, 1, 0.85)
	sp.set_border_width_all(3)
	sp.set_corner_radius_all(12)
	sp.shadow_color = Color(0, 0, 0, 0.5)
	sp.shadow_size = 12
	sp.content_margin_left = 16
	sp.content_margin_right = 16
	sp.content_margin_top = 16
	sp.content_margin_bottom = 16
	_painel.add_theme_stylebox_override("panel", sp)
	add_child(_painel)
	_lista = VBoxContainer.new()
	_lista.add_theme_constant_override("separation", 10)
	_painel.add_child(_lista)
	resized.connect(_layout)
	_montar()
	_layout()
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.3)

func _escala() -> Dictionary:
	var k: float = maxf(size.x / REF.x, size.y / REF.y)      # a arte cobre a tela (16:9)
	var tam: Vector2 = REF * k
	var org: Vector2 = (size - tam) * 0.5
	if tam.y > size.y:
		org.y = 0.0                  # igual ao vídeo: telas muito largas cortam embaixo e preservam o título
	return {"k": k, "org": org, "tam": tam}

# ------------------------------------------------------------------ layout
func _layout() -> void:
	if size.x < 10.0 or _fundo == null:
		return
	var e: Dictionary = _escala()
	var k: float = e["k"]
	var org: Vector2 = e["org"]
	var pos: Vector2 = org + PAINEL_REF.position * k
	pos.x = maxf(pos.x, 12.0)
	var tam: Vector2 = PAINEL_REF.size * k
	tam.x = minf(tam.x, size.x - 24.0)
	pos.y = clampf(pos.y, 8.0, maxf(8.0, size.y - 200.0))
	tam.y = minf(tam.y, size.y - pos.y - 12.0)       # nunca passa da borda da tela (telas muito largas)
	_painel.position = pos
	var n: int = maxi(_botoes.size(), 1)
	var disp: float = tam.y - 32.0 - float(n - 1) * 10.0
	var alt: float = minf(disp / float(n), 66.0 * k)
	for b in _botoes:
		(b as Button).custom_minimum_size = Vector2(0, alt)
		(b as Button).add_theme_font_size_override("font_size", int(clampf(24.0 * k, 12.0, 34.0)))
		(b as Button).add_theme_color_override("font_outline_color", CONTORNO)
		(b as Button).add_theme_constant_override("outline_size", maxi(2, int(3.0 * k)))
	_painel.custom_minimum_size = Vector2(tam.x, tam.y)      # altura fixa: cobre os 4 botões desenhados no vídeo original
	_painel.reset_size()
	_painel.size.x = tam.x

# ------------------------------------------------------------------ menu
func _existe_carreira() -> bool:
	return GameState.carreira_ativa or SaveSystem.existe_save()

func _lista_menu() -> Array:
	if _modo == "config":
		Opcoes.carregar()
		var c: Array = [
			{"id": "mao", "txt": "Toque: " + Opcoes.rotulo_mao()},
			{"id": "inv", "txt": "Chute: " + ("invertido" if Opcoes.invertido else "normal")},
			{"id": "tela", "txt": "Tela cheia (F11)"},
			{"id": "v_geral", "txt": _amb().rotulo_volume("geral")},
			{"id": "vol", "txt": _amb().rotulo_volume()},
			{"id": "v_partida", "txt": _amb().rotulo_volume("partida")},
			{"id": "mudo", "txt": _amb().rotulo_mudo()},
			{"id": "jogar_rapido", "txt": "Partida rápida"},
			{"id": "professor", "txt": "Modo professor"},
			{"id": "creditos", "txt": "Créditos"},
		]
		if SaveSystem.existe_save():
			c.append({"id": "apagar", "txt": "Toque de novo p/ apagar" if _confirma_apagar else "Apagar progresso"})
		c.append({"id": "voltar", "txt": "Voltar"})
		return c
	var m: Array = [
		{"id": "jogar", "txt": "Jogar"},
		{"id": "continuar", "txt": "Continuar carreira", "off": not _existe_carreira()},
		{"id": "novo", "txt": "Nova carreira"},
		{"id": "config", "txt": "Configurações"},
	]
	if not OS.has_feature("web") and not OS.has_feature("mobile"):
		m.append({"id": "sair", "txt": "Sair"})
	return m

func _montar() -> void:
	_opcoes = _lista_menu()
	_sel = clampi(_sel, 0, _opcoes.size() - 1)
	if bool(_opcoes[_sel].get("off", false)):
		_sel = _proximo_ativo(_sel, 1)
	for c in _lista.get_children():
		_lista.remove_child(c)
		c.queue_free()
	_botoes.clear()
	for i in _opcoes.size():
		var o: Dictionary = _opcoes[i]
		var b := Button.new()
		b.name = "Menu_" + str(o["id"])
		b.text = str(o["txt"]).to_upper()
		b.clip_text = true
		b.disabled = bool(o.get("off", false))
		b.custom_minimum_size = Vector2(0, 44)
		b.focus_mode = Control.FOCUS_NONE
		b.mouse_default_cursor_shape = Control.CURSOR_ARROW if b.disabled else Control.CURSOR_POINTING_HAND
		if _fonte != null:
			b.add_theme_font_override("font", _fonte)
		var idx: int = i
		b.pressed.connect(func():
			_sel = idx
			_ativar())
		b.mouse_entered.connect(func():
			if _sel != idx and not bool(_opcoes[idx].get("off", false)):
				_sel = idx
				_estilizar())
		_lista.add_child(b)
		_botoes.append(b)
	_estilizar()
	_layout.call_deferred()
	if _t_inicio:
		_lista.modulate.a = 0.0                # transição suave ao trocar entre menu e configurações
		create_tween().tween_property(_lista, "modulate:a", 1.0, 0.18)
	_t_inicio = true

func _caixa(fundo: Color, borda: Color, bw: int, brilho: bool) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fundo
	s.border_color = borda
	s.set_border_width_all(bw)
	s.set_corner_radius_all(14)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 4
	s.content_margin_bottom = 4
	if brilho:
		s.shadow_color = Color(1, 1, 1, 0.55)
		s.shadow_size = 9
	else:
		s.shadow_color = Color(0, 0, 0, 0.5)
		s.shadow_size = 3
		s.shadow_offset = Vector2(0, 3)
	return s

func _estilizar() -> void:
	for i in _botoes.size():
		var b: Button = _botoes[i]
		var sel: bool = i == _sel
		var id: String = str(_opcoes[i]["id"])
		var off: bool = b.disabled
		var fundo: Color = VERMELHO
		if id == "apagar":
			fundo = Color("7A1A22")
		if off:
			fundo = Color("5C2A2E")
		var s: StyleBoxFlat
		if sel and not off:
			s = _caixa(VERMELHO_CLARO, Color.WHITE, 4, true)
		else:
			s = _caixa(fundo, CONTORNO, 4, false)
		for k in ["normal", "hover", "pressed", "focus", "disabled"]:
			b.add_theme_stylebox_override(k, s)
		var cor_txt: Color = Color("A58A8C") if off else Color.WHITE
		for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_disabled_color"]:
			b.add_theme_color_override(k, cor_txt)

func _proximo_ativo(de: int, passo: int) -> int:
	var n: int = _opcoes.size()
	var i: int = de
	for _k in n:
		i = (i + passo + n) % n
		if not bool(_opcoes[i].get("off", false)):
			return i
	return de

func _input(e: InputEvent) -> void:
	if is_instance_valid(get_node_or_null("Dialogo")):
		return
	if e.is_action_pressed("ui_down"):
		_sel = _proximo_ativo(_sel, 1)
		_confirma_apagar = false
		_estilizar()
	elif e.is_action_pressed("ui_up"):
		_sel = _proximo_ativo(_sel, -1)
		_confirma_apagar = false
		_estilizar()
	elif e.is_action_pressed("ui_cancel") and _modo != "menu":
		_modo = "menu"
		_sel = 0
		_montar()
	elif e.is_action_pressed("ui_accept"):
		_ativar()

# ------------------------------------------------------------------ ações
func _tem_carreira() -> bool:
	if GameState.carreira_ativa:
		return true
	if SaveSystem.existe_save() and SaveSystem.carregar():
		return true
	return false

func _sem_carreira() -> void:
	var d: Dialogo = Dialogo.abrir(self, {"nome": "AVISO", "retrato": "res://assets/ui/ref/npcs/diretor_retrato.png",
		"paginas": ["Ainda não existe uma carreira salva. Comece uma nova para jogar, ver campeonatos e contratar."],
		"opcoes": [{"txt": "Começar nova carreira", "acao": func(): _novo_jogo()}], "fechar_txt": "Voltar"})
	d.name = "Dialogo"

func _novo_jogo() -> void:
	GameState.novo_jogo()
	GameState.carreira_ativa = true
	SceneManager.ir_para("hub", false)       # chega ao mapa; o tutorial abre na primeira entrada

func _confirmar_nova() -> void:
	var d: Dialogo = Dialogo.abrir(self, {"nome": "NOVA CARREIRA", "retrato": "res://assets/ui/ref/npcs/diretor_retrato.png",
		"paginas": ["Já existe uma carreira em andamento. Se você começar outra, a atual será substituída quando você salvar a nova. Deseja continuar?"],
		"opcoes": [{"txt": "Sim, começar nova carreira", "acao": func(): _novo_jogo()}], "fechar_txt": "Cancelar"})
	d.name = "Dialogo"

func _ir(tela: String) -> void:
	if _tem_carreira():
		if tela == "desafio" and GameState.temporada_status != "em_andamento":
			tela = "fim_temporada"
		SceneManager.ir_para(tela)
	else:
		_sem_carreira()

func _creditos() -> void:
	Dialogo.abrir_creditos(self)

func _ativar() -> void:
	if _opcoes.is_empty() or bool(_opcoes[_sel].get("off", false)):
		return
	match str(_opcoes[_sel]["id"]):
		"jogar":
			# Jogar leva ao mapa: retoma a carreira existente ou abre uma nova (com tutorial)
			if _existe_carreira() and _tem_carreira():
				SceneManager.ir_para("hub", false)
			else:
				_novo_jogo()
		"continuar":
			# carreira que já está na memória (saída para o menu sem salvar) continua de onde parou
			if GameState.carreira_ativa or SaveSystem.carregar():
				SceneManager.ir_para("hub", false)
		"novo":
			if _existe_carreira():
				_confirmar_nova()
			else:
				_novo_jogo()
		"config":
			_modo = "config"
			_sel = 0
			_montar()
		"sair": get_tree().quit()
		"voltar":
			_modo = "menu"
			_sel = 0
			_confirma_apagar = false
			_montar()
		"mao":
			Opcoes.alternar_mao()
			_montar()
		"inv":
			Opcoes.alternar_inversao()
			_montar()
		"tela":
			var tc: Node = get_node_or_null("/root/TelaCheia")
			if tc != null:
				tc.call("alternar")
		"jogar_rapido": _ir("config_partida")
		"v_geral":
			_amb().proximo_volume("geral")
			_montar()
		"v_partida":
			_amb().proximo_volume("partida")
			_montar()
		"vol":
			_amb().proximo_volume()
			_montar()
		"mudo":
			_amb().alternar_mudo()
			_montar()
		"professor": _ir("professor")
		"creditos": _creditos()
		"camp": _ir("torneios")
		"mercado": _ir("mercado")
		"apagar":
			if _confirma_apagar:
				SaveSystem.apagar_progresso()
				_confirma_apagar = false
				_sel = 0
			else:
				_confirma_apagar = true
			_montar()

## Autoload de som (acesso por caminho: funciona também em ferramentas que rodam sem autoloads registrados).
func _amb() -> Node:
	return Engine.get_main_loop().root.get_node("Ambiente")
