extends Control
class_name Hud2
## HUD pixel art 480x270: placar, relógio, escudos, indicador de jogador controlado,
## barra de força do chute e letreiros grandes (GOL / INTERVALO / FIM DE JOGO).
const FONTE_ESC := 1
var casa: Dictionary = {"sigla": "CFC", "cor1": Color("C94F50"), "cor2": Color("8F3035")}
var fora: Dictionary = {"sigla": "UNV", "cor1": Color("3B6E9E"), "cor2": Color("FFFDF8")}
var gols: Array = [0, 0]
var tempo_s: float = 0.0
var periodo: String = "1T"
var carga: float = 0.0
var nome_ctrl: String = ""
var bp: Dictionary = {}
var stats: String = ""
var folego: float = 1.0
var pausado: bool = false
var ajuda: bool = false
var defendendo: bool = false        # o adversário está com a bola e você controla um jogador de linha
var estado_jogando: bool = false
var decorrido: float = 0.0
var retrato: bool = false
var posse: int = -1                      # -1 sem posse, 0 casa, 1 visitante
var amarelos: Array = [0, 0]
var vermelhos: Array = [0, 0]
var em_campo: Array = [11, 11]
var trocas: Array = [3, 3]
var partida: Partida = null              # para o minimapa (somente leitura)
var minimapa: bool = true
var _sub: String = ""
var _banner: ImageTexture = null
var _banner_t: float = 0.0
var _t: float = 0.0
var _tex_cache: Dictionary = {}

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	custom_minimum_size = Vector2(480, 270)
	size = Vector2(480, 270)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func banner(txt: String, sub: String = "", seg: float = 2.0, vermelho: bool = false) -> void:
	var esc: int = 3 if txt.length() <= 9 else 2
	_banner = PixelUI.letreiro(txt, esc, Color("FF8A8A") if vermelho else Color("FFDE59"), Color("D8202F") if vermelho else Color("F08C28"))
	_banner_t = seg
	_sub = sub

func _txt(s: String, esc: int, cor: Color, sombra: Color = Color("1F1511")) -> ImageTexture:
	var k: String = "%s|%d|%s" % [s, esc, cor.to_html()]
	if not _tex_cache.has(k):
		if _tex_cache.size() > 200:
			_tex_cache.clear()
		_tex_cache[k] = PixelUI.texto(s, esc, cor, sombra)
	return _tex_cache[k]

func _process(delta: float) -> void:
	_t += delta
	_banner_t = maxf(0.0, _banner_t - delta)
	queue_redraw()

func _escudo(c: Dictionary, x: int, y: int) -> void:
	var c1: Color = c["cor1"]
	var c2: Color = c["cor2"]
	var cont := Color("F2F2F2")
	# escudo 11x13: contorno claro, metade c1 / metade c2, ponta embaixo
	for j in 13:
		var larg: int = 11 if j < 8 else 11 - (j - 7) * 2
		if larg < 1:
			larg = 1
		var x0: int = x + (11 - larg) / 2
		draw_rect(Rect2(x0, y + j, larg, 1), cont)
		if larg > 2:
			draw_rect(Rect2(x0 + 1, y + j, (larg - 2) / 2 + (larg - 2) % 2, 1), c1)
			draw_rect(Rect2(x0 + 1 + (larg - 2) / 2 + (larg - 2) % 2, y + j, (larg - 2) / 2, 1), c2)

func _draw() -> void:
	var vinho := Color("5A1420")
	var borda := Color("2A0A10")
	var ouro := Color("F2C14E")
	# placar central (modelo): escudos, siglas, gols e tempo
	draw_rect(Rect2(112, 0, 256, 21), borda)
	draw_rect(Rect2(114, 0, 252, 19), vinho)
	draw_rect(Rect2(114, 19, 252, 2), ouro)
	_escudo(casa, 120, 3)
	_escudo(fora, 349, 3)
	var tc: ImageTexture = _txt(str(casa["sigla"]), FONTE_ESC, Color("FFFDF6"))
	draw_texture(tc, Vector2(134, 7))
	var tf: ImageTexture = _txt(str(fora["sigla"]), FONTE_ESC, Color("FFFDF6"))
	draw_texture(tf, Vector2(346 - tf.get_width(), 7))
	draw_rect(Rect2(204, 0, 72, 21), borda)
	draw_rect(Rect2(206, 0, 68, 19), Color("3A0F18"))
	draw_rect(Rect2(206, 19, 68, 2), ouro)
	var placar: ImageTexture = _txt("%d - %d" % [gols[0], gols[1]], 2, Color("FFFDF6"))
	draw_texture(placar, Vector2(240 - placar.get_width() * 0.5, 3))
	var m: int = int(tempo_s) / 60
	var s: int = int(tempo_s) % 60
	draw_rect(Rect2(212, 21, 56, 11), borda)
	draw_rect(Rect2(213, 21, 54, 10), vinho)
	var rel: ImageTexture = _txt("%02d:%02d %s" % [m, s, periodo], FONTE_ESC, ouro)
	draw_texture(rel, Vector2(240 - rel.get_width() * 0.5, 24))
	if not bp.is_empty():
		var tp: Vector2 = bp["tela"]
		var amarelo := Color("F2C14E")
		draw_arc(tp, 7.0, 0.0, TAU, 20, amarelo, 1.5)
		draw_line(tp + Vector2(-11, 0), tp + Vector2(11, 0), amarelo, 1.0)
		draw_line(tp + Vector2(0, -11), tp + Vector2(0, 11), amarelo, 1.0)
		var tipo_txt: String = {"penalti": "PÊNALTI", "escanteio": "ESCANTEIO", "falta": "FALTA PERIGOSA"}[str(bp["tipo"])]
		var dica: String = "SETAS: mira e profundidade · CHUTE cruza" if str(bp["tipo"]) == "escanteio" else "SETAS: mira - segure CHUTE e solte"
		draw_rect(Rect2(90, 182, 300, 26), borda)
		draw_rect(Rect2(92, 184, 296, 22), vinho)
		var t1: ImageTexture = _txt(tipo_txt, FONTE_ESC, ouro)
		draw_texture(t1, Vector2(240 - t1.get_width() * 0.5, 185))
		var t2: ImageTexture = _txt(dica, FONTE_ESC, Color("FFFDF6"))
		draw_texture(t2, Vector2(240 - t2.get_width() * 0.5, 195))
		if str(bp["tipo"]) != "escanteio":
			draw_rect(Rect2(180, 172, 120, 7), borda)
			draw_rect(Rect2(181, 173, 118.0 * float(bp["carga"]), 5), Color("E8452C") if float(bp["carga"]) > 0.92 else amarelo)
	# cartão do jogador controlado (canto inferior esquerdo)
	if nome_ctrl != "":
		draw_rect(Rect2(4, 240, 96, 26), borda)
		draw_rect(Rect2(6, 242, 92, 22), vinho)
		draw_rect(Rect2(6, 242, 92, 2), ouro)
		var n: ImageTexture = _txt(nome_ctrl, FONTE_ESC, Color("FFFDF6"))
		draw_texture(n, Vector2(10, 247))
		draw_rect(Rect2(10, 257, 84, 4), borda)
		draw_rect(Rect2(11, 258, int(82.0 * clampf(folego, 0.0, 1.0)), 2), Color("7BD36B") if folego > 0.3 else Color("FF5A3B"))
	_faixa_info()
	if minimapa and partida != null and not pausado:
		_minimapa()
	if defendendo and not pausado and estado_jogando:
		var dd: ImageTexture = _txt("K DESARMAR   I CARRINHO", 1, Color("FFD84A"), Color("14101C"))
		draw_texture(dd, Vector2(480 - dd.get_width() - 6, 246))
	if decorrido < 8.0 and not pausado:
		var dica: ImageTexture = _txt("H: COMANDOS", 1, Color("FFD84A"))
		draw_texture(dica, Vector2(480 - dica.get_width() - 6, 260))
	if _banner_t > 0.0 and _banner != null and not pausado:
		var y: float = 44.0 + (sin(_t * 8.0) * 1.0 if _banner_t > 0.2 else 0.0)
		draw_texture(_banner, Vector2(round(240 - _banner.get_width() * 0.5), round(y)))
		if _sub != "":
			var tsub: ImageTexture = _txt(_sub, 1, Color("FFE9A8"))
			draw_texture(tsub, Vector2(round(240 - tsub.get_width() * 0.5), round(y) + _banner.get_height() + 3))
	if retrato:
		var gi: ImageTexture = _txt("GIRE O CELULAR PARA A HORIZONTAL", 1, Color("1F1511"), Color("FFD84A"))
		draw_rect(Rect2(240 - gi.get_width() * 0.5 - 4, 232, gi.get_width() + 8, 11), Color("FFD84A"))
		draw_texture(gi, Vector2(round(240 - gi.get_width() * 0.5), 235))
	if pausado:
		draw_rect(Rect2(0, 18, 480, 252), Color(0, 0, 0, 0.55))
		if ajuda:
			_ajuda()

## Minimapa (canto superior direito): campo inteiro, jogadores por cor de time e a bola.
func _minimapa() -> void:
	var w: float = 60.0
	var h: float = w * Cfg.PH / Cfg.PW * 1.0
	var o := Vector2(240.0 - w * 0.5, 270.0 - h - 4.0)
	draw_rect(Rect2(o - Vector2(1, 1), Vector2(w + 2, h + 2)), Color("1F1511"))
	draw_rect(Rect2(o, Vector2(w, h)), Color(0.24, 0.45, 0.22, 0.78))
	var lin := Color(1, 1, 1, 0.45)
	draw_rect(Rect2(o, Vector2(w, h)), lin, false, 1.0)
	draw_line(o + Vector2(w * 0.5, 0), o + Vector2(w * 0.5, h), lin, 1.0)
	draw_rect(Rect2(o + Vector2(0, h * 0.3), Vector2(w * 0.12, h * 0.4)), lin, false, 1.0)
	draw_rect(Rect2(o + Vector2(w * 0.88, h * 0.3), Vector2(w * 0.12, h * 0.4)), lin, false, 1.0)
	for q in partida.jogadores:
		var j: Jogador = q as Jogador
		if j.expulso:
			continue
		var c: Vector2 = (o + Vector2(j.position.x / Cfg.PW * w, j.position.y / Cfg.PH * h)).round()
		var cor: Color = casa["cor1"] if j.time == 0 else fora["cor1"]
		draw_rect(Rect2(c - Vector2(1, 1), Vector2(3, 3)), Color("F7F2E4") if j.controlado else cor)
		if j.controlado:
			draw_rect(Rect2(c - Vector2(2, 2), Vector2(5, 5)), Color("F2C14E"), false, 1.0)
	if partida.bola != null:
		var b: Vector2 = (o + Vector2(partida.bola.position.x / Cfg.PW * w, partida.bola.position.y / Cfg.PH * h)).round()
		draw_rect(Rect2(b - Vector2(1, 1), Vector2(2, 2)), Color.WHITE)

## Segunda faixa: indicador de posse (centro) e cartões/substituições de cada time.
func _faixa_info() -> void:
	# posse: barrinha discreta sob o placar; cartões/trocas só aparecem quando há algo a mostrar
	var cc: Color = casa["cor1"]
	var cf: Color = fora["cor1"]
	if posse >= 0:
		draw_rect(Rect2(222, 33, 17, 2), Color(cc.r, cc.g, cc.b, 1.0 if posse == 0 else 0.25))
		draw_rect(Rect2(241, 33, 17, 2), Color(cf.r, cf.g, cf.b, 1.0 if posse == 1 else 0.25))
	for t in 2:
		var x: int = 120 if t == 0 else 349
		if int(amarelos[t]) > 0:
			draw_rect(Rect2(x, 33, 4, 6), Color("FFD84A")); draw_rect(Rect2(x, 33, 4, 6), Color("1F1511"), false, 1.0)
			draw_texture(_txt(str(amarelos[t]), 1, Color.WHITE), Vector2(x + 6, 33)); x += 16
		if int(vermelhos[t]) > 0:
			draw_rect(Rect2(x, 33, 4, 6), Color("E03A3A")); draw_rect(Rect2(x, 33, 4, 6), Color("1F1511"), false, 1.0)
			draw_texture(_txt(str(vermelhos[t]), 1, Color.WHITE), Vector2(x + 6, 33)); x += 16
		# jogadores em campo: só aparece quando um time está com menos que o outro (expulsão), para ficar claro por que
		if int(em_campo[0]) != int(em_campo[1]):
			draw_texture(_txt("%d" % int(em_campo[t]), 1, Color("FFD0C8") if int(em_campo[t]) < int(em_campo[1 - t]) else Color("D8F5D0")), Vector2(x, 33)); x += 12
		if int(trocas[t]) < (5 if Cfg.MODO_11 else 3):
			draw_texture(_txt("T" + str(trocas[t]), 1, Color("F7F2E4")), Vector2(x, 33))

func _ajuda() -> void:
	draw_rect(Rect2(50, 24, 380, 232), Color("1F1511"))
	draw_rect(Rect2(51, 25, 378, 230), Color("4A2328"))
	draw_rect(Rect2(50, 24, 380, 232), Color("F7F2E4"), false, 1.0)
	var t: ImageTexture = PixelUI.letreiro("COMANDOS", 2)
	draw_texture(t, Vector2(round(240 - t.get_width() * 0.5), 29))
	var linhas: Array = [
		["MOVER", "WASD / SETAS"],
		["PASSE RASTEIRO", "J   (SEM BOLA: TROCA JOGADOR)"],
		["PASSE ALTO", "I"],
		["CHUTE", "K  SEGURE = MAIS FORCA"],
		["DESARME EM PE", "K SEM A BOLA"],
		["CARRINHO", "I SEM A BOLA (ARRISCA FALTA)"],
		["CORRER", "SHIFT  (GASTA FOLEGO)"],
		["TROCAR JOGADOR", "L  (PAUSADO: SUBSTITUI)"],
		["PAUSA / COMANDOS", "P ou ESC  /  H"],
		["CONTROLE", "A PASSE  B CHUTE/DESARME  X ALTO/CARRINHO"],
		["", "Y TROCA  RB CORRER"],
		["CELULAR", "JOYSTICK + BOTOES NA TELA"],
	]
	var y: int = 68
	for l in linhas:
		draw_texture(_txt(String(l[0]), 1, Color("FFD84A")), Vector2(62, y))
		draw_texture(_txt(String(l[1]), 1, Color("FFFFFF")), Vector2(190, y))
		y += 14
	var f: ImageTexture = _txt("H OU P: FECHAR", 1, Color("F7F2E4"))
	draw_texture(f, Vector2(round(240 - f.get_width() * 0.5), 243))
