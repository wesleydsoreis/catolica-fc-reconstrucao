class_name FundoNoturno
extends RefCounted
## Cenário noturno de estádio (céu, lua, cidade, refletores e gramado) em pixel art, gerado por código.

static var _tex: ImageTexture = null
const W: int = 195
const H: int = 422

static func textura() -> ImageTexture:
	if _tex != null:
		return _tex
	var img := Image.create(W, H, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for y in H:
		var t: float = float(y) / float(H)
		img.fill_rect(Rect2i(0, y, W, 1), Color(0.055 + 0.08 * t, 0.055 + 0.09 * t, 0.19 + 0.16 * t))
	for i in 60:
		img.set_pixel(rng.randi_range(0, W - 1), rng.randi_range(0, 150), Color("fffadc"))
	# lua
	for y in range(-9, 10):
		for x in range(-9, 10):
			if x * x + y * y <= 81:
				img.set_pixel(172 + x, 14 + y, Color("faf6d6"))
	# cidade
	var x: int = 0
	while x < W:
		var w: int = rng.randi_range(14, 26)
		var h: int = rng.randi_range(25, 60)
		img.fill_rect(Rect2i(x, 205 - h, w, h), Color("12163a"))
		for wy in range(205 - h + 5, 200, 7):
			for wx in range(x + 3, x + w - 3, 6):
				if rng.randf() < 0.45:
					img.fill_rect(Rect2i(wx, wy, 2, 3), Color("f5c846"))
		x += w + 2
	# arquibancada escura e pista vermelha
	img.fill_rect(Rect2i(0, 205, W, 22), Color("181e40"))
	img.fill_rect(Rect2i(0, 222, W, 5), Color("c84646"))
	# gramado em perspectiva
	for y in range(227, H):
		var t2: float = float(y - 227) / float(H - 227)
		var meia: float = 48.0 + t2 * 120.0
		var x0: int = int(W * 0.5 - meia)
		var x1: int = int(W * 0.5 + meia)
		var banda: int = int(float(y - 227) / (6.0 + t2 * 10.0)) % 2
		var verde: Color = Color("5cae3c") if banda == 0 else Color("4f9a34")
		img.fill_rect(Rect2i(maxi(0, x0), y, mini(W, x1) - maxi(0, x0), 1), verde)
		img.fill_rect(Rect2i(maxi(0, x0 - 1), y, 1, 1), Color("f0f0e6"))
		if x1 < W:
			img.fill_rect(Rect2i(x1, y, 1, 1), Color("f0f0e6"))
		for xx in range(0, maxi(0, x0 - 1)):
			img.set_pixel(xx, y, Color("181e40"))
		for xx in range(mini(W, x1 + 1), W):
			img.set_pixel(xx, y, Color("181e40"))
	# círculo central
	for a in 120:
		var ang: float = TAU * float(a) / 120.0
		var px: int = int(W * 0.5 + cos(ang) * 34.0)
		var py: int = int(318 + sin(ang) * 11.0)
		img.set_pixel(px, py, Color("f0f0e6"))
	img.fill_rect(Rect2i(W / 2, 227, 1, H - 227), Color("f0f0e6"))
	# refletores
	for lx in [16, 179]:
		img.fill_rect(Rect2i(lx - 1, 70, 3, 140), Color("2a2e58"))
		img.fill_rect(Rect2i(lx - 12, 52, 25, 14), Color("3c4170"))
		for i in 4:
			for j in 2:
				img.fill_rect(Rect2i(lx - 10 + i * 6, 54 + j * 6, 4, 4), Color("fffac8"))
	_tex = ImageTexture.create_from_image(img)
	return _tex
