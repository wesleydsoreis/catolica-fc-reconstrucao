extends Control
## Escalação das partidas (FUT7): 7 titulares em campo, formações de 7 e banco com o restante do elenco.
## É independente da escalação de 11 da gestão (Elenco). Usa GameState.fut7_* e vale para a partida jogável.

const LABEL_POS := {"GOLEIRO": "GOL", "DEFENSOR": "ZAG", "MEIA_DEFENSOR": "VOL", "MEIA": "MEI", "MEIA_ATAQUE": "MEA", "ATAQUE": "ATA"}
const COR_CAT := {"GOL": Color("F39C12"), "DEF": Color("3B6E9E"), "MEI": Color("5E9B4A"), "ATA": Color("C94F50")}

var _sel: int = -1
var _col: VBoxContainer
var _campo: Control
var _tokens: Array = []
var _frames: Dictionary = {}

func _ready() -> void:
	GameState.fut7_garantir()
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	rol.add_child(_col)
	_montar()

func _cat(j: Dictionary) -> String:
	return GameState._categoria_de_posicao(str(j.get("posicao", "MEIA")))

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_tokens.clear()
	var f: Dictionary = GameState.fut7_formacao_atual()
	var tit: Array = GameState.fut7_titulares()
	# título + força
	var soma := 0.0
	for j in tit:
		if j != null:
			soma += float(j["overall"])
	var cab := HBoxContainer.new()
	var t := Tema.titulo_secao("Escalação FUT7 · %d titulares" % tit.size())
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cab.add_child(t)
	cab.add_child(Tema.chip("MÉDIA %d" % int(round(soma / maxf(1.0, tit.size()))), Tema.VINHO))
	_col.add_child(cab)
	# formações
	var lf := HBoxContainer.new()
	lf.add_theme_constant_override("separation", 6)
	for fo in GameData.formacoes_fut7:
		var b := Tema.botao(str(fo["label"]), "escuro" if fo["id"] == f["id"] else "secundario", 38)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var fid: String = str(fo["id"])
		b.pressed.connect(func():
			_sel = -1
			GameState.fut7_mudar_formacao(fid)
			_montar.call_deferred())
		lf.add_child(b)
	_col.add_child(lf)
	# campo
	_campo = Control.new()
	_campo.custom_minimum_size = Vector2(0, 300)
	_campo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_campo.clip_contents = true
	_campo.draw.connect(_desenhar_campo)
	_campo.resized.connect(_posicionar)
	_col.add_child(_campo)
	for i in f["slots"].size():
		var tk: Button = _token(i, f["slots"][i], tit[i])
		_campo.add_child(tk)
		_tokens.append(tk)
	_posicionar.call_deferred()
	# selecionado
	_col.add_child(_painel_sel(tit, f))
	# banco
	var bn := Tema.cartao(Tema.BRANCO, 10)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 6)
	bn.add_child(bv)
	bv.add_child(Tema.titulo_secao("Banco de reservas"))
	var banco: Array = GameState.fut7_banco()
	if banco.is_empty():
		bv.add_child(Tema.rotulo("Sem reservas.", 13))
	for r in banco:
		bv.add_child(_linha_banco(r))
	_col.add_child(bn)
	# ações
	var auto := Tema.botao("AUTO · MELHOR TIME", "secundario", 44)
	auto.pressed.connect(func():
		_sel = -1
		GameState.fut7_sugerir(str(f["id"]))
		GameState.estado_mudou.emit()
		_montar.call_deferred())
	_col.add_child(auto)
	if GameState.prep_confirmada:
		var ir := Tema.botao("CONFIRMAR E IR PARA A TÁTICA", "primario", 56)
		ir.pressed.connect(func(): SceneManager.ir_para("tatica"))
		_col.add_child(ir)
	var fim := Control.new()
	fim.custom_minimum_size = Vector2(0, 8)
	_col.add_child(fim)

# ---------------------------------------------------------------- campo e fichas
func _frames_de(cid: String) -> SpriteFrames:
	if not _frames.has(cid):
		_frames[cid] = Npc.montar_frames(cid)
	return _frames[cid]

func _token(i: int, slot: Dictionary, j) -> Button:
	var b := Button.new()
	b.flat = false
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(76, 78)
	b.size = Vector2(76, 78)
	var sel: bool = i == _sel
	var estilo: StyleBoxFlat = Tema.caixa(Color(1, 1, 0.6, 0.35) if sel else Color(0, 0, 0, 0), Tema.AMARELO if sel else Color(0, 0, 0, 0), 3, 10, false, 0)
	for k in ["normal", "hover", "pressed", "focus"]:
		b.add_theme_stylebox_override(k, estilo)
	var cid: String = "goleiro" if slot["cat"] == "GOL" else "jogador"
	var at := AtlasTexture.new()
	at.atlas = load("res://assets/gerado/npcs/%s.png" % cid)
	at.region = Rect2(0, 0, 26, 38)
	var spr := TextureRect.new()
	spr.texture = at
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	spr.size = Vector2(39, 57)
	spr.position = Vector2(18, 2)
	spr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	spr.stretch_mode = TextureRect.STRETCH_SCALE
	spr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(spr)
	var num := Tema.chip(str(int(j.get("numero", slot["num"]))) if j != null else str(int(slot["num"])), COR_CAT[slot["cat"]])
	num.position = Vector2(2, 2)
	num.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(num)
	var nome := Label.new()
	nome.text = str(j["nome"]).split(" ")[0] if j != null else "—"
	nome.add_theme_font_size_override("font_size", 11)
	nome.add_theme_color_override("font_color", Color.WHITE)
	nome.add_theme_color_override("font_outline_color", Tema.TINTA)
	nome.add_theme_constant_override("outline_size", 5)
	nome.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nome.position = Vector2(0, 58)
	nome.size = Vector2(76, 16)
	nome.clip_text = true
	nome.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(nome)
	if j != null and GameState.indisponivel(str(j["id"])):
		var su := Tema.chip("SUSP" if GameState.jogo_suspenso(str(j["id"])) else "LESÃO", Tema.VINHO)
		su.position = Vector2(20, 40)
		su.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(su)
	if j != null:
		var ov := Tema.chip(str(int(j["overall"])), Tema.TINTA)
		ov.position = Vector2(50, 2)
		ov.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(ov)
	b.pressed.connect(func(): _clicou_token(i))
	return b

func _posicionar() -> void:
	if _campo == null or not is_instance_valid(_campo):
		return
	var f: Dictionary = GameState.fut7_formacao_atual()
	var tam: Vector2 = _campo.size
	for i in _tokens.size():
		var s: Dictionary = f["slots"][i]
		var tk: Button = _tokens[i]
		tk.position = Vector2(s["x"] * (tam.x - 40.0) + 4.0, s["y"] * tam.y) - Vector2(38, 36)
		tk.position.x = clampf(tk.position.x, 2.0, tam.x - 78.0)
		tk.position.y = clampf(tk.position.y, 2.0, tam.y - 80.0)
	_campo.queue_redraw()

func _desenhar_campo() -> void:
	var s: Vector2 = _campo.size
	var m: float = 8.0
	var c: Control = _campo
	c.draw_rect(Rect2(Vector2.ZERO, s), Color("1F1511"))
	var area := Rect2(m, m, s.x - 2 * m, s.y - 2 * m)
	c.draw_rect(area, Color("4F8F3C"))
	var faixas: int = 8
	for k in faixas:
		if k % 2 == 0:
			c.draw_rect(Rect2(area.position.x + area.size.x * k / faixas, area.position.y, area.size.x / faixas, area.size.y), Color("5BA044"))
	var lc := Color(1, 1, 1, 0.9)
	c.draw_rect(area, lc, false, 2.0)
	c.draw_line(Vector2(area.position.x + area.size.x * 0.5, area.position.y), Vector2(area.position.x + area.size.x * 0.5, area.end.y), lc, 2.0)
	c.draw_arc(area.get_center(), area.size.y * 0.16, 0, TAU, 32, lc, 2.0)
	var pa: float = area.size.y * 0.5
	c.draw_rect(Rect2(area.position.x, area.get_center().y - pa * 0.5, area.size.x * 0.14, pa), lc, false, 2.0)
	c.draw_rect(Rect2(area.end.x - area.size.x * 0.14, area.get_center().y - pa * 0.5, area.size.x * 0.14, pa), lc, false, 2.0)
	c.draw_rect(Rect2(area.position.x - 6, area.get_center().y - 18, 6, 36), Color("F7F2E4"))
	c.draw_rect(Rect2(area.end.x, area.get_center().y - 18, 6, 36), Color("F7F2E4"))

func _clicou_token(i: int) -> void:
	if _sel >= 0 and _sel != i:
		# troca de lugar dois titulares
		var tit: Array = GameState.fut7_titulares()
		GameState.fut7_trocar(i, str(tit[_sel]["id"]))
		_sel = -1
	else:
		_sel = -1 if _sel == i else i
	_montar.call_deferred()

# ---------------------------------------------------------------- painéis
func _painel_sel(tit: Array, f: Dictionary) -> Control:
	var c := Tema.cartao(Tema.PAINEL2, 10)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	c.add_child(v)
	if _sel < 0 or _sel >= tit.size() or tit[_sel] == null:
		v.add_child(Tema.titulo_secao("Jogador selecionado"))
		v.add_child(Tema.rotulo("Toque num jogador do campo para ver os atributos. Toque em outro para trocar de lugar, ou em ENTRAR no banco para substituir.", 13))
		return c
	var j: Dictionary = tit[_sel]
	var slot: Dictionary = f["slots"][_sel]
	var h := HBoxContainer.new()
	var nome := Tema.rotulo("%s  #%s" % [str(j["nome"]), str(j.get("numero", "-"))], 18)
	nome.add_theme_color_override("font_color", Tema.TITULO)
	h.add_child(nome)
	h.add_child(Tema.chip(LABEL_POS.get(j.get("posicao", "MEIA"), "MEI"), COR_CAT[_cat(j)]))
	v.add_child(h)
	if GameState.fut7_afinidade(j, str(slot["cat"])) > (1 if slot["cat"] != "MEI" else 0):
		v.add_child(Tema.chip("FORA DE POSIÇÃO (slot %s)" % slot["cat"], Tema.LARANJA))
	if GameState.jogo_lesionado(str(j["id"])):
		v.add_child(Tema.chip("LESIONADO: %d RODADA(S) FORA (um reserva entra no lugar)" % int(j.get("lesao", 0)), Tema.VINHO))
	elif GameState.jogo_suspenso(str(j["id"])):
		v.add_child(Tema.chip("SUSPENSO: FORA DO PRÓXIMO JOGO (um reserva entra no lugar)", Tema.VINHO))
	elif GameState.amarelos_acumulados(str(j["id"])) > 0:
		v.add_child(Tema.chip("AMARELOS %d/%d (3 = suspensão)" % [GameState.amarelos_acumulados(str(j["id"])), GameState.AMARELOS_PARA_SUSPENSAO], Tema.LARANJA))
	v.add_child(Tema.barra("Overall", float(j["overall"]), Color("C94F50")))
	v.add_child(Tema.barra("Energia", float(j["energia"]), Tema.VERDE, "%"))
	v.add_child(Tema.barra("Condição física", GameState.fisico_de(j), Tema.AZUL))
	v.add_child(Tema.barra("Técnica", GameState.tecnica_de(j), Tema.VINHO))
	v.add_child(Tema.barra("Moral", float(j.get("moral_individual", 60)), Tema.LARANJA, "%"))
	var extra: String = "Salário %s/rodada" % Tema.reais(int(j.get("salario", 0)))
	var gols: int = int(GameState.gols_registrados.get(j["nome"], 0))
	extra += " · %d gol(s)" % gols
	v.add_child(Tema.rotulo(extra, 12, Tema.TEXTO2))
	return c

func _linha_banco(r: Dictionary) -> Control:
	var l := HBoxContainer.new()
	l.add_theme_constant_override("separation", 8)
	var n := Tema.chip(str(int(r.get("numero", 0))), Color("8A8270"))
	l.add_child(n)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 0)
	info.add_child(Tema.rotulo(str(r["nome"]) + ("  · SUSPENSO" if GameState.jogo_suspenso(str(r["id"])) else ("  · LESIONADO" if GameState.jogo_lesionado(str(r["id"])) else "")), 14))
	info.add_child(Tema.rotulo("%s · OVR %d · Energia %d%%" % [LABEL_POS.get(r.get("posicao", "MEIA"), "MEI"), int(r["overall"]), int(r["energia"])], 11, Tema.TEXTO2))
	l.add_child(info)
	var b := Tema.botao("ENTRAR" if _sel >= 0 else "—", "verde" if _sel >= 0 else "secundario", 40)
	b.custom_minimum_size = Vector2(92, 40)
	b.disabled = _sel < 0 or GameState.indisponivel(str(r["id"]))
	var id: String = str(r["id"])
	b.pressed.connect(func():
		GameState.fut7_trocar(_sel, id)
		_sel = -1
		_montar.call_deferred())
	l.add_child(b)
	return l
