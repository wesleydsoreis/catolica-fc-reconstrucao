extends Node
## Som de ambiente por área (autoload). Cada tela de área toca, em loop, o som do vídeo dela (assets/audio/area-*.ogg).
## Regras:
##  - Um som por vez: ao trocar de área o anterior some com fade enquanto o novo entra (sem sobreposição audível).
##  - O som de área fica no barramento "Ambiente"; quando houver música de fundo, ela é abaixada (ducking) enquanto a área toca.
##  - Só toca depois da primeira interação (clique/toque/tecla), respeitando a política de autoplay do navegador.
##  - Volume e mudo gravados em user://opcoes.cfg (no navegador vira armazenamento local); se não gravar, segue em memória.
##  - Para ao perder o foco/ir para segundo plano e volta ao retomar.

const AREAS := {
	"inicio": "area-menu", "hub": "area-mapa", "mapa": "area-mapa",
	"painel": "area-secretaria", "treino": "area-treino", "mercado": "area-mercado", "estadio_obras": "area-obras",
}
## Áreas com vários sons: ao entrar sorteia um (sem repetir o último) e, a cada 18–30 s, troca por outro também sorteado.
const POOLS := {"area-menu": ["area-menu-bola", "area-menu-passaros", "area-menu-manha"]}
const PASTA := "res://assets/audio/"
const EXTS := ["ogg", "mp3", "wav"]
const FADE := 0.35
const MUDO_DB := -80.0

var volume: float = 0.8            # som de ambiente das áreas, 0..1
var geral: float = 1.0             # volume geral do jogo (Master), 0..1
var partida: float = 0.8           # sons da partida: torcida e apito (barramento "Partida")
var mudo: bool = false
var area_atual: String = ""        # id do arquivo tocando ("" = silêncio)
var interagiu: bool = false
var em_segundo_plano: bool = false
var _pool_ultimo: String = ""       # último sorteado no pool atual
var _pool_token: int = 0
var _pedida: String = ""           # área pedida (pode esperar a primeira interação)
var _a: AudioStreamPlayer
var _b: AudioStreamPlayer
var _ativo: AudioStreamPlayer
var _tw: Tween
var _extra: Dictionary = {}        # streams registradas por código (testes)

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for nome in ["Ambiente", "Partida"]:
		if AudioServer.get_bus_index(nome) < 0:
			AudioServer.add_bus()
			var i: int = AudioServer.bus_count - 1
			AudioServer.set_bus_name(i, nome)
			AudioServer.set_bus_send(i, "Master")
	_a = _novo_player()
	_b = _novo_player()
	_ativo = _a
	_carregar()
	_aplicar_bus()

func _novo_player() -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.bus = "Ambiente"
	p.volume_db = MUDO_DB
	add_child(p)
	return p

# ---------------------------------------------------------------- opções
func _carregar() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://opcoes.cfg") == OK:
		volume = clampf(float(cf.get_value("audio", "ambiente", 0.8)), 0.0, 1.0)
		mudo = bool(cf.get_value("audio", "mudo", false))
		geral = clampf(float(cf.get_value("audio", "geral", 1.0)), 0.0, 1.0)
		partida = clampf(float(cf.get_value("audio", "partida", 0.8)), 0.0, 1.0)

func _salvar() -> void:
	var cf := ConfigFile.new()
	cf.load("user://opcoes.cfg")                       # preserva as outras seções (controles)
	cf.set_value("audio", "ambiente", volume)
	cf.set_value("audio", "mudo", mudo)
	cf.set_value("audio", "geral", geral)
	cf.set_value("audio", "partida", partida)
	if cf.save("user://opcoes.cfg") != OK:
		push_warning("Ambiente: não foi possível gravar as opções de som; valores valem só nesta sessão.")

func definir_volume(v: float) -> void:
	definir("ambiente", v)

func alternar_mudo() -> void:
	mudo = not mudo
	_aplicar_bus()
	_salvar()

## Passo do menu (0 → 25 → 50 → 75 → 100 → 0 %), para qualquer um dos três volumes: "ambiente", "geral", "partida".
func proximo_volume(qual: String = "ambiente") -> void:
	var v: float = float(get(_prop(qual)))
	var pct: int = int(round(v * 100.0 / 25.0))
	definir(qual, float((pct + 1) % 5) * 0.25)

func _prop(qual: String) -> String:
	return "volume" if qual == "ambiente" else qual

func definir(qual: String, v: float) -> void:
	set(_prop(qual), clampf(v, 0.0, 1.0))
	_aplicar_bus()
	_salvar()

func rotulo_volume(qual: String = "ambiente") -> String:
	var nomes := {"ambiente": "Som ambiente", "geral": "Volume geral", "partida": "Som da partida"}
	return "%s: %d%%" % [nomes[qual], int(round(float(get(_prop(qual))) * 100.0))]

func rotulo_mudo() -> String:
	return "Som: " + ("MUDO" if mudo else "ligado")

func _aplicar_bus() -> void:
	AudioServer.set_bus_mute(0, mudo or geral <= 0.001)            # mudo e volume geral valem para o jogo inteiro
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(geral, 0.0001)))
	for par in [["Ambiente", volume], ["Partida", partida]]:
		var i: int = AudioServer.get_bus_index(par[0])
		if i < 0:
			continue
		AudioServer.set_bus_mute(i, float(par[1]) <= 0.001)
		AudioServer.set_bus_volume_db(i, linear_to_db(maxf(float(par[1]), 0.0001)))
	var m: int = AudioServer.get_bus_index("Musica")          # música de fundo (se existir) fica abaixo do som da área
	if m >= 0:
		AudioServer.set_bus_volume_db(m, -12.0 if area_atual != "" and not mudo else 0.0)

# ---------------------------------------------------------------- áreas
## Chamado pelo SceneManager a cada troca de tela.
func tela(nome: String) -> void:
	var nova: String = str(AREAS.get(nome, ""))
	if nova != _pedida:
		_pool_token += 1                               # saiu da área: cancela o revezamento agendado
	_pedida = nova
	_tocar_pedida()

func _tocar_pedida() -> void:
	if not interagiu:
		return                                         # autoplay: espera o primeiro clique/toque/tecla
	if POOLS.has(_pedida):
		if not (POOLS[_pedida] as Array).has(area_atual):
			_sortear_pool()
		return
	if _pedida == area_atual:
		return
	var st: AudioStream = _stream(_pedida) if _pedida != "" else null
	_trocar(st, _pedida if st != null else "")

func _sortear_pool() -> void:
	var lista: Array = (POOLS[_pedida] as Array).filter(func(n): return n != _pool_ultimo and _stream(n) != null)
	if lista.is_empty():
		lista = (POOLS[_pedida] as Array).filter(func(n): return _stream(n) != null)
	if lista.is_empty():
		_trocar(null, "")                              # nenhum arquivo: silêncio, sem erro
		return
	var id: String = lista[randi() % lista.size()]
	_pool_ultimo = id
	var st: AudioStream = _stream(id)
	var folga: float = maxf(0.0, st.get_length() - 35.0)
	_trocar(st, id, randf() * folga)                   # começa num ponto sorteado: cada visita soa diferente
	_pool_token += 1
	var tk: int = _pool_token
	get_tree().create_timer(randf_range(18.0, 30.0), true).timeout.connect(func():
		if tk == _pool_token and POOLS.has(_pedida):
			_sortear_pool())

func _stream(id: String) -> AudioStream:
	if _extra.has(id):
		return _extra[id]
	for e in EXTS:
		var caminho: String = "%s%s.%s" % [PASTA, id, e]
		if ResourceLoader.exists(caminho):
			var s: Resource = load(caminho)
			if s is AudioStream:
				return s
	return null                                        # arquivo ainda não entregue: área em silêncio, sem erro

func registrar(id: String, s: AudioStream) -> void:
	_extra[id] = s

func _trocar(novo: AudioStream, id: String, inicio: float = 0.0) -> void:
	var velho: AudioStreamPlayer = _ativo
	if _tw != null and _tw.is_valid():
		_tw.kill()
	_tw = create_tween().set_parallel(true)
	if velho.playing:
		_tw.tween_property(velho, "volume_db", MUDO_DB, FADE)
		var v := velho
		get_tree().create_timer(FADE).timeout.connect(func(): if v != _ativo or area_atual == "": v.stop())
	area_atual = id
	if novo != null:
		_laco(novo)
		var p: AudioStreamPlayer = _b if velho == _a else _a
		p.stream = novo
		p.volume_db = MUDO_DB
		p.play(inicio)
		p.stream_paused = em_segundo_plano          # play() limpa a pausa: reaplica depois
		_tw.tween_property(p, "volume_db", 0.0, FADE)
		_ativo = p
	_aplicar_bus()

func _laco(s: AudioStream) -> void:
	if s is AudioStreamOggVorbis:
		(s as AudioStreamOggVorbis).loop = true
	elif s is AudioStreamMP3:
		(s as AudioStreamMP3).loop = true
	elif s is AudioStreamWAV:
		(s as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
		if (s as AudioStreamWAV).loop_end <= 0:
			(s as AudioStreamWAV).loop_end = (s as AudioStreamWAV).data.size() / maxi(1, (2 if (s as AudioStreamWAV).format == AudioStreamWAV.FORMAT_16_BITS else 1) * (2 if (s as AudioStreamWAV).stereo else 1))

func tocando() -> bool:
	return _ativo != null and _ativo.playing and not _ativo.stream_paused

# ---------------------------------------------------------------- autoplay e segundo plano
func _input(ev: InputEvent) -> void:
	if interagiu:
		return
	if ev is InputEventMouseButton or ev is InputEventScreenTouch or ev is InputEventKey or ev is InputEventJoypadButton:
		if (ev is InputEventMouseButton or ev is InputEventScreenTouch) and not ev.is_pressed():
			return
		interagiu = true
		_tocar_pedida()

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_WINDOW_FOCUS_OUT, NOTIFICATION_APPLICATION_PAUSED:
			_segundo_plano(true)
		NOTIFICATION_APPLICATION_FOCUS_IN, NOTIFICATION_WM_WINDOW_FOCUS_IN, NOTIFICATION_APPLICATION_RESUMED:
			_segundo_plano(false)

func _segundo_plano(sim: bool) -> void:
	em_segundo_plano = sim
	for p in [_a, _b]:
		if p != null:
			(p as AudioStreamPlayer).stream_paused = sim
