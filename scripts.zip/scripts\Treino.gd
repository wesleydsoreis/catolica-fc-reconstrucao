extends Control
## Centro de Treinamento: agenda semanal de 4 turnos + jogador em foco.
## Os efeitos são reais (condição física, técnica, entrosamento, energia, moral e risco de lesão) e a prévia mostra os números antes de confirmar.

const ORDEM := ["fisico", "tecnico", "tatico", "recuperacao", "folga"]
const COR := {"fisico": Tema.AZUL, "tecnico": Tema.VINHO, "tatico": Tema.LARANJA, "recuperacao": Tema.VERDE, "folga": Tema.AMARELO}

var _col: VBoxContainer
var _agenda: Array = []
var _foco_idx: int = 0
var _jogadores: Array = []

func _ready() -> void:
	_agenda = GameState.agenda_treino.duplicate()
	_jogadores = GameState.elenco.duplicate()
	_jogadores.sort_custom(func(a, b): return int(a["overall"]) > int(b["overall"]))
	for i in _jogadores.size():
		if str(_jogadores[i]["id"]) == GameState.treino_foco_id:
			_foco_idx = i
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	_col = VBoxContainer.new()
	_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_col.add_theme_constant_override("separation", 10)
	mg.add_child(_col)
	_montar()

func _foco_id() -> String:
	return str(_jogadores[_foco_idx]["id"]) if not _jogadores.is_empty() else ""

func _montar() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	var feito: bool = GameState.treino_confirmado
	_col.add_child(Tema.titulo_secao("Centro de Treinamento · Rodada %d" % GameState.rodada_atual))
	var info := Tema.rotulo("Distribua os 4 turnos da semana. Cada escolha muda atributos de verdade, mas treino pesado aumenta o risco de lesão.", 13)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_col.add_child(info)
	# --- agenda
	var ca := Tema.cartao(Tema.BRANCO)
	var va := VBoxContainer.new()
	va.add_theme_constant_override("separation", 8)
	ca.add_child(va)
	va.add_child(Tema.rotulo("AGENDA DA SEMANA", 12, Tema.TITULO))
	var dias := ["TERÇA", "QUARTA", "QUINTA", "SEXTA"]
	for i in GameState.TURNOS_TREINO:
		var tipo: String = str(_agenda[i])
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 8)
		var d := Tema.rotulo(dias[i], 12, Tema.TEXTO)
		d.custom_minimum_size.x = 56
		d.size_flags_horizontal = Control.SIZE_FILL
		d.autowrap_mode = TextServer.AUTOWRAP_OFF
		h.add_child(d)
		var b := Tema.botao("%s  ▸" % str(GameState.TIPOS_TREINO[tipo]["nome"]).to_upper(), "ouro" if tipo == "folga" else "secundario", 44)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.name = "Turno_%d" % i
		b.disabled = feito
		var idx: int = i
		b.pressed.connect(func():
			_agenda[idx] = ORDEM[(ORDEM.find(_agenda[idx]) + 1) % ORDEM.size()]
			_montar.call_deferred())
		var bs := Tema.caixa(COR[tipo].darkened(0.28), Tema.TINTA, 3, 8, false, 8)
		for k in ["normal", "hover", "pressed", "disabled"]:
			b.add_theme_stylebox_override(k, bs)
		h.add_child(b)
		va.add_child(h)
		var ds := Tema.rotulo(str(GameState.TIPOS_TREINO[tipo]["desc"]), 11, Tema.TEXTO2)
		ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		va.add_child(ds)
	_col.add_child(ca)
	# --- foco
	var cf := Tema.cartao(Tema.BRANCO)
	var vf := VBoxContainer.new()
	cf.add_child(vf)
	vf.add_child(Tema.rotulo("JOGADOR EM FOCO (treino técnico rende +2,0 extra)", 12, Tema.TITULO))
	var hf := HBoxContainer.new()
	hf.add_theme_constant_override("separation", 6)
	var bp := Tema.botao("◀", "secundario", 42)
	bp.custom_minimum_size.x = 48
	bp.name = "FocoAnterior"
	bp.disabled = feito
	bp.pressed.connect(func():
		_foco_idx = (_foco_idx - 1 + _jogadores.size()) % _jogadores.size()
		_montar.call_deferred())
	hf.add_child(bp)
	var j: Dictionary = _jogadores[_foco_idx] if not _jogadores.is_empty() else {}
	var nj := Tema.rotulo("%s · OVR %d · Téc %d" % [j.get("nome", "—"), int(j.get("overall", 0)), int(GameState.tecnica_de(j)) if not j.is_empty() else 0], 14)
	nj.name = "FocoNome"
	nj.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hf.add_child(nj)
	var bn := Tema.botao("▶", "secundario", 42)
	bn.custom_minimum_size.x = 48
	bn.name = "FocoProximo"
	bn.disabled = feito
	bn.pressed.connect(func():
		_foco_idx = (_foco_idx + 1) % _jogadores.size()
		_montar.call_deferred())
	hf.add_child(bn)
	vf.add_child(hf)
	_col.add_child(cf)
	# --- prévia
	var pv: Dictionary = GameState.previa_treino(_agenda, _foco_id())
	var cp := Tema.cartao(Tema.AMARELO, 12)
	var vp := VBoxContainer.new()
	vp.add_theme_constant_override("separation", 3)
	cp.add_child(vp)
	vp.add_child(Tema.rotulo("PRÉVIA DA SEMANA", 12, Tema.TITULO))
	vp.add_child(_linha("Condição física", "+%.1f" % pv["fisico"]))
	vp.add_child(_linha("Técnica (elenco / foco)", "+%.1f / +%.1f" % [pv["tecnica"], pv["tecnica"] + pv["tecnica_foco"]]))
	vp.add_child(_linha("Entrosamento do estilo atual", "%d → %d" % [int(pv["entrosamento_de"]), int(minf(100.0, pv["entrosamento_de"] + pv["entrosamento"]))]))
	vp.add_child(_linha("Energia média do elenco", "%+d" % int(pv["energia"])))
	vp.add_child(_linha("Moral", "%+d" % int(pv["moral"])))
	var risco := _linha("Risco de lesão por jogador", "%.1f%%" % (100.0 * pv["risco_medio"]))
	risco.name = "LinhaRisco"
	vp.add_child(risco)
	var f := Tema.rotulo("Risco = 1,2% × (turnos intensos − 1) + 0,07% × (70 − energia) − 1,2% × recuperações", 11, Tema.TEXTO2)
	f.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vp.add_child(f)
	_col.add_child(cp)
	# --- ações / relatório
	if feito:
		var cr := Tema.cartao(Tema.BRANCO)
		var vr := VBoxContainer.new()
		cr.add_child(vr)
		vr.add_child(Tema.rotulo("TREINO DA SEMANA CONCLUÍDO", 12, Tema.TITULO))
		for m in GameState.relatorio_treino:
			var l := Tema.rotulo("• " + str(m), 13)
			l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			vr.add_child(l)
		_col.add_child(cr)
	else:
		var conf := Tema.botao("CONFIRMAR TREINO", "primario", 54)
		conf.name = "BotaoConfirmar"
		conf.pressed.connect(func():
			GameState.confirmar_treino(_agenda, _foco_id())
			_montar.call_deferred())
		_col.add_child(conf)
	var vl := Tema.botao("VOLTAR AO MAPA", "escuro", 44)
	vl.name = "BotaoVoltar"
	vl.pressed.connect(func(): SceneManager.ir_para("mapa", false))
	_col.add_child(vl)

func _linha(a: String, b: String) -> Control:
	var h := HBoxContainer.new()
	var l := Tema.rotulo(a, 13)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	var r := Tema.rotulo(b, 13, Tema.TITULO)
	r.size_flags_horizontal = Control.SIZE_SHRINK_END
	r.autowrap_mode = TextServer.AUTOWRAP_OFF
	h.add_child(r)
	return h
