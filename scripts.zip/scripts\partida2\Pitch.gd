extends Node2D
class_name Pitch
## Campo em projeção ortogonal com rolagem horizontal (câmera segue a bola). A lógica roda em (x,y) do plano 2D
## (Cfg.PW x Cfg.PH); project() converte para o "mundo de tela" (largura LARG_MUNDO); a câmera desloca esse mundo.
## Constantes iguais às de scripts/arte/campo_gen.py.
const SW := 480
const SH := 270
const MARG := 150.0
static var KX: float = 0.20
static var YF: float = 96.0
static var YN: float = 266.0
static var KY: float = 0.0872
static var LARG_MUNDO: float = 720.0
static var sufixo: String = "11"

signal gol_balancou(lado: int)
var gols: Array = []

static func usar_modo() -> void:
	if Cfg.MODO_11:
		KX = 0.20
		sufixo = "11"
	else:
		KX = 0.185
		sufixo = "7"
	KY = (YN - YF) / Cfg.PH
	LARG_MUNDO = (Cfg.PW + 2.0 * MARG) * KX

static func project(x: float, y: float) -> Vector2:
	return Vector2((x + MARG) * KX, YF + y * KY)

## Deslocamento horizontal da câmera (px) para centralizar x_mundo; limitado às bordas do campo.
static func camera_x(x_mundo: float) -> float:
	if LARG_MUNDO <= SW:
		return (LARG_MUNDO - SW) * 0.5
	return clampf((x_mundo + MARG) * KX - SW * 0.5, 0.0, LARG_MUNDO - SW)

func _ready() -> void:
	usar_modo()
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var fundo := Sprite2D.new()
	fundo.centered = false
	fundo.texture = load("res://assets/gerado/campo_%s.png" % sufixo)
	add_child(fundo)
	var meta: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/gerado/projecao_%s.json" % sufixo))
	for n in ["gol_esq", "gol_dir"]:
		var s := Sprite2D.new()
		s.centered = false
		s.texture = load("res://assets/gerado/%s_%s.png" % [n, sufixo])
		var o: Array = meta["gols"][n]
		s.position = Vector2(o[0], o[1])
		add_child(s)
		gols.append(s)

func balancar_rede(lado: int) -> void:
	var s: Sprite2D = gols[lado]
	var t := create_tween()
	for i in 4:
		t.tween_property(s, "position:x", s.position.x + (3 - i) * (1 if lado == 0 else -1) * (-1 if i % 2 else 1), 0.05)
	t.tween_property(s, "position:x", s.position.x, 0.05)
