extends Control
## Mercado
## Lista o catálogo de mercado (GameState.mercado_jogadores — já filtrado dos
## jogadores já contratados), com filtro por raridade e contratação real
## (desconta do caixa, adiciona ao elenco), igual às regras do HTML original.

const LABEL_POSICAO := {
	"GOLEIRO": "GOL", "DEFENSOR": "ZAG", "MEIA_DEFENSOR": "VOL",
	"MEIA": "MEI", "MEIA_ATAQUE": "MEA", "ATAQUE": "ATA",
}
const ORDEM_RARIDADES := ["TODAS", "comum", "incomum", "raro", "craque", "especial"]

@onready var linha_filtros: HBoxContainer = $Coluna/LinhaFiltros
@onready var lista_jogadores: VBoxContainer = $Coluna/Scroll/Margem/ListaJogadores
@onready var label_caixa: Label = $Coluna/BarraTopo/LinhaTopo/LabelCaixa

var _filtro_atual: String = "TODAS"

func _ready() -> void:
	_montar_filtros()
	GameState.estado_mudou.connect(_atualizar)
	_atualizar()

func _exit_tree() -> void:
	if GameState.estado_mudou.is_connected(_atualizar):
		GameState.estado_mudou.disconnect(_atualizar)

func _montar_filtros() -> void:
	for r in ORDEM_RARIDADES:
		var botao := Button.new()
		botao.text = r if r == "TODAS" else GameData.faixas_mercado.get(r, {}).get("label", r)
		botao.custom_minimum_size = Vector2(0, 36)
		botao.clip_text = true
		botao.add_theme_font_size_override("font_size", 10)
		Tema.aplicar_botao(botao, "secundario")
		for k in ["normal", "hover", "pressed", "disabled"]:
			(botao.get_theme_stylebox(k) as StyleBoxFlat).content_margin_left = 2
			(botao.get_theme_stylebox(k) as StyleBoxFlat).content_margin_right = 2
		botao.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		botao.pressed.connect(func():
			_filtro_atual = r
			_atualizar()
		)
		linha_filtros.add_child(botao)

func _atualizar() -> void:
	label_caixa.text = "Caixa: %s" % _formatar_reais(int(GameState.financas.get("caixa", 0)))
	for filho in lista_jogadores.get_children():
		filho.queue_free()
	for jogador in GameState.mercado_jogadores:
		if _filtro_atual != "TODAS" and jogador["raridade"] != _filtro_atual:
			continue
		lista_jogadores.add_child(_criar_linha(jogador))

const COR_RARIDADE := {"comum": Color("8A8270"), "incomum": Color("5E9B4A"), "raro": Color("3B6E9E"), "craque": Color("8F303A"), "especial": Color("C98A00")}

func _criar_linha(jogador: Dictionary) -> Control:
	var painel := Tema.cartao(Tema.BRANCO, 8)
	var linha := HBoxContainer.new()
	linha.add_theme_constant_override("separation", 10)
	painel.add_child(linha)
	var rar: String = str(jogador["raridade"])
	var cor: Color = COR_RARIDADE.get(rar, Color("8A8270"))
	# círculo com a inicial
	var cir := PanelContainer.new()
	var sc: StyleBoxFlat = Tema.caixa(cor, Tema.TINTA, 3, 24, false, 0)
	cir.add_theme_stylebox_override("panel", sc)
	cir.custom_minimum_size = Vector2(48, 48)
	var ini := Label.new()
	ini.text = str(jogador["nome"]).substr(0, 1).to_upper()
	ini.add_theme_font_size_override("font_size", 22)
	ini.add_theme_color_override("font_color", Color.WHITE)
	ini.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ini.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ini.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cir.add_child(ini)
	var cc := CenterContainer.new()
	cc.add_child(cir)
	linha.add_child(cc)

	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 2)
	linha.add_child(info)
	var pos_label: String = LABEL_POSICAO.get(jogador["posicao"], jogador["posicao"])
	var nome := Tema.rotulo(str(jogador["nome"]), 15)
	info.add_child(nome)
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 6)
	chips.add_child(Tema.chip(pos_label, Tema.TINTA))
	chips.add_child(Tema.chip("OVR %d" % int(jogador["overall"]), Tema.VINHO))
	chips.add_child(Tema.chip(rar.to_upper(), cor))
	info.add_child(chips)
	if jogador.get("habilidade_especial"):
		info.add_child(Tema.rotulo(str(jogador["habilidade_especial"]), 11, Tema.TEXTO2))

	var sem_saldo: bool = float(GameState.financas.get("caixa", 0)) < float(jogador["preco"])
	var botao_comprar := Tema.botao("SEM SALDO" if sem_saldo else _formatar_reais(int(jogador["preco"])), "primario", 46)
	botao_comprar.add_theme_font_size_override("font_size", 12)
	botao_comprar.disabled = sem_saldo
	botao_comprar.custom_minimum_size = Vector2(104, 46)
	var id_jogador: String = jogador["id"]
	botao_comprar.pressed.connect(func(): _contratar(id_jogador))
	linha.add_child(botao_comprar)
	return painel

func _contratar(id_jogador: String) -> void:
	var mensagem := GameState.contratar_jogador(id_jogador)
	if mensagem != "":
		var aviso := AcceptDialog.new()
		aviso.dialog_text = mensagem
		add_child(aviso)
		aviso.popup_centered()
		aviso.confirmed.connect(func(): aviso.queue_free())

func _formatar_reais(valor: int) -> String:
	var negativo := valor < 0
	var v := absi(valor)
	var texto := str(v)
	var resultado := ""
	var contagem := 0
	for i in range(texto.length() - 1, -1, -1):
		resultado = texto[i] + resultado
		contagem += 1
		if contagem % 3 == 0 and i != 0:
			resultado = "." + resultado
	return "%sR$ %s" % ["-" if negativo else "", resultado]

func _on_botao_voltar_pressed() -> void:
	SceneManager.voltar()
