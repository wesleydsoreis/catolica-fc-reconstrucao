class_name Paleta
extends RefCounted
## Paleta e estilos da identidade nova (bordô, vermelho institucional, branco, creme e dourado).

const DOURADO := Color("E8B84A")
const BORDO := Color("4B0A12")
const BORDO_ESC := Color("2A0A10")
const VERMELHO := Color("B3202A")
const CREME := Color("F7EFDF")
const BRANCO := Color("FFFDF6")

static func estilo(fundo: Color, borda: Color, bw: int = 2, raio: int = 10, margem: int = 8, sombra: bool = true) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fundo
	s.border_color = borda
	s.set_border_width_all(bw)
	s.set_corner_radius_all(raio)
	if sombra:
		s.shadow_color = Color(0, 0, 0, 0.45)
		s.shadow_size = 6
		s.shadow_offset = Vector2(0, 3)
	s.content_margin_left = margem
	s.content_margin_right = margem
	s.content_margin_top = margem * 0.6
	s.content_margin_bottom = margem * 0.6
	return s

## tipo: "ouro" (ação principal), "bordo" (padrão), "perigo", "discreto".
static func botao(texto: String, tipo: String = "bordo", tam: int = 20, altura: float = 44.0) -> Button:
	var b := Button.new()
	b.text = texto
	b.custom_minimum_size = Vector2(0, altura)
	b.focus_mode = Control.FOCUS_ALL
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.add_theme_font_override("font", Fontes.titulo(600))
	b.add_theme_font_size_override("font_size", tam)
	var n: Color = Color("7A1220")
	var h: Color = DOURADO
	var bd: Color = Color("A83040")
	var txt: Color = CREME
	var txt_h: Color = BORDO_ESC
	match tipo:
		"ouro":
			n = DOURADO; h = Color("F5D27A"); bd = BORDO_ESC; txt = BORDO_ESC
		"perigo":
			n = VERMELHO; h = Color("D8434D"); bd = BORDO_ESC; txt_h = CREME
		"discreto":
			n = Color(1, 1, 1, 0.06); h = Color(1, 1, 1, 0.2); bd = Color(1, 1, 1, 0.25); txt_h = CREME
	b.add_theme_stylebox_override("normal", estilo(n, bd, 2, 10, 12))
	b.add_theme_stylebox_override("hover", estilo(h, BORDO_ESC if tipo != "discreto" else DOURADO, 2, 10, 12))
	b.add_theme_stylebox_override("pressed", estilo(h.darkened(0.12), BORDO_ESC, 2, 10, 12, false))
	b.add_theme_stylebox_override("focus", estilo(Color(0, 0, 0, 0), DOURADO, 3, 10, 12, false))
	b.add_theme_stylebox_override("disabled", estilo(Color("3A1218"), Color("55252C"), 2, 10, 12, false))
	b.add_theme_color_override("font_color", txt)
	b.add_theme_color_override("font_hover_color", txt_h)
	b.add_theme_color_override("font_pressed_color", txt_h)
	b.add_theme_color_override("font_focus_color", txt)
	b.add_theme_color_override("font_disabled_color", Color("8C6A6A"))
	return b

static func rotulo(texto: String, tam: int = 18, cor: Color = CREME, titulo: bool = false, peso: int = 500) -> Label:
	var l := Label.new()
	l.text = texto
	l.add_theme_color_override("font_color", cor)
	l.add_theme_font_override("font", Fontes.titulo(maxi(peso, 600)) if titulo else Fontes.texto(peso))
	l.add_theme_font_size_override("font_size", tam)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l
