extends RefCounted
class_name Cfg
## Constantes compartilhadas da partida. O tamanho do campo depende do modo: 11x11 (principal) ou FUT7 (modo extra).

static var MODO_11: bool = true
static var PW: float = 3300.0          # comprimento do campo (px de mundo)
static var PH: float = 1950.0          # largura do campo
const MARGEM: float = 150.0            # área fora das linhas
static var GOL_METADE: float = 150.0   # metade da boca do gol
const GOL_PROF: float = 80.0           # profundidade da rede
const ALTURA_TRAVE: float = 90.0       # acima disso a bola passa por cima do gol

const COR_CASA: Color = Color("C0392B")
const COR_FORA: Color = Color("2E6FD6")
const COR_ROXO: Color = Color("3B1A8C")

static func usar_modo(onze: bool) -> void:
	MODO_11 = onze
	PW = 3300.0 if onze else 2200.0
	PH = 1950.0 if onze else 1300.0
	GOL_METADE = 150.0 if onze else 125.0
