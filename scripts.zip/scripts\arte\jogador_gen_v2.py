"""Gerador v2 dos jogadores: célula 24x28, proporção menos infantil (cabeça ~30% da altura),
contorno escuro, 6 cortes de cabelo em camadas separadas, braços/pernas por segmentos.
Saída: folha de CORPO (etiquetas) + 6 folhas de CABELO + json de animações.
Etiquetas: 1 pele, 2 cabelo, 3 camisa, 4 calção, 5 meia, 6 chuteira, 7 luva (= pele p/ linha),
8 olho/sobrancelha, 11 manga/gola, 99 contorno. G=1 => tom mais escuro."""
import os, json, math
from PIL import Image
CW,CH=24,28
SKIN,HAIR,SHIRT,SHORTS,SOCK,BOOT,GLOVE,DARK,SLEEVE,OUT=1,2,3,4,5,6,7,8,11,99
class Cv:
    def __init__(s): s.im=Image.new("RGBA",(CW,CH),(0,0,0,0)); s.p=s.im.load()
    def px(s,x,y,l,sh=0):
        x=int(round(x)); y=int(round(y))
        if 0<=x<CW and 0<=y<CH: s.p[x,y]=(l,sh,0,255)
    def r(s,x,y,w,h,l,sh=0):
        for j in range(int(h)):
            for i in range(int(w)): s.px(x+i,y+j,l,sh)
    def get(s,x,y):
        return s.p[x,y] if 0<=x<CW and 0<=y<CH else (0,0,0,0)
def seg(c,p0,p1,w,colf,bend=0.0):
    """segmento grosso de p0 a p1; colf(i,n,x,y) devolve (label,sombra)."""
    n=int(max(abs(p1[0]-p0[0]),abs(p1[1]-p0[1]),1))
    for i in range(n+1):
        t=i/n
        x=p0[0]+(p1[0]-p0[0])*t+bend*math.sin(math.pi*t)
        y=p0[1]+(p1[1]-p0[1])*t
        l,sh=colf(i,n,x,y)
        for k in range(w):
            c.px(x+k,y,l,sh)
def contorno(c):
    p=c.p; out=c.im.copy(); q=out.load()
    for y in range(CH):
        for x in range(CW):
            if p[x,y][3]==0:
                for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
                    X,Y=x+dx,y+dy
                    if 0<=X<CW and 0<=Y<CH and p[X,Y][3]==255 and p[X,Y][0]!=OUT:
                        q[x,y]=(OUT,0,0,255); break
    return out
# ------------------------------------------------------------------ cabelos
NE=6
def cabelo(c,vista,estilo,hx,hy):
    """desenha o cabelo; (hx,hy) = canto sup. esq. da cabeça (8 de largura, 8 de altura)."""
    H=HAIR
    if vista=='b':
        c.r(hx,hy,8,6,H); c.r(hx,hy+5,8,1,H,1)
        if estilo==5: c.r(hx-1,hy+2,10,8,H); c.r(hx,hy+9,8,1,H,1)
        if estilo==2: c.r(hx-1,hy-1,10,7,H)
        if estilo==4:
            for i in (0,2,4,6): c.px(hx+i,hy-1,H)
        if estilo==1: c.r(hx,hy,8,3,H); c.r(hx,hy+3,8,3,H,1)
        return
    if vista=='f':
        if estilo==0: c.r(hx,hy,8,2,H); c.r(hx+5,hy-1,3,1,H); c.px(hx,hy+2,H); c.px(hx+7,hy+2,H)
        if estilo==1: c.r(hx+1,hy,6,1,H); c.px(hx,hy+1,H,1); c.px(hx+7,hy+1,H,1)
        if estilo==2: c.r(hx-1,hy-1,10,3,H); c.r(hx-1,hy+2,2,2,H); c.r(hx+7,hy+2,2,2,H)
        if estilo==3: c.r(hx,hy,8,2,H); c.r(hx,hy+2,5,1,H); c.px(hx,hy+3,H); c.px(hx+7,hy+2,H)
        if estilo==4:
            c.r(hx,hy,8,1,H)
            for i in (0,2,4,6): c.px(hx+i,hy-1,H)
            c.px(hx,hy+1,H); c.px(hx+7,hy+1,H)
        if estilo==5: c.r(hx,hy,8,2,H); c.r(hx-1,hy+1,2,8,H); c.r(hx+7,hy+1,2,8,H)
        return
    # lado (virado para a direita)
    if estilo==0: c.r(hx,hy,7,2,H); c.r(hx,hy+2,3,3,H); c.r(hx+4,hy-1,3,1,H)
    if estilo==1: c.r(hx+1,hy,5,1,H); c.r(hx,hy+1,2,3,H,1)
    if estilo==2: c.r(hx-1,hy-1,9,3,H); c.r(hx-1,hy+2,3,4,H)
    if estilo==3: c.r(hx,hy,7,2,H); c.r(hx,hy+2,3,3,H); c.r(hx+4,hy+2,3,1,H)
    if estilo==4:
        c.r(hx,hy,7,1,H); c.r(hx,hy+1,3,3,H)
        for i in (0,2,4): c.px(hx+i,hy-1,H)
    if estilo==5: c.r(hx,hy,7,2,H); c.r(hx-1,hy+1,4,8,H); c.px(hx-1,hy+8,H,1)
# ------------------------------------------------------------------ helpers de corpo
def perna_f(c,cx,quadril,pe,larg=2):
    def col(i,n,x,y):
        if y<=20: return (SHORTS,0)
        if y>=pe[1]-1: return (BOOT,0)
        return (SOCK,0)
    seg(c,(quadril,19),pe,larg,col)
def perna_s(c,quadril,pe,bend,sombra=0):
    def col(i,n,x,y):
        if y<=20: return (SHORTS,sombra)
        if y>=pe[1]-1: return (BOOT,sombra)
        return (SOCK,sombra)
    seg(c,(quadril,19),pe,2,col,bend)
    # bico da chuteira
    c.px(pe[0]+2,pe[1],BOOT,sombra); c.px(pe[0]+2,pe[1]-1 if pe[1]<26 else pe[1],BOOT,sombra) if False else None
def braco(c,ombro,mao,frente=True,bend=0.0):
    def col(i,n,x,y):
        if i<=2: return (SLEEVE,0 if frente else 1)
        return (GLOVE,0 if frente else 1)
    seg(c,ombro,mao,2,col,bend)
def torso_f(c,dy,costas=False):
    c.r(8,10+dy,8,8,SHIRT); c.r(15,10+dy,1,8,SHIRT,1); c.r(8,17+dy,8,1,SHIRT,1)
    if not costas: c.r(10,10+dy,4,1,SLEEVE)
    else: c.r(10,10+dy,4,1,SLEEVE,1)
    c.r(8,18+dy,8,3,SHORTS); c.r(15,18+dy,1,3,SHORTS,1); c.r(12,19+dy,1,2,SHORTS,1)
def cabeca_f(c,dy,costas=False,boca=False,hdx=0):
    x=8+hdx
    c.r(x,2+dy,8,8,SKIN); c.r(x+7,3+dy,1,6,SKIN,1); c.r(x,9+dy,8,1,SKIN,1)
    if not costas:
        c.px(x+1,5+dy,DARK); c.px(x+2,5+dy,DARK); c.px(x+5,5+dy,DARK); c.px(x+6,5+dy,DARK)   # sobrancelhas
        c.px(x+2,6+dy,DARK); c.px(x+5,6+dy,DARK)                                               # olhos
        if boca: c.r(x+3,8+dy,2,1,DARK)
        else: c.px(x+3,8+dy,SKIN,1); c.px(x+4,8+dy,SKIN,1)
    return (x,2+dy)
def tronco_s(c,dy,lean):
    for i in range(8):
        sh=round(lean*(7-i)/7)
        c.r(9+sh,10+dy+i,6,1,SHIRT)
        c.px(14+sh,10+dy+i,SHIRT,1)
    c.r(9+round(lean),10+dy,6,1,SLEEVE)
    c.r(9,18+dy,6,3,SHORTS); c.r(14,18+dy,1,3,SHORTS,1)
def cabeca_s(c,dy,lean,boca=False):
    x=9+round(lean)
    c.r(x,2+dy,7,8,SKIN); c.r(x+6,3+dy,1,6,SKIN,1); c.r(x,9+dy,7,1,SKIN,1)
    c.px(x+7,6+dy,SKIN); c.px(x+7,7+dy,SKIN,1)                     # nariz
    c.px(x+4,5+dy,DARK); c.px(x+5,5+dy,DARK); c.px(x+5,6+dy,DARK) # sobrancelha e olho
    if boca: c.px(x+6,8+dy,DARK)
    return (x,2+dy)

# ================================================================== construtores de pose
def _legf(c,q,pe,dy):
    def col(i,n,x,y):
        if y<=20+dy: return (SHORTS,0)
        if y>=pe[1]-1: return (BOOT,0)
        return (SOCK,0)
    seg(c,(q,19+dy),pe,2,col)
    if pe[1]<26: pass
def F(e,vista='f',dy=0,lf=(9,26),rf=(13,26),la=(6,17),ra=(17,17),boca=False,hdx=0):
    c=Cv(); costas=(vista=='b')
    _legf(c,9,lf,dy); _legf(c,13,rf,dy)
    torso_f(c,dy,costas)
    braco(c,(6,11+dy),la,True); braco(c,(16,11+dy),ra,True)
    hx,hy=cabeca_f(c,dy,costas,boca,hdx)
    cabelo(c,vista,e,hx,hy)
    meta={"head":[hx,hy]}
    if costas: meta["num"]=[12,11+dy]
    return c,meta
def S(e,dy=0,lean=0,fl=(12,26),bl=(10,26),fa=(14,17),ba=(8,17),boca=False,fb=0.0,bb=0.0,vista='s'):
    c=Cv(); lean=int(lean)
    sx=11+lean
    braco(c,(sx-1,11+dy),ba,False)
    perna_s(c,10,bl,bb,1)
    tronco_s(c,dy,lean)
    hx,hy=cabeca_s(c,dy,lean,boca)
    cabelo(c,'s',e,hx,hy)
    perna_s(c,12,fl,fb,0)
    braco(c,(sx,11+dy),fa,True)
    return c,{"head":[hx,hy]}
def ciclo(e,n,amp,lift,lean,arm,bob=True):
    fr=[]
    for k in range(n):
        p=2*math.pi*k/n
        def leg(ph):
            x=11+amp*math.sin(ph); cs=math.cos(ph)
            return (round(x),round(26-lift*max(0,cs))), lift*0.5*max(0,cs)
        fl,fb=leg(p); bl,bb=leg(p+math.pi)
        a1=(round(11+arm*math.sin(p+math.pi)),round(17-0.6*arm*max(0,math.sin(p+math.pi))-(2 if lean>=2 else 0)))
        a2=(round(11+arm*math.sin(p)),round(17-0.6*arm*max(0,math.sin(p))-(2 if lean>=2 else 0)))
        dy=-1 if (bob and abs(math.sin(p*2))>0.7 and lift>1) else 0
        fr.append(lambda e=e,dy=dy,lean=lean,fl=fl,bl=bl,fb=fb,bb=bb,a1=a1,a2=a2: S(e,dy,lean,fl,bl,a1,a2,False,fb,bb))
    return fr
def ciclo_f(e,vista,n,lift,arm,sw=0):
    fr=[]
    for k in range(n):
        p=2*math.pi*k/n
        la_=max(0,math.sin(p)); lb=max(0,-math.sin(p))
        lf=(9,round(26-lift*la_)); rf=(13,round(26-lift*lb))
        al=(6,round(17+arm*math.sin(p))); ar=(17,round(17-arm*math.sin(p)))
        dy=-1 if (lift>1 and abs(math.sin(p))>0.7) else 0
        fr.append(lambda e=e,vista=vista,dy=dy,lf=lf,rf=rf,al=al,ar=ar: F(e,vista,dy,lf,rf,al,ar))
    return fr
# ---- poses especiais (deitados / goleiro)
def carrinho(e,k):
    c=Cv()
    fase=[(0,0),(0,1),(1,1),(2,2)][k]   # preparação / deslizando / deslizando / final
    b=fase[1]
    # tronco inclinado para trás, perna da frente estendida na grama
    seg(c,(8,18+b),(14,22+b),4,lambda i,n,x,y:(SHIRT,1 if i>n*0.8 else 0))
    seg(c,(13,22+b),(15,24+b),3,lambda i,n,x,y:(SHORTS,0))
    seg(c,(15,24),(21,25 if k<3 else 26),2,lambda i,n,x,y:(BOOT if i>=n-1 else SOCK,0))
    c.px(22,25,BOOT); c.px(22,26,BOOT)
    seg(c,(14,24),(16,26),2,lambda i,n,x,y:(SOCK if i<n else BOOT,1))
    # cabeça levantada
    x0=2; y0=12+b
    c.r(x0,y0,7,7,SKIN); c.r(x0+6,y0+1,1,5,SKIN,1); c.r(x0,y0+6,7,1,SKIN,1)
    c.px(x0+4,y0+3,DARK); c.px(x0+5,y0+3,DARK); c.px(x0+5,y0+4,DARK); c.px(x0+6,y0+5,DARK)
    cabelo(c,'s',e,x0,y0-1)
    # braços de apoio
    seg(c,(7,19+b),(4,24),2,lambda i,n,x,y:(SLEEVE if i<2 else GLOVE,1))
    seg(c,(10,19+b),(11,15) if k>=1 else (12,16),2,lambda i,n,x,y:(SLEEVE if i<2 else GLOVE,0))
    return c,{"head":[x0,y0]}
def queda(e,k):
    c=Cv()
    if k==0:    # caindo: tronco inclinado, braços abertos
        seg(c,(9,12),(13,21),5,lambda i,n,x,y:(SHIRT,1 if i>n*0.7 else 0))
        seg(c,(13,21),(15,23),4,lambda i,n,x,y:(SHORTS,0))
        seg(c,(14,23),(19,26),2,lambda i,n,x,y:(SOCK if i<n-1 else BOOT,0))
        seg(c,(16,22),(21,24),2,lambda i,n,x,y:(SOCK if i<n-1 else BOOT,1))
        c.r(5,6,7,7,SKIN); c.px(9,9,DARK); c.px(10,9,DARK); c.px(10,10,DARK)
        cabelo(c,'s',e,5,5)
        seg(c,(9,14),(4,10),2,lambda i,n,x,y:(SLEEVE if i<2 else GLOVE,1))
        seg(c,(13,14),(18,10),2,lambda i,n,x,y:(SLEEVE if i<2 else GLOVE,0))
        return c,{"head":[5,6]}
    y=21
    perna=[0,-2,-1][k-1]
    # deitado de costas: cabeça à esquerda
    c.r(8,y,9,5,SHIRT); c.r(8,y+4,9,1,SHIRT,1); c.r(8,y,9,1,SLEEVE)
    c.r(17,y,3,5,SHORTS); c.r(19,y+2,1,3,SHORTS,1)
    seg(c,(20,y+1),(23,y+1+perna),2,lambda i,n,x,yy:(SOCK if i<n-1 else BOOT,0))
    seg(c,(20,y+3),(23,y+4),2,lambda i,n,x,yy:(SOCK if i<n-1 else BOOT,1))
    c.r(1,y-1,7,7,SKIN); c.r(1,y+5,7,1,SKIN,1)
    c.px(4,y+1,DARK); c.px(5,y+1,DARK); c.px(5,y+2,DARK)
    cabelo(c,'s',e,1,y-2)
    seg(c,(10,y-1),(12,y-4 if k==2 else y-3),2,lambda i,n,x,yy:(SLEEVE if i<1 else GLOVE,0))
    seg(c,(11,y+5),(15,y+6),2,lambda i,n,x,yy:(SLEEVE if i<1 else GLOVE,1))
    return c,{"head":[1,y-1]}
def festa(e,k):
    # pulo com os braços para o alto
    pul=[0,-2,-3,-1][k]; 
    al=[(4,6),(3,4),(4,5),(5,7)][k]; ar=[(19,6),(20,4),(19,5),(18,7)][k]
    return F(e,'f',pul,(9,26+pul if pul<-1 else 26),(13,26+pul if pul<-1 else 26),(al[0],al[1]),(ar[0],ar[1]),boca=True)
def gk_espera(e,k,vista='f'):
    dy=[1,1,2,1][k]
    return F(e,vista,dy,(7,26),(15,26),(4,15+k%2),(19,15+(k+1)%2))
def gk_lateral(e,k):
    # deslocamento lateral de frente: passos cruzados, corpo baixo
    pos=[((8,26),(14,26)),((10,25),(16,26)),((9,26),(15,26)),((7,26),(13,25))][k]
    return F(e,'f',1,pos[0],pos[1],(4,16),(19,16))
def gk_defesa(e,k):
    # braços esticados para cima e para os lados
    a=[((5,5),(18,5)),((7,3),(16,3)),((6,4),(17,4))][k]
    return F(e,'f',-1 if k else 0,(9,26),(13,26),a[0],a[1],boca=True)
def gk_merg(e,alto,k):
    c=Cv()
    if alto:
        # decolagem -> extensão máxima na diagonal -> queda
        cfg=[((6,24),(9,17),(10,8),(16,2)),((5,24),(10,15),(12,6),(21,2)),((4,22),(10,13),(13,6),(22,3)),((3,22),(9,14),(12,9),(20,10))][k]
        pe,quad,cab,mao=cfg
        seg(c,pe,quad,3,lambda i,n,x,y:(SOCK if i<n*0.7 else SHORTS,0))
        seg(c,(pe[0]+3,pe[1]-1),(quad[0]+2,quad[1]),2,lambda i,n,x,y:(BOOT if i==0 else SOCK,1))
        seg(c,quad,(cab[0]+2,cab[1]+6),5,lambda i,n,x,y:(SHORTS if i<n*0.25 else SHIRT,1 if i>n*0.75 else 0))
        hx,hy=cab[0],cab[1]
        c.r(hx,hy,6,6,SKIN); c.r(hx,hy+5,6,1,SKIN,1); c.px(hx+4,hy+2,DARK); c.px(hx+5,hy+3,DARK)
        cabelo(c,'s',e,hx,hy-1)
        seg(c,(hx+1,hy+7),(mao[0],mao[1]+1),2,lambda i,n,x,y:(SLEEVE if i<2 else GLOVE,1))
        seg(c,(hx+3,hy+6),mao,2,lambda i,n,x,y:(SLEEVE if i<2 else GLOVE,0))
        for dx in (0,1):
            c.px(mao[0]+2+dx,mao[1]-1,GLOVE); c.px(mao[0]+2+dx,mao[1]+1,GLOVE)
        return c,{"head":[hx,hy]}
    # mergulho baixo: corpo quase horizontal, braços esticados à frente
    y=[18,21,22,23][k]; ext=[(13,15),(19,18),(22,19),(21,21)][k]
    seg(c,(2,y+3),(9,y+2),2,lambda i,n,x,yy:(BOOT if i==0 else SOCK,0))
    seg(c,(2,y+5),(9,y+4),2,lambda i,n,x,yy:(BOOT if i==0 else SOCK,1))
    c.r(9,y,4,5,SHORTS)
    c.r(12,y-1,7,6,SHIRT); c.r(12,y+4,7,1,SHIRT,1)
    hx,hy=17,y-4
    c.r(hx,hy,6,6,SKIN); c.r(hx,hy+5,6,1,SKIN,1); c.px(hx+4,hy+2,DARK); c.px(hx+5,hy+3,DARK)
    cabelo(c,'s',e,hx,hy-1)
    seg(c,(15,y),(ext[0],ext[1]+1),2,lambda i,n,x,yy:(SLEEVE if i<2 else GLOVE,1))
    seg(c,(16,y+1),ext,2,lambda i,n,x,yy:(SLEEVE if i<2 else GLOVE,0))
    c.px(ext[0]+2,ext[1],GLOVE); c.px(ext[0]+2,ext[1]+1,GLOVE)
    return c,{"head":[hx,hy]}
def gk_repo(e,k):
    # reposição: braço para trás, depois lançamento para frente
    a=[((14,10),(6,17)),((9,6),(6,17)),((17,12),(6,17)),((14,17),(8,17))][k]
    lean=[-1,-1,1,1][k]
    return S(e,0,lean,(12,26),(9,26),a[0],a[1])
# ================================================================== animações
def A():
    an=[]   # (nome, fps, loop, [builders])
    def add(n,fps,loop,fr): an.append((n,fps,loop,fr))
    E=lambda f:(lambda e:f(e))
    L=lambda fn:[ (lambda e,i=i:fn(e,i)) for i in range(0)]
    # parado
    add("idle_s",4,True,[lambda e:S(e,0,0,(12,26),(10,26),(13,18),(9,18)),lambda e:S(e,0,0,(12,26),(10,26),(13,18),(9,18)),lambda e:S(e,1,0,(12,26),(10,26),(13,19),(9,19)),lambda e:S(e,0,0,(12,26),(10,26),(13,18),(9,18))])
    add("idle_f",4,True,[lambda e:F(e,'f',0),lambda e:F(e,'f',0),lambda e:F(e,'f',1,(9,26),(13,26),(6,18),(17,18)),lambda e:F(e,'f',0)])
    add("idle_b",4,True,[lambda e:F(e,'b',0),lambda e:F(e,'b',0),lambda e:F(e,'b',1,(9,26),(13,26),(6,18),(17,18)),lambda e:F(e,'b',0)])
    for nm,n,amp,lift,lean,arm,fps,liftf,armf in (("walk",6,3,1,0,2,7,1,1),("run",6,5,3,1,4,11,2,3),("sprint",6,6,4,2,5,14,3,4)):
        fs=ciclo(0,n,amp,lift,lean,arm)
        # reconstroi com 'e' variável
        def mk(amp=amp,lift=lift,lean=lean,arm=arm,n=n):
            out=[]
            for k in range(n):
                out.append(lambda e,k=k:ciclo(e,n,amp,lift,lean,arm)[k](e) if False else _cic(e,k,n,amp,lift,lean,arm))
            return out
        add(nm+"_s",fps,True,mk())
        add(nm+"_f",fps,True,[lambda e,k=k:_cicf(e,'f',k,n,liftf,armf) for k in range(n)])
        add(nm+"_b",fps,True,[lambda e,k=k:_cicf(e,'b',k,n,liftf,armf) for k in range(n)])
    # com bola
    add("drible_s",11,True,[lambda e,k=k:_cic(e,k,6,3,2,1,5,wide=True) for k in range(6)])
    add("drible_f",9,True,[lambda e,k=k:_dribf(e,'f',k) for k in range(4)])
    add("drible_b",9,True,[lambda e,k=k:_dribf(e,'b',k) for k in range(4)])
    add("passe_s",14,False,[lambda e:S(e,0,-1,(10,26),(9,26),(14,16),(7,18)),lambda e:S(e,0,0,(14,25),(9,26),(15,17),(6,16)),lambda e:S(e,0,1,(16,26),(9,26),(15,17),(6,16)),lambda e:S(e,0,0,(12,26),(10,26),(13,18),(9,18))])
    add("passe_f",14,False,[lambda e:F(e,'f',0,(9,26),(13,25),(5,15),(18,15)),lambda e:F(e,'f',0,(9,26),(14,23),(5,14),(18,16)),lambda e:F(e,'f',0,(9,26),(13,26),(6,17),(17,17))])
    add("passe_b",14,False,[lambda e:F(e,'b',0,(9,26),(13,25),(5,15),(18,15)),lambda e:F(e,'b',0,(9,26),(14,23),(5,14),(18,16)),lambda e:F(e,'b',0,(9,26),(13,26),(6,17),(17,17))])
    add("chute_s",16,False,[lambda e:S(e,0,-1,(7,23),(11,26),(15,15),(7,18),fb=-1),lambda e:S(e,0,-2,(5,21),(11,26),(15,14),(6,17),fb=-2),lambda e:S(e,0,2,(18,23),(11,26),(8,16),(15,14),fb=1),lambda e:S(e,-1,2,(20,20),(11,26),(7,16),(16,15),fb=1),lambda e:S(e,0,1,(14,26),(10,26),(9,17),(14,16))])
    add("chute_f",16,False,[lambda e:F(e,'f',0,(9,26),(14,22),(4,14),(19,17)),lambda e:F(e,'f',-1,(9,26),(15,19),(3,15),(20,16)),lambda e:F(e,'f',0,(9,26),(13,26),(6,18),(17,17))])
    add("chute_b",16,False,[lambda e:F(e,'b',0,(9,26),(14,22),(4,14),(19,17)),lambda e:F(e,'b',-1,(9,26),(15,19),(3,15),(20,16)),lambda e:F(e,'b',0,(9,26),(13,26),(6,18),(17,17))])
    add("recepcao_s",10,False,[lambda e:S(e,0,-1,(14,23),(10,26),(15,15),(7,15),fb=1),lambda e:S(e,1,-1,(12,24),(10,26),(14,17),(7,16),fb=1),lambda e:S(e,0,0,(12,26),(10,26),(13,18),(9,18))])
    add("recepcao_f",10,False,[lambda e:F(e,'f',0,(9,26),(13,23),(4,15),(19,15)),lambda e:F(e,'f',1,(9,26),(13,25),(5,16),(18,16)),lambda e:F(e,'f',0)])
    add("desarme_s",12,False,[lambda e:S(e,1,1,(14,26),(7,26),(15,17),(6,16),fb=0,bb=0),lambda e:S(e,1,2,(19,25),(7,26),(14,18),(6,15)),lambda e:S(e,1,1,(18,26),(7,26),(14,17),(6,16)),lambda e:S(e,0,0,(12,26),(10,26),(13,18),(9,18))])
    add("bloqueio_s",10,False,[lambda e:S(e,1,-1,(14,25),(8,26),(14,13),(8,14)),lambda e:S(e,1,-1,(14,24),(8,26),(15,12),(9,13))])
    add("bloqueio_f",10,False,[lambda e:F(e,'f',1,(7,26),(15,26),(7,12),(16,12)),lambda e:F(e,'f',1,(7,26),(15,26),(6,10),(17,10))])
    add("carrinho",10,False,[lambda e,k=k:carrinho(e,k) for k in range(4)])
    add("queda",6,False,[lambda e,k=k:queda(e,k) for k in range(3)])
    add("festa",8,True,[lambda e,k=k:festa(e,k) for k in range(4)])
    add("lamento",3,True,[lambda e:F(e,'f',0,(9,26),(13,26),(7,5),(16,5)),lambda e:F(e,'f',1,(9,26),(13,26),(7,6),(16,6))])
    add("gk_espera_f",5,True,[lambda e,k=k:gk_espera(e,k) for k in range(4)])
    add("gk_espera_b",5,True,[lambda e,k=k:gk_espera(e,k,'b') for k in range(4)])
    add("gk_lateral",10,True,[lambda e,k=k:gk_lateral(e,k) for k in range(4)])
    add("gk_defesa",10,False,[lambda e,k=k:gk_defesa(e,k) for k in range(3)])
    add("gk_mergulho_baixo",12,False,[lambda e,k=k:gk_merg(e,False,k) for k in range(4)])
    add("gk_mergulho_alto",12,False,[lambda e,k=k:gk_merg(e,True,k) for k in range(4)])
    add("gk_reposicao",10,False,[lambda e,k=k:gk_repo(e,k) for k in range(4)])
    return an
def _cic(e,k,n,amp,lift,lean,arm,wide=False):
    p=2*math.pi*k/n
    def leg(ph):
        cs=math.cos(ph)
        return (round(11+amp*math.sin(ph)),round(26-lift*max(0,cs))), lift*0.5*max(0,cs)
    fl,fb=leg(p); bl,bb=leg(p+math.pi)
    up=2 if lean>=2 else 0
    if wide:
        a1=(round(14+2*math.sin(p)),17); a2=(round(7-2*math.sin(p)),16)
    else:
        a1=(round(11+arm*math.sin(p+math.pi)),round(17-0.6*arm*max(0,math.sin(p+math.pi))-up))
        a2=(round(11+arm*math.sin(p)),round(17-0.6*arm*max(0,math.sin(p))-up))
    dy=-1 if (abs(math.sin(2*p))>0.7 and lift>1) else 0
    return S(e,dy,lean,fl,bl,a1,a2,False,fb,bb)
def _cicf(e,vista,k,n,lift,arm):
    p=2*math.pi*k/n
    la_=max(0,math.sin(p)); lb=max(0,-math.sin(p))
    lf=(9,round(26-lift*la_)); rf=(13,round(26-lift*lb))
    al=(6,round(17+arm*math.sin(p))); ar=(17,round(17-arm*math.sin(p)))
    dy=-1 if (lift>1 and abs(math.sin(p))>0.7) else 0
    return F(e,vista,dy,lf,rf,al,ar)
def _dribf(e,vista,k):
    d=[(9,26),(9,25)][k%2],[(13,25),(13,26)][k%2]
    return F(e,vista,0 if k%2 else -1,d[0],d[1],(4,16),(19,16))
# ================================================================== exportação
def exportar(saida):
    os.makedirs(saida,exist_ok=True)
    an=A(); mx=max(len(a[3]) for a in an)
    meta={"cell":[CW,CH],"estilos":NE,"anims":{}}
    for e in range(NE):
        sheet=Image.new("RGBA",(mx*CW,len(an)*CH),(0,0,0,0))
        for r,(nome,fps,loop,frs) in enumerate(an):
            heads=[]; nums=[]
            for k,fn in enumerate(frs):
                c,m=fn(e)
                sheet.paste(contorno(c),(k*CW,r*CH))
                heads.append(m["head"]); nums.append(m.get("num"))
            if e==0:
                meta["anims"][nome]={"row":r,"frames":len(frs),"fps":fps,"loop":loop,"head":heads,"num":nums if any(nums) else None}
        sheet.save(os.path.join(saida,f"jogadores_v2_e{e}.png"))
    json.dump(meta,open(os.path.join(saida,"jogadores_v2.json"),"w"))
    return meta
if __name__=="__main__":
    here=os.path.dirname(os.path.abspath(__file__))
    m=exportar(os.path.join(here,"..","..","assets","gerado"))
    print(len(m["anims"]),"animações")
