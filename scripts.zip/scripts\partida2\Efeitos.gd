extends Node2D
class_name Efeitos
## Confete/papel picado, poeira de grama, flash e tremor de câmera. Tudo em pixels inteiros.
var _p: Array = []        # {pos, vel, cor, vida, tipo, g}
var _flash: float = 0.0
var _tremor: float = 0.0
var _forca: float = 0.0
var alvo_tremor: Node2D = null
var _base: Vector2 = Vector2.ZERO
const CORES := [Color("D8202F"), Color("FFD84A"), Color("3FB8FF"), Color("FFFFFF"), Color("2DA44E"), Color("E86AA6")]

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func confete(onde: Vector2 = Vector2(240, 60), n: int = 90) -> void:
	for i in n:
		_p.append({"pos": onde + Vector2(randf_range(-160, 160), randf_range(-10, 10)), "vel": Vector2(randf_range(-25, 25), randf_range(10, 60)),
			"cor": CORES[randi() % CORES.size()], "vida": randf_range(1.6, 3.2), "tipo": 0, "g": randf_range(20, 50)})

func poeira(onde: Vector2, forca: float = 1.0) -> void:
	for i in int(4 + forca * 4):
		_p.append({"pos": onde + Vector2(randf_range(-2, 2), -1), "vel": Vector2(randf_range(-22, 22), randf_range(-26, -6)),
			"cor": Color("86D028") if i % 2 == 0 else Color("C8E8A0"), "vida": randf_range(0.2, 0.45), "tipo": 1, "g": 80.0})

## Texto flutuante curto (ex.: "DESARME!", "PIII!"): sobe e some. `onde` em coordenadas de tela (480x270).
func texto(onde: Vector2, txt: String, cor: Color = Color.WHITE) -> void:
	var t: ImageTexture = PixelUI.texto(txt, 1, cor, Color("14101C"))
	_p.append({"pos": onde - Vector2(t.get_width() * 0.5, 0.0), "vel": Vector2(0, -16), "cor": Color.WHITE, "vida": 1.0, "tipo": 2, "g": 0.0, "tex": t})

func flash(seg: float = 0.12) -> void:
	_flash = seg

func tremer(forca: float = 2.0, seg: float = 0.35) -> void:
	_forca = forca
	_tremor = seg
	if alvo_tremor != null:
		_base = alvo_tremor.position

func _process(delta: float) -> void:
	for p in _p:
		p["vida"] -= delta
		var v: Vector2 = p["vel"]
		v.y += float(p["g"]) * delta
		if p["tipo"] == 0:
			v.x += sin(float(p["vida"]) * 7.0 + (p["pos"] as Vector2).x) * 20.0 * delta
		p["vel"] = v
		p["pos"] = (p["pos"] as Vector2) + v * delta
	_p = _p.filter(func(q): return q["vida"] > 0.0)
	_flash = maxf(0.0, _flash - delta)
	if _tremor > 0.0:
		_tremor -= delta
		if alvo_tremor != null:
			alvo_tremor.position = _base + Vector2(randi_range(-1, 1), randi_range(-1, 1)) * (_forca if _tremor > 0.0 else 0.0)
			if _tremor <= 0.0:
				alvo_tremor.position = _base
	queue_redraw()

func _draw() -> void:
	for p in _p:
		var pos: Vector2 = (p["pos"] as Vector2).round()
		var c: Color = p["cor"]
		if p["tipo"] == 2:
			draw_texture(p["tex"], pos, Color(1, 1, 1, clampf(float(p["vida"]) * 2.5, 0.0, 1.0)))
		elif p["tipo"] == 0:
			draw_rect(Rect2(pos, Vector2(2, 3) if int(p["vida"] * 8.0) % 2 == 0 else Vector2(3, 2)), c)
		else:
			c.a = clampf(p["vida"] * 3.0, 0.0, 1.0)
			draw_rect(Rect2(pos, Vector2(1, 1)), c)
	if _flash > 0.0:
		draw_rect(Rect2(0, 0, 480, 270), Color(1, 1, 1, clampf(_flash * 4.0, 0.0, 0.5)))
