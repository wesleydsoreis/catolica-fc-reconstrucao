class_name TutorialMapa
extends CanvasLayer
## Tutorial animado da primeira entrada: 7 etapas com os vídeos do clube como cenário,
## o gatinho mascote como guia e painéis do Godot (texto e números reais da carreira) sobre as áreas
## onde os vídeos têm interface/dados fictícios gravados. Só o necessário é coberto; o gatinho e os cenários
## continuam animados. Pode ser pulado e revisto pelo menu de pausa ou pelo botão "?" do mapa.

signal fechado(concluido: bool)

const V_MAPA := "res://assets/video/mapa_animado.ogv"
const V_TREINO := "res://assets/video/treinamento.ogv"
const V_SECRETARIA := "res://assets/video/secretaria.ogv"
const V_MERCADO := "res://assets/video/mercado.ogv"
const V_OBRAS := "res://assets/video/obras.ogv"
const GATO_NEUTRO := "res://assets/ui/mascote/poses/gato_grande_dir.png"   # corpo inteiro, de pé
const GATO_ALEGRE := "res://assets/ui/mascote/poses/gato_grande_esq.png"   # corpo inteiro, comemorando
const ESCUDO := "res://assets/ui/ref/escudo.png"
const TOTAL := 7
const DESIGN := Vector2(1280, 720)
const TINTA := Color("3A0A10")
const PAPEL := Color("F7EFDF")

var _mapa: Control
var _auto: bool
var _i: int = 0
var _raiz: Control
var _palco: Control
var _video: VideoFundo
var _video_atual: String = ""
var _conteudo: Control
var _fade: ColorRect
var _btn_ant: Button
var _btn_prox: Button
var _lb_passo: Label
var _gato: TextureRect
var _t: float = 0.0
var _gato_y: float = 0.0

## `auto` = abertura automática da carreira nova (ao terminar ou pular, marca o tutorial como concluído).
static func abrir(mapa: Control, auto: bool) -> TutorialMapa:
	var t := TutorialMapa.new()
	t._mapa = mapa
	t._auto = auto
	t.layer = 60
	mapa.add_child(t)
	return t

func _ready() -> void:
	_raiz = Control.new()
	_raiz.name = "Raiz"
	_raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_raiz.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_raiz)
	var fundo := ColorRect.new()
	fundo.color = Color("1A0508")
	fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(fundo)
	_palco = Control.new()          # área 16:9 em coordenadas de projeto (1280x720), escalada para a janela
	_palco.name = "Palco"
	_palco.size = DESIGN
	_palco.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_palco)
	_conteudo = Control.new()
	_conteudo.name = "Conteudo"
	_conteudo.size = DESIGN
	_conteudo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_palco.add_child(_conteudo)
	_fade = ColorRect.new()
	_fade.color = Color(0.1, 0.02, 0.04, 1.0)
	_fade.size = DESIGN
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_palco.add_child(_fade)
	_raiz.resized.connect(_ajustar)
	_ajustar()
	_ir(0)

func _ajustar() -> void:
	if _raiz == null or _palco == null:
		return
	var k: float = minf(_raiz.size.x / DESIGN.x, _raiz.size.y / DESIGN.y)
	if k <= 0.0:
		return
	_palco.scale = Vector2(k, k)
	_palco.position = (_raiz.size - DESIGN * k) * 0.5

func _process(dt: float) -> void:
	_t += dt
	if is_instance_valid(_gato):
		_gato.position.y = _gato_y + 3.0 * sin(_t * 2.2)          # respiração discreta do mascote

func _input(e: InputEvent) -> void:
	if e.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_fechar(false)
	elif e.is_action_pressed("ui_right"):
		get_viewport().set_input_as_handled()
		_ir(_i + 1)
	elif e.is_action_pressed("ui_left"):
		get_viewport().set_input_as_handled()
		_ir(_i - 1)

# ------------------------------------------------------------------ utilidades visuais
func _milhar(n: int) -> String:
	var t := str(absi(n))
	var r := ""
	while t.length() > 3:
		r = "." + t.substr(t.length() - 3) + r
		t = t.substr(0, t.length() - 3)
	return ("-" if n < 0 else "") + t + r

func _rs(n: int) -> String:
	return "R$ " + _milhar(n)

func _rot(texto: String, tam: int, cor: Color, titulo: bool = false, peso: int = 0) -> Label:
	var l := Label.new()
	l.text = texto
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_color_override("font_color", cor)
	l.add_theme_font_override("font", Fontes.titulo(peso if peso > 0 else 700) if titulo else Fontes.texto(peso if peso > 0 else 500))
	l.add_theme_font_size_override("font_size", tam)
	return l

func _texto(texto: String, tam: int = 17, cor: Color = TINTA) -> Label:
	var l := _rot(texto, tam, cor)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

## Cartão no estilo do jogo: barra bordô com título + corpo creme. Devolve o VBox do corpo.
func _cartao(r: Rect2, titulo: String) -> VBoxContainer:
	var p := PanelContainer.new()
	p.position = r.position
	p.custom_minimum_size = r.size
	p.size = r.size
	p.clip_contents = true
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", Paleta.estilo(PAPEL, Color("7A1220"), 3, 12, 0))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(v)
	if titulo != "":
		var barra := PanelContainer.new()
		barra.mouse_filter = Control.MOUSE_FILTER_IGNORE
		barra.add_theme_stylebox_override("panel", Paleta.estilo(Color("8E1222"), Color("8E1222"), 0, 8, 12, false))
		barra.add_child(_rot(titulo.to_upper(), 20, PAPEL, true))
		v.add_child(barra)
	var m := MarginContainer.new()
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	m.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for lado in ["left", "right"]:
		m.add_theme_constant_override("margin_" + lado, 14)
	m.add_theme_constant_override("margin_top", 8)
	m.add_theme_constant_override("margin_bottom", 6)
	v.add_child(m)
	var corpo := VBoxContainer.new()
	corpo.add_theme_constant_override("separation", 5)
	corpo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	m.add_child(corpo)
	_conteudo.add_child(p)
	return corpo

func _dado(rotulo: String, valor: String, cor_valor: Color = Color("8E1222")) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var a := _rot(rotulo, 16, TINTA)
	a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(a)
	h.add_child(_rot(valor, 17, cor_valor, true))
	return h

func _topico(corpo: VBoxContainer, txt: String) -> void:
	corpo.add_child(_texto("•  " + txt, 17))

## Balão de fala sobre o balão desenhado no vídeo (o texto gravado é trocado por um texto do jogo).
func _balao(r: Rect2, txt: String, ponta_direita: bool = true) -> void:
	var p := PanelContainer.new()
	p.position = r.position
	p.custom_minimum_size = r.size
	p.size = r.size
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", Paleta.estilo(Color("FBF3E4"), Color("5A2A1A"), 3, 16, 12))
	var l := _texto(txt, 18)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	p.add_child(l)
	_conteudo.add_child(p)
	if ponta_direita:
		var tri := Polygon2D.new()
		var y: float = r.position.y + r.size.y * 0.62
		tri.polygon = PackedVector2Array([Vector2(r.end.x - 2, y - 12), Vector2(r.end.x + 20, y + 14), Vector2(r.end.x - 2, y + 12)])
		tri.color = Color("FBF3E4")
		_conteudo.add_child(tri)

func _cabecalho(local: String, sub: String) -> void:
	var p := PanelContainer.new()
	p.position = Vector2.ZERO
	p.custom_minimum_size = Vector2(DESIGN.x, 88)
	p.size = Vector2(DESIGN.x, 88)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := Paleta.estilo(Color("8E0F1C"), Paleta.DOURADO, 0, 0, 0, false)
	sb.border_width_bottom = 4
	p.add_theme_stylebox_override("panel", sb)
	_conteudo.add_child(p)
	var esc := TextureRect.new()
	esc.texture = load(ESCUDO)
	esc.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	esc.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	esc.position = Vector2(22, 10)
	esc.size = Vector2(62, 66)
	esc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_conteudo.add_child(esc)
	var a := _rot("CATÓLICA FC", 34, Color.WHITE, true)
	a.position = Vector2(106, 8)
	_conteudo.add_child(a)
	var b := _rot("TUTORIAL DA CARREIRA", 17, Color("F3D9D2"), false, 600)
	b.position = Vector2(108, 52)
	_conteudo.add_child(b)
	var sep := ColorRect.new()
	sep.color = Color(1, 1, 1, 0.55)
	sep.position = Vector2(385, 14)
	sep.size = Vector2(2, 60)
	sep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_conteudo.add_child(sep)
	var c := _rot(local.to_upper(), 36, Color.WHITE, true)
	c.position = Vector2(412, 6)
	_conteudo.add_child(c)
	var d := _rot(sub, 18, Color("F3D9D2"), false, 600)
	d.position = Vector2(414, 54)
	_conteudo.add_child(d)
	for x in [905.0, 935.0]:                     # faixas brancas diagonais, como nos cabeçalhos da arte
		var f := Polygon2D.new()
		f.polygon = PackedVector2Array([Vector2(x + 28, 0), Vector2(x + 52, 0), Vector2(x + 24, 84), Vector2(x, 84)])
		f.color = Color(1, 1, 1, 0.85 if x < 910.0 else 0.4)
		_conteudo.add_child(f)

func _placa(r: Rect2) -> PanelContainer:
	var p := PanelContainer.new()
	p.position = r.position
	p.custom_minimum_size = r.size
	p.size = r.size
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := Paleta.estilo(Color("8E0F1C"), Paleta.DOURADO, 0, 0, 10, false)
	sb.border_width_top = 3
	p.add_theme_stylebox_override("panel", sb)
	_conteudo.add_child(p)
	return p

func _gatinho(r: Rect2, alegre: bool) -> void:
	_gato = TextureRect.new()
	_gato.texture = load(GATO_ALEGRE if alegre else GATO_NEUTRO)
	_gato.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_gato.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_gato.position = r.position
	_gato.size = r.size
	_gato.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_gato.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_gato_y = r.position.y
	var sombra := Panel.new()
	var ssb := StyleBoxFlat.new()
	ssb.bg_color = Color(0, 0, 0, 0.28)
	ssb.set_corner_radius_all(100)
	sombra.add_theme_stylebox_override("panel", ssb)
	sombra.position = Vector2(r.position.x + r.size.x * 0.12, r.end.y - 10)
	sombra.size = Vector2(r.size.x * 0.76, 18)
	sombra.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_conteudo.add_child(sombra)
	_conteudo.add_child(_gato)

# ------------------------------------------------------------------ navegação
func _trocar_video(caminho: String) -> void:
	if caminho == _video_atual and is_instance_valid(_video):
		return
	if is_instance_valid(_video):
		_video.liberar()               # um vídeo por vez: libera o anterior
		_video.queue_free()
	_video = VideoFundo.criar(caminho, null, false)
	_video.size = DESIGN
	_palco.add_child(_video)
	_palco.move_child(_video, _conteudo.get_index())
	_video.size = DESIGN
	_video_atual = caminho

func _ir(i: int) -> void:
	if i < 0:
		return
	if i >= TOTAL:
		_fechar(true)
		return
	_i = i
	_fade.color.a = 1.0
	_gato = null
	for c in _conteudo.get_children():
		_conteudo.remove_child(c)
		c.queue_free()
	var vid: String = [V_MAPA, V_TREINO, V_SECRETARIA, V_MERCADO, V_OBRAS, V_MAPA, V_MAPA][i]
	_trocar_video(vid)
	match i:
		0: _passo_boas_vindas()
		1: _passo_treino()
		2: _passo_secretaria()
		3: _passo_mercado()
		4: _passo_obras()
		5: _passo_classificacao()
		6: _passo_mapa()
	_rodape()
	create_tween().tween_property(_fade, "color:a", 0.0, 0.28)          # transição suave entre etapas
	if is_instance_valid(_btn_prox):
		_btn_prox.grab_focus.call_deferred()

func _rodape() -> void:
	var esq := _placa(Rect2(0, 648, 492, 72))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	esq.add_child(h)
	var pular: Button = Paleta.botao("PULAR TUTORIAL", "discreto", 18, 44)
	pular.name = "Tut_Pular"
	pular.pressed.connect(func(): _fechar(false))
	h.add_child(pular)
	_lb_passo = _rot("%d DE %d" % [_i + 1, TOTAL], 24, Color.WHITE, true)
	_lb_passo.name = "Tut_Passo"
	h.add_child(_lb_passo)
	var pontos := HBoxContainer.new()
	pontos.add_theme_constant_override("separation", 5)
	pontos.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pontos.alignment = BoxContainer.ALIGNMENT_CENTER
	for k in TOTAL:
		var d := ColorRect.new()
		d.custom_minimum_size = Vector2(10, 10)
		d.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		d.color = Paleta.DOURADO if k == _i else Color(1, 1, 1, 0.35)
		d.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pontos.add_child(d)
	h.add_child(pontos)
	var dir := _placa(Rect2(840, 648, 440, 72))
	var h2 := HBoxContainer.new()
	h2.add_theme_constant_override("separation", 12)
	h2.alignment = BoxContainer.ALIGNMENT_END
	h2.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dir.add_child(h2)
	_btn_ant = Paleta.botao("‹ ANTERIOR", "bordo", 18, 44)
	_btn_ant.name = "Tut_Anterior"
	_btn_ant.disabled = _i == 0
	_btn_ant.pressed.connect(func(): _ir(_i - 1))
	h2.add_child(_btn_ant)
	var ultimo: bool = _i == TOTAL - 1
	_btn_prox = Paleta.botao("COMEÇAR CARREIRA" if ultimo else "PRÓXIMO ›", "ouro", 18, 44)
	_btn_prox.name = "Tut_Proximo"
	_btn_prox.pressed.connect(func(): _ir(_i + 1))
	h2.add_child(_btn_prox)

# ------------------------------------------------------------------ etapas
func _passo_boas_vindas() -> void:
	var f: Dictionary = GameState.financas
	var c: VBoxContainer = _cartao(Rect2(808, 112, 456, 440), "Bem-vindo à Católica FC")
	c.add_child(_texto("“Bem-vindo à Católica FC! A partir de agora, você está no comando. Cuide do clube, desenvolva seu elenco, tome boas decisões e leve a Católica ao topo!”", 18, Color("8E1222")))
	_topico(c, "Você é o treinador e o gestor: elenco, treinos, finanças e partidas.")
	_topico(c, "Objetivo: conduzir o clube por várias temporadas, disputar o Campeonato Universitário, o InterLajes e a Copa dos Gigantes e cumprir as metas da diretoria.")
	c.add_child(_dado("Temporada", str(GameState.temporada)))
	c.add_child(_dado("Elenco", "%d jogadores" % GameState.elenco.size()))
	c.add_child(_dado("Caixa", _rs(int(f.get("caixa", 0)))))
	c.add_child(_dado("Confiança da diretoria", "%d%%" % int(f.get("confianca_diretoria", 0))))
	_gatinho(Rect2(560, 330, 230, 312), true)

func _passo_treino() -> void:
	_cabecalho("Campo de Treinamento", "Evoluir é o nosso plano!")
	var a: VBoxContainer = _cartao(Rect2(890, 114, 272, 176), "Sobre o treino")
	a.add_child(_texto("“Aqui seus jogadores evoluem! Um bom treino deixa o time mais forte, descansado e preparado.”", 17, Color("8E1222")))
	var b: VBoxContainer = _cartao(Rect2(888, 296, 386, 352), "Como funciona")
	_topico(b, "4 turnos por semana: monte a agenda de cada turno.")
	_topico(b, "Modalidades: Físico, Técnico, Tático, Recuperação e Folga.")
	_topico(b, "Escolha o jogador em foco para evoluí-lo mais.")
	_topico(b, "Treino pesado cansa: vigie energia, condição física e moral.")
	_topico(b, "Veja a prévia dos efeitos e confirme. Depois de confirmada, a agenda trava.")
	var en: float = 0.0
	var mo: float = 0.0
	for j in GameState.elenco:
		en += float(j.get("energia", 0))
		mo += float(j.get("moral_individual", 0))
	var n: int = maxi(GameState.elenco.size(), 1)
	b.add_child(_dado("Treino desta semana", "confirmado" if GameState.treino_confirmado else "pendente"))
	b.add_child(_dado("Energia média do elenco", "%d%%" % int(round(en / n))))
	b.add_child(_dado("Moral média", "%d" % int(round(mo / n))))

func _passo_secretaria() -> void:
	var f: Dictionary = GameState.financas
	_cabecalho("Secretaria e Diretoria", "Administre o clube e tome grandes decisões!")
	_balao(Rect2(878, 103, 258, 95), "As decisões de hoje refletem no futuro do clube!")
	var c: VBoxContainer = _cartao(Rect2(840, 206, 436, 442), "Finanças e metas")
	c.add_child(_dado("Caixa do clube", _rs(int(f.get("caixa", 0)))))
	c.add_child(_dado("Preço do ingresso", _rs(int(f.get("preco_ingresso", 0)))))
	c.add_child(_dado("Dívida", _rs(int(GameState.divida()))))
	c.add_child(_dado("Confiança da diretoria", "%d%%" % int(f.get("confianca_diretoria", 0))))
	c.add_child(_dado("Confiança da torcida", "%d%%" % int(round(float(f.get("torcida", 0))))))
	c.add_child(_texto("Metas da diretoria desta temporada:", 16, Color("8E1222")))
	for m in GameState.metas:
		c.add_child(_texto("•  " + str(m.get("titulo", "")), 15))
	_topico(c, "A bilheteria depende do preço, da torcida e do adversário. Empréstimo ajuda o caixa, mas gera dívida com juros.")

func _passo_mercado() -> void:
	var f: Dictionary = GameState.financas
	_cabecalho("Mercado", "Contrate, negocie e fortaleça seu elenco!")
	_balao(Rect2(878, 105, 258, 95), "Hora de reforçar o time! Veja os melhores jogadores do mercado.")
	var lista: Array = GameState.mercado_jogadores.duplicate()
	lista.sort_custom(func(a, b): return int(a["overall"]) > int(b["overall"]))
	var c: VBoxContainer = _cartao(Rect2(10, 306, 845, 300), "Jogadores disponíveis")
	var rot := {"GOLEIRO": "GOL", "DEFENSOR": "ZAG", "MEIA_DEFENSOR": "VOL", "MEIA": "MEI", "MEIA_ATAQUE": "MEA", "ATAQUE": "ATA"}
	for k in mini(5, lista.size()):
		var j: Dictionary = lista[k]
		var h := HBoxContainer.new()
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var nome := _rot(str(j["nome"]), 19, TINTA, true)
		nome.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nome.clip_text = true
		h.add_child(nome)
		var pos := _rot(str(rot.get(j["posicao"], j["posicao"])), 17, Color("8E1222"), true)
		pos.custom_minimum_size = Vector2(60, 0)
		h.add_child(pos)
		var ovr := _rot("OVR %d" % int(j["overall"]), 17, TINTA)
		ovr.custom_minimum_size = Vector2(100, 0)
		h.add_child(ovr)
		var pr := _rot(_rs(int(j["preco"])), 18, Color("8E1222"), true)
		pr.custom_minimum_size = Vector2(150, 0)
		pr.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		h.add_child(pr)
		c.add_child(h)
	if lista.is_empty():
		c.add_child(_texto("Nenhum jogador disponível no mercado agora.", 18))
	_placa(Rect2(930, 628, 350, 22))          # cobre o botão desenhado no vídeo
	var d: VBoxContainer = _cartao(Rect2(862, 232, 412, 372), "Como funciona")
	_topico(d, "Filtre por posição e veja os detalhes do atleta antes de decidir.")
	_topico(d, "Contratar usa o caixa e aumenta o elenco; vender traz caixa e abre vaga.")
	_topico(d, "Compre com cuidado: o saldo é limitado.")
	d.add_child(_dado("Caixa disponível", _rs(int(f.get("caixa", 0)))))
	d.add_child(_dado("Elenco atual", "%d jogadores" % GameState.elenco.size()))

func _passo_obras() -> void:
	_cabecalho("Obras", "Construa, melhore e evolua seu clube!")
	_balao(Rect2(852, 108, 270, 98), "Investir no clube é o caminho para um futuro ainda maior!")
	var c: VBoxContainer = _cartao(Rect2(780, 220, 488, 284), "Instalações do clube")
	var nomes := {"arquibancada": "Arquibancada", "iluminacao": "Iluminação", "lanchonete": "Lanchonete", "centro_treinamento": "Centro de Treinamento"}
	for chave in GameState.ESTADIO_MELHORIAS.keys():
		var info: Dictionary = GameState.ESTADIO_MELHORIAS[chave]
		var nivel: int = int(GameState.financas["estadio"].get(chave, 0))
		var h := HBoxContainer.new()
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var nm := _rot(str(nomes.get(chave, info["nome"])), 18, TINTA, true)
		nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(nm)
		h.add_child(_rot("Nível %d/3" % nivel, 16, Color("8E1222"), true))
		c.add_child(h)
		var prox: String = "nível máximo" if nivel >= 3 else "próximo: %s · manutenção %s" % [_rs(int(info["niveis"][nivel]["custo"])), _rs(int(info["niveis"][nivel]["manut"]))]
		c.add_child(_rot("%s — %s" % [str(info["efeito"]), prox], 13, Color("6B4A44")))
	var e1: VBoxContainer = _cartao(Rect2(15, 522, 697, 116), "Custos e manutenção")
	e1.add_child(_dado("Manutenção atual do estádio", _rs(GameState.manutencao_estadio_total())))
	e1.add_child(_dado("Capacidade", "%s lugares" % _milhar(int(GameState.financas.get("capacidade_estadio", 0)))))
	var e2: VBoxContainer = _cartao(Rect2(738, 522, 530, 116), "Por que investir")
	e2.add_child(_texto("Mais público e receita, torcida mais confiante e melhor recuperação de energia.", 16))

func _passo_classificacao() -> void:
	var comp: String = Competicoes.competicao_da_rodada(GameState.rodada_atual)
	var src: Array = GameState.copa if comp == "copa" and not GameState.copa.is_empty() else GameState.clubes
	var tabela: Array = Competicoes.ordenar_tabela(src)
	var nome_comp := {"universitario": "Campeonato Universitário", "interlajes": "InterLajes", "copa": "Copa dos Gigantes"}
	var c: VBoxContainer = _cartao(Rect2(280, 112, 720, 522), "Classificação · " + str(nome_comp.get(comp, "Campeonato")))
	var cab := ["#", "Clube", "P", "J", "V", "E", "D", "GP", "GC", "SG"]
	c.add_child(_linha_tab(cab, true, false))
	for k in mini(10, tabela.size()):
		var t: Dictionary = tabela[k]
		var sg: int = int(t["gols_pro"]) - int(t["gols_contra"])
		c.add_child(_linha_tab([str(k + 1), str(t["nome"]), str(int(t["pontos"])), str(int(t["jogos"])), str(int(t["vitorias"])), str(int(t["empates"])), str(int(t["derrotas"])), str(int(t["gols_pro"])), str(int(t["gols_contra"])), "%+d" % sg], false, t["id"] == "catolica"))
	var pos: int = 0
	for k in tabela.size():
		if tabela[k]["id"] == "catolica":
			pos = k + 1
	if pos > 10:
		c.add_child(_linha_tab(["%d" % pos, "Católica FC", "…", "", "", "", "", "", "", ""], false, true))
	c.add_child(_texto("Posição da Católica: %dº. Vitória vale 3 pontos, empate 1. O saldo (SG) desempata." % pos, 15, Color("8E1222")))
	var info: Variant = GameState.obter_partida_da_rodada() if GameState.temporada_status == "em_andamento" else null
	if info != null:
		c.add_child(_texto("Próximo jogo: %s (%s) · rodada %d" % [str(info["adversario"].get("nome", "?")), "em casa" if info["em_casa"] else "fora", GameState.rodada_atual], 15))
	_gatinho(Rect2(1030, 372, 220, 244), false)

func _linha_tab(cols: Array, cab: bool, destaque: bool) -> Control:
	var pc := PanelContainer.new()
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.91, 0.72, 0.29, 0.45) if destaque else (Color("EBD9C3") if cab else Color(0, 0, 0, 0))
	sb.set_corner_radius_all(4)
	sb.content_margin_left = 6
	sb.content_margin_right = 6
	sb.content_margin_top = 2
	sb.content_margin_bottom = 2
	pc.add_theme_stylebox_override("panel", sb)
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for k in cols.size():
		var l := _rot(str(cols[k]), 18, TINTA, cab or destaque or k == 1 or k == 2, 700 if (cab or destaque) else 500)
		if k == 1:
			l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			l.clip_text = true
		else:
			l.custom_minimum_size = Vector2(30 if k == 0 else 48, 0)
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		h.add_child(l)
	pc.add_child(h)
	return pc

func _passo_mapa() -> void:
	var c: VBoxContainer = _cartao(Rect2(808, 112, 456, 440), "Agora é com você!")
	c.add_child(_texto("“Agora é com você! Explore o clube, organize sua equipe, cuide das finanças e prepare a Católica FC para vencer. Boa sorte, treinador!”", 18, Color("8E1222")))
	_topico(c, "O mapa é o centro da carreira: clique nos edifícios para acessar cada função.")
	_topico(c, "No estádio, JOGAR RODADA leva à partida, depois de confirmar treino e escalação.")
	_topico(c, "A barra de baixo tem Prancheta, Finanças, Base e Conquistas.")
	_topico(c, "Esc abre o menu de pausa; o botão ? do mapa reabre este tutorial.")
	_gatinho(Rect2(560, 330, 230, 312), true)

func _fechar(concluido: bool) -> void:
	if _auto:
		GameState.tutorial_concluido = true      # concluído ou pulado: não repete sozinho
	if is_instance_valid(_video):
		_video.liberar()
	fechado.emit(concluido)
	queue_free()
