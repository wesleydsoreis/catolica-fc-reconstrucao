extends Control
## Resultado final do amistoso: placar, autores e opções. Nada é gravado na carreira.

func _ready() -> void:
	var r: Dictionary = GameState.amistoso_resultado
	var rol := ScrollContainer.new()
	rol.set_anchors_preset(Control.PRESET_FULL_RECT)
	rol.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(rol)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	var mg := MarginContainer.new()
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + l, 12)
	rol.add_child(mg)
	mg.add_child(col)
	if r.is_empty():
		col.add_child(Tema.titulo_secao("Sem resultado"))
		return
	var gc: int = int(r["gc"])
	var ga: int = int(r["ga"])
	var tipo := "VITÓRIA!" if gc > ga else ("DERROTA" if gc < ga else "EMPATE")
	var cor: Color = Tema.VERDE if gc > ga else (Tema.VINHO if gc < ga else Tema.AMARELO)
	col.add_child(Tema.titulo_secao("Amistoso · fim de jogo"))
	var cp := Tema.cartao(Tema.BRANCO, 16)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	cp.add_child(v)
	var t := Tema.rotulo(tipo, 26, cor.darkened(0.25) if gc >= ga else cor)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.name = "Tipo"
	v.add_child(t)
	var pl := Tema.rotulo("Católica FC  %d x %d  %s" % [gc, ga, str(r["adversario"].get("nome_curto", r["adversario"].get("nome", "?")))], 20)
	pl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	pl.name = "Placar"
	v.add_child(pl)
	var lc := HBoxContainer.new()
	lc.alignment = BoxContainer.ALIGNMENT_CENTER
	lc.add_theme_constant_override("separation", 6)
	lc.add_child(Tema.chip(str(GameState.DIFICULDADES.get(str(r.get("dificuldade", "normal")), {"nome": "NORMAL"})["nome"]), Tema.AZUL))
	lc.add_child(Tema.chip("FORMAÇÃO " + str(r.get("formacao_id", "")), Tema.VINHO))
	v.add_child(lc)
	col.add_child(cp)
	var aut: Array = r.get("autores", [])
	if not aut.is_empty():
		var ca := Tema.cartao(Tema.BRANCO)
		var va := VBoxContainer.new()
		ca.add_child(va)
		va.add_child(Tema.rotulo("GOLS DA CATÓLICA", 12, Tema.TITULO))
		for a in aut:
			va.add_child(Tema.rotulo("⚽ " + str(a), 14))
		col.add_child(ca)
	var nota := Tema.rotulo("Amistoso: não vale pontos, não mexe no caixa e não avança a rodada.", 12)
	nota.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(nota)
	var b1 := Tema.botao("JOGAR DE NOVO", "primario", 52)
	b1.name = "BotaoRevanche"
	b1.pressed.connect(func():
		GameState.amistoso["em_jogo"] = true
		SceneManager.ir_para("partida", false))
	col.add_child(b1)
	var b2 := Tema.botao("CONFIGURAR OUTRA PARTIDA", "secundario", 44)
	b2.name = "BotaoConfig"
	b2.pressed.connect(func(): SceneManager.ir_para("config_partida", false))
	col.add_child(b2)
	var b3 := Tema.botao("MENU PRINCIPAL", "escuro", 44)
	b3.name = "BotaoMenu"
	b3.pressed.connect(func(): SceneManager.ir_para("inicio", false))
	col.add_child(b3)
