class_name PausaMapa
extends CanvasLayer
## Menu de pausa da carreira (Esc ou Start): continuar, salvar, configurações, tutorial e voltar ao menu.
## Sair para o menu principal NUNCA apaga a carreira: ela continua na memória e no arquivo salvo.

signal fechado
signal pediu_tutorial

var _caixa: VBoxContainer
var _msg: Label
var _estado: String = "principal"

static func abrir(pai: Node) -> PausaMapa:
	var p := PausaMapa.new()
	p.layer = 70
	pai.add_child(p)
	return p

func _ready() -> void:
	var raiz := Control.new()
	raiz.name = "Raiz"
	raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	raiz.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(raiz)
	var dim := ColorRect.new()
	dim.color = Color(0.1, 0.02, 0.04, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(dim)
	var centro := CenterContainer.new()
	centro.set_anchors_preset(Control.PRESET_FULL_RECT)
	raiz.add_child(centro)
	var painel := PanelContainer.new()
	painel.add_theme_stylebox_override("panel", Paleta.estilo(Color(Paleta.BORDO.r, Paleta.BORDO.g, Paleta.BORDO.b, 0.97), Paleta.DOURADO, 3, 16, 22))
	painel.custom_minimum_size = Vector2(min(420.0, get_viewport().get_visible_rect().size.x - 24.0), 0)
	centro.add_child(painel)
	_caixa = VBoxContainer.new()
	_caixa.add_theme_constant_override("separation", 8)
	painel.add_child(_caixa)
	_principal()

func _input(e: InputEvent) -> void:
	var start: bool = e is InputEventJoypadButton and (e as InputEventJoypadButton).pressed and (e as InputEventJoypadButton).button_index == JOY_BUTTON_START
	if e.is_action_pressed("ui_cancel") or start:
		get_viewport().set_input_as_handled()
		if _estado == "principal":
			fechar()
		else:
			_principal()

func fechar() -> void:
	fechado.emit()
	queue_free()

func _limpar() -> void:
	for c in _caixa.get_children():
		c.queue_free()
	_caixa.reset_size()

func _titulo(t: String) -> void:
	var l: Label = Paleta.rotulo(t, 40, Paleta.DOURADO, true, 700)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_caixa.add_child(l)

func _btn(nome: String, texto: String, tipo: String, acao: Callable) -> Button:
	var b: Button = Paleta.botao(texto, tipo, 22, 46)
	b.name = nome
	b.pressed.connect(acao)
	_caixa.add_child(b)
	return b

func _status(texto: String, cor: Color = Color("E3CFC0")) -> void:
	_msg = Paleta.rotulo(texto, 16, cor)
	_msg.name = "Status"
	_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_caixa.add_child(_msg)

func _principal() -> void:
	_estado = "principal"
	_limpar()
	_titulo("PAUSA")
	var total: int = GameData.regras_especiais.get("total_rodadas", 28)
	var sujo: bool = SaveSystem.nao_salvo()
	_status("Temporada %d · Rodada %d/%d\n%s" % [GameState.temporada, GameState.rodada_atual, total, "Há alterações não salvas." if sujo else "Carreira salva."], Color("FF9A8A") if sujo else Color("E3CFC0"))
	var c: Button = _btn("Pausa_Continuar", "CONTINUAR", "ouro", fechar)
	_btn("Pausa_Salvar", "SALVAR CARREIRA", "bordo", _salvar)
	_btn("Pausa_Config", "CONFIGURAÇÕES", "bordo", _config)
	_btn("Pausa_Tutorial", "TUTORIAL", "bordo", func():
		pediu_tutorial.emit()
		queue_free())
	_btn("Pausa_Menu", "VOLTAR AO MENU PRINCIPAL", "discreto", _pedir_menu)
	c.grab_focus.call_deferred()

func _salvar() -> void:
	var ok: bool = SaveSystem.salvar()
	_principal()
	_msg.text = "Carreira salva com sucesso." if ok else "Não foi possível salvar."
	_msg.add_theme_color_override("font_color", Color("9BE08A") if ok else Color("FF9A8A"))

func _config() -> void:
	_estado = "config"
	_limpar()
	Opcoes.carregar()
	_titulo("CONFIGURAÇÕES")
	_btn("Config_Mao", "Toque: " + Opcoes.rotulo_mao(), "bordo", func():
		Opcoes.alternar_mao()
		_config())
	_btn("Config_Inv", "Passe/chute: " + ("invertido" if Opcoes.invertido else "normal"), "bordo", func():
		Opcoes.alternar_inversao()
		_config())
	_btn("Config_Tela", "Tela cheia (F11)", "bordo", func():
		var tc: Node = get_node_or_null("/root/TelaCheia")
		if tc != null:
			tc.call("alternar"))
	_btn("Config_Voltar", "VOLTAR", "ouro", _principal)

func _pedir_menu() -> void:
	if not SaveSystem.nao_salvo():
		_ir_menu()
		return
	_estado = "confirmar"
	_limpar()
	_titulo("SAIR PARA O MENU?")
	var l: Label = Paleta.rotulo("Há progresso não salvo desde o último salvamento. A carreira não será apagada, mas o que não foi salvo pode ser perdido se você fechar o jogo.", 17)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_caixa.add_child(l)
	_btn("Pausa_SalvarSair", "SALVAR E SAIR", "ouro", func():
		SaveSystem.salvar()
		_ir_menu())
	_btn("Pausa_SairSemSalvar", "SAIR SEM SALVAR", "perigo", _ir_menu)
	_btn("Pausa_Cancelar", "CANCELAR", "discreto", _principal)

func _ir_menu() -> void:
	SceneManager.limpar_historico()
	SceneManager.ir_para("inicio", false)
