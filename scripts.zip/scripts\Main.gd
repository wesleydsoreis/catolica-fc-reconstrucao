extends Control
## Main
## Cena raiz. Registra o ScreenContainer no SceneManager, abre a tela inicial
## e intercepta o botão/gesto físico de Voltar do Android para navegar dentro
## do jogo em vez de fechar o app (ver project.godot: run/quit_on_go_back=false).

func _ready() -> void:
	_aplicar_estilo_pixel()
	get_tree().node_added.connect(_no_novo)
	SceneManager.registrar_container($ScreenContainer)
	SceneManager.ir_para("inicio", false)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		# Botão físico/gesto de Voltar do Android chegou aqui.
		if not SceneManager.voltar():
			# Não há para onde voltar (estamos na tela inicial): deixa o SO
			# decidir (normalmente minimiza o app, em vez de encerrar abruptamente).
			pass

func _unhandled_input(event: InputEvent) -> void:
	# Esc / Start: no mapa abre o menu de pausa; nas demais telas de gestão volta para a tela anterior.
	var start: bool = event is InputEventJoypadButton and (event as InputEventJoypadButton).pressed and (event as InputEventJoypadButton).button_index == JOY_BUTTON_START
	if event.is_action_pressed("ui_cancel") or start:
		var t: String = SceneManager.tela_atual()
		if t == "hub" or t == "mapa":
			var m: Node = $ScreenContainer.get_child(0) if $ScreenContainer.get_child_count() > 0 else null
			if m != null and m.has_method("abrir_pausa"):
				m.call("abrir_pausa")
		elif t == "partida":
			return      # a partida tem o seu próprio menu de pausa
		elif t != "inicio":
			SceneManager.voltar()
		get_viewport().set_input_as_handled()

func _aplicar_estilo_pixel() -> void:
	# tema novo (cartões creme, contorno grosso, botões laranja) construído em código
	var tema: Theme = Tema.construir()
	var f: Font = load("res://assets/fonte/pixel2.fnt")
	if f is FontFile:
		(f as FontFile).fallbacks = [ThemeDB.fallback_font]
	theme = tema
	var fundo := TextureRect.new()
	fundo.texture = Tema.fundo_pontilhado()
	fundo.stretch_mode = TextureRect.STRETCH_TILE
	fundo.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	fundo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	fundo.set_anchors_preset(Control.PRESET_FULL_RECT)
	fundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fundo)
	move_child(fundo, 1)
	$FundoCreme.visible = false
	_fundo = fundo
	_montar_cabecalho()

# ------------------------------------------------------------ cabeçalho + abas
const TELAS_SEM_MOLDURA := ["inicio", "partida", "hub", "mapa", "treino", "painel", "mercado", "estadio_obras", "torneios"]
const ABAS := [["painel", "PAINEL"], ["elenco", "ELENCO"], ["mercado", "MERCADO"], ["estadio_obras", "ESTÁDIO"], ["torneios", "LIGAS"]]
var _fundo: TextureRect
var _cab: PanelContainer
var _lb_sub: Label
var _abas: HBoxContainer
var _tela: String = ""

func _montar_cabecalho() -> void:
	_cab = PanelContainer.new()
	var st: StyleBoxFlat = Tema.caixa(Tema.BRANCO, Tema.TINTA, 3, 0, false, 10)
	st.border_width_left = 0
	st.border_width_right = 0
	st.border_width_top = 0
	st.border_width_bottom = 4
	_cab.add_theme_stylebox_override("panel", st)
	_cab.set_anchors_preset(Control.PRESET_TOP_WIDE)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	_cab.add_child(col)
	var lin := HBoxContainer.new()
	lin.add_theme_constant_override("separation", 10)
	col.add_child(lin)
	var voltar := Tema.botao("‹", "secundario", 40)
	voltar.custom_minimum_size = Vector2(44, 40)
	voltar.pressed.connect(func(): SceneManager.voltar())
	voltar.name = "BotaoVoltarTopo"
	lin.add_child(voltar)
	var esc: Control = load("res://scenes/ui/EscudoCFC.tscn").instantiate()
	esc.custom_minimum_size = Vector2(44, 44)
	lin.add_child(esc)
	var tx := VBoxContainer.new()
	tx.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tx.add_theme_constant_override("separation", 0)
	lin.add_child(tx)
	var nome := Label.new()
	nome.text = "CATÓLICA FC"
	nome.add_theme_font_size_override("font_size", 22)
	nome.add_theme_color_override("font_color", Tema.TEXTO)
	tx.add_child(nome)
	_lb_sub = Label.new()
	_lb_sub.add_theme_font_size_override("font_size", 12)
	_lb_sub.add_theme_color_override("font_color", Tema.TITULO)
	tx.add_child(_lb_sub)
	var tc := Tema.botao("⛶", "secundario", 40)
	tc.custom_minimum_size = Vector2(44, 40)
	tc.pressed.connect(func():
		var n: Node = get_node_or_null("/root/TelaCheia")
		if n != null: n.call("alternar"))
	lin.add_child(tc)
	_abas = HBoxContainer.new()
	_abas.add_theme_constant_override("separation", 6)
	col.add_child(_abas)
	add_child(_cab)
	_cab.visible = false
	GameState.estado_mudou.connect(_atualizar_sub)
	resized.connect(_ajustar)

func _posicao_clube() -> int:
	var lista: Array = GameState.clubes.duplicate()
	lista.sort_custom(func(a, b):
		var da: int = int(a["gols_pro"]) - int(a["gols_contra"])
		var db: int = int(b["gols_pro"]) - int(b["gols_contra"])
		if int(a["pontos"]) != int(b["pontos"]): return int(a["pontos"]) > int(b["pontos"])
		return da > db)
	for i in lista.size():
		if lista[i]["id"] == "catolica":
			return i + 1
	return 1

func _atualizar_sub() -> void:
	if _lb_sub == null or GameState.clubes.is_empty():
		return
	var total: int = GameData.regras_especiais.get("total_rodadas", 28)
	_lb_sub.text = "Temporada %d · Rodada %d/%d · %dº lugar" % [GameState.temporada, GameState.rodada_atual, total, _posicao_clube()]

func ao_trocar(tela: String) -> void:
	_tela = tela
	var com: bool = not TELAS_SEM_MOLDURA.has(tela)
	_cab.visible = com
	if com:
		_atualizar_sub()
		for c in _abas.get_children():
			c.queue_free()
		var eh_aba: bool = false
		for a in ABAS:
			if a[0] == tela:
				eh_aba = true
		_abas.visible = eh_aba
		if eh_aba:
			for a in ABAS:
				var b := Tema.botao(a[1], "escuro" if a[0] == tela else "secundario", 34)
				b.add_theme_font_size_override("font_size", 11)
				b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				b.pressed.connect(func():
					if a[0] != _tela:
						SceneManager.ir_para(a[0], false))
				_abas.add_child(b)
		var bv: Node = _cab.find_child("BotaoVoltarTopo", true, false)
		if bv != null:
			(bv as Control).visible = SceneManager.pode_voltar() and not eh_aba or tela == "painel" and SceneManager.pode_voltar()
	_ajustar.call_deferred()

func _ajustar() -> void:
	if _cab == null:
		return
	var larg: float = size.x
	var coluna: float = minf(larg, Tema.LARGURA_MAX) if not TELAS_SEM_MOLDURA.has(_tela) else larg
	var margem: float = (larg - coluna) * 0.5
	var topo: float = 0.0
	if _cab.visible:
		_cab.reset_size()
		topo = _cab.size.y + 8.0
		var cw: float = minf(larg, Tema.LARGURA_MAX + 20.0)
		_cab.position = Vector2((larg - cw) * 0.5, 0)
		_cab.size.x = cw
	var sc: Control = $ScreenContainer
	sc.offset_left = margem + (10.0 if coluna < larg else 0.0)
	sc.offset_right = -(margem + (10.0 if coluna < larg else 0.0))
	sc.offset_top = topo
	sc.offset_bottom = -(8.0 if topo > 0.0 else 0.0)

func _no_novo(n: Node) -> void:
	if n is Label and str(n.name).begins_with("Titulo"):
		var l: Label = n as Label
		l.add_theme_color_override("font_color", Tema.TITULO)
		l.add_theme_font_size_override("font_size", 16)
		l.clip_text = true
