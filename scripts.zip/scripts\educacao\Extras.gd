class_name Extras
extends RefCounted
## Fase 7: clima, rivalidade, categoria de base, metas pessoais e conquistas.

const CLIMAS := {
	"sol": {"nome": "Sol", "desc": "Tempo bom, sem efeito.", "publico": 1.0, "cansaco": 1.0, "erro": 1.0},
	"chuva": {"nome": "Chuva", "desc": "Gramado molhado: mais erros de passe e menos torcedores (−12%).", "publico": 0.88, "cansaco": 1.0, "erro": 1.12},
	"calor": {"nome": "Calor forte", "desc": "O time se cansa mais rápido (+20% de cansaço).", "publico": 0.95, "cansaco": 1.2, "erro": 1.0},
}
const NOMES_BASE := ["Guto", "Teco", "Davi", "Nando", "Lipe", "Caio", "Renan", "Biel", "Tito", "Joca", "Dudu", "Marcelo", "Yuri", "Kaká", "Léo", "Pedrinho"]
const POSICOES_BASE := ["GOLEIRO", "DEFENSOR", "MEIA_DEFENSOR", "MEIA", "MEIA_ATAQUE", "ATAQUE"]
const LIMITE_ELENCO := 24
const RODADAS_EMPRESTIMO := 6

static func clima(sala: int, temporada: int, rodada: int) -> String:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("clima|%d|%d|%d" % [sala, temporada, rodada])
	var r: float = rng.randf()
	return "sol" if r < 0.6 else ("chuva" if r < 0.82 else "calor")

static func sortear_rival(ids: Array, sala: int) -> String:
	var l: Array = ids.filter(func(x): return x != "catolica")
	l.sort()
	return str(l[absi(hash("rival|%d" % sala)) % l.size()]) if not l.is_empty() else ""

static func gerar_jovens(temporada: int, sala: int, ocupados: Array) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("base|%d|%d" % [sala, temporada])
	var nomes: Array = NOMES_BASE.duplicate()
	var r: Array = []
	for i in 3:
		var nome: String = ""
		while nome == "" or ocupados.has(nome.to_upper()):
			nome = nomes[rng.randi() % nomes.size()]
		ocupados = ocupados + [nome.to_upper()]
		var ov: int = 52 + rng.randi() % 9
		r.append({"id": "base_%d_%d" % [temporada, i], "nome": nome.to_upper(), "posicao": POSICOES_BASE[rng.randi() % POSICOES_BASE.size()],
			"overall": ov, "potencial": ov + 12 + rng.randi() % 12, "idade": 16 + rng.randi() % 3, "promovido": false})
	return r

const CONQUISTAS := [
	{"id": "primeira_vitoria", "nome": "Primeira vitória", "desc": "Vença uma partida."},
	{"id": "sequencia3", "nome": "Embalo", "desc": "Vença 3 jogos seguidos."},
	{"id": "invicto5", "nome": "Muralha", "desc": "Fique 5 jogos sem perder."},
	{"id": "goleada", "nome": "Goleada", "desc": "Vença por 3 gols de diferença ou mais."},
	{"id": "classico", "nome": "Rei do clássico", "desc": "Vença o seu maior rival."},
	{"id": "artilheiro", "nome": "Artilheiro", "desc": "Um jogador chega a 5 gols na temporada."},
	{"id": "matematico", "nome": "Craque dos números", "desc": "Acerte 5 desafios de primeira."},
	{"id": "mestre", "nome": "Mestre de uma área", "desc": "Chegue ao nível Avançado em alguma área."},
	{"id": "quitou", "nome": "Nome limpo", "desc": "Quite uma dívida inteira."},
	{"id": "torcida80", "nome": "Estádio em festa", "desc": "Leve a torcida a 80% ou mais."},
	{"id": "diretoria90", "nome": "Queridinho da diretoria", "desc": "Chegue a 90% de confiança."},
	{"id": "base", "nome": "Prata da casa", "desc": "Promova um jovem da base."},
	{"id": "meta_pessoal", "nome": "Missão cumprida", "desc": "Um jogador bate a meta pessoal."},
	{"id": "campeao", "nome": "Campeão", "desc": "Conquiste um título."},
]
const PREMIO_CONQUISTA := 3000
