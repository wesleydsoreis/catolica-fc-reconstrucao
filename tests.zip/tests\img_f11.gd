extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	var modo: String = OS.get_cmdline_user_args()[0]
	Cfg.usar_modo(modo == "11")
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	root.content_scale_size = Vector2i(480, 270)
	root.size = Vector2i(1440, 810)
	await process_frame
	var p: Partida = Partida.new()
	p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"; p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	p.piloto_auto = true
	root.add_child(p)
	for i in 600: await physics_frame
	await _cap("f11_%s_a" % modo)
	for i in 900: await physics_frame
	await _cap("f11_%s_b" % modo)
	quit(0)
func _cap(n: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/%s.png" % n)
