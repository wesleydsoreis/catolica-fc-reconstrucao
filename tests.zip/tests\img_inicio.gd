extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var cena: Control = load("res://scenes/TelaInicial.tscn").instantiate()
	root.add_child(cena)
	cena.set_anchors_preset(Control.PRESET_FULL_RECT)
	for i in 10: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/inicio_a.png")
	cena._modo = "opcoes"; cena._sel = 1
	for i in 5: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/inicio_b.png")
	quit(0)
