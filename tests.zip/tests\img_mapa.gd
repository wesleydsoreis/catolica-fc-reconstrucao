extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.iniciar_sala("2A-2026", "Ana Souza"); gs.tutorial_concluido = true
	for k in 3:
		gs.simular_partida(); gs.avancar_rodada()
	var sufixo: String = OS.get_environment("SUF") if OS.get_environment("SUF") != "" else "a"
	sm.ir_para("hub", false)
	for i in 25: await process_frame
	var mapa: Node = main.get_node("ScreenContainer").get_child(0)
	for alvo in ["", "estadio", "federacao", "treino"]:
		if alvo != "":
			mapa.call("_mostrar", alvo)
		for i in 15: await process_frame
		await RenderingServer.frame_post_draw
		root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/mapa_%s_%s.png" % [sufixo, alvo if alvo != "" else "base"])
		if alvo != "":
			mapa.call("_esconder", alvo)
	quit()
