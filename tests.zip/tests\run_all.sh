#!/usr/bin/env bash
# Regressão completa. Uso: GODOT=/caminho/godot bash tests/run_all.sh   (na raiz do projeto)
G="${GODOT:-godot}"
$G --headless --path . --import >/dev/null 2>&1
for t in teste_escalacao teste_etapa5 teste_etapa6 teste_fase1 teste_fase2 teste_fase3 teste_11x11 teste_bolas_paradas teste_fase4 teste_fase5 teste_fase6 teste_fase7 teste_mapa teste_pausa teste_telas teste_prancheta teste_integracao teste_jogabilidade teste_menu teste_npcs teste_formacoes_partida teste_ambiente teste_som_partida; do
  echo "=== $t"
  timeout 600 $G --headless --path . --fixed-fps 60 res://tests/$t.tscn 2>&1 | grep -E "FALHOU|FALHAS|SCRIPT ERROR|Parse Error" | head -20
done
echo "=== teste_etapa7"
timeout 900 $G --headless --path . --fixed-fps 60 res://tests/teste_etapa7.tscn 2>&1 | grep -E "FALHOU|FALHAS|SCRIPT ERROR|Parse Error" | head -20
echo FIM
