extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _assinatura(gs: Node) -> String:
	var nomes: Array = gs.elenco.map(func(j): return str(j["nome"]) + str(j["overall"]))
	var cal: String = str(gs.calendario[0]) if gs.calendario.size() > 0 else ""
	return str(nomes) + cal + str(gs.metas) + str(gs.desafio_atual()["enunciado"])
func _ready() -> void:
	await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	# sala de aula: mesma semente => mesma carreira, metas e problema
	gs.iniciar_sala("2A-2026", "Ana")
	var a1: String = _assinatura(gs)
	var seed1: int = gs.sala_seed
	gs.iniciar_sala("2A-2026", "Bruno")
	var a2: String = _assinatura(gs)
	ok(seed1 != 0 and gs.sala_seed == seed1, "código da turma gera a mesma semente (%d)" % seed1)
	ok(a1 == a2, "mesma turma: mesmo elenco, calendário, metas e problema")
	gs.iniciar_sala("OUTRA-TURMA", "Carla")
	ok(_assinatura(gs) != a1, "turma diferente: cenário diferente")
	gs.sair_sala()
	ok(gs.sala_seed == 0 and gs.turma_codigo == "", "sair da sala volta à carreira livre")
	# temporada entra na semente dos problemas
	ok(Educacao.semente(1, 1, "funcoes", "medio", 0) != Educacao.semente(1, 2, "funcoes", "medio", 0), "temporada diferente muda o problema")
	# desafios e decisões registrados
	gs.iniciar_sala("T1", "Dani")
	var p: Dictionary = gs.desafio_atual()
	gs.iniciar_cronometro_desafio()
	gs.responder_desafio((int(p["correta"]) + 1) % 4)
	gs.responder_desafio(int(p["correta"]))
	ok(gs.educacao_log.size() == 1 and gs.educacao_log[0].has("tempo_s") and gs.educacao_log[0]["tentativas"] == 2, "log do desafio com tentativas e tempo")
	gs.simular_partida()
	ok(gs.decisoes_log.size() == 1 and gs.decisoes_log[0].has("formacao") and gs.decisoes_log[0].has("preco_ingresso"), "decisões da rodada registradas")
	gs.responder_coletiva(1)
	ok(int(gs.decisoes_log[0]["coletiva"]) == 1, "resposta da coletiva entra no relatório")
	# relatório
	var r: Dictionary = Relatorio.resumo(gs)
	ok(r["desafios_total"] == 1 and r["acertos_1a_total"] == 0 and r["aluno"] == "Dani" and r["turma"] == "T1", "resumo do relatório")
	var csv: String = Relatorio.csv(gs)
	ok(csv.contains("RESUMO POR AREA") and csv.contains("DESAFIOS") and csv.contains("DECISOES POR RODADA") and csv.contains("aluno;Dani"), "CSV com as 3 seções")
	var js = JSON.parse_string(Relatorio.json(gs))
	ok(js is Dictionary and js["desafios"].size() == 1 and js["decisoes"].size() == 1 and js["turma"] == "T1", "JSON válido e completo")
	var caminho: String = Relatorio.exportar(gs, "csv")
	ok(caminho != "" and FileAccess.file_exists(caminho), "exportar CSV grava o arquivo: " + caminho)
	var caminho2: String = Relatorio.exportar(gs, "json")
	ok(caminho2 != "" and FileAccess.file_exists(caminho2), "exportar JSON grava o arquivo")
	# desbloqueios por competência
	gs.competencias = {}
	ok(gs.nivel_area("estatistica") == 0, "começa Iniciante")
	gs.competencias["estatistica"] = {"acertos": 3, "total": 3}
	ok(gs.nivel_area("estatistica") == 1, "3 acertos = Intermediário")
	gs.competencias["estatistica"] = {"acertos": 8, "total": 8}
	gs.competencias["financas"] = {"acertos": 8, "total": 8}
	gs.competencias["funcoes"] = {"acertos": 8, "total": 8}
	gs.competencias["probabilidade"] = {"acertos": 8, "total": 8}
	gs.competencias["porcentagem"] = {"acertos": 8, "total": 8}
	ok(gs.nivel_area("estatistica") == 2 and gs.nivel_area("financas") == 2, "8 acertos = Avançado")
	ok(Educacao.quartis([1, 2, 3, 4, 5, 6, 7, 8]) == [2.5, 6.5] and Educacao.quartis([1, 2, 3, 4, 5, 6, 7]) == [2.0, 6.0], "quartis")
	gs.financas["divida"] = 100000.0
	# novos problemas usam dados reais do jogo
	var ctx: Dictionary = Educacao.contexto(gs)
	var viu_demanda := false
	var viu_divida := false
	for sd in 80:
		var f: Dictionary = Educacao.gerar("funcoes", "medio", ctx, sd)
		if str(f["titulo"]) == "A demanda do seu estádio":
			viu_demanda = true
		var g: Dictionary = Educacao.gerar("financas", "superior", ctx, sd)
		if str(g["titulo"]) == "O peso da dívida":
			viu_divida = true
	ok(int(ctx["pub25"]) > 1000, "público a R$ 25 vem do estádio real (%d)" % int(ctx["pub25"]))
	ok(viu_demanda and viu_divida, "problemas com a demanda e a dívida reais aparecem")
	# telas
	for tela in ["competencias", "professor", "prancheta", "financas", "inicio"]:
		var cena: Node = load(sm.CENAS[tela]).instantiate()
		add_child(cena)
		await get_tree().process_frame
		await get_tree().process_frame
		ok(cena.get_child_count() > 0, "tela %s abre" % tela)
		if tela == "competencias":
			ok(cena.find_child("Desbloqueio_estatistica_2", true, false) != null and cena.find_child("Area_funcoes", true, false) != null, "árvore: áreas e desbloqueios")
		if tela == "professor":
			ok(cena.find_child("CampoTurma", true, false) != null and cena.find_child("BotaoCSV", true, false) != null and cena.find_child("BotaoAtivarSala", true, false) != null, "professor: sala e exportação")
			(cena.find_child("BotaoCSV", true, false) as Button).pressed.emit()
			await get_tree().process_frame
			ok(str((cena.find_child("LabelExport", true, false) as Label).text).length() > 5, "botão CSV mostra o resultado da exportação")
		if tela == "prancheta":
			ok(cena.find_child("StatQuartis", true, false) != null and cena.find_child("StatDesvio", true, false) != null and cena.find_child("StatEsperado", true, false) != null, "prancheta: ferramentas desbloqueadas")
		if tela == "financas":
			ok(cena.find_child("TabelaDemanda", true, false) != null and cena.find_child("PrecoOtimo", true, false) != null and cena.find_child("SimuladorQuitacao", true, false) != null, "finanças: ferramentas desbloqueadas")
		if tela == "inicio":
			cena._modo = "config"; cena._montar()
			var ids: Array = []
			for o in cena._opcoes: ids.append(o["id"])
			ok(ids.has("professor"), "Configurações do menu inicial têm Modo professor")
		cena.queue_free()
		await get_tree().process_frame
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit()
