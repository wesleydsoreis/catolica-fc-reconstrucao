extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	gs.novo_jogo()
	# 1) conteúdo real de cada personagem
	for id in NpcDados.NOMES.keys():
		var d: Dictionary = NpcDados.dialogo(id)
		ok(d["paginas"].size() >= 1 and str(d["paginas"][0]).length() > 10, "%s: texto" % id)
		ok(ResourceLoader.exists(d["retrato"]) and ResourceLoader.exists("res://assets/gerado/npcs/%s.png" % id), "%s: arte" % id)
		for o in d["opcoes"]:
			ok(sm.CENAS.has(o["tela"]), "%s: opção '%s' leva a tela válida" % [id, o["txt"]])
		var sf: SpriteFrames = Npc.montar_frames(id)
		ok(sf.has_animation("idle_down") and sf.has_animation("walk_side") and sf.has_animation("interact") and sf.get_frame_count("walk_down") == 4, "%s: SpriteFrames" % id)
	# 2) dados reais mudam o diálogo
	gs.financas["caixa"] = -5000
	ok("vermelho" in str(NpcDados.dialogo("diretor")["paginas"][1]), "diretor reage a caixa negativo")
	gs.ultimos_resultados = ["V"]
	ok("vitória" in str(NpcDados.dialogo("torcedor")["paginas"][1]), "torcedor reage à vitória")
	gs.financas["caixa"] = 1000000
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
