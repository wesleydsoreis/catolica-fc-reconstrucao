extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	sm.ir_para("desafio", false)
	for i in 20: await process_frame
	await _cap("desafio")
	sm.ir_para("diretor", false)
	for i in 20: await process_frame
	await _cap("diretor")
	var p = gs.desafio_atual()
	gs.responder_desafio((int(p["correta"]) + 1) % 4)
	root.find_child("BotaoCalculadora", true, false).pressed.emit()
	sm.ir_para("diretor", false)
	for i in 20: await process_frame
	await _cap("diretor_erro")
	sm.ir_para("prancheta", false)
	for i in 20: await process_frame
	await _cap("prancheta")
	quit()
func _cap(nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/f4_%s.png" % nome)
