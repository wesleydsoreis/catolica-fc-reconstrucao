extends SceneTree
func _initialize() -> void:
	Cfg.usar_modo(false)
	_rodar()
func _rodar() -> void:
	await process_frame
	var falhas: int = 0
	var p := Partida.new()
	p.nome_casa = "CFC"; p.sigla_casa = "CFC"; p.nome_fora = "ADV"; p.sigla_fora = "ADV"
	p.reservas_casa = [{"nome": "Davi", "numero": 12, "overall": 71, "cat": "GOL"}, {"nome": "Pedro", "numero": 14, "overall": 74, "cat": "DEF"}]
	root.add_child(p)
	for i in 120: await process_frame
	# carrinho não atravessa adversário
	var a: Jogador = null
	var b: Jogador = null
	for q in p.jogadores:
		if q.time == 0 and q.papel == "MEI" and a == null: a = q
		if q.time == 1 and q.papel == "MEI" and b == null: b = q
	p.bola.dono = null
	p.bola.position = Vector2(100, 100)
	a.position = Vector2(1000, 600); b.position = Vector2(1015, 600); b.atordoado = 0.0
	a.investida = 0.3; a.investida_dir = Vector2.RIGHT
	p._investida_toca(a)
	if a.investida != 0.0 or b.atordoado <= 0.0:
		falhas += 1; print("FALHA: carrinho atravessou o adversário")
	# substituição: goleiro só por goleiro, linha só por linha
	var gk: Jogador = null
	var linha: Jogador = null
	for q in p.jogadores:
		if q.time == 0 and q.papel == "GOL": gk = q
		if q.time == 0 and q.papel == "DEF": linha = q
	if p.substituir(gk, 1): falhas += 1; print("FALHA: goleiro trocado por jogador de linha")
	if p.substituir(linha, 0): falhas += 1; print("FALHA: jogador de linha trocado por goleiro")
	var antes: int = int(p.subs_restantes[0])
	if not p.substituir(linha, 1) or int(p.subs_restantes[0]) != antes - 1 or linha.numero != 14:
		falhas += 1; print("FALHA: substituição válida")
	if not p.substituir(gk, 0) or gk.numero != 12:
		falhas += 1; print("FALHA: troca de goleiro")
	# opções de controle: inversão troca eventos
	Opcoes.invertido = true; Opcoes.aplicar()
	var ev: Array = InputMap.action_get_events("passe")
	var tem_k: bool = false
	for e in ev:
		if e is InputEventKey and (e as InputEventKey).physical_keycode == KEY_K: tem_k = true
	if not tem_k: falhas += 1; print("FALHA: inversão passe/chute")
	Opcoes.invertido = false; Opcoes.aplicar()
	# sair da partida pelo menu (duas confirmações)
	var saiu := [false]
	p.sair_pedido.connect(func(): saiu[0] = true)
	p.pausado = true
	for i in 5: await process_frame
	var itens: Array = p.menu._itens_menu()
	p.menu.sel = itens.size() - 1
	p.menu._confirmar()
	if saiu[0]: falhas += 1; print("FALHA: saiu sem confirmar")
	p.menu._confirmar()
	if not saiu[0]: falhas += 1; print("FALHA: não saiu após confirmar")
	# reinício deixa só 1 controlado
	p.pausado = false
	p._gol(1)
	for i in 300: await process_frame
	var n: int = 0
	for q in p.jogadores:
		if q.controlado: n += 1
	if n != 1: falhas += 1; print("FALHA: controlados após reinício = ", n)
	# goleiro nunca é controlado pelo jogador; repõe para companheiro livre
	var gk2: Jogador = null
	for q in p.jogadores:
		if q.time == 0 and q.papel == "GOL": gk2 = q
	p.estado = Partida.Estado.JOGANDO
	p._tomar(gk2)
	for i in 5: await process_frame
	if p.controlado == gk2 or gk2.controlado: falhas += 1; print("FALHA: goleiro controlável")
	var antes_dono: Jogador = p.bola.dono
	var passou: bool = false
	for i in 400:
		await process_frame
		if p.bola.dono != gk2:
			passou = true
			break
	if not passou: falhas += 1; print("FALHA: goleiro não repôs a bola")
	print("FALHAS: ", falhas)
	quit(0)
