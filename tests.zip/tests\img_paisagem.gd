extends SceneTree
func _novo(gs, forca_fora: float = 0.95) -> Partida:
	var d: Dictionary = gs.dados_partida_jogavel()
	var p: Partida = Partida.new()
	p.escalacao_casa = d["escalacao"]; p.reservas_casa = d["reservas"]
	p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	return p
func _foto(nome: String) -> void:
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/%s.png" % nome)
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	DisplayServer.window_set_size(Vector2i(1280, 720))
	await process_frame
	await process_frame
	root.content_scale_size = Vector2i(1280, 720)
	await process_frame
	var gs = root.get_node("GameState")
	gs.novo_jogo(); gs.escolher_tatica("ofensivo")
	# 1) partida (PC)
	var p: Partida = _novo(gs)
	p.piloto_auto = true
	root.add_child(p)
	for i in 700: await physics_frame
	_foto("1_partida_pc")
	# 5) cartão vermelho
	p.piloto_auto = false
	for i in 260: await physics_frame
	var alvo: Jogador = p.times[1][6]
	alvo.amarelos = 1
	p.estado = Partida.Estado.JOGANDO
	var guard := 0
	while int(p.vermelhos[1]) == 0 and guard < 200:
		var alvo2: Jogador = p.times[1][6]
		alvo2.amarelos = 1
		p._cartao(alvo2)
		guard += 1
	p._mostrar("CARTÃO VERMELHO!", "ADV 8 expulso — UNV com 10", 5.0)
	for i in 2: await physics_frame
	_foto("5_cartao_vermelho")
	p.queue_free()
	await process_frame
	# 3) celular em paisagem
	DisplayServer.window_set_size(Vector2i(844, 390))
	await process_frame
	await process_frame
	var q: Partida = _novo(gs)
	q.piloto_auto = false
	root.add_child(q)
	await process_frame
	q.toque.mostrar = true
	q.toque.queue_redraw()
	for i in 500: await physics_frame
	q.toque.queue_redraw()
	await physics_frame
	_foto("3_partida_celular")
	quit(0)
