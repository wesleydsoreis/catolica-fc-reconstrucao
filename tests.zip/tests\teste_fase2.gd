extends Node
## Fase 2: mapa clicável, agenda de treino, entrosamento, lesões e save.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _tela(main: Node) -> Node:
	return main.get_node("ScreenContainer").get_child(0)
func _ready() -> void:
	Cfg.usar_modo(false)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	gs.novo_jogo(); gs.fut7_garantir()
	# ---------- fórmulas
	var j0: Dictionary = gs.elenco[0]
	j0["energia"] = 100.0
	var r_leve: float = gs.risco_lesao_treino(["recuperacao", "folga", "recuperacao", "folga"], j0)
	var r_pesado: float = gs.risco_lesao_treino(["fisico", "fisico", "fisico", "fisico"], j0)
	ok(r_leve == 0.0 and r_pesado > 0.03, "risco de lesão: treino pesado > leve (%.3f vs %.3f)" % [r_pesado, r_leve])
	j0["energia"] = 30.0
	ok(gs.risco_lesao_treino(["fisico", "fisico", "fisico", "fisico"], j0) > r_pesado, "energia baixa aumenta o risco")
	j0["energia"] = 100.0
	var pv: Dictionary = gs.previa_treino(["fisico", "tecnico", "tatico", "recuperacao"], "")
	ok(is_equal_approx(pv["fisico"], 1.2) and is_equal_approx(pv["energia"], -5 - 3 - 3 + 12), "prévia: físico +1,2 e energia -(5+3+3)+12")
	# ---------- efeitos reais
	var ag: Array = ["fisico", "fisico", "tecnico", "tatico"]
	var f_ant: float = gs.fisico_de(j0)
	var t_ant: float = gs.tecnica_de(j0)
	var foco: Dictionary = gs.elenco[1]
	var tf_ant: float = gs.tecnica_de(foco)
	var e_ant: float = gs.entrosamento_atual()
	for j in gs.elenco: j["energia"] = 100.0; j["lesao"] = 0
	seed(3)
	gs.confirmar_treino(ag, str(foco["id"]))
	ok(gs.treino_confirmado, "treino confirmado")
	ok(is_equal_approx(gs.fisico_de(j0), f_ant + 2.4), "físico do elenco +2,4 (2 turnos)")
	ok(is_equal_approx(gs.tecnica_de(j0), t_ant + 0.9), "técnica do elenco +0,9")
	ok(gs.tecnica_de(foco) > tf_ant + 2.5, "jogador em foco evolui mais na técnica")
	ok(is_equal_approx(gs.entrosamento_atual(), e_ant + 6.0), "entrosamento do estilo +6 por turno tático")
	ok(j0["energia"] <= 100.0 - 5 - 5 - 3 - 3 + 0.01 or int(j0.get("lesao", 0)) >= 0, "energia consumida")
	var antes: float = gs.fisico_de(j0)
	gs.confirmar_treino(["fisico", "fisico", "fisico", "fisico"], "")
	ok(gs.fisico_de(j0) == antes, "treino não pode ser confirmado duas vezes na mesma semana")
	# ---------- lesão: indisponível e substituído
	var tit: Array = gs.fut7_titulares()
	var alvo: Dictionary = tit[2]
	var id: String = str(alvo["id"])
	gs.registrar_lesao(id, 2)
	ok(gs.jogo_lesionado(id) and gs.indisponivel(id), "lesionado fica indisponível")
	var d: Dictionary = gs.dados_partida_jogavel(null, false)
	var ids: Array = []
	for e in d["escalacao"]: ids.append(e["id"])
	for r in d["reservas"]: ids.append(r["id"])
	ok(not ids.has(id) and d["escalacao"].size() == 7, "lesionado fora da partida e substituído (7 titulares)")
	ok(d["escalacao"][0].has("fisico") and d["escalacao"][0].has("tecnica"), "partida recebe físico e técnica")
	# ---------- lesão conta a partir da próxima rodada
	gs.avancar_rodada()
	ok(int(gs._jogador_por_id(id)["lesao"]) == 2, "lesão nova não desconta na rodada em que ocorreu")
	gs.avancar_rodada()
	ok(int(gs._jogador_por_id(id)["lesao"]) == 1, "lesão desconta 1 por rodada")
	ok(not gs.treino_confirmado, "nova rodada reabre a agenda de treino")
	# recuperação dupla encurta
	gs._jogador_por_id(id)["lesao"] = 3
	for j in gs.elenco: j["energia"] = 100.0
	gs.confirmar_treino(["recuperacao", "recuperacao", "folga", "folga"], "")
	ok(int(gs._jogador_por_id(id)["lesao"]) == 2, "2 turnos de recuperação encurtam lesões em 1")
	# ---------- simulação com lesões ocorre ao longo de várias partidas
	var total_les := 0
	for k in 120:
		total_les += gs._lesoes_simuladas(gs.slots_efetivos()).size()
	ok(total_les > 0 and total_les < 120 * 11 * 0.05, "lesões simuladas existem e são raras (%d em 120 jogos)" % total_les)
	# ---------- save/load
	gs.entrosamento["1"] = 77.0
	gs.agenda_treino = ["tatico", "folga", "fisico", "tecnico"]
	gs.treino_foco_id = str(foco["id"])
	ss.salvar()
	gs.entrosamento["1"] = 0.0
	gs.agenda_treino = ["folga", "folga", "folga", "folga"]
	ok(ss.carregar(), "save carrega")
	ok(is_equal_approx(float(gs.entrosamento["1"]), 77.0) and gs.agenda_treino[0] == "tatico" and gs.treino_foco_id == str(foco["id"]), "save guarda agenda, foco e entrosamento")
	ok(gs.treino_confirmado == true, "treino já confirmado permanece confirmado após carregar")
	# ---------- telas
	gs.treino_confirmado = false
	sm.ir_para("hub", false); await _esperar(5)
	var mapa: Node = _tela(main)
	ok(mapa.name == "Mapa", "hub abre o Mapa")
	var nomes := ["sede", "treino", "mercado", "federacao", "vestiario", "obras", "estadio"]
	var destinos := ["painel", "treino", "mercado", "torneios", "elenco", "estadio_obras", "desafio"]
	for i in nomes.size():
		sm.ir_para("hub", false); await _esperar(4)
		var b: Button = _tela(main).find_child("Local_" + nomes[i], true, false) as Button
		if b == null:
			ok(false, "local " + nomes[i] + " existe"); continue
		var r: Rect2 = Rect2(Vector2.ZERO, _tela(main).size)
		ok(r.encloses(Rect2(b.position, b.size)), "local %s cabe na tela" % nomes[i])
		b.pressed.emit(); await _esperar(5)
		ok(sm._tela_atual == destinos[i], "%s leva a %s" % [nomes[i], destinos[i]])
	# Treino: UI
	sm.ir_para("treino", false); await _esperar(5)
	var tr: Node = _tela(main)
	var t0: Button = tr.find_child("Turno_0", true, false) as Button
	ok(t0 != null, "tela de treino tem a agenda")
	var txt_antes: String = t0.text
	t0.pressed.emit(); await _esperar(3)
	t0 = _tela(main).find_child("Turno_0", true, false) as Button
	ok(t0.text != txt_antes, "clicar no turno troca o tipo de treino")
	var prox: Button = _tela(main).find_child("FocoProximo", true, false) as Button
	ok(prox != null, "seletor de jogador em foco existe")
	var conf: Button = _tela(main).find_child("BotaoConfirmar", true, false) as Button
	conf.pressed.emit(); await _esperar(4)
	ok(gs.treino_confirmado and gs.relatorio_treino.size() > 0, "botão confirma o treino e gera relatório")
	ok(_tela(main).find_child("BotaoConfirmar", true, false) == null or (_tela(main).find_child("BotaoConfirmar", true, false) as Button).disabled, "botão não pode ser reutilizado")
	# Escalação com lesão
	gs.registrar_lesao(id, 1)
	sm.ir_para("escalacao", false); await _esperar(5)
	ok(_tela(main) != null, "escalação abre com lesionado")
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
