extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState"); var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.tutorial_concluido = true
	for t in ["inicio", "mapa", "treino", "mercado", "estadio_obras", "prancheta"]:
		sm.ir_para(t, false)
		for i in 40: await process_frame
		var t0: int = Time.get_ticks_usec()
		for i in 240: await process_frame
		var ms: float = float(Time.get_ticks_usec() - t0) / 1000.0 / 240.0
		print("PERF %s %.1f ms/frame (%.0f fps) mem_est %.0f MB video_mem %.0f MB" % [t, ms, 1000.0 / ms, Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0, Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0])
	quit()
