extends SceneTree
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	var suf: String = args[0] if args.size() > 0 else "x"
	await _cap(suf, "inicio")
	root.get_node("GameState").novo_jogo()
	var sm: Node = root.get_node("SceneManager")
	for t in ["hub", "painel", "estadio_obras", "elenco", "mercado", "torneios", "desafio", "preparacao", "tatica"]:
		sm.ir_para(t, false)
		for i in 4: await process_frame
		await _cap(suf, t)
	quit()

func _cap(suf: String, nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/ui_%s_%s.png" % [suf, nome])
