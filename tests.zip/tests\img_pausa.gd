extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	await create_timer(0.5).timeout
	var gs = root.get_node("GameState"); var sm = root.get_node("SceneManager")
	gs.novo_jogo(); sm.ir_para("hub", false)
	await create_timer(1.5).timeout
	var mapa = main.get_node("ScreenContainer").get_child(0)
	await create_timer(0.5).timeout
	root.get_texture().get_image().save_png("/tmp/s2/shots/tut_1.png")
	for i in 3: mapa._tutorial._btn_prox.pressed.emit()
	await create_timer(0.6).timeout
	root.get_texture().get_image().save_png("/tmp/s2/shots/tut_estadio.png")
	mapa._tutorial._fechar(false)
	await create_timer(0.3).timeout
	mapa.abrir_pausa()
	await create_timer(0.6).timeout
	root.get_texture().get_image().save_png("/tmp/s2/shots/pausa.png")
	quit()
