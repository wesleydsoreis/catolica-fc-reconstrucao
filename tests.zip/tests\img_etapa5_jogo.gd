extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	gs.amistoso = {"adversario_id": "univille", "formacao_id": "2-2-2", "dificuldade": "normal", "em_jogo": true}
	sm.ir_para("partida", false)
	for i in 240: await process_frame
	var p = main.get_node("ScreenContainer").get_child(0)._partida
	await _cap("hud")
	p.pausado = true
	for i in 10: await process_frame
	await _cap("pausa")
	p.menu.sel = 3; p.menu._confirmar()
	for i in 5: await process_frame
	await _cap("config")
	p.menu.sel = 4; p.menu._confirmar()
	p.menu.sel = 2; p.menu._confirmar()
	for i in 5: await process_frame
	await _cap("escalacao")
	quit()
func _cap(nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/e5_jogo_%s.png" % nome)
