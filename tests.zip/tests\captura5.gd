extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState"); var sm = root.get_node("SceneManager")
	gs.novo_jogo()
	for r in 11:
		gs.escolher_tatica("equilibrado")
		gs.simular_partida({"proprio": randi() % 4, "adversario": randi() % 3, "autores": ["WES", "LUCAS"]})
		gs.avancar_rodada()
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	for cena in ["hub", "torneios", "estadio_obras"]:
		sm.ir_para(cena, false)
		for i in 6: await process_frame
		root.get_viewport().get_texture().get_image().save_png("/tmp/s2/k_%s.png" % cena)
	var t = main.get_node("ScreenContainer").get_child(0)
	sm.ir_para("torneios", false)
	for i in 4: await process_frame
	t = main.get_node("ScreenContainer").get_child(0)
	t._abas.current_tab = 1
	for i in 4: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/k_inter.png")
	gs.temporada_status = "encerrada"
	sm.ir_para("fim_temporada", false)
	for i in 6: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/k_fim.png")
	quit(0)
