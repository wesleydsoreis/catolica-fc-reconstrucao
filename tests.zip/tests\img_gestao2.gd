extends SceneTree
func _foto(nome: String) -> void:
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/%s.png" % nome)
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState"); var sm = root.get_node("SceneManager")
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 6: await process_frame
	gs.novo_jogo()
	for t in ["hub","desafio","preparacao","torneios"]:
		sm.ir_para(t, false)
		for i in 12: await process_frame
		_foto("h_" + t)
	gs.escolher_tatica("equilibrado")
	gs.simular_partida()
	sm.ir_para("resultado", false)
	for i in 12: await process_frame
	_foto("h_resultado")
	quit(0)
