extends SceneTree
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 5: await process_frame
	var suf: String = args[0] if args.size() > 0 else "x"
	root.get_node("GameState").novo_jogo()
	root.get_node("SceneManager").ir_para("escalacao", false)
	for i in 10: await process_frame
	var e: Node = main.get_node("ScreenContainer").get_child(0)
	e._clicou_token(3)
	for i in 10: await process_frame
	await _cap(suf, "esc")
	quit()
func _cap(suf: String, nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/%s_%s.png" % [nome, suf])
