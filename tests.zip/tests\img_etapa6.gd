extends SceneTree
func _initialize() -> void:
	var suf: String = OS.get_cmdline_user_args()[0]
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo()
	for k in 3:
		gs.simular_partida(); gs.avancar_rodada()
	sm.ir_para("torneios", false)
	for i in 20: await process_frame
	var t: Node = main.get_node("ScreenContainer").get_child(0)
	for ab in [0, 1, 2, 4]:
		t.find_child("Abas", true, false).current_tab = ab
		for i in 5: await process_frame
		await _cap(suf, "torneios_%d" % ab)
	sm.ir_para("desafio", false)
	for i in 15: await process_frame
	await _cap(suf, "desafio")
	sm.ir_para("preparacao", false)
	for i in 15: await process_frame
	await _cap(suf, "preparacao")
	gs.temporada_status = "encerrada"
	gs.universitario_posicoes = {"catolica": 3}
	sm.ir_para("fim_temporada", false)
	for i in 15: await process_frame
	await _cap(suf, "fim_temporada")
	quit()
func _cap(suf: String, nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/e6_%s_%s.png" % [suf, nome])
