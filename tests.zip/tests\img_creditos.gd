extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 30: await process_frame
	var t: Node = main.get_node("ScreenContainer").get_child(0)
	t._creditos()
	for i in 20: await process_frame
	t.get_node("Dialogo")._fim_digitacao() if t.get_node("Dialogo")._digitando else null
	t.get_node("Dialogo")._avancar()
	for i in 90: await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/creditos_%s.png" % OS.get_environment("SUF"))
	quit()
