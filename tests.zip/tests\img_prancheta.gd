extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.iniciar_sala("2A-2026", "Ana Souza"); gs.tutorial_concluido = true
	for k in 4:
		gs.simular_partida(); gs.avancar_rodada()
	gs.registrar_lesao(str(gs.elenco[0]["id"]), 2)
	sm.ir_para("prancheta", false)
	for i in 20: await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/prancheta_a.png")
	var sc: ScrollContainer = main.get_node("ScreenContainer").get_child(0).get_child(0)
	sc.scroll_vertical = 700
	for i in 5: await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/prancheta_b.png")
	quit()
