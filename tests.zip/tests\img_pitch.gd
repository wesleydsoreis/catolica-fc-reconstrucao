extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var p := Pitch.new(); root.add_child(p)
	for i in 6: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/e2_godot.png")
	quit(0)
