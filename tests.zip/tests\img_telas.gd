extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.iniciar_sala("2A-2026", "Ana Souza"); gs.tutorial_concluido = true
	for k in 3:
		gs.simular_partida(); gs.avancar_rodada()
	var suf: String = OS.get_environment("SUF") if OS.get_environment("SUF") != "" else "a"
	for t in ["treino", "painel", "mercado", "estadio_obras", "torneios"]:
		sm.ir_para(t, false)
		for i in 50: await process_frame
		await RenderingServer.frame_post_draw
		root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/tela_%s_%s.png" % [suf, t])
	quit()
