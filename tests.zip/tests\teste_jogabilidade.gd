extends Node
## Melhorias de jogabilidade: desarme em pé x carrinho, controles, árbitro em campo (11x11 e FUT7).
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _novo(onze: bool) -> Partida:
	Cfg.usar_modo(onze)
	var p := Partida.new()
	add_child(p)
	return p
func _preparar(p: Partida) -> Array:
	# controlado (time 0) perto de um rival com a bola, ambos parados no meio do campo
	var me: Jogador = null
	for q in p.times[0]:
		if (q as Jogador).papel != "GOL": me = q; break
	var rv: Jogador = null
	for q in p.times[1]:
		if (q as Jogador).papel != "GOL": rv = q; break
	for j in p.jogadores:
		(j as Jogador).position = Vector2(300, 300) if j != me and j != rv else (j as Jogador).position
		(j as Jogador).vel = Vector2.ZERO
	var c: Vector2 = Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5)
	rv.position = c; rv.vel = Vector2.ZERO; rv.face = Vector2.RIGHT
	me.position = c + Vector2(-60, 0); me.vel = Vector2.ZERO
	if p.controlado != null:
		p.controlado.controlado = false
	p.controlado = me; me.controlado = true
	p.bola.dono = rv; p.bola.position = rv.position; p.bola.ultimo_time = 1
	p.piloto_auto = false
	me.cd_desarme = 0.0; me.investida = 0.0; me.atordoado = 0.0
	return [me, rv]
func _ready() -> void:
	await get_tree().process_frame
	for onze in [true, false]:
		var rot := "11x11" if onze else "FUT7"
		var p := _novo(onze)
		var n := 0
		while p.estado != Partida.Estado.JOGANDO and n < 900:
			await get_tree().process_frame; n += 1
		ok(p.estado == Partida.Estado.JOGANDO, rot + ": partida em andamento")
		# ---- árbitro em campo
		ok(p.vis != null and p.vis.arbitro != null and p.vis.arbitro.pl != null, rot + ": árbitro existe na apresentação")
		var arb: Arbitro = p.vis.arbitro
		var pos0: Vector2 = arb.pos
		for i in 420:
			p.bola.dono = null; p.bola.vel = Vector2.ZERO; p.bola.position = Vector2(Cfg.PW * 0.85, Cfg.PH * 0.2)
			await get_tree().process_frame
		ok(arb.pos.distance_to(pos0) > 150.0, rot + ": árbitro se move acompanhando o jogo")
		var d: float = arb.pos.distance_to(Vector2(Cfg.PW * 0.85, Cfg.PH * 0.2))
		ok(d > 60.0 and d < 600.0, rot + ": árbitro fica a distância razoável da bola (%.0f)" % d)
		ok(Arbitro.apito_som().data.size() > 1000, rot + ": apito sintetizado existe")
		ok(ResourceLoader.exists("res://assets/audio/arbitro/apito-curto.ogg") and Arbitro._apito(false) is AudioStreamOggVorbis, rot + ": apito real carregado")
		# ---- desarme em pé (K sem a bola)
		var ps: Array = _preparar(p)
		var me: Jogador = ps[0]; var rv: Jogador = ps[1]
		Input.action_press("chute")
		await _esperar(2)
		Input.action_release("chute")
		ok(me.invest_tipo == "pe" or me.investida <= 0.0, rot + ": K sem a bola faz desarme em pé (não carrinho)")
		ok(me.cd_desarme > 0.0, rot + ": desarme tem tempo de recarga")
		ok(p.vis._estado(me) != "carrinho", rot + ": desarme em pé não usa a animação de carrinho")
		# ---- carrinho (I sem a bola) com mira automática no portador
		ps = _preparar(p)
		me = ps[0]; rv = ps[1]
		Input.action_press("lob")
		await get_tree().process_frame
		var tipo_c: String = me.invest_tipo
		var dir_c: Vector2 = me.investida_dir
		Input.action_release("lob")
		ok(tipo_c == "carrinho", rot + ": I sem a bola faz carrinho")
		ok(dir_c.x > 0.9, rot + ": sem setas, o carrinho mira sozinho no portador (%s)" % str(dir_c))
		ok(p.vis._estado(me) == "carrinho" or me.investida <= 0.0, rot + ": carrinho usa a animação de carrinho")
		await _esperar(60)
		ok(me.cd_desarme > 0.5 or me.atordoado > 0.0 or me.investida <= 0.0, rot + ": carrinho tem recuperação")
		# ---- estatística do resolver: desarme em pé x carrinho, de frente x por trás
		var res := {}
		for cfg in [["pe_frente", false, Vector2.LEFT], ["pe_tras", false, Vector2.RIGHT], ["car_frente", true, Vector2.LEFT], ["car_tras", true, Vector2.RIGHT]]:
			var roubos := 0; var faltas := 0; var N := 400
			for i in N:
				p.estado = Partida.Estado.JOGANDO
				ps = _preparar(p)
				me = ps[0]; rv = ps[1]
				rv.face = cfg[2]                       # LEFT = portador olha para quem desarma (de frente)
				p.bola.dono = rv
				var f0: int = int(p.faltas[0])
				var r0: int = int(p.estat["roubos"][0])
				p._resolver_desarme(me, rv, cfg[1])
				if int(p.estat["roubos"][0]) > r0: roubos += 1
				if int(p.faltas[0]) > f0: faltas += 1
				p.estado = Partida.Estado.JOGANDO
				for jx in [me, rv]:
					if jx.expulso:                      # o sorteio de cartão pode expulsar: devolve ao jogo para repetir a amostra
						jx.expulso = false; jx.visible = true; p.times[jx.time].append(jx); p.jogadores.append(jx)
			res[cfg[0]] = [float(roubos) / N, float(faltas) / N]
			print("  %s: roubo %.0f%%  falta %.0f%%" % [cfg[0], 100.0 * res[cfg[0]][0], 100.0 * res[cfg[0]][1]])
		ok(res["pe_frente"][0] > 0.25 and res["pe_frente"][0] < 0.9, rot + ": desarme em pé tem chance equilibrada")
		ok(res["car_frente"][1] > res["pe_frente"][1], rot + ": carrinho arrisca mais falta que o desarme em pé")
		ok(res["pe_tras"][1] > res["pe_frente"][1], rot + ": vir por trás aumenta o risco de falta")
		ok(res["car_tras"][1] > res["car_frente"][1], rot + ": carrinho por trás é o mais arriscado")
		# ---- árbitro vai à falta e mostra cartão
		p.estado = Partida.Estado.JOGANDO
		ps = _preparar(p)
		me = ps[0]; rv = ps[1]
		rv.position = Vector2(Cfg.PW * 0.3, Cfg.PH * 0.7)
		arb.pos = rv.position + Vector2(320, -110)           # árbitro acompanhando o lance, a uns 300 px
		var ap0: int = arb.apitos_tocados
		p._falta(me, rv)
		await _esperar(2)
		ok(arb.apitos_tocados > ap0 and arb._audio.stream is AudioStreamOggVorbis, rot + ": falta faz o árbitro apitar (apito real)")
		ok(arb._lance_t > 0.0, rot + ": falta manda o árbitro ao local do lance")
		var menor: float = 1e9
		for i in 300:
			await get_tree().process_frame
			menor = minf(menor, arb.pos.distance_to(p.ultimo_lance))
		ok(menor < 150.0, rot + ": árbitro chegou perto da falta (%.0f)" % menor)
		p.vis.banner("CARTÃO AMARELO", "Teste", 2.0)
		ok(arb._cartao == "amarelo" and arb._cartao_t > 1.0, rot + ": árbitro mostra cartão amarelo")
		p.vis.banner("CARTÃO VERMELHO!", "Teste", 2.0)
		ok(arb._cartao == "vermelho", rot + ": árbitro mostra cartão vermelho")
		# ---- partida segue sem travar com árbitro (30 s de jogo automático)
		p.estado = Partida.Estado.JOGANDO
		p.piloto_auto = true
		await _esperar(600)
		ok(is_instance_valid(p) and p.vis != null, rot + ": 10 s de jogo automático com árbitro sem erros")
		p.queue_free()
		await _esperar(3)
	# ---- organização: o time não se amontoa na bola e os dois lados começam/seguem com o mesmo número
	for onze in [true, false]:
		var rot2: String = "11x11" if onze else "FUT7"
		var q: Partida = _novo(onze)
		q.piloto_auto = true
		await _esperar(2)
		ok((q.times[0] as Array).size() == (q.times[1] as Array).size(), rot2 + ": times começam com o mesmo número de jogadores (%d)" % (q.times[0] as Array).size())
		var soma := 0.0; var n := 0; var perto := 0.0
		for i in 60 * 40:
			await get_tree().physics_frame
			if q.estado == Partida.Estado.JOGANDO and i > 300 and i % 30 == 0:
				var c := 0
				for jj in q.jogadores:
					var jg: Jogador = jj
					if jg.papel == "GOL": continue
					var dd: float = jg.position.distance_to(q.bola.position)
					soma += dd; n += 1
					if dd < 300.0 * (Cfg.PW / 2200.0): c += 1
				perto += c
		var amostras: float = maxf(1.0, float(n) / maxf(1.0, float(q.jogadores.size() - 2)))
		var media: float = soma / maxf(1.0, float(n))
		ok(media > (0.17 if onze else 0.155) * Cfg.PW, rot2 + ": distância média à bola %.0f px (espalhados)" % media)
		ok(perto / amostras <= (0.45 if onze else 0.5) * float(q.jogadores.size() - 2), rot2 + ": no máximo metade dos jogadores de linha junto da bola (%.1f)" % (perto / amostras))
		var d0: int = (q.times[0] as Array).size() + int(q.vermelhos[0]); var d1: int = (q.times[1] as Array).size() + int(q.vermelhos[1])
		ok(d0 == d1, rot2 + ": jogadores em campo + expulsos fecha igual para os dois times")
		# gravidade: desarme em pé leve quase nunca expulsa
		var verm := 0
		var alvo: Jogador = (q.times[0] as Array)[3]
		for k in 600:
			alvo.amarelos = 0
			if q._cartao(alvo, 0.12) == "vermelho": verm += 1
		ok(verm < 30, rot2 + ": desarme leve raramente rende vermelho (%d/600, 2º amarelo incluído)" % verm)
		q.queue_free()
		await _esperar(3)
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
