extends SceneTree
var falhas := 0
func _check(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHA  ") + m)
	if not c: falhas += 1
func _initialize() -> void:
	Cfg.usar_modo(false)
	_rodar()
func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState")
	gs.novo_jogo(); gs.escolher_tatica("equilibrado")
	var d: Dictionary = gs.dados_partida_jogavel(null, false)
	_check(d["reservas"].size() > 0, "reservas disponíveis: %d" % d["reservas"].size())
	var tot_f := 0; var tot_a := 0; var tot_v := 0; var tot_p := 0
	for k in 6:
		var p: Partida = Partida.new()
		p.escalacao_casa = d["escalacao"]; p.reservas_casa = d["reservas"].duplicate(true)
		p.piloto_auto = true
		root.add_child(p)
		await process_frame
		var f := 0
		while p.estado != Partida.Estado.FIM and f < 30000:
			p._physics_process(1.0 / 60.0)
			p._process(1.0 / 60.0)
			f += 1
		tot_f += p.faltas[0] + p.faltas[1]; tot_a += p.amarelos[0] + p.amarelos[1]
		tot_v += p.vermelhos[0] + p.vermelhos[1]; tot_p += p.penaltis[0] + p.penaltis[1]
		_check(p.estado == Partida.Estado.FIM, "partida %d terminou (%d x %d)" % [k, p.gols[0], p.gols[1]])
		_check(p.times[0].size() == 7 - p.vermelhos[0] and p.times[1].size() == 7 - p.vermelhos[1], "jogadores em campo coerentes com expulsões")
		p.queue_free()
		await process_frame
	print("  faltas %d  amarelos %d  vermelhos %d  pênaltis %d  (6 jogos)" % [tot_f, tot_a, tot_v, tot_p])
	_check(tot_f > 0, "houve faltas")
	# substituição manual
	var p2: Partida = Partida.new()
	p2.escalacao_casa = d["escalacao"]; p2.reservas_casa = d["reservas"].duplicate(true)
	root.add_child(p2)
	await process_frame
	for i in 90: p2._physics_process(1.0 / 60.0); p2._process(1.0 / 60.0)
	var antes: String = p2.controlado.nome
	var ok: bool = p2.substituir_controlado()
	_check(ok and p2.controlado.nome != antes and p2.subs_restantes[0] == 2, "substituição trocou %s por %s" % [antes, p2.controlado.nome])
	p2.substituir_controlado(); p2.substituir_controlado(); 
	_check(not p2.substituir_controlado() and p2.subs_restantes[0] == 0, "limite de 3 trocas")
	# falta/cartão forçado
	var a: Jogador = p2.times[1][5]; var v: Jogador = p2.times[0][5]
	p2.estado = Partida.Estado.JOGANDO
	p2._expulsar(a)
	_check(p2.times[1].size() == 6 and not p2.jogadores.has(a), "expulsão remove jogador")
	for i in 200: p2._physics_process(1.0 / 60.0); p2._process(1.0 / 60.0)
	_check(true, "jogo segue com 10 sem erro")
	print("FALHAS: ", falhas)
	quit(falhas)
