extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.iniciar_sala("2A-2026", "Ana Souza"); gs.fut7_garantir()
	for k in 5:
		var p = gs.desafio_atual()
		gs.iniciar_cronometro_desafio()
		gs.responder_desafio(int(p["correta"]) if k % 2 == 0 else (int(p["correta"]) + 1) % 4)
		gs.responder_desafio(int(p["correta"]))
		gs.rodada_atual += 1
	gs.competencias["estatistica"] = {"acertos": 3, "total": 4}
	sm.ir_para("competencias", false)
	for i in 20: await process_frame
	await _cap("competencias")
	sm.ir_para("professor", false)
	for i in 20: await process_frame
	await _cap("professor")
	quit()
func _cap(nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/f6_%s.png" % nome)
