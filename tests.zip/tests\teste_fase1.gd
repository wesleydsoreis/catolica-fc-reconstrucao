extends Node
## Fase 1: suspensões (vermelho / 3 amarelos), disciplina no save, tática de 3 eixos e goleiro com a bola.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	Cfg.usar_modo(false)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	gs.novo_jogo(); gs.fut7_garantir()
	var tit: Array = gs.fut7_titulares()
	var campo: Dictionary = tit[2]          # um titular de linha
	var id: String = str(campo["id"])
	var nome: String = str(campo["nome"])
	# ---- vermelho direto: 1 jogo
	var msgs: Array = gs._processar_disciplina([{"id": id, "nome": nome, "time": 0, "tipo": "vermelho_direto"}])
	ok(gs.jogo_suspenso(id) and msgs.size() == 1, "vermelho direto suspende por 1 jogo")
	var d: Dictionary = gs.dados_partida_jogavel(null, false)
	var ids_jogo: Array = []
	for e in d["escalacao"]: ids_jogo.append(e["id"])
	for r in d["reservas"]: ids_jogo.append(r["id"])
	ok(not ids_jogo.has(id), "suspenso não aparece nem como titular nem no banco da partida")
	ok(d["escalacao"].size() == 7, "escalação continua com 7 titulares (reserva entra no lugar)")
	var efet: Array = gs.slots_efetivos()
	var ids_sl: Array = []
	for s in efet: ids_sl.append(s["jogador_id"])
	ok(not ids_sl.has(id) and efet.size() == gs.slots.size(), "gestão (11): suspenso substituído sem alterar a escalação salva")
	var d_am: Dictionary = (func():
		gs.amistoso = {"adversario_id": "univille", "formacao_id": "3-2-1", "dificuldade": "normal"}
		return gs.dados_partida_amistoso()).call()
	var ids_am: Array = []
	for e in d_am["escalacao"]: ids_am.append(e["id"])
	ok(ids_am.has(id) or ids_am.size() == 7, "amistoso não é afetado por suspensões")
	gs.amistoso = {}
	# cumpre a suspensão no próximo jogo
	gs._processar_disciplina([])
	ok(not gs.jogo_suspenso(id), "suspensão cumprida após 1 jogo")
	# ---- 3 amarelos em partidas diferentes
	var id2: String = str(tit[3]["id"])
	gs._processar_disciplina([{"id": id2, "nome": "X", "time": 0, "tipo": "amarelo"}])
	gs._processar_disciplina([{"id": id2, "nome": "X", "time": 0, "tipo": "amarelo"}])
	ok(not gs.jogo_suspenso(id2) and gs.amarelos_acumulados(id2) == 2, "2 amarelos acumulados: ainda disponível (2/3)")
	var m3: Array = gs._processar_disciplina([{"id": id2, "nome": "X", "time": 0, "tipo": "amarelo"}])
	ok(gs.jogo_suspenso(id2) and gs.amarelos_acumulados(id2) == 0 and m3.size() == 1, "3º amarelo: suspende 1 jogo e zera o contador")
	gs._processar_disciplina([])
	ok(not gs.jogo_suspenso(id2), "volta depois de cumprir")
	# ---- 2 amarelos na mesma partida = vermelho e não acumulam
	var id3: String = str(tit[4]["id"])
	gs._processar_disciplina([{"id": id3, "nome": "Y", "time": 0, "tipo": "amarelo"}, {"id": id3, "nome": "Y", "time": 0, "tipo": "vermelho_2a"}])
	ok(gs.jogo_suspenso(id3) and gs.amarelos_acumulados(id3) == 0, "2º amarelo na mesma partida = vermelho (amarelos não acumulam)")
	gs._processar_disciplina([])
	# ---- save / load
	gs.escolher_eixos({"pressao": 2, "linha": 0, "construcao": 1})
	gs._processar_disciplina([{"id": id2, "nome": "X", "time": 0, "tipo": "amarelo"}])
	ss.salvar()
	gs.novo_jogo()
	ok(gs.disciplina.is_empty() and gs.tatica_eixos.is_empty(), "novo jogo zera disciplina e eixos")
	ss.carregar()
	ok(gs.amarelos_acumulados(id2) == 1 and gs.tatica_eixos.get("pressao") == 2, "save/load preserva amarelos e eixos táticos")
	# save antigo sem os campos
	var dados_antigos: Dictionary = {}
	gs.tatica_eixos = {}; gs.disciplina = {}
	ok(gs.eixos_atuais()["pressao"] == 1, "sem eixos salvos: usa a tática pronta (equilibrado)")
	gs.escolher_tatica("ofensivo")
	ok(gs.eixos_atuais()["linha"] == 2, "tática pronta 'ofensivo' = linha adiantada")
	# ---- partida jogável: eixos, cartões com id e expulsão cumprida
	gs.novo_jogo(); gs.fut7_garantir()
	gs.escolher_eixos({"pressao": 2, "linha": 2, "construcao": 1})
	sm.ir_para("partida", false)
	await _esperar(6)
	var pj: Node = main.get_node("ScreenContainer").get_child(0)
	var p = pj._partida
	ok(p.eixos[0]["pressao"] == 2 and p.eixos[0]["construcao"] == 1 and p.eixos_definidos, "eixos da carreira chegam à partida")
	ok(p.eixos[1]["pressao"] in [0, 1, 2], "adversário recebe eixos do seu estilo")
	var comid := 0
	for q in p.times[0]:
		if (q as Jogador).jid != "": comid += 1
	ok(comid == 11, "os 11 titulares chegam com id (para disciplina)")
	var atleta: Jogador = p.times[0][2]
	var fez := false
	for i in 400:
		if p._cartao(atleta) != "" and not atleta.expulso:
			pass
		if atleta.expulso:
			fez = true
			break
	var log_ok: bool = p.cartoes_log.size() > 0 and str(p.cartoes_log[0]["id"]) == atleta.jid
	ok(log_ok, "cartões registram o id do jogador (%d entradas)" % p.cartoes_log.size())
	# expulso sai da partida e a quantidade em campo cai
	if not fez:
		p._expulsar(atleta)
	ok(p.times[0].size() == 10 and not p.jogadores.has(atleta), "expulso sai da partida (time com 10)")
	var tem_vermelho: bool = false
	for c in p.cartoes_log:
		if str(c["tipo"]).begins_with("vermelho"): tem_vermelho = true
	if not tem_vermelho:
		p.cartoes_log.append({"id": atleta.jid, "nome": atleta.nome, "time": 0, "tipo": "vermelho_direto"})
	# ---- goleiro com a bola: time se espalha, rival recua, só então passa
	var gk: Jogador = null
	for q in p.times[0]:
		if (q as Jogador).papel == "GOL": gk = q
	p.pausado = false
	p.estado = Partida.Estado.JOGANDO
	p._tomar(gk)
	gk.position = Vector2(120, Cfg.PH * 0.5)
	p.bola.position = gk.position
	var ini: Array = []
	for q in p.times[0]:
		if q != gk: ini.append((q as Jogador).position)
	var passou := false
	var t_ret := 0.0
	var f := 0
	while f < 600:
		await get_tree().physics_frame
		f += 1
		if p.bola.dono != gk:
			passou = true
			t_ret = f / 60.0
			break
	ok(passou, "goleiro acaba repondo a bola (após %.1fs)" % t_ret)
	ok(t_ret >= 2.0, "goleiro espera ao menos 2 s para o time se arrumar (%.1fs)" % t_ret)
	ok(t_ret <= 5.5, "e não passa de ~5 s segurando (%.1fs)" % t_ret)
	# jogadores se mexeram para espaços livres enquanto esperava
	var mov := 0.0
	var k := 0
	for q in p.times[0]:
		if q != gk and k < ini.size():
			mov += (q as Jogador).position.distance_to(ini[k])
			k += 1
	ok(mov > 150.0, "companheiros se reposicionaram durante a espera (%.0f px no total)" % mov)
	# rival não invade a área do goleiro com a bola
	p._tomar(gk)
	gk.segurando = 4.0
	var invasor := 0
	for i in 120:
		await get_tree().physics_frame
		for q in p.times[1]:
			if (q as Jogador).papel != "GOL" and (q as Jogador).position.x < Cfg.PW * 0.28:
				invasor += 1
	ok(invasor == 0, "adversários não pressionam o goleiro dentro da própria área (%d frames invadindo)" % invasor)
	# ---- tática pelo menu de pausa: só no intervalo / bola parada
	p.estado = Partida.Estado.JOGANDO
	p.pausado = true
	await _esperar(4)
	p.menu.modo = MenuPartida.Modo.MENU
	p.menu.sel = 3
	p.menu._confirmar()
	ok(not p.menu._tat, "tática bloqueada durante o jogo corrido")
	p.estado = Partida.Estado.INTERVALO
	p.menu._confirmar()
	ok(p.menu._tat, "tática liberada no intervalo")
	var antes_p: int = int(p.eixos[0]["pressao"])
	p.menu.sel = 0
	p.menu._confirmar()
	ok(int(p.eixos[0]["pressao"]) == (antes_p + 1) % 3, "alterar pressão no intervalo muda os eixos da partida")
	p.menu.sel = 3
	p.menu._confirmar()
	ok(not p.menu._tat and p.menu.sel == 3, "voltar do submenu de tática")
	p.pausado = false
	p.estado = Partida.Estado.JOGANDO
	# ---- fecha partida e aplica disciplina via fluxo de carreira
	p.estado = Partida.Estado.FIM
	p.gols = [1, 0]
	var id_exp: String = atleta.jid
	pj._concluir()
	await _esperar(4)
	ok(gs.jogo_suspenso(id_exp), "expulso na partida jogada fica suspenso na carreira")
	var r = gs.resultado_rodada
	ok(r != null and r.has("disciplina") and r["disciplina"].size() >= 1, "resultado mostra a disciplina da rodada")
	sm.ir_para("resultado", false); await _esperar(4)
	ok(main.get_node("ScreenContainer").get_child(0).find_child("CartaoDisciplina", true, false) != null, "tela de resultado exibe o cartão de disciplina")
	sm.ir_para("escalacao", false); await _esperar(4)
	ok(main.get_node("ScreenContainer").get_child(0) != null, "escalação abre com suspenso marcado")
	sm.ir_para("tatica", false); await _esperar(4)
	var tt: Node = main.get_node("ScreenContainer").get_child(0)
	var bt: Button = tt.find_child("Eixo_pressao_0", true, false) as Button
	ok(bt != null, "tela de tática mostra os 3 eixos")
	bt.pressed.emit()
	await _esperar(3)
	ok(gs.tatica_eixos.get("pressao") == 0, "clicar no eixo muda a tática salva")
	(main.get_node("ScreenContainer").get_child(0).find_child("Preset_ofensivo", true, false) as Button).pressed.emit()
	await _esperar(3)
	ok(gs.tatica_eixos.is_empty() and gs.eixos_atuais()["linha"] == 2, "esquema pronto 'Ofensivo' ajusta os eixos")
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
