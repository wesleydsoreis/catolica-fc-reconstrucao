extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	Cfg.usar_modo(true)
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	root.content_scale_size = Vector2i(480, 270)
	root.size = Vector2i(1440, 810)
	await process_frame
	var suf: String = OS.get_environment("SUF") if OS.get_environment("SUF") != "" else "a"
	var p: Partida = Partida.new()
	p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"; p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	root.add_child(p)
	Engine.time_scale = 4.0
	for i in 700: await physics_frame
	p.piloto_auto = true
	for k in 4:
		for i in 330: await physics_frame
		await _cap("%s_%d" % [suf, k])
	quit(0)
func _cap(n: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/jogo_%s.png" % n)
