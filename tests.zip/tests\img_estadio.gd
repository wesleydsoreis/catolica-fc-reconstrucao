extends SceneTree
func _initialize() -> void:
	_rodar()
func _foto(n: String) -> void:
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/%s.png" % n)
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var c := Cenario.new(); root.add_child(c)
	for i in 70: await process_frame
	_foto("e3_calmo")
	c.estadio.comemorar(5.0); c.campo.balancar_rede(1)
	for i in 20: await process_frame
	_foto("e3_gol")
	quit(0)
