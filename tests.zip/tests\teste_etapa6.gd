extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	for i in 5: await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	gs.novo_jogo()
	gs.simular_partida(); gs.avancar_rodada()
	gs.simular_partida(); gs.avancar_rodada()
	sm.ir_para("torneios", false)
	for i in 6: await get_tree().process_frame
	var t: Node = main.get_node("ScreenContainer").get_child(0)
	var ab: TabContainer = t.find_child("Abas", true, false)
	ok(ab != null and ab.get_tab_count() == 6, "Federação com 6 abas (Univ., Jogos, InterLajes, Copa, Artilharia, Troféus)")
	var jogos: Node = ab.get_child(1)
	var linhas := 0
	for c in jogos.get_child(0).get_children():
		if c is PanelContainer and c.get_child_count() > 0 and c.get_child(0) is HBoxContainer and c.get_child(0).get_child(0) is Label and c.get_child(0).get_child(0).text.begins_with("R"):
			linhas += 1
	ok(linhas == 11, "calendário lista as 11 rodadas da Católica (%d)" % linhas)
	var uni: Node = ab.get_child(0)
	ok(uni.get_child(0).get_child_count() >= 13, "tabela do Universitário com 12 clubes + cabeçalho + zona G8")
	# jogos feitos aparecem com placar
	var com_placar := 0
	for c in jogos.get_child(0).get_children():
		if c is PanelContainer and c.get_child_count() > 0 and c.get_child(0) is HBoxContainer and c.get_child(0).get_child_count() == 3 and c.get_child(0).get_child(2) is Label and " x " in c.get_child(0).get_child(2).text:
			com_placar += 1
	ok(com_placar == 2, "2 jogos disputados com placar no calendário (%d)" % com_placar)
	for tela in ["desafio", "preparacao", "resultado", "fim_temporada", "tatica", "mercado", "elenco", "painel", "escalacao"]:
		sm.ir_para(tela, false)
		for i in 4: await get_tree().process_frame
		ok(main.get_node("ScreenContainer").get_child(0) != null, "tela '%s' abre sem erro" % tela)
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
