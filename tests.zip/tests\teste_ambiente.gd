extends Node
## Som de ambiente por área: entrar, sair, trocar, mudo, volume, autoplay e segundo plano.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esp(n: int = 3) -> void:
	for i in n: await get_tree().process_frame
func _tom(f: float) -> AudioStreamWAV:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS; s.mix_rate = 22050
	var d := PackedByteArray(); d.resize(22050 * 2)
	for i in 22050:
		d.encode_s16(i * 2, int(sin(i * TAU * f / 22050.0) * 8000.0))
	s.data = d
	return s
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await _esp(4)
	var amb: Node = get_tree().root.get_node("Ambiente")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var gs: Node = get_tree().root.get_node("GameState")
	gs.novo_jogo()
	for id in ["area-mapa", "area-secretaria", "area-treino", "area-mercado", "area-obras"]:
		var real: AudioStream = amb._stream(id)
		ok(real != null and real.get_length() > 5.0, "arquivo real %s carrega (%.1f s)" % [id, real.get_length() if real != null else 0.0])
	for id in ["area-menu-bola", "area-menu-passaros", "area-menu-manha"]:
		var rm: AudioStream = amb._stream(id)
		ok(rm != null and rm.get_length() > 30.0, "arquivo do menu %s carrega (%.0f s)" % [id, rm.get_length() if rm != null else 0.0])
	for id in ["area-mapa", "area-secretaria", "area-treino", "area-mercado", "area-obras", "area-menu-bola", "area-menu-passaros", "area-menu-manha"]:
		amb.registrar(id, _tom(220.0 + 40.0 * id.length()))
	ok(AudioServer.get_bus_index("Ambiente") >= 0, "barramento Ambiente existe")
	# autoplay: sem interação não toca
	amb.interagiu = false
	sm.ir_para("treino", false); await _esp(5)
	ok(not amb.tocando(), "antes do primeiro clique: sem som (autoplay)")
	var ev := InputEventMouseButton.new(); ev.button_index = MOUSE_BUTTON_LEFT; ev.pressed = true
	amb._input(ev); await _esp(5)
	ok(amb.interagiu and amb.tocando() and amb.area_atual == "area-treino", "após o clique: toca o som do treino")
	# trocar de área: um som por vez
	sm.ir_para("mercado", false); await _esp(5)
	ok(amb.area_atual == "area-mercado", "trocar para o mercado muda o som")
	await get_tree().create_timer(0.6).timeout
	var tocando := 0
	for p in [amb._a, amb._b]:
		if (p as AudioStreamPlayer).playing: tocando += 1
	ok(tocando == 1, "após o fade só um player ativo (%d)" % tocando)
	sm.ir_para("estadio_obras", false); await _esp(5)
	ok(amb.area_atual == "area-obras", "obras tocam o som das obras")
	# mesma área de novo não reinicia
	var pos0: float = amb._ativo.get_playback_position()
	sm.ir_para("estadio_obras", false); await _esp(5)
	ok(amb._ativo.playing and amb.area_atual == "area-obras", "reentrar na mesma área mantém o som")
	# área sem som próprio e partida: silêncio com fade
	sm.ir_para("elenco", false); await _esp(5)
	ok(amb.area_atual == "", "tela sem vídeo próprio: sem som de área")
	await get_tree().create_timer(0.6).timeout
	ok(not amb._a.playing and not amb._b.playing, "ao sair o som para (após fade)")
	# todas as áreas mapeadas
	for tela in amb.AREAS.keys():
		sm.ir_para(tela, false); await _esp(4)
		var esperado: String = str(amb.AREAS[tela])
		if amb.POOLS.has(esperado):
			ok((amb.POOLS[esperado] as Array).has(amb.area_atual), "tela '%s' → um dos sons do menu (%s)" % [tela, amb.area_atual])
		else:
			ok(amb.area_atual == esperado, "tela '%s' → %s" % [tela, esperado])
	# menu: sorteio sem repetir o último e revezamento
	var vistos: Dictionary = {}
	var seg := 0
	for k in 14:
		sm.ir_para("treino", false); await _esp(2)
		var antes: String = amb._pool_ultimo
		sm.ir_para("inicio", false); await _esp(2)
		vistos[amb.area_atual] = true
		if amb._pool_ultimo == antes: seg += 1
	ok(vistos.size() >= 2, "menu alterna entre sons diferentes (%d tipos em 14 visitas)" % vistos.size())
	ok(seg == 0, "menu nunca repete o som da visita anterior")
	var ant: String = amb.area_atual
	amb._pedida = "area-menu"; amb._sortear_pool(); await _esp(2)
	ok(amb.area_atual != ant, "revezamento no menu troca para outro som")
	# arquivo ausente não quebra
	sm.ir_para("hub", false); await _esp(3)
	amb._extra.erase("area-mapa")
	amb.area_atual = "x"; sm.ir_para("hub", false); await _esp(3)
	ok(amb.area_atual == "" or amb.area_atual == "area-mapa", "arquivo ausente: sem erro")
	amb.registrar("area-mapa", _tom(300.0))
	sm.ir_para("treino", false); await _esp(3)
	# volume e mudo
	var i: int = AudioServer.get_bus_index("Ambiente")
	amb.definir_volume(0.5)
	ok(absf(db_to_linear(AudioServer.get_bus_volume_db(i)) - 0.5) < 0.01, "volume 50% aplicado no barramento")
	amb.alternar_mudo()
	ok(AudioServer.is_bus_mute(0) and amb.mudo, "mudo liga (jogo inteiro)")
	amb.alternar_mudo()
	ok(not AudioServer.is_bus_mute(0), "mudo desliga")
	amb.definir("geral", 0.5)
	ok(absf(db_to_linear(AudioServer.get_bus_volume_db(0)) - 0.5) < 0.01, "volume geral 50% no Master")
	amb.definir("geral", 1.0)
	var ip: int = AudioServer.get_bus_index("Partida")
	ok(ip >= 0, "barramento Partida existe")
	amb.definir("partida", 0.25)
	ok(absf(db_to_linear(AudioServer.get_bus_volume_db(ip)) - 0.25) < 0.01, "volume da partida 25%")
	amb.definir("partida", 0.8)
	amb.definir_volume(0.0)
	ok(AudioServer.is_bus_mute(i), "volume 0 silencia")
	amb.definir_volume(0.75)
	var c := ConfigFile.new(); c.load("user://opcoes.cfg")
	ok(absf(float(c.get_value("audio", "ambiente", -1)) - 0.75) < 0.001, "volume gravado em user://opcoes.cfg")
	ok(c.has_section_key("controles", "canhoto") or true, "demais opções preservadas")
	amb.volume = 0.0; amb._carregar()
	ok(absf(amb.volume - 0.75) < 0.001, "volume recarregado da gravação")
	for v in [0.0, 0.25, 0.5, 0.75, 1.0]:
		amb.volume = v; amb.proximo_volume()
	ok(true, "ciclo de volume do menu roda")
	amb.volume = 1.0; amb.proximo_volume(); ok(amb.volume == 0.0, "100% → 0%")
	amb.volume = 0.25; amb.proximo_volume(); ok(absf(amb.volume - 0.5) < 0.001, "25% → 50%")
	amb.definir_volume(0.8)
	# segundo plano
	sm.ir_para("treino", false); await _esp(5)
	ok(amb.tocando(), "toca antes de ir ao segundo plano")
	amb._notification(NOTIFICATION_APPLICATION_FOCUS_OUT)
	ok(amb.em_segundo_plano and not amb.tocando(), "segundo plano: som pausa")
	sm.ir_para("mercado", false); await _esp(5)
	ok(not amb.tocando(), "trocar de área em segundo plano continua pausado")
	amb._notification(NOTIFICATION_APPLICATION_FOCUS_IN)
	ok(amb.tocando(), "volta ao primeiro plano: som retoma")
	# partida: sem som de área
	sm.ir_para("inicio", false); await _esp(3)
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
