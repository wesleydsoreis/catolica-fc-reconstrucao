extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	gs.novo_jogo()
	# demanda: preço maior => menos público; receita tem máximo interior
	var p20: Dictionary = gs.previsao_bilheteria(20, 70.0)
	var p40: Dictionary = gs.previsao_bilheteria(40, 70.0)
	ok(p20["publico"] > p40["publico"], "preço maior reduz o público (%d > %d)" % [p20["publico"], p40["publico"]])
	var melhor := 0
	var rm := 0
	for p in range(Gestao.PRECO_MIN, Gestao.PRECO_MAX + 1):
		var r: int = gs.previsao_bilheteria(p, 70.0)["receita"]
		if r > rm:
			rm = r
			melhor = p
	ok(melhor > Gestao.PRECO_MIN and melhor < Gestao.PRECO_MAX, "existe preço ótimo interior (R$ %d)" % melhor)
	gs.definir_preco_ingresso(999)
	ok(gs.financas["preco_ingresso"] == Gestao.PRECO_MAX, "preço limitado ao máximo")
	gs.definir_preco_ingresso(25)
	# dívida
	var c0: float = gs.financas["caixa"]
	ok(gs.tomar_emprestimo(100000) == "" and gs.financas["caixa"] == c0 + 100000 and gs.divida() == 100000.0, "empréstimo credita o caixa e cria dívida")
	ok(gs.tomar_emprestimo(250000) != "" and gs.divida() == 100000.0, "limite de dívida respeitado")
	ok(absf(Gestao.divida_apos(100000.0, 3) - 109272.7) < 0.5, "juros compostos: 100k a 3%% por 3 rodadas = %.1f" % Gestao.divida_apos(100000.0, 3))
	ok(gs.pagar_divida(40000) == "" and gs.divida() == 60000.0, "pagamento parcial")
	ok(gs.pagar_divida(999999) == "" and gs.divida() == 0.0, "quitar tudo")
	ok(gs.pagar_divida(10) != "", "sem dívida: nada a pagar")
	# metas
	ok(gs.metas.size() == 3, "3 metas na temporada")
	var ids := {}
	for m in gs.metas: ids[m["id"]] = true
	ok(ids.size() == 3, "metas distintas")
	var ma: Array = Gestao.sortear_metas(1, 1000000.0, 0)
	ok(str(ma) == str(Gestao.sortear_metas(1, 1000000.0, 0)) and str(ma) != str(Gestao.sortear_metas(2, 1000000.0, 0)), "metas reprodutíveis por temporada/sala")
	# rodada completa: confiança, torcida, manchete, juros
	gs.tomar_emprestimo(100000)
	var d0: float = gs.financas["confianca_diretoria"]
	var t0: float = gs.financas["torcida"]
	gs.simular_partida()
	var r = gs.resultado_rodada
	ok(r != null and str(r.get("manchete", "")) != "", "manchete gerada: " + str(r.get("manchete", "")))
	var delta_d: float = gs.financas["confianca_diretoria"] - d0
	var esperado: float = 2.0 if r["tipo_resultado"] == "vitoria" else (-2.0 if r["tipo_resultado"] == "derrota" else 0.0)
	ok(absf(delta_d - esperado) < 0.01 or absf(delta_d - esperado - 4.0) < 0.01, "confiança da diretoria reage ao resultado (%+.0f)" % delta_d)
	ok(gs.financas["torcida"] != t0 or r["tipo_resultado"] == "empate", "torcida reage ao resultado")
	ok(absf(gs.divida() - 103000.0) < 0.5, "dívida cresceu 3%% na rodada (%.1f)" % gs.divida())
	# imprensa
	var c: Dictionary = gs.coletiva_atual()
	ok(not c.is_empty() and not c["feita"] and (c["opcoes"] as Array).size() == 3, "coletiva disponível com 3 respostas")
	var m0: float = gs.elenco[0]["moral_individual"]
	var o: Dictionary = gs.responder_coletiva(0)
	ok(not o.is_empty() and gs.coletiva_atual()["feita"], "responder marca como feita")
	ok(gs.responder_coletiva(1).is_empty(), "só uma coletiva por rodada")
	ok(absf(gs.elenco[0]["moral_individual"] - clampf(m0 + float(o["moral"]), 0, 100)) < 0.01, "resposta altera moral do elenco")
	# fim de temporada
	var av: Dictionary = gs.avaliar_diretoria_fim()
	ok((av["metas"] as Array).size() == 3 and str(av["veredito"]) != "", "avaliação da diretoria: " + str(av["veredito"]))
	var cx: float = gs.financas["caixa"]
	gs.avaliar_diretoria_fim()
	ok(gs.financas["caixa"] == cx, "bônus de meta não é pago duas vezes")
	gs.financas["confianca_diretoria"] = 10.0
	ok(str(gs.avaliar_diretoria_fim()["veredito"]).begins_with("Ultimato"), "confiança baixa → ultimato (sem demissão)")
	gs.nova_temporada()
	ok(gs.metas.size() == 3 and not gs.metas[0]["cumprida"], "nova temporada sorteia novas metas")
	# telas
	gs.novo_jogo()
	gs.simular_partida()
	for tela in ["financas", "imprensa", "painel", "fim_temporada", "resultado"]:
		var cena: Node = load(sm.CENAS[tela]).instantiate()
		add_child(cena)
		await get_tree().process_frame
		await get_tree().process_frame
		ok(cena.get_child_count() > 0, "tela %s abre" % tela)
		if tela == "financas":
			ok(cena.find_child("GraficoReceita", true, false) != null and cena.find_child("PrecoMais", true, false) != null and cena.find_child("Emprestimo_100000", true, false) != null, "finanças: gráfico, preço e empréstimo")
			(cena.find_child("PrecoMais", true, false) as Button).pressed.emit()
			await get_tree().process_frame
			await get_tree().process_frame
			ok(gs.financas["preco_ingresso"] == 30, "botão + R$ 5 altera o preço")
		if tela == "imprensa":
			ok(cena.find_child("Manchete", true, false) != null and cena.find_child("Resposta_2", true, false) != null, "imprensa: manchete e 3 respostas")
		if tela == "painel":
			ok(cena.find_child("BotaoFinancas", true, false) != null, "painel: botão de finanças")
		if tela == "resultado":
			ok(cena.find_child("BotaoColetiva", true, false) != null and cena.find_child("Manchete", true, false) != null, "resultado: manchete e botão da coletiva")
		if tela == "fim_temporada":
			ok(cena.find_child("AvaliacaoDiretoria", true, false) != null, "fim de temporada: avaliação da diretoria")
		cena.queue_free()
		await get_tree().process_frame
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit()
