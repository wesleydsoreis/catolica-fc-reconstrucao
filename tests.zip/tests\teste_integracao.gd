extends Node
## Fase 6: experiência completa pela interface real + memória/vídeos. Complementa as demais suítes (ver docs/TESTES_FASE6.md).
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _tela(main: Node) -> Node:
	return main.get_node("ScreenContainer").get_child(0)
func _ready() -> void:
	await _esperar(3)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	ss.apagar_progresso()
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child(main)
	await _esperar(8)
	# 1-2. inicialização + menu animado
	var menu: Node = _tela(main)
	ok(sm.tela_atual() == "inicio" and menu is Control, "1. jogo inicializa na tela inicial")
	await _esperar(40)
	var vf: VideoFundo = menu._fundo
	var p0: float = vf.posicao()
	await _esperar(40)
	ok(vf.esta_tocando() and vf.posicao() > p0, "2. menu animado reproduzindo")
	ok((menu.find_child("Menu_continuar", true, false) as Button).disabled, "   sem save: Continuar desabilitado")
	# 3. nova carreira pelo botão do menu
	(menu.find_child("Menu_novo", true, false) as Button).pressed.emit()
	await _esperar(40)
	var mapa: Node = _tela(main)
	ok(mapa.name == "Mapa" and not gs.clubes.is_empty(), "3. nova carreira cria o mundo e abre o mapa")
	# 4-8. tutorial pela interface
	ok(is_instance_valid(mapa._tutorial) and not gs.tutorial_concluido, "4. tutorial inicia sozinho na carreira nova")
	var t = mapa._tutorial
	await _esperar(20)
	for i in 3:
		(t.find_child("Tut_Proximo", true, false) as Button).pressed.emit(); await _esperar(5)
	ok(t._i == 3, "5. navegação entre etapas (avançar)")
	(t.find_child("Tut_Anterior", true, false) as Button).pressed.emit(); await _esperar(5)
	ok(t._i == 2, "6. botão voltar do tutorial")
	for i in 5:
		(t.find_child("Tut_Proximo", true, false) as Button).pressed.emit(); await _esperar(5)
	await _esperar(10)
	ok(gs.tutorial_concluido and not is_instance_valid(mapa._tutorial), "8. concluir na última etapa fecha e marca concluído")
	# 7. pular numa segunda carreira
	gs.novo_jogo(); sm.ir_para("hub", false); await _esperar(40)
	mapa = _tela(main)
	ok(is_instance_valid(mapa._tutorial) and not gs.tutorial_concluido, "   segunda carreira: tutorial reabre")
	(mapa._tutorial.find_child("Tut_Pular", true, false) as Button).pressed.emit(); await _esperar(10)
	ok(gs.tutorial_concluido, "7. botão pular conclui o tutorial")
	# 9. persistência no save
	ok(ss.salvar(), "   salvar")
	gs.novo_jogo()
	ok(not gs.tutorial_concluido, "   (nova carreira em memória volta a pendente)")
	ok(ss.carregar() and gs.tutorial_concluido, "9. tutorial concluído persiste no save")
	# 10. carreira antiga
	var f := FileAccess.open(ss.CAMINHO_SAVE, FileAccess.READ); var d = JSON.parse_string(f.get_as_text()); f.close()
	d.erase("tutorial_concluido")
	var w := FileAccess.open(ss.CAMINHO_SAVE, FileAccess.WRITE); w.store_string(JSON.stringify(d)); w.close()
	gs.tutorial_concluido = false
	ok(ss.carregar() and gs.tutorial_concluido, "10. carreira antiga (sem o campo) carrega sem repetir tutorial")
	# Continuar pelo menu
	sm.ir_para("inicio", false); await _esperar(10)
	menu = _tela(main)
	var cont: Button = menu.find_child("Menu_continuar", true, false) as Button
	ok(not cont.disabled, "   com save: Continuar habilitado")
	cont.pressed.emit(); await _esperar(30)
	ok(_tela(main).name == "Mapa" and not is_instance_valid(_tela(main)._tutorial), "   Continuar abre o mapa sem tutorial")
	# 11-13. mapa, hotspots, entrar/sair de cada edifício; 14-15. vídeos internos e controles
	mapa = _tela(main)
	await _esperar(30)
	var mp0: float = mapa._fundo.posicao()
	await _esperar(40)
	ok(mapa._fundo.esta_tocando() and mapa._fundo.posicao() > mp0, "11. mapa animado reproduzindo")
	var destinos := {"estadio": "desafio", "sede": "painel", "treino": "treino", "mercado": "mercado", "obras": "estadio_obras", "federacao": "torneios", "vestiario": "elenco"}
	for id in destinos.keys():
		sm.ir_para("hub", false); await _esperar(25)
		mapa = _tela(main)
		var h: Button = mapa.find_child("Local_" + id, true, false) as Button
		ok(h != null and h.size.x > 20 and h.size.y > 20, "12. hotspot %s existe e tem área" % id)
		h.pressed.emit(); await _esperar(30)
		var tela: Node = _tela(main)
		ok(sm.tela_atual() == destinos[id], "13. entra em %s → %s" % [id, destinos[id]])
		if tela is TelaVideo:
			ok(tela._fundo.esta_tocando(), "14. vídeo interno de %s reproduzindo" % id)
			var vm: Button = tela.find_child("Tela_VoltarMapa", true, false) as Button
			ok(vm != null, "15. controle Voltar ao mapa em %s" % id)
			vm.pressed.emit(); await _esperar(10)
			ok(sm.tela_atual() == "mapa", "13. sai de %s de volta ao mapa" % id)
		else:
			ok(sm.voltar(), "13. sai de %s (histórico)" % id)
	# 16. dados dinâmicos: caixa muda → HUD e mascote refletem
	sm.ir_para("mercado", false); await _esperar(30)
	var tv: Node = _tela(main)
	gs.financas["caixa"] = 777777.0
	gs.estado_mudou.emit(); await _esperar(3)
	ok(tv._caixa_lb.text.find("777.777") >= 0, "16. dados dinâmicos: barra do clube acompanha o caixa")
	sm.ir_para("hub", false); await _esperar(25)
	ok(_tela(main).find_child("BotaoPrancheta", true, false) != null, "   Prancheta acessível no mapa")
	# 17. salvar e carregar
	var cx: float = float(gs.financas["caixa"]); var rod: int = gs.rodada_atual
	ss.salvar(); gs.novo_jogo(); ss.carregar()
	ok(float(gs.financas["caixa"]) == cx and gs.rodada_atual == rod, "17. salvar e carregar preservam caixa e rodada")
	# 18-21. partida 11x11, FUT7, classificação, calendário
	var rod0: int = gs.rodada_atual
	gs.simular_partida(); gs.avancar_rodada()
	ok(gs.rodada_atual == rod0 + 1, "18. rodada 11x11 simulada e avançada")
	gs.amistoso = {"adversario_id": gs.adversarios_amistoso()[0]["id"], "dificuldade": "normal", "modo": "7", "meu_time_id": gs.adversarios_amistoso()[1]["id"], "formacao_id": ""}
	var d7: Dictionary = gs.dados_partida_amistoso()
	ok(not d7.is_empty() and not d7.get("modo11", true), "19. amistoso FUT7 monta a partida")
	var tab: Array = Competicoes.ordenar_tabela(gs.clubes)
	var pts_ok: bool = true
	for i in tab.size() - 1:
		if int(tab[i]["pontos"]) < int(tab[i + 1]["pontos"]): pts_ok = false
	ok(tab.size() >= 8 and pts_ok, "20. classificação ordenada por pontos (%d clubes)" % tab.size())
	var jogados: int = 0
	for r in gs.calendario:
		for m in r:
			if bool(m.get("jogado", false)): jogados += 1
	ok(gs.calendario.size() >= 11 and jogados >= 1, "21. calendário com %d rodadas e jogos registrados" % gs.calendario.size())
	# 22. resoluções nas telas novas
	var win: Window = get_tree().root
	var falha_res := 0
	for tam in [Vector2i(360, 640), Vector2i(768, 1024), Vector2i(1280, 720), Vector2i(1920, 1080), Vector2i(2560, 1080)]:
		win.size = tam
		for t2 in ["inicio", "mapa", "treino", "painel", "mercado", "estadio_obras", "torneios", "prancheta"]:
			sm.ir_para(t2, false); await _esperar(4)
			var n: Control = _tela(main) as Control
			if n == null or n.size.x < 100 or n.size.y < 100:
				falha_res += 1
	win.size = Vector2i(1280, 720)
	ok(falha_res == 0, "22. 8 telas em 5 resoluções abrem com tamanho válido")
	# 23. memória e vazamento com vídeos: 5 ciclos pelas telas com vídeo
	sm.ir_para("hub", false); await _esperar(30)
	var ciclo: Array = ["treino", "painel", "mercado", "estadio_obras", "torneios", "hub", "inicio"]
	for k in 2:
		for t3 in ciclo:
			sm.ir_para(t3, false); await _esperar(6)
	await _esperar(20)
	var nos0: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	var mem0: float = float(Performance.get_monitor(Performance.MEMORY_STATIC))
	var orf0: int = int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT))
	for k in 6:
		for t3 in ciclo:
			sm.ir_para(t3, false); await _esperar(6)
	sm.ir_para("inicio", false); await _esperar(30)
	var nos1: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	var mem1: float = float(Performance.get_monitor(Performance.MEMORY_STATIC))
	var orf1: int = int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT))
	print("  nós %d → %d · órfãos %d → %d · memória estática %.1f → %.1f MB (42 trocas de tela com vídeo)" % [nos0, nos1, orf0, orf1, mem0 / 1048576.0, mem1 / 1048576.0])
	ok(nos1 <= nos0 + 40, "23. sem vazamento de nós após 42 trocas de tela com vídeo")
	ok(orf1 <= orf0 + 5, "23. sem nós órfãos acumulando")
	ok(mem1 < mem0 + 60.0 * 1048576.0, "23. memória estática estável (+%.1f MB)" % ((mem1 - mem0) / 1048576.0))
	var t0: int = Time.get_ticks_usec(); var frames: int = 0
	sm.ir_para("mapa", false); await _esperar(20)
	t0 = Time.get_ticks_usec()
	for i in 120:
		await get_tree().process_frame; frames += 1
	var med: float = float(Time.get_ticks_usec() - t0) / 1000.0 / frames
	print("  mapa com vídeo: %.2f ms/frame (headless, sem render)" % med)
	ok(med < 17.0, "23. mapa com vídeo roda abaixo de 17 ms/frame (%.2f)" % med)
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
