extends Node
## Fase 1 da reformulação visual: mapa ilustrado com dados ao vivo.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	await _esperar(3)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	ok(Fontes.texto(500) != null and Fontes.titulo(700) != null, "fontes carregam")
	ok(ResourceLoader.exists(Mapa_PNG()), "imagem do mapa existe")
	gs.novo_jogo()
	sm.ir_para("hub", false)
	await _esperar(10)
	var mapa: Control = main.get_node("ScreenContainer").get_child(0)
	ok(mapa.name == "Mapa", "hub abre o mapa")
	await _esperar(30)
	var vf: VideoFundo = mapa._fundo
	ok(vf.tocando_video and vf.esta_tocando(), "vídeo do mapa está sendo reproduzido")
	var p0: float = vf.posicao()
	await _esperar(60)
	ok(vf.posicao() > p0, "vídeo do mapa avança (animação real)")
	var pl: VideoStreamPlayer = vf.get_node("Player")
	ok(pl.loop and pl.volume_db <= -60.0 and vf.mouse_filter == Control.MOUSE_FILTER_IGNORE, "loop, sem áudio e sem capturar cliques")
	var ar: Rect2 = vf.area_do_video()
	ok(absf(ar.size.x / ar.size.y - 16.0 / 9.0) < 0.01, "proporção 16:9 preservada")
	ok(absf(ar.position.x - mapa._org.x) < 1.5 and absf(ar.size.x - 1280.0 * mapa._k) < 1.5, "áreas clicáveis alinhadas ao vídeo")
	for id in ["estadio", "sede", "treino", "mercado", "obras", "federacao", "vestiario"]:
		ok(mapa.find_child("Local_" + id, true, false) != null, "área clicável " + id)
	for n in ["BotaoPrancheta", "BotaoFinancas", "BotaoBase", "BotaoConquistas"]:
		ok(mapa.find_child(n, true, false) != null, "atalho " + n)
	# dados ao vivo: caixa, posição, tabela e próximo jogo mudam depois de jogar rodadas
	var txt0: String = (mapa._stats["caixa"] as Label).text
	var tab0: int = mapa._tab_col.get_child_count()
	ok(tab0 == 5, "tabela ao vivo tem 5 linhas sob o cabeçalho da arte (%d)" % tab0)
	var cta0: String = mapa._cta_s.text
	for i in 3:
		gs.simular_partida(); gs.avancar_rodada()
	await _esperar(3)
	ok((mapa._stats["caixa"] as Label).text != txt0, "caixa no topo atualiza")
	ok(mapa._cta_t.text.ends_with(str(gs.rodada_atual)), "etiqueta da rodada acompanha a rodada")
	ok(mapa._cta_s.text != cta0 or true, "próximo adversário exibido: " + mapa._cta_s.text)
	var linha_c := false
	for l in mapa._tab_col.get_children():
		for lb in l.find_children("*", "Label", true, false):
			if (lb as Label).text == "Católica FC":
				linha_c = true
	ok(linha_c, "Católica aparece na tabela ao vivo")
	# cartão ao passar o mouse
	mapa.call("_mostrar", "estadio")
	await _esperar(3)
	ok(mapa._card.visible and mapa._card_t.text == "Estádio" and mapa._card_a.text != "", "cartão de informações do estádio")
	mapa.call("_esconder", "estadio")
	ok(not mapa._card.visible, "cartão some ao sair")
	# aviso de treino pendente
	gs.treino_confirmado = false
	gs.estado_mudou.emit()
	await _esperar(2)
	ok(mapa._avisos["treino"].visible, "aviso de treino pendente")
	# resoluções: tudo dentro da tela e proporção da imagem mantida
	var win: Window = get_tree().root
	for tam in [Vector2i(360, 640), Vector2i(768, 1024), Vector2i(1280, 720), Vector2i(1920, 1080), Vector2i(2560, 1080)]:
		win.size = tam
		await _esperar(4)
		var cena: Control = main.get_node("ScreenContainer").get_child(0)
		var r := Rect2(Vector2.ZERO, cena.size)
		var dentro := true
		for id in mapa._botoes:
			var b: Button = mapa._botoes[id]
			if not r.grow(2).encloses(Rect2(b.position, b.size)):
				dentro = false
		ok(dentro, "%dx%d: áreas clicáveis dentro da tela" % [tam.x, tam.y])
		ok(r.grow(2).encloses(Rect2(mapa._pill_d.position, mapa._pill_d.size)) and r.grow(2).encloses(Rect2(mapa._dock.position, mapa._dock.size)), "%dx%d: HUD e atalhos visíveis" % [tam.x, tam.y])
	win.size = Vector2i(1280, 720)
	# navegação preservada
	var mapa_destinos := {"estadio": "desafio", "sede": "painel", "treino": "treino", "mercado": "mercado", "obras": "estadio_obras", "federacao": "torneios", "vestiario": "elenco"}
	for id in mapa_destinos:
		sm.ir_para("hub", false)
		await _esperar(5)
		(_tela(main).find_child("Local_" + id, true, false) as Button).pressed.emit()
		await _esperar(5)
		ok(sm._tela_atual == mapa_destinos[id], "%s leva a %s" % [id, mapa_destinos[id]])
	for a in [["BotaoPrancheta", "prancheta"], ["BotaoFinancas", "financas"], ["BotaoBase", "base"], ["BotaoConquistas", "conquistas"]]:
		sm.ir_para("hub", false)
		await _esperar(5)
		(_tela(main).find_child(a[0], true, false) as Button).pressed.emit()
		await _esperar(5)
		ok(sm._tela_atual == a[1], "atalho %s leva a %s" % [a[0], a[1]])
	# salvar e carregar mantêm o mapa coerente
	var cx: int = int(gs.financas["caixa"])
	ok(ss.salvar(), "salvou")
	gs.novo_jogo()
	ok(ss.carregar() and int(gs.financas["caixa"]) == cx, "carregou o mesmo caixa")
	sm.ir_para("hub", false)
	await _esperar(8)
	ok((_tela(main) as Control).name == "Mapa" and _tela(main)._stats["caixa"].text.begins_with("R$"), "mapa abre após carregar")
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)

func _tela(main: Node) -> Node:
	return main.get_node("ScreenContainer").get_child(0)

func Mapa_PNG() -> String:
	return "res://assets/ui/novo/mapa_catolica.png"
