extends Node
func _ready() -> void:
	Cfg.usar_modo(false)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	for i in 5: await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var gd: Node = get_tree().root.get_node("GameData")
	var falhas := 0
	for fo in gd.formacoes_fut7:
		gs.novo_jogo()
		gs.fut7_mudar_formacao(fo["id"])
		gs.amistoso = {"adversario_id": str(gs.adversarios_amistoso()[0]["id"]), "formacao_id": fo["id"], "dificuldade": "normal", "modo": "7", "em_jogo": true}
		sm.ir_para("partida", false)
		for i in 5: await get_tree().process_frame
		var pj: Node = main.get_node("ScreenContainer").get_child(0)
		var p = pj._partida
		var n := 0
		while p.estado != 5 and n < 14000:
			await get_tree().process_frame
			n += 1
		print("FORMACAO %s: placar %d x %d, frames %d, fim=%s" % [fo["id"], p.gols[0], p.gols[1], n, str(p.estado == 5)])
		if p.estado != 5: falhas += 1
		sm.bloqueio_voltar = false
		sm.ir_para("hub", false)
		for i in 3: await get_tree().process_frame
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
