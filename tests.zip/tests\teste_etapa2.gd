extends SceneTree
var falhas := 0
func _check(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHA  ") + m)
	if not c: falhas += 1

func _initialize() -> void:
	Cfg.usar_modo(false)
	_rodar()

func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState")
	var sm = root.get_node("SceneManager")
	gs.novo_jogo()
	gs.escolher_tatica("ofensivo")
	var d: Dictionary = gs.dados_partida_jogavel(null, false)
	_check(d["escalacao"].size() == 7, "7 titulares FUT7: %d" % d["escalacao"].size())
	_check(d["escalacao"][0]["cat"] == "GOL" and d["escalacao"][6]["cat"] == "ATA", "ordem GOL..ATA")
	print("  adversário:", d["adversario"]["nome"], " forca ", d["adversario"]["forca"], " casa=", d["em_casa"])
	var caixa0: float = gs.financas["caixa"]
	var rodada0: int = gs.rodada_atual

	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	sm.ir_para("partida")
	await process_frame
	await process_frame
	var pj: Node = main.get_node("ScreenContainer").get_child(0)
	_check(pj.name == "PartidaJogo" or pj.get_script() != null, "cena da partida carregada")
	var p = pj._partida
	_check(p != null, "Partida criada")
	_check(sm.bloqueio_voltar, "Voltar bloqueado durante a partida")
	_check(p.jogadores.size() == 22, "22 jogadores (11x11)")
	var j0 = p.times[0][0]
	_check(j0.nome == d["escalacao"][0]["nome"], "goleiro da casa = titular escalado (%s)" % j0.nome)
	var m0: float = 0.0
	var m1: float = 0.0
	for j in p.times[0]: m0 += j.habil("chute")
	for j in p.times[1]: m1 += j.habil("chute")
	print("  chute médio casa %.3f  fora %.3f" % [m0 / 7.0, m1 / 7.0])
	sm.voltar()
	await process_frame
	_check(main.get_node("ScreenContainer").get_child(0) == pj, "Voltar não sai da partida")

	p.piloto_auto = true
	Engine.time_scale = 12.0
	var f := 0
	while p.estado != Partida.Estado.FIM and f < 20000:
		await physics_frame
		f += 1
	Engine.time_scale = 1.0
	_check(p.estado == Partida.Estado.FIM, "partida terminou (frames %d)" % f)
	var gc: int = p.gols[0]
	var ga: int = p.gols[1]
	print("  placar jogado ", gc, " x ", ga)
	p.continuar_pedido.emit()
	await process_frame
	await process_frame
	var r = gs.resultado_rodada
	_check(r != null, "resultado_rodada preenchido")
	_check(r["placar_catolica"] == gc and r["placar_adversario"] == ga, "placar oficial = placar jogado")
	var esperado: String = "vitoria" if gc > ga else ("derrota" if gc < ga else "empate")
	_check(r["tipo_resultado"] == esperado, "tipo de resultado coerente: " + r["tipo_resultado"])
	_check(gs.financas["caixa"] != caixa0, "finanças atualizadas")
	_check(not sm.bloqueio_voltar, "Voltar liberado")
	_check(main.get_node("ScreenContainer").get_child_count() >= 1, "tela de resultado ativa")
	gs.avancar_rodada()
	_check(gs.rodada_atual == rodada0 + 1, "avançar rodada funciona")
	# caminho simulado continua intacto
	gs.escolher_tatica("equilibrado")
	gs.simular_partida()
	_check(gs.resultado_rodada != null, "SIMULAR continua funcionando")
	print("FALHAS: ", falhas)
	quit(falhas)
