extends SceneTree
var falhas := 0
func _check(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHA  ") + m)
	if not c: falhas += 1
func _initialize() -> void:
	_rodar()

func _jogar_rodada(gs, placar: Dictionary) -> void:
	gs.escolher_tatica("equilibrado")
	gs.simular_partida(placar)
	gs.avancar_rodada()

func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState")
	# 1) temporada vitoriosa: vence tudo -> campeã dos 3
	gs.novo_jogo()
	var caixa0: float = gs.financas["caixa"]
	for r in 11:
		_jogar_rodada(gs, {"proprio": 4, "adversario": 0, "autores": ["WES", "WES", "LUCAS", "VH"]})
	_check(gs.rodada_atual == 12, "chegou à rodada 12")
	_check(not gs.interlajes.is_empty() and gs.interlajes["quartas"].size() == 4, "chave de quartas criada")
	_check(gs.universitario_posicoes["catolica"] == 1, "Católica 1ª colocada após 11 vitórias")
	for r in 6:
		var info = gs.obter_partida_da_rodada()
		_check(info != null and info["competicao"] == "interlajes", "rodada %d é InterLajes (%s %s)" % [gs.rodada_atual, info["estagio"], info["lado"]])
		_jogar_rodada(gs, {"proprio": 3, "adversario": 0})
	_check(gs.interlajes["campeao_id"] == "catolica", "campeã do InterLajes")
	_check(gs.copa.size() == 12 and gs.copa_calendario.size() == 11, "Copa montada: 12 clubes, 11 rodadas")
	for r in 11:
		var info2 = gs.obter_partida_da_rodada()
		_check(info2 != null and info2["competicao"] == "copa", "rodada %d é Copa vs %s" % [gs.rodada_atual, info2["adversario"]["nome"]])
		_jogar_rodada(gs, {"proprio": 2, "adversario": 0})
	_check(gs.temporada_status == "encerrada", "temporada encerrada")
	_check(gs.copa_campeao_id == "catolica", "campeã da Copa")
	_check(gs.trofeus.size() == 3, "3 troféus: %d" % gs.trofeus.size())
	_check(gs.obter_partida_da_rodada() == null, "sem partida após o fim")
	var art: Array = gs.artilharia(3)
	_check(art.size() > 0 and art[0]["gols"] > 0, "artilharia registrada: %s" % str(art))
	print("  prêmios:", gs.premios_temporada.size(), " caixa ", int(caixa0), " -> ", int(gs.financas["caixa"]))
	# salvar/carregar
	_check(root.get_node("SaveSystem").salvar(), "salvou")
	var tr: int = gs.trofeus.size()
	gs.trofeus = []
	_check(root.get_node("SaveSystem").carregar() and gs.trofeus.size() == tr and gs.copa.size() == 12, "carregou com competições")
	gs.nova_temporada()
	_check(gs.temporada == 2 and gs.rodada_atual == 1 and gs.interlajes.is_empty() and gs.copa.is_empty(), "nova temporada zerou competições")
	_check(gs.obter_partida_da_rodada() != null, "nova temporada tem partida")

	# 2) temporada ruim: perde sempre -> fora do G8 / eliminada, fecha sozinha
	var resumo := {}
	for k in 12:
		gs.novo_jogo()
		for r in 11:
			_jogar_rodada(gs, {"proprio": 0, "adversario": 2})
		var chave: String = "g8" if gs.universitario_g8.has("catolica") else "fora"
		if gs.universitario_g8.has("catolica"):
			var guard := 0
			while gs.temporada_status == "em_andamento" and guard < 20:
				_jogar_rodada(gs, {"proprio": 0, "adversario": 1})
				guard += 1
			_check(guard < 20, "série %d: eliminada e encerrada" % k)
		_check(gs.temporada_status == "encerrada", "série %d: temporada encerrou (%s)" % [k, chave])
		_check(gs.copa_campeao_id != "", "série %d: Copa simulada tem campeão (%s)" % [k, gs.copa_campeao_id])
	# 3) estádio
	gs.novo_jogo()
	var cap0: int = gs.financas["capacidade_estadio"]
	_check(gs.comprar_melhoria_estadio("arquibancada") == "", "comprou arquibancada")
	_check(gs.financas["capacidade_estadio"] == cap0 + 1500, "capacidade +1500")
	_check(gs.manutencao_estadio_total() == 4000 + 1500, "manutenção somou")
	gs.financas["caixa"] = 1000.0
	_check(gs.comprar_melhoria_estadio("lanchonete") != "", "sem caixa não compra")
	print("FALHAS: ", falhas)
	quit(falhas)
