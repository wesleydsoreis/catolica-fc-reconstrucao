extends Node
## Pausa (Esc/Start), tutorial da primeira entrada e preservação da carreira.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _tecla(a: String) -> void:
	var e := InputEventAction.new(); e.action = a; e.pressed = true
	Input.parse_input_event(e)
func _ready() -> void:
	await _esperar(3)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	# carreira nova: tutorial abre sozinho
	gs.novo_jogo()
	ok(not gs.tutorial_concluido, "carreira nova começa com tutorial pendente")
	sm.ir_para("hub", false)
	await _esperar(12)
	var mapa: Control = main.get_node("ScreenContainer").get_child(0)
	var tut: Node = mapa.find_child("Raiz", true, false)
	ok(mapa._tutorial != null and is_instance_valid(mapa._tutorial), "tutorial abre na primeira entrada")
	var t = mapa._tutorial
	ok(t.TOTAL == 7, "tutorial tem 7 etapas")
	await _esperar(20)
	ok(t._video != null and t._video.esta_tocando(), "etapa 1: vídeo do mapa tocando")
	var vids := {}
	for i in 6:
		t._btn_prox.pressed.emit(); await _esperar(25)
		vids[t._video_atual] = true
		ok(t._i == i + 1 and t._video != null and t._video.esta_tocando(), "etapa %d: vídeo tocando (%s)" % [i + 2, t._video_atual.get_file()])
		var n_players := 0
		for nd in t._palco.get_children():
			if nd is VideoFundo: n_players += 1
		ok(n_players == 1, "só um vídeo carregado por vez")
	ok(vids.size() == 5, "5 vídeos diferentes usados (mapa, treino, secretaria, mercado, obras)")
	for i in 6:
		t._btn_ant.pressed.emit(); await _esperar(3)
	ok(t._i == 0 and t._btn_ant.disabled, "botão Anterior volta até a etapa 1")
	for i in 3:
		t._btn_prox.pressed.emit(); await _esperar(3)
	var pular: Button = t.find_child("Tut_Pular", true, false)
	pular.pressed.emit(); await _esperar(3)
	ok(gs.tutorial_concluido, "pular marca como concluído")
	# volta ao mapa: não repete
	sm.ir_para("estadio_obras", true); await _esperar(5)
	sm.voltar(); await _esperar(12)
	mapa = main.get_node("ScreenContainer").get_child(0)
	ok(mapa._tutorial == null or not is_instance_valid(mapa._tutorial), "tutorial não repete após concluído")
	# Esc abre pausa no mapa
	_tecla("ui_cancel"); await _esperar(4)
	ok(is_instance_valid(mapa._pausa), "Esc abre menu de pausa")
	for n in ["Pausa_Continuar", "Pausa_Salvar", "Pausa_Config", "Pausa_Tutorial", "Pausa_Menu"]:
		ok(mapa._pausa.find_child(n, true, false) != null, "botão " + n)
	# salvar zera pendência
	ss.salvar()
	ok(not ss.nao_salvo(), "após salvar não há progresso pendente")
	(mapa._pausa.find_child("Pausa_Continuar", true, false) as Button).pressed.emit(); await _esperar(3)
	ok(not is_instance_valid(mapa._pausa) or mapa._pausa.is_queued_for_deletion(), "Continuar fecha a pausa")
	# voltar ao menu sem pendência: vai direto, carreira preservada
	var clubes: int = gs.clubes.size(); var rod: int = gs.rodada_atual
	mapa.abrir_pausa(); await _esperar(3)
	(mapa._pausa.find_child("Pausa_Menu", true, false) as Button).pressed.emit(); await _esperar(10)
	ok(sm.tela_atual() == "inicio", "voltar ao menu principal sem pendência")
	ok(gs.clubes.size() == clubes and gs.rodada_atual == rod, "carreira preservada na memória")
	ok(ss.existe_save(), "save em disco preservado")
	# progresso não salvo: pede confirmação
	sm.ir_para("hub", false); await _esperar(12)
	mapa = main.get_node("ScreenContainer").get_child(0)
	gs.simular_partida(); gs.avancar_rodada()
	ok(ss.nao_salvo(), "jogar rodada gera progresso não salvo")
	mapa.abrir_pausa(); await _esperar(3)
	(mapa._pausa.find_child("Pausa_Menu", true, false) as Button).pressed.emit(); await _esperar(4)
	ok(sm.tela_atual() != "inicio", "com pendência não sai direto")
	ok(mapa._pausa.find_child("Pausa_SalvarSair", true, false) != null and mapa._pausa.find_child("Pausa_Cancelar", true, false) != null, "confirmação oferece salvar e sair / cancelar")
	(mapa._pausa.find_child("Pausa_Cancelar", true, false) as Button).pressed.emit(); await _esperar(3)
	ok(sm.tela_atual() != "inicio", "cancelar mantém no mapa")
	(mapa._pausa.find_child("Pausa_Menu", true, false) as Button).pressed.emit(); await _esperar(3)
	(mapa._pausa.find_child("Pausa_SalvarSair", true, false) as Button).pressed.emit(); await _esperar(10)
	ok(sm.tela_atual() == "inicio" and not ss.nao_salvo(), "salvar e sair funciona")
	# save antigo (sem campo) não repete tutorial
	var f := FileAccess.open(ss.CAMINHO_SAVE, FileAccess.READ); var d = JSON.parse_string(f.get_as_text()); f.close()
	d.erase("tutorial_concluido")
	var w := FileAccess.open(ss.CAMINHO_SAVE, FileAccess.WRITE); w.store_string(JSON.stringify(d)); w.close()
	gs.tutorial_concluido = false
	ok(ss.carregar() and gs.tutorial_concluido, "save antigo carrega com tutorial concluído")
	# tutorial pelo menu de pausa (não auto) não altera flag
	sm.ir_para("hub", false); await _esperar(12)
	mapa = main.get_node("ScreenContainer").get_child(0)
	mapa.abrir_tutorial(false); await _esperar(3)
	ok(is_instance_valid(mapa._tutorial), "tutorial reabre sob demanda")
	mapa._tutorial._fechar(false); await _esperar(2)
	print("FALHAS: ", falhas)
	get_tree().quit()
