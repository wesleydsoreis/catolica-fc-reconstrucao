extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var p := Partida.new()
	p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	root.add_child(p)
	root.size = Vector2i(390, 844)
	for i in 30: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/retrato.png")
	print("OK")
	quit(0)
