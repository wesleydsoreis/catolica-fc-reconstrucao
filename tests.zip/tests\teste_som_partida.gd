extends Node
## Sons de torcida na partida: sorteio, reações, volume e pausa.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esp(n: int = 3) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	var amb: Node = get_tree().root.get_node("Ambiente")
	amb.interagiu = true
	for n in ["torcida-abertura", "torcida-estadio", "torcida-multidao", "torcida-palmas", "torcida-rugido", "torcida-cantando", "torcida-gol"]:
		var s: AudioStream = load("res://assets/audio/torcida/%s.ogg" % n)
		ok(s != null and s.get_length() > 4.0, "%s carrega (%.1f s)" % [n, s.get_length() if s != null else 0.0])
	for onze in [true, false]:
		Cfg.usar_modo(onze)
		var p := Partida.new()
		add_child(p)
		await _esp(5)
		var som: SomPartida = p.vis.som
		ok(som != null, "%s: SomPartida criado pela visão" % ("11x11" if onze else "FUT7"))
		ok(AudioServer.get_bus_index("Partida") >= 0 and som._vozes[0].bus == "Partida", "sons no barramento Partida")
		som.silencio = true
		p.estado = Partida.Estado.JOGANDO
		p.piloto_auto = true
		# fundo contínuo: abertura primeiro, depois sorteados sem repetir e sem silêncio entre eles
		som.log_sons.clear()
		som._fundo_comecou = false; som._fundo_ativo = false
		var potencia_min := 9.0
		var tempo := 0.0
		var trocas_ok := true
		while tempo < 260.0:
			som._fundo_continuo(0.05)
			tempo += 0.05
			if tempo > 1.0 and som._fundo_ativo:
				var pot: float = pow(sin(float(som._g[0]) * PI * 0.5), 2.0) + pow(sin(float(som._g[1]) * PI * 0.5), 2.0)
				potencia_min = minf(potencia_min, pot)
		ok(som.log_sons.size() > 0 and som.log_sons[0] == "torcida-abertura", "fundo começa com a torcida de abertura")
		var seq: Array = som.log_sons.slice(1)
		var rep := 0
		for i in range(1, seq.size()):
			if seq[i] == seq[i - 1]: rep += 1
		var distintos: Dictionary = {}
		for n in seq: distintos[n] = true
		ok(seq.size() >= 6 and rep == 0 and distintos.size() >= 3 and not seq.has("torcida-abertura"), "depois da abertura: %d sons sorteados sem repetir em sequência (%d tipos)" % [seq.size(), distintos.size()])
		ok(potencia_min > 0.9, "emenda sem silêncio: potência mínima %.2f (crossfade)" % potencia_min)
		# apito final apaga o fundo
		p.estado = Partida.Estado.FIM
		som._fundo_continuo(0.05)
		for i in 80: som._fundo_continuo(0.05)
		ok(float(som._g[0]) <= 0.001 and float(som._g[1]) <= 0.001, "fim de jogo: fundo se apaga com fade")
		p.estado = Partida.Estado.JOGANDO
		som._fundo_ativo = true
		# gol da casa
		som.log_sons.clear()
		p.gols[0] = int(p.gols[0]) + 1
		await _esp(3)
		ok("torcida-rugido" in som.log_sons and "torcida-gol" in som.log_sons, "gol da casa: rugido + torcida do gol")
		som.log_sons.clear()
		p.gols[1] = int(p.gols[1]) + 1
		await _esp(3)
		ok(som.log_sons.has("torcida-gol") and not som.log_sons.has("torcida-rugido"), "gol sofrido: só torcida baixa")
		# chute/defesa/falta sorteiam reações (probabilístico: várias tentativas)
		var reagiu := 0
		for k in 30:
			som._cool_reacao = 0.0
			som.log_sons.clear()
			p.estat["chutes"][0] += 1; p.estat["defesas"][1] += 1; p.faltas[1] += 1
			await _esp(2)
			if som.log_sons.size() > 0: reagiu += 1
		ok(reagiu >= 5 and reagiu <= 30, "reações a chute/defesa/falta sorteadas (%d/30)" % reagiu)
		# intensidade acompanha o perigo
		p.bola.position = Vector2(Cfg.PW * 0.5, Cfg.PH * 0.5)
		for i in 200: som._intensidade(0.1)
		var meio: float = som.intensidade
		p.bola.position = Vector2(Cfg.PW * 0.95, Cfg.PH * 0.5)
		for i in 200: som._intensidade(0.1)
		ok(som.intensidade > meio + 0.2, "intensidade sobe com a bola perto do gol (%.2f → %.2f)" % [meio, som.intensidade])
		# apito final
		som.log_sons.clear()
		p.estado = Partida.Estado.FIM
		await _esp(3)
		ok(som.log_sons.has("torcida-palmas"), "fim de jogo: palmas")
		# jogo real (som ligado) por 20 s sem erros
		som.silencio = false
		p.estado = Partida.Estado.JOGANDO
		await get_tree().create_timer(3.0).timeout
		ok(is_instance_valid(p), "partida com som real roda sem erros")
		p.queue_free()
		await _esp(3)
	# pausa e segundo plano
	Cfg.usar_modo(true)
	var q := Partida.new(); add_child(q); await _esp(5)
	q.estado = Partida.Estado.JOGANDO
	q.vis.som.tocar("torcida-estadio", 0.0, 5.0, 0.0)
	await _esp(3)
	q.pausado = true; await _esp(3)
	ok(q.vis.som._vozes[0].stream_paused, "pausa do jogo pausa a torcida")
	q.pausado = false; await _esp(3)
	ok(not q.vis.som._vozes[0].stream_paused, "despausar retoma")
	q.queue_free()
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
