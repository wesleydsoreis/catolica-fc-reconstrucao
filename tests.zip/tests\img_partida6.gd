extends SceneTree
func _foto(n: String) -> void:
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/%s.png" % n)
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var p := Partida.new()
	p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	p.piloto_auto = true
	root.add_child(p)
	for i in 300: await process_frame
	_foto("f6_jogo1")
	for i in 400: await process_frame
	_foto("f6_jogo2")
	p.pausado = true; p.ajuda_aberta = true
	for i in 3: await process_frame
	_foto("f6_ajuda")
	p.pausado = false; p.ajuda_aberta = false
	p._gol(0)
	for i in 8: await process_frame
	_foto("f6_gol")
	quit(0)
