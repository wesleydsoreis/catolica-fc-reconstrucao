extends Node
## Fase 4: telas internas com vídeo animado + painéis reais do Godot, reaproveitando as telas e regras existentes.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	await _esperar(3)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	gs.novo_jogo()
	gs.tutorial_concluido = true
	var win: Window = get_tree().root
	var tipos := {"treino": "Turno_0", "painel": "BotaoFinancas", "mercado": "LinhaFiltros", "estadio_obras": "", "torneios": "Abas"}
	var videos := {}
	for t in tipos.keys():
		sm.ir_para(t, false)
		await _esperar(40)
		var tv: Node = main.get_node("ScreenContainer").get_child(0)
		ok(tv is TelaVideo, "%s: casca com vídeo" % t)
		var vf: VideoFundo = tv._fundo
		ok(vf.tocando_video and vf.esta_tocando(), "%s: vídeo reproduzindo" % t)
		var p0: float = vf.posicao()
		await _esperar(40)
		ok(vf.posicao() > p0, "%s: vídeo avança" % t)
		var pl: VideoStreamPlayer = vf.get_node("Player")
		ok(pl.loop and pl.volume_db <= -60.0 and vf.mouse_filter == Control.MOUSE_FILTER_IGNORE, "%s: loop, mudo e sem controles" % t)
		videos[vf.caminho] = true
		if tipos[t] != "":
			ok(tv.find_child(tipos[t], true, false) != null, "%s: tela funcional existente hospedada (%s)" % [t, tipos[t]])
		else:
			ok(tv.find_child("PainelTela", true, false) != null and gs.ESTADIO_MELHORIAS.size() > 0, "%s: tela de obras hospedada" % t)
		var vm: Button = tv.find_child("Tela_VoltarMapa", true, false) as Button
		ok(vm != null and vm.visible, "%s: botão Voltar ao mapa" % t)
		ok(tv.find_child("NomeTela", true, false) != null, "%s: título da tela" % t)
		# resoluções: o palco 16:9 sempre cabe na tela e o painel fica dentro do palco
		for tam in [Vector2i(1280, 720), Vector2i(1920, 1080), Vector2i(2560, 1080), Vector2i(1024, 768), Vector2i(800, 600)]:
			win.size = tam
			await _esperar(3)
			var palco: Control = tv.get_node("Palco")
			var r := Rect2(palco.position, Vector2(1280, 720) * palco.scale.x)
			ok(Rect2(Vector2.ZERO, tv.size).grow(2).encloses(r), "%s %dx%d: cabe na tela" % [t, tam.x, tam.y])
		win.size = Vector2i(1280, 720)
		await _esperar(3)
		vm.pressed.emit()
		await _esperar(6)
		ok(sm.tela_atual() == "mapa", "%s: voltar ao mapa" % t)
	ok(videos.size() == 5, "5 vídeos distintos (Classificação usa o do mapa temporariamente)")
	# --- dados reais no mascote e na barra
	sm.ir_para("mercado", false); await _esperar(30)
	var tv: Node = main.get_node("ScreenContainer").get_child(0)
	var bal: Label = tv.find_child("BalaoMascote", true, false).get_child(0) as Label
	ok(bal.text.find(tv._milhar(int(gs.financas["caixa"]))) >= 0, "mascote do mercado cita o caixa real")
	# contratação continua funcionando dentro da casca
	var cx0: float = float(gs.financas["caixa"])
	var n0: int = gs.elenco.size()
	var id: String = ""
	for j in gs.mercado_jogadores:
		if float(j["preco"]) <= cx0:
			id = j["id"]; break
	ok(id != "", "há jogador acessível")
	var msg: String = gs.contratar_jogador(id)
	await _esperar(5)
	ok(msg != "" and gs.elenco.size() == n0 + 1 and float(gs.financas["caixa"]) < cx0, "contratação funciona (caixa desce, elenco sobe)")
	var lb: Label = tv._caixa_lb
	ok(lb.text.find(tv._milhar(int(gs.financas["caixa"]))) >= 0, "barra inferior atualiza o caixa")
	# treino dentro da casca confirma de verdade
	sm.ir_para("treino", false); await _esperar(20)
	var conf: Button = main.get_node("ScreenContainer").get_child(0).find_child("BotaoConfirmar", true, false) as Button
	conf.pressed.emit(); await _esperar(4)
	ok(gs.treino_confirmado, "treino confirmado na tela com vídeo")
	# obras: compra de melhoria
	sm.ir_para("estadio_obras", false); await _esperar(20)
	var btn: Button = null
	for b in main.get_node("ScreenContainer").get_child(0).find_children("*", "Button", true, false):
		if (b as Button).text.begins_with("CONFIRMAR OBRA") and not (b as Button).disabled:
			btn = b; break
	ok(btn != null, "botão de obra disponível")
	var cap0: float = float(gs.financas["capacidade_estadio"])
	btn.pressed.emit(); await _esperar(4)
	ok(float(gs.financas["capacidade_estadio"]) > cap0, "obra aplicada (capacidade aumenta)")
	# esc volta (histórico) e save/load preservam
	sm.ir_para("torneios", true); await _esperar(10)
	ok(sm.voltar() and sm.tela_atual() != "torneios", "histórico de navegação continua funcionando")
	ss.salvar()
	var cx: float = float(gs.financas["caixa"])
	gs.novo_jogo(); ss.carregar()
	ok(float(gs.financas["caixa"]) == cx, "save/load preservados")
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
