extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	var tit: Array = gs.fut7_titulares()
	gs.registrar_lesao(str(tit[3]["id"]), 2)
	gs._processar_disciplina([{"id": tit[2]["id"], "nome": tit[2]["nome"], "time": 0, "tipo": "vermelho_direto"}])
	sm.ir_para("hub", false)
	for i in 20: await process_frame
	await _cap("mapa")
	sm.ir_para("treino", false)
	for i in 20: await process_frame
	await _cap("treino")
	var conf = root.find_child("BotaoConfirmar", true, false)
	if conf: conf.pressed.emit()
	for i in 10: await process_frame
	await _cap("treino_relatorio")
	sm.ir_para("escalacao", false)
	for i in 20: await process_frame
	await _cap("escalacao_lesao")
	quit()
func _cap(nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/f2_%s.png" % nome)
