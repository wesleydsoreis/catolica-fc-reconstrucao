extends SceneTree
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var suf: String = args[0] if args.size() > 0 else "x"
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	sm.ir_para("config_partida", false)
	for i in 20: await process_frame
	await _cap(suf, "config")
	gs.amistoso["formacao_id"] = "3-2-1"; gs.amistoso["dificuldade"] = "dificil"
	gs.amistoso_resultado = {"adversario": gs.clube_por_id("univille"), "gc": 3, "ga": 1, "autores": ["Dinho", "Vh", "Dinho"], "dificuldade": "dificil", "formacao_id": "3-2-1"}
	sm.ir_para("resultado_amistoso", false)
	for i in 20: await process_frame
	await _cap(suf, "resultado_amistoso")
	gs.simular_partida({"proprio": 2, "adversario": 1, "autores": ["Dinho", "Vh"]})
	sm.ir_para("resultado", false)
	for i in 20: await process_frame
	await _cap(suf, "resultado_carreira")
	quit()
func _cap(suf: String, nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/e5_%s_%s.png" % [suf, nome])
