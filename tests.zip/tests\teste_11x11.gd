extends Node
## Carreira em 11x11 e amistoso 11x11 / FUT7 com time escolhido.
var falhas := 0
func chk(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHA  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	await get_tree().process_frame
	GameState.novo_jogo()
	var d: Dictionary = GameState.dados_partida_jogavel()
	chk(d.get("modo11", false), "carreira em 11x11")
	chk((d["escalacao"] as Array).size() == 11, "11 titulares: %d" % (d["escalacao"] as Array).size())
	chk((d["formacao_linhas"] as Array).size() == 11, "formação com 11 linhas")
	chk((d["reservas"] as Array).size() > 0, "banco: %d" % (d["reservas"] as Array).size())
	GameState.amistoso = {"adversario_id": GameState.adversarios_amistoso()[0]["id"], "dificuldade": "normal", "modo": "7", "meu_time_id": GameState.adversarios_amistoso()[1]["id"], "formacao_id": ""}
	var d7: Dictionary = GameState.dados_partida_amistoso()
	chk(not d7.is_empty() and not d7.get("modo11", true), "FUT7 diversão com outro time")
	chk((d7["escalacao"] as Array).size() == 7 and d7.has("time_casa"), "7 jogadores e time_casa")
	GameState.amistoso["modo"] = "11"
	var d11: Dictionary = GameState.dados_partida_amistoso()
	chk((d11["escalacao"] as Array).size() == 11, "amistoso 11x11")
	# partida 11 curta
	for onze in [true, false]:
		Cfg.usar_modo(onze)
		var p := Partida.new()
		var dd: Dictionary = d11 if onze else d7
		p.escalacao_casa = dd["escalacao"]; p.formacao_casa = dd["formacao_linhas"]; p.reservas_casa = dd["reservas"]
		add_child(p)
		for i in 600:
			await get_tree().process_frame
		var n0 := 0
		for j in p.jogadores:
			if j.time == 0: n0 += 1
		chk(n0 == (11 if onze else 7), "partida com %d jogadores por time" % n0)
		p.queue_free()
		await get_tree().process_frame
	Cfg.usar_modo(true)
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit()
