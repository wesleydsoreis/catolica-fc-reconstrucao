extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var p := Partida.new()
	p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	root.add_child(p)
	p.toque.mostrar = true
	for i in 200: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/toque_d.png")
	Opcoes.canhoto = true
	for i in 5: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/toque_c.png")
	Opcoes.canhoto = false
	quit(0)
