extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var f := ColorRect.new(); f.color = Color("12A012"); f.size = Vector2(120, 80); root.add_child(f)
	var p := Player.new(); root.add_child(p)
	p.configurar(Player.kit_do_clube(Color("C94F50"), Color("8F3035")), Color("D98C4E"), Color("241812"))
	p.position = Vector2(60, 60); p.ctrl = true; p.carga = 0.6; p.tocar("idle_f", false)
	for i in 12: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/marca.png")
	quit(0)
