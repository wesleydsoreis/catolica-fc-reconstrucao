extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _novo(onze: bool) -> Partida:
	Cfg.usar_modo(onze)
	var p := Partida.new()
	add_child(p)
	return p
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	await get_tree().process_frame
	for onze in [true, false]:
		var rot := "11x11" if onze else "FUT7"
		var p := _novo(onze)
		var n := 0
		while p.estado != Partida.Estado.JOGANDO and n < 900:
			await get_tree().process_frame
			n += 1
		ok(p.estado == Partida.Estado.JOGANDO, rot + ": partida em andamento")
		p.piloto_auto = false
		p.bp_jogavel = true
		# pênalti manual: segura CHUTE, mira para baixo e solta
		p.estado = Partida.Estado.JOGANDO
		var vit: Jogador = p.times[0][3]
		vit.position = Vector2(Cfg.PW - 150.0, Cfg.PH * 0.5)
		p._penalti(0, vit)
		ok(p.estado == Partida.Estado.BOLA_PARADA and p.bp["tipo"] == "penalti", rot + ": pênalti entra em modo de cobrança")
		ok(absf(p.bola.position.x - Cfg.PW * 0.925) < 2.0, rot + ": bola na marca do pênalti")
		var fora_area := true
		for j in p.jogadores:
			if j != p.bp["cob"] and j.papel != "GOL" and j.position.x > Cfg.PW * 0.845:
				fora_area = false
		ok(fora_area, rot + ": jogadores fora da área")
		Input.action_press("baixo")
		var k := 0
		while float(p.bp["ax"]) < 0.3 and k < 900:
			await get_tree().process_frame
			k += 1
		Input.action_release("baixo")
		ok(float(p.bp["ax"]) > 0.2, rot + ": setas movem a mira (%.2f)" % float(p.bp["ax"]))
		Input.action_press("chute")
		k = 0
		while float(p.bp["carga"]) < 0.4 and k < 900:
			await get_tree().process_frame
			k += 1
		ok(float(p.bp["carga"]) > 0.3, rot + ": segurar carrega força (%.2f)" % float(p.bp["carga"]))
		Input.action_release("chute")
		await _esperar(3)
		ok(p.estado == Partida.Estado.JOGANDO and p.bola.vel.length() > 300.0, rot + ": cobrança sai e o jogo segue")
		# escanteio
		p.estado = Partida.Estado.JOGANDO
		p._iniciar_bp("escanteio", Vector2(Cfg.PW - 10.0, 10.0))
		ok(p.estado == Partida.Estado.BOLA_PARADA, rot + ": escanteio entra em modo de cobrança")
		Input.action_press("chute")
		await _esperar(2)
		Input.action_release("chute")
		await _esperar(3)
		ok(p.estado == Partida.Estado.JOGANDO and p.bola.vz > 200.0, rot + ": cruzamento levanta a bola")
		await _esperar(80)
		ok(p.bola.position.x > Cfg.PW * 0.7, rot + ": cruzamento cai na área (x=%d)" % int(p.bola.position.x))
		# falta perigosa com piloto automático: executa sozinho
		p.piloto_auto = true
		p.estado = Partida.Estado.JOGANDO
		p._iniciar_bp("falta", Vector2(Cfg.PW * 0.72, Cfg.PH * 0.4))
		k = 0
		while p.estado == Partida.Estado.BOLA_PARADA and k < 900:
			await get_tree().process_frame
			k += 1
		ok(p.estado != Partida.Estado.BOLA_PARADA, rot + ": piloto automático bate a falta sozinho")
		p.queue_free()
		await get_tree().process_frame
	Cfg.usar_modo(true)
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit()
