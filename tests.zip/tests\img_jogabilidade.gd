extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	Cfg.usar_modo(true)
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	root.content_scale_size = Vector2i(480, 270)
	root.size = Vector2i(1440, 810)
	await process_frame
	var p: Partida = Partida.new()
	p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"; p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	root.add_child(p)
	for i in 300: await physics_frame
	p.estado = Partida.Estado.JOGANDO
	p.piloto_auto = false
	# cenário de defesa: rival com a bola, jogador controlado marcando
	var me: Jogador = null
	var rv: Jogador = null
	for q in p.times[0]:
		if (q as Jogador).papel == "MEI": me = q; break
	for q in p.times[1]:
		if (q as Jogador).papel == "MEI": rv = q; break
	var c: Vector2 = Vector2(Cfg.PW * 0.5, Cfg.PH * 0.55)
	rv.position = c; rv.face = Vector2.RIGHT
	me.position = c + Vector2(-70, 0)
	if p.controlado != null: p.controlado.controlado = false
	p.controlado = me; me.controlado = true
	p.bola.dono = rv; p.bola.position = rv.position
	p.vis.arbitro.pos = c + Vector2(-230, -150)
	for i in 20: await physics_frame
	await _cap("defesa")
	p._falta(me, rv)
	p.vis.flutuar(me.position, "DESARME!", Color("7BD36B"))
	for i in 50: await physics_frame
	await _cap("falta")
	p.vis.banner("CARTÃO AMARELO", "teste", 2.0)
	for i in 30: await physics_frame
	await _cap("cartao")
	quit(0)
func _cap(n: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/jog_%s.png" % n)
