extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState"); var sm: Node = root.get_node("SceneManager")
	gs.iniciar_sala("2A-2026", "Ana Souza")
	for k in 3:
		gs.simular_partida(); gs.avancar_rodada()
	gs.tutorial_concluido = false
	sm.ir_para("hub", false)
	for i in 30: await process_frame
	var mapa: Node = main.get_node("ScreenContainer").get_child(0)
	var t = mapa._tutorial
	for n in 7:
		await create_timer(1.6).timeout
		await RenderingServer.frame_post_draw
		root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/tut_v%d.png" % (n + 1))
		t._btn_prox.pressed.emit()
	quit()
