extends Node
## Etapa 7: navegação por todas as telas, vazamento de nós, tempo de processamento da partida,
## tamanhos de janela e fluxo completo de rodada.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	var win: Window = get_tree().root
	# --- 1. todas as telas, em vários tamanhos de janela
	gs.novo_jogo(); gs.fut7_garantir()
	var telas: Array = ["inicio", "hub", "mapa", "treino", "diretor", "prancheta", "financas", "imprensa", "competencias", "professor", "base", "conquistas", "painel", "elenco", "escalacao", "mercado", "torneios", "estadio_obras", "desafio", "preparacao", "tatica", "config_partida"]
	for tam in [Vector2i(360, 640), Vector2i(390, 844), Vector2i(768, 1024), Vector2i(1280, 720), Vector2i(1920, 1080)]:
		win.size = tam
		await _esperar(3)
		var bons := 0
		for t in telas:
			sm.ir_para(t, false)
			await _esperar(3)
			var tela: Node = main.get_node("ScreenContainer").get_child(0)
			if tela != null and tela.is_inside_tree():
				bons += 1
		ok(bons == telas.size(), "%dx%d: %d/%d telas abrem" % [tam.x, tam.y, bons, telas.size()])
	# --- 2. vazamento de nós ao navegar 150 vezes
	sm.ir_para("hub", false)   # mede sempre na mesma tela (o Mapa tem mais nós que as outras)
	await _esperar(10)
	var antes: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	var orf0: int = int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT))
	for i in 150:
		sm.ir_para(telas[i % telas.size()], false)
		await _esperar(1)
	sm.ir_para("hub", false)
	await _esperar(10)
	var depois: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	var orf1: int = int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT))
	ok(depois - antes < 60, "sem vazamento de nós após 150 trocas de tela (%d -> %d)" % [antes, depois])
	ok(orf1 - orf0 < 20, "sem órfãos acumulando (%d -> %d)" % [orf0, orf1])
	# --- 3. fluxo completo da rodada: desafio > preparação > tática > partida > resultado > hub
	var rodada: int = gs.rodada_atual
	sm.ir_para("desafio", false); await _esperar(3)
	sm.ir_para("partida", false); await _esperar(6)
	var pj: Node = main.get_node("ScreenContainer").get_child(0)
	var p = pj._partida
	# --- 4. custo de processamento por frame durante a partida
	var n := 0
	var t0: int = Time.get_ticks_usec()
	var pico := 0.0
	var ult: int = t0
	while p.estado != 5 and n < 22000:
		await get_tree().process_frame
		var agora: int = Time.get_ticks_usec()
		if n > 60:
			pico = maxf(pico, float(agora - ult) / 1000.0)
		ult = agora
		n += 1
	var med: float = float(Time.get_ticks_usec() - t0) / 1000.0 / maxf(1.0, n)
	print("  processamento (CPU, sem render): média %.2f ms  pico %.2f ms (%d frames)" % [med, pico, n])
	ok(med < 4.0, "média por frame < 4 ms de CPU de lógica+UI (%.2f)" % med)
	ok(p.estado == 5, "partida chegou ao fim")
	var nodes_jogo: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	p.continuar_pedido.emit()
	await _esperar(6)
	ok(main.get_node("ScreenContainer").get_child(0).name == "Resultado", "resultado oficial aparece")
	ok(gs.resultado_rodada != null and gs.rodada_atual == rodada, "rodada ainda não avançou antes de confirmar")
	main.get_node("ScreenContainer").get_child(0)._on_botao_proxima_rodada_pressed()
	await _esperar(5)
	ok(gs.rodada_atual == rodada + 1, "próxima rodada avança uma vez só")
	var nodes_pos: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	ok(nodes_pos < nodes_jogo, "nós da partida liberados ao sair (%d -> %d)" % [nodes_jogo, nodes_pos])
	# --- 5. save: gravar, recarregar, comparar
	ss.salvar()
	var cx: float = float(gs.financas["caixa"])
	var fm: String = str(gs.escalacao_fut7.get("formacao", ""))
	gs.novo_jogo()
	ss.carregar()
	ok(float(gs.financas["caixa"]) == cx and str(gs.escalacao_fut7.get("formacao", "")) == fm and gs.rodada_atual == rodada + 1, "save/load preserva caixa, rodada e formação FUT7")
	# --- 6. temporada inteira simulada (28 rodadas) sem travar
	var guarda := 0
	while gs.temporada_status == "em_andamento" and guarda < 60:
		gs.simular_partida(); gs.avancar_rodada(); guarda += 1
	ok(gs.temporada_status != "em_andamento", "temporada completa simulada em %d rodadas" % guarda)
	sm.ir_para("fim_temporada", false); await _esperar(4)
	ok(main.get_node("ScreenContainer").get_child(0).name == "FimTemporada", "fim de temporada abre")
	gs.nova_temporada()
	ok(gs.temporada == 2 and gs.rodada_atual == 1, "nova temporada começa na rodada 1")
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
