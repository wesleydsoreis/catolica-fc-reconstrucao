extends SceneTree
func _foto(n: String) -> void:
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/%s.png" % n)
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var p := Partida.new()
	p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	root.add_child(p)
	p.toque.mostrar = true
	for i in 200: await process_frame
	p.controlado.carga = 0.6
	p._mostrar("CARTÃO AMARELO", "JOSI (CFC)", 3.0)
	for i in 5: await process_frame
	_foto("f6_humano")
	var sp: Vector2 = Pitch.project(p.controlado.position.x, p.controlado.position.y)
	print("CTRL ", sp)
	quit(0)
