extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var p := Partida.new()
	p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	root.add_child(p)
	p.toque.mostrar = true
	for i in 400: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/limpo.png")
	p.pausado = true
	for i in 10: await process_frame
	p.menu.sel = 6; p.menu._confirmar()
	for i in 5: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/limpo_pausa.png")
	# reinício: após gol só deve haver 1 controlado
	p.pausado = false
	p._gol(1)
	for i in 400: await process_frame
	var n: int = 0
	for q in p.jogadores:
		if q.controlado: n += 1
	print("CONTROLADOS_APOS_REINICIO ", n)
	quit(0)
