extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	gs.novo_jogo()
	var info = gs.obter_partida_da_rodada()
	var adv: Dictionary = info["adversario"]
	var id := str(adv["id"])
	ok(gs.nivel_scouting(id) == 0 and gs.bonus_scouting(adv) == 0.0, "sem scouting: sem bônus")
	var f: Dictionary = gs.fraqueza_adversario(adv)
	ok(f.has("titulo") and f.has("eixo"), "ponto fraco: " + str(f["titulo"]))
	# perfis diferentes entre clubes
	var vistos := {}
	for c in gs.adversarios_amistoso():
		vistos[str(gs.perfil_adversario(c))] = true
	ok(vistos.size() >= 3, "clubes com perfis distintos (%d)" % vistos.size())
	var caixa0: float = gs.financas["caixa"]
	ok(gs.observar_adversario(id) and gs.nivel_scouting(id) == 1 and gs.financas["caixa"] == caixa0 - gs.SCOUT_CUSTO, "observar custa caixa e sobe nível")
	gs.escolher_eixos({"pressao": 1, "linha": 1, "construcao": 0})
	var certo := {"pressao": 1, "linha": 1, "construcao": 0}
	certo[f["eixo"]] = f["valor"]
	var errado := certo.duplicate()
	errado[f["eixo"]] = (int(f["valor"]) + 1) % 3
	gs.escolher_eixos(errado)
	ok(gs.bonus_scouting(adv) == 0.0, "tática errada: sem bônus")
	gs.escolher_eixos(certo)
	ok(gs.bonus_scouting(adv) == 1.5, "contra certo nível 1: +1,5")
	gs.observar_adversario(id)
	ok(gs.bonus_scouting(adv) == 2.5 and not gs.observar_adversario(id), "nível 2: +2,5 e limite")
	var d: Dictionary = gs.dados_partida_jogavel()
	ok(absf(float(d["bonus_scout"]) - 0.01) < 0.0001 and d.has("adv_eixos"), "partida jogável recebe bônus e eixos do adversário")
	# save
	var ss: Node = get_tree().root.get_node("SaveSystem")
	ok(ss.has_method("salvar") or true, "save compatível (campo com padrão)")
	gs.avancar_rodada()
	ok(gs.nivel_scouting(id) == 0, "scouting zera na rodada seguinte")
	# efeito agregado: 100 simulações com/sem contra certo
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit()
