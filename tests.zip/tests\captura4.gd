extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var p: Partida = Partida.new()
	p.piloto_auto = true
	root.add_child(p)
	for i in 30: await process_frame
	p.bola.position = Vector2(2100, 650)
	p._gol(0)
	for i in 50: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/g1.png")
	for i in 400: await process_frame
	print("ok ", p.gols, p.torcida.confete.size())
	quit(0)
