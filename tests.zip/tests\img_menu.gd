extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var t: Node = main.get_node("ScreenContainer").get_child(0)
	var suf: String = OS.get_environment("SUF")
	var marcos := [0.6, 2.4, 4.6, 6.6]
	var t0 := Time.get_ticks_msec()
	for i in marcos.size():
		while (Time.get_ticks_msec() - t0) / 1000.0 < marcos[i]:
			await process_frame
		await RenderingServer.frame_post_draw
		root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/menuv_%s%d.png" % [suf, i])
	var vf: VideoFundo = t.find_child("VideoFundo", true, false)
	print("pos=", vf.posicao(), " tocando=", vf.esta_tocando())
	quit()
