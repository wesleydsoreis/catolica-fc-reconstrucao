extends SceneTree
## Mede o efeito real de cada configuração tática: N partidas completas (piloto automático) contra um adversário equilibrado.
## uso: godot --headless --path . --fixed-fps 60 --script tests/medir_taticas.gd -- <nome> <pressao> <linha> <construcao> <partidas>
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var a := OS.get_cmdline_user_args()
	var nome: String = a[0]
	var eix := {"pressao": int(a[1]), "linha": int(a[2]), "construcao": int(a[3])}
	var n: int = int(a[4])
	var acc := {"gp": 0.0, "gc": 0.0, "chp": 0.0, "chc": 0.0, "rou": 0.0, "roc": 0.0, "posse": 0.0, "dist": 0.0, "falt": 0.0, "cans": 0.0, "pas": 0.0}
	for m in n:
		var p := Partida.new()
		p.nome_casa = "CFC"; p.sigla_casa = "CFC"; p.nome_fora = "ADV"; p.sigla_fora = "ADV"
		p.eixos[0] = eix
		p.eixos_definidos = true
		root.add_child(p)
		p.piloto_auto = true
		var frames := 0
		while p.estado != Partida.Estado.FIM and frames < 40000:
			await process_frame
			frames += 1
		acc["gp"] += p.gols[0]; acc["gc"] += p.gols[1]
		acc["chp"] += p.estat["chutes"][0]; acc["chc"] += p.estat["chutes"][1]
		acc["rou"] += p.estat["roubos"][0]; acc["roc"] += p.estat["roubos"][1]
		var pt: float = p.estat["posse_t"][0] + p.estat["posse_t"][1]
		acc["posse"] += 100.0 * p.estat["posse_t"][0] / maxf(1.0, pt)
		acc["pas"] += p.estat["passes"][0]
		acc["dist"] += p.estat["dist_passes"][0] / maxf(1.0, p.estat["passes"][0])
		acc["falt"] += p.faltas[0]
		acc["cans"] += p.cansaco[0]
		p.queue_free()
		await process_frame
	var o := "TAT %-14s n=%d" % [nome, n]
	for k in ["gp", "gc", "chp", "chc", "rou", "roc", "posse", "pas", "dist", "falt", "cans"]:
		o += "  %s=%.2f" % [k, acc[k] / n]
	print(o)
	quit(0)
