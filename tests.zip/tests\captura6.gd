extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	root.content_scale_size = Vector2i(1280, 720)
	root.size = Vector2i(1280, 720)
	await process_frame
	var gs = root.get_node("GameState")
	gs.novo_jogo(); gs.escolher_tatica("ofensivo")
	var d: Dictionary = gs.dados_partida_jogavel()
	var p: Partida = Partida.new()
	p.escalacao_casa = d["escalacao"]; p.reservas_casa = d["reservas"]
	p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"; p.cor_fora_1 = Color("3B6E9E"); p.cor_fora_2 = Color("FFFDF8")
	p.piloto_auto = true
	root.add_child(p)
	for i in 400:
		await physics_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/s_jogo.png")
	var f := 0
	while p.estado != Partida.Estado.GOL and f < 6000:
		await physics_frame
		f += 1
	for i in 40: await physics_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/s_gol.png")
	quit(0)
