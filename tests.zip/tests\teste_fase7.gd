extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	gs.iniciar_sala("F7", "Teste")
	# clima determinístico e variado
	var cont := {"sol": 0, "chuva": 0, "calor": 0}
	for r in 200:
		cont[Extras.clima(gs.sala_seed, 1, r + 1)] += 1
	ok(Extras.clima(gs.sala_seed, 1, 3) == Extras.clima(gs.sala_seed, 1, 3), "clima é determinístico")
	ok(cont["sol"] > 80 and cont["chuva"] > 15 and cont["calor"] > 5, "clima variado: %s" % str(cont))
	# rival
	ok(gs.rival_id != "" and gs.rival_id != "catolica" and gs.clube_por_id(gs.rival_id).size() > 0, "rival sorteado: " + gs.nome_rival())
	# base e promoção
	ok(gs.base_jovens.size() == 3, "3 jovens na base")
	var n0: int = gs.elenco.size()
	ok(gs.promover_jovem(0) == "" and gs.elenco.size() == n0 + 1 and gs.elenco[-1]["da_peneira"], "promover jovem entra no elenco")
	ok(gs.promover_jovem(0) != "", "não promove duas vezes")
	ok(gs.conquistas.has("base"), "conquista Prata da casa")
	# empréstimo
	var res = null
	for j in gs.elenco:
		if gs.pode_emprestar(j):
			res = j
			break
	ok(res != null, "há reserva emprestável")
	var ov0: int = int(res["overall"])
	ok(gs.emprestar_jogador(str(res["id"])) == "" and gs.indisponivel(str(res["id"])), "emprestado fica indisponível")
	var folha0 := 0
	for j in gs.elenco:
		folha0 += 1 if int(j.get("emprestado", 0)) > 0 else 0
	for i in Extras.RODADAS_EMPRESTIMO:
		gs.avancar_rodada()
	ok(int(res.get("emprestado", 0)) == 0 and int(res["overall"]) >= ov0 and not gs.indisponivel(str(res["id"])), "empréstimo termina e jogador volta (%d -> %d)" % [ov0, res["overall"]])
	var tit: Dictionary = {}
	for s in gs.slots:
		if s["jogador_id"] != null:
			tit = gs._jogador_por_id(s["jogador_id"])
			break
	ok(gs.emprestar_jogador(str(tit["id"])) != "", "titular não pode ser emprestado")
	# metas pessoais
	ok(gs.metas_pessoais.size() > 0, "metas pessoais criadas")
	var m: Dictionary = gs.metas_pessoais[0]
	var cx0: float = float(gs.financas["caixa"])
	gs.gols_registrados[m["nome"]] = int(gs.gols_registrados.get(m["nome"], 0)) + int(m["alvo"])
	gs._checar_conquistas()
	ok(bool(m["cumprida"]) and float(gs.financas["caixa"]) > cx0 and gs.conquistas.has("meta_pessoal"), "meta pessoal cumprida dá prêmio e conquista")
	# conquista nova aparece uma vez
	ok(gs.pegar_conquistas_novas().size() > 0 and gs.pegar_conquistas_novas().is_empty(), "toasts de conquista entregues uma vez")
	# público: clássico e chuva
	var adv: Dictionary = gs.clube_por_id(gs.rival_id)
	ok(gs.eh_classico(adv) and not gs.eh_classico(gs.clube_por_id("catolica")), "detecta clássico")
	# salvar/carregar
	gs.h2h[gs.rival_id] = {"v": 2, "e": 1, "d": 0}
	ok(get_tree().root.get_node("SaveSystem").salvar(), "salvou")
	var rv: String = gs.rival_id
	gs.rival_id = ""
	gs.h2h = {}
	gs.base_jovens = []
	gs.conquistas = {}
	ok(get_tree().root.get_node("SaveSystem").carregar() and gs.rival_id == rv and gs.h2h[rv]["v"] == 2 and gs.base_jovens.size() == 3 and gs.conquistas.has("base"), "save preserva rival, H2H, base e conquistas")
	# temporadas completas simuladas (invariantes + estatística)
	var tot_gols := 0
	var tot_jogos := 0
	var vit := 0
	var caixas: Array = []
	var chuvas := 0
	var classicos := 0
	for semente in 4:
		gs.iniciar_sala("SIM%d" % semente, "Bot")
		for t in 2:
			var guard := 0
			while gs.temporada_status == "em_andamento" and guard < 80:
				guard += 1
				var info = gs.obter_partida_da_rodada()
				if info == null:
					break
				if not gs.desafio_atual().is_empty():
					gs.responder_desafio(int(gs.desafio_atual()["correta"]))
				chuvas += 1 if gs.clima_atual() == "chuva" else 0
				classicos += 1 if gs.eh_classico(info["adversario"]) else 0
				gs.simular_partida()
				var rr: Dictionary = gs.resultado_rodada
				tot_gols += int(rr["placar_catolica"]) + int(rr["placar_adversario"])
				tot_jogos += 1
				vit += 1 if rr["tipo_resultado"] == "vitoria" else 0
				if gs.metas_pessoais.size() > 0 and guard % 5 == 0:
					gs.promover_jovem(0)
				if guard % 7 == 0:
					for j in gs.elenco:
						if gs.pode_emprestar(j):
							gs.emprestar_jogador(str(j["id"]))
							break
				gs.avancar_rodada()
			ok(guard < 80, "temporada %d da sala SIM%d terminou (%d rodadas)" % [t + 1, semente, guard])
			ok(gs.elenco.size() >= 14 and gs.elenco.size() <= Extras.LIMITE_ELENCO, "elenco dentro dos limites (%d)" % gs.elenco.size())
			for c in gs.conquistas:
				if not Extras.CONQUISTAS.any(func(q): return q["id"] == c):
					ok(false, "conquista desconhecida " + c)
			caixas.append(float(gs.financas["caixa"]))
			if gs.temporada_status == "encerrada":
				gs.nova_temporada()
	ok(tot_jogos > 100, "jogos simulados: %d" % tot_jogos)
	print("  balanceamento: %.2f gols/jogo, %.0f%% vitórias, chuva %d, clássicos %d, caixas %s" % [float(tot_gols) / maxf(1.0, tot_jogos), 100.0 * vit / maxf(1.0, tot_jogos), chuvas, classicos, str(caixas.map(func(x): return int(x)))])
	ok(float(tot_gols) / maxf(1.0, tot_jogos) > 1.0 and float(tot_gols) / maxf(1.0, tot_jogos) < 5.0, "média de gols plausível")
	ok(classicos > 0, "clássicos acontecem na temporada")
	# telas
	gs.novo_jogo()
	for tela in ["base", "conquistas", "hub"]:
		var cena: Node = load(sm.CENAS[tela]).instantiate()
		add_child(cena)
		await get_tree().process_frame
		await get_tree().process_frame
		ok(cena.get_child_count() > 0, "tela %s abre" % tela)
		if tela == "base":
			ok(cena.find_child("BotaoPromover_0", true, false) != null, "base: botão promover")
			(cena.find_child("BotaoPromover_0", true, false) as Button).pressed.emit()
			await get_tree().process_frame
			await get_tree().process_frame
		if tela == "conquistas":
			ok(cena.find_child("CartaoRival", true, false) != null and cena.find_child("Conquista_base", true, false) != null, "conquistas: rival e lista")
		cena.queue_free()
		await get_tree().process_frame
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
