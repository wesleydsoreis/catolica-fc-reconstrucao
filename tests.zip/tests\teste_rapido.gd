extends SceneTree
# Teste de fumaça para rodar na SUA versão do Godot (ex.: 4.7.2):
#   godot --headless --path . --import
#   godot --path . --script tests/teste_rapido.gd        (sem --headless para validar o shader também)
# Imprime "RAPIDO OK" se a partida montar, rodar 900 quadros e usar as animações novas sem erro.
func _initialize() -> void:
	Cfg.usar_modo(false)
	_rodar()
func _rodar() -> void:
	await process_frame
	var erros: int = 0
	var p := Partida.new()
	p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
	root.add_child(p)
	p.piloto_auto = true
	for i in 900:
		await process_frame
	var vis: PartidaVis = null
	for c in p.get_children():
		if c is PartidaVis:
			vis = c
	if vis == null or vis._players.size() < 14:
		erros += 1; print("FALHA: jogadores visuais ausentes")
	else:
		var tex: Texture2D = Player._folhas[0]
		if tex == null or tex.get_width() < 144:
			erros += 1; print("FALHA: folha de sprites não carregou")
		print("jogadores visuais: ", vis._players.size(), "  gols: ", p.gols)
	print("RAPIDO OK" if erros == 0 else "RAPIDO COM FALHAS: %d" % erros)
	quit(erros)
