extends Node
## Menu principal novo: Jogar · Continuar carreira · Nova carreira · Configurações · Sair, integrado ao fluxo real.
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esp(n: int = 3) -> void:
	for i in n: await get_tree().process_frame
func _ids(t: Node) -> Array:
	var l: Array = []
	for o in t._opcoes: l.append(o["id"])
	return l
func _btn(t: Node, id: String) -> Button:
	return t.find_child("Menu_" + id, true, false) as Button
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await _esp(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	ss.apagar_progresso(); gs.clubes = []
	var t: Node = main.get_node("ScreenContainer").get_child(0)
	t._montar()
	var vf: VideoFundo = t.find_child("VideoFundo", true, false)
	ok(vf != null, "menu usa o componente VideoFundo")
	ok(ResourceLoader.exists("res://assets/video/menu_animado.ogv") and load("res://assets/video/menu_animado.ogv") is VideoStreamTheora, "vídeo do menu é Ogg Theora carregável")
	await _esp(30)
	var pl: VideoStreamPlayer = vf.get_node("Player")
	ok(vf.tocando_video and pl.is_playing(), "vídeo do menu está sendo reproduzido")
	var p0: float = vf.posicao()
	await _esp(60)
	ok(vf.posicao() > p0, "vídeo avança (animação real, não imagem estática)")
	ok(pl.loop and pl.volume_db <= -60.0 and pl.stream != null and not vf.get_node("Reserva").visible, "loop ligado, áudio mudo e quadro de reserva oculto")
	ok(vf.mouse_filter == Control.MOUSE_FILTER_IGNORE and not pl.has_node("Controles"), "sem controles de vídeo e sem capturar cliques")
	var ar: Rect2 = vf.area_do_video()
	ok(absf(ar.size.x / ar.size.y - 16.0 / 9.0) < 0.01, "proporção 16:9 preservada (%.3f)" % (ar.size.x / ar.size.y))
	var tela := Rect2(Vector2.ZERO, vf.size)
	ok(ar.encloses(tela.grow(-1)), "vídeo cobre a tela inteira")
	var ids: Array = _ids(t)
	for id in ["jogar", "continuar", "novo", "config"]:
		ok(ids.has(id), "opção '%s' presente" % id)
	ok(ids.has("sair") or OS.has_feature("web") or OS.has_feature("mobile"), "opção sair (desktop)")
	ok(_btn(t, "continuar").disabled, "sem carreira: Continuar carreira fica desabilitado")
	# recursos antigos preservados dentro de Configurações
	t._sel = ids.find("config"); t._ativar()
	ok(t._modo == "config", "abre Configurações")
	var ids_c: Array = _ids(t)
	for id in ["mao", "inv", "tela", "jogar_rapido", "professor", "creditos", "voltar"]:
		ok(ids_c.has(id), "configurações contém '%s'" % id)
	# sem carreira: partida rápida avisa em vez de quebrar
	t._sel = ids_c.find("jogar_rapido"); t._ativar()
	await _esp()
	ok(t.get_node_or_null("Dialogo") != null and sm._tela_atual == "inicio", "sem carreira: aviso e continua no menu")
	t.get_node("Dialogo")._fechar()
	await _esp()
	t._modo = "menu"; t._sel = 0; t._montar()
	# JOGAR sem carreira: abre carreira nova no mapa, com tutorial pendente
	ids = _ids(t)
	t._sel = ids.find("jogar"); t._ativar()
	await _esp(6)
	ok(sm._tela_atual == "hub" and gs.clubes.size() > 0, "Jogar sem carreira abre nova carreira no mapa")
	ok(not gs.tutorial_concluido, "carreira nova chega ao mapa com tutorial pendente")
	ok(ss.salvar(), "salvou")
	# volta ao menu: Continuar fica habilitado e leva ao mapa sem tutorial repetido
	gs.tutorial_concluido = true
	sm.ir_para("inicio", false)
	await _esp(4)
	t = main.get_node("ScreenContainer").get_child(0)
	ok(not _btn(t, "continuar").disabled, "com carreira: Continuar carreira habilitado")
	for par in [["continuar", "hub"], ["jogar", "hub"]]:
		t._modo = "menu"; t._montar()
		t._sel = _ids(t).find(par[0]); t._ativar()
		await _esp(5)
		ok(sm._tela_atual == par[1], "%s leva ao mapa" % par[0])
		sm.ir_para("inicio", false)
		await _esp(4)
		t = main.get_node("ScreenContainer").get_child(0)
	# continuar com save e memória vazia: carrega o arquivo
	gs.clubes = []; gs.carreira_ativa = false
	t._modo = "menu"; t._montar()
	ok(not _btn(t, "continuar").disabled, "memória vazia mas com save: Continuar habilitado")
	t._sel = _ids(t).find("continuar"); t._ativar()
	await _esp(5)
	ok(sm._tela_atual == "hub" and gs.clubes.size() > 0, "continuar carrega o save")
	# nova carreira com carreira existente pede confirmação (não apaga nada ainda)
	sm.ir_para("inicio", false)
	await _esp(4)
	t = main.get_node("ScreenContainer").get_child(0)
	var caixa0: int = int(gs.financas["caixa"]); var cl0: int = gs.clubes.size()
	t._sel = _ids(t).find("novo"); t._ativar()
	await _esp()
	ok(t.get_node_or_null("Dialogo") != null and sm._tela_atual == "inicio", "Nova carreira com carreira existente pede confirmação")
	ok(ss.existe_save() and gs.clubes.size() == cl0 and int(gs.financas["caixa"]) == caixa0, "carreira atual intacta enquanto confirma")
	t.get_node("Dialogo")._fechar()
	await _esp()
	# créditos e configurações
	t._creditos()
	await _esp(1)
	ok(t.get_node_or_null("Dialogo") != null, "créditos abrem")
	var pgs: Array = t.get_node("Dialogo")._dados["paginas"]
	var txt: String = " ".join(pgs)
	ok("Erik Pinheiro" in txt and "Wesley Reis" in txt and "Daniel Trindade" in txt, "créditos têm os 3 nomes exatos")
	ok(not ("Desenvolvimento" in txt or "Programador" in txt or "Designer" in txt), "créditos sem cargos inventados")
	t.get_node("Dialogo")._fechar()
	t._modo = "config"; t._montar()
	var antes: bool = Opcoes.invertido
	t._sel = _ids(t).find("inv"); t._ativar()
	ok(Opcoes.invertido != antes, "configuração de passe/chute alterna")
	t._ativar()
	# Esc volta do submenu
	await _esp(2)
	var e := InputEventAction.new(); e.action = "ui_cancel"; e.pressed = true
	t._input(e)
	ok(t._modo == "menu", "Esc volta ao menu principal")
	ss.apagar_progresso()
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
