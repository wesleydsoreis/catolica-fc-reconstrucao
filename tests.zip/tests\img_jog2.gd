extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var fundo := ColorRect.new(); fundo.color = Color("12A012"); fundo.size = Vector2(480, 270); root.add_child(fundo)
	var nomes := ["idle_f","idle_b","idle_s","run_f","run_b","run_s","chute_s","chute_f","carrinho","queda","festa","gk_baixo","gk_alto"]
	var k := Player.kit_do_clube(Color("3B6E9E"), Color("FFFDF8"))
	for i in nomes.size():
		var p := Player.new(); root.add_child(p)
		var gk: bool = nomes[i].begins_with("gk")
		p.configurar(Player.kit_do_clube(Color.BLACK, Color.BLACK, true) if gk else k, Color("F6C9A2"), Color("241812"))
		p.position = Vector2(30 + (i % 7) * 64, 60 + (i / 7) * 80)
		p.tocar(nomes[i], false)
		var l := Label.new(); l.text = nomes[i]; l.add_theme_font_size_override("font_size", 8); l.position = p.position + Vector2(-20, 6); root.add_child(l)
	for i in 30: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/e4_anims.png")
	quit(0)
