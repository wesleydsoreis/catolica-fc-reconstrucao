extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	gs.novo_jogo()
	var ctx: Dictionary = Educacao.contexto(gs)
	# 1) geradores: 5 áreas × 3 níveis × 60 sementes
	var invalidos := 0
	var diferentes := {}
	for a in Educacao.AREAS:
		for n in Educacao.NIVEIS:
			for sd in 60:
				var p: Dictionary = Educacao.gerar(a, n, ctx, sd * 31 + 5)
				var ops: Array = p["opcoes"]
				var uniq := {}
				for o in ops: uniq[o] = true
				if ops.size() != 4 or uniq.size() != 4 or int(p["correta"]) < 0 or int(p["correta"]) > 3 or (p["passos"] as Array).is_empty() or str(p["enunciado"]) == "":
					invalidos += 1
				diferentes[str(p["enunciado"])] = true
	ok(invalidos == 0, "900 problemas válidos (4 alternativas distintas, passos, correta no intervalo): inválidos=%d" % invalidos)
	ok(diferentes.size() > 150, "números diferentes a cada vez (%d enunciados distintos)" % diferentes.size())
	# 2) conferência independente das contas
	var p1: Dictionary = Educacao.gerar("estatistica", "fund2", ctx, 3)
	var soma := 0.0
	for d in p1["dados"]: soma += float(d["valor"])
	ok(p1["opcoes"][p1["correta"]] == Educacao.num(soma / 5.0, 1), "média confere (%s)" % p1["opcoes"][p1["correta"]])
	var p2: Dictionary = Educacao.gerar("estatistica", "superior", ctx, 3)
	var vv: Array = p2["dados"].map(func(d): return int(d["valor"]))
	ok(p2["opcoes"][p2["correta"]] == Educacao.num(Educacao.desvio(vv), 1), "desvio padrão confere")
	var p3: Dictionary = Educacao.gerar("estatistica", "medio", ctx, 3)
	var v3: Array = p3["dados"].map(func(d): return int(d["valor"]))
	v3.sort()
	ok(p3["opcoes"][p3["correta"]] == Educacao.num(float(v3[3]), 1), "mediana confere")
	ok(Educacao.mediana([1, 2, 3, 4]) == 2.5 and Educacao.moda([1, 2, 2, 3]) == [2] and Educacao.moda([1, 2, 3]).is_empty() and absf(Educacao.desvio([2, 4, 4, 4, 5, 5, 7, 9]) - 2.0) < 0.001, "funções estatísticas (mediana/moda/desvio)")
	var pj: Dictionary = Educacao.gerar("porcentagem", "superior", ctx, 9)
	ok(str(pj["passos"][-1]).contains("1,0"), "juros compostos exibe o fator")
	ok(Calculadora.avaliar("2+3×4") == 14.0 and Calculadora.avaliar("(10−4)÷4") == 1.5 and Calculadora.avaliar("1,5×2") == 3.0 and is_nan(Calculadora.avaliar("2+*")), "calculadora avalia expressões")
	# 3) mesma rodada = mesmo problema; rodada seguinte muda
	var a1: Dictionary = gs.desafio_atual()
	var a2: Dictionary = gs.desafio_atual()
	ok(a1["enunciado"] == a2["enunciado"], "problema estável dentro da rodada")
	ok(Educacao.semente(1, 1, "estatistica", "medio", 0) != Educacao.semente(2, 1, "estatistica", "medio", 0) and Educacao.semente(1, 1, "estatistica", "medio", 5) == Educacao.semente(1, 1, "estatistica", "medio", 5), "semente varia por rodada e é reprodutível (modo sala de aula)")
	# 4) responder: errar → nova tentativa; acertar → recompensa; só 1 resolução por rodada
	var caixa0: float = gs.financas["caixa"]
	var moral0: int = gs.clube["moral_geral"]
	var errada: int = (int(a1["correta"]) + 1) % 4
	var r1: Dictionary = gs.responder_desafio(errada)
	ok(not r1["correto"] and not r1["resolvido"] and gs.financas["caixa"] == caixa0, "errar: sem prêmio, pode tentar de novo")
	var r2: Dictionary = gs.responder_desafio(int(a1["correta"]))
	ok(r2["correto"] and r2["premio"] == Educacao.RECOMPENSA_2A and gs.financas["caixa"] == caixa0 + Educacao.RECOMPENSA_2A, "acertar na 2ª: metade do prêmio")
	ok(gs.desafio_resolvido() and gs.responder_desafio(0).get("ja_resolvido", false), "uma resolução por rodada")
	ok(gs.clube["moral_geral"] == moral0, "acerto na 2ª tentativa não dá moral")
	gs.rodada_atual += 1
	ok(not gs.desafio_resolvido(), "nova rodada libera novo desafio")
	var b1: Dictionary = gs.desafio_atual()
	var r3: Dictionary = gs.responder_desafio(int(b1["correta"]))
	ok(r3["premio"] == Educacao.RECOMPENSA_1A and gs.clube["moral_geral"] == moral0 + 2, "acertar de primeira: prêmio cheio + moral")
	var area: String = str(b1["area"])
	ok(int(gs.competencias[area]["acertos"]) == 1 and gs.educacao_log.size() == 2, "competência e relatório registrados")
	# 5) níveis
	for n in Educacao.NIVEIS:
		gs.definir_nivel_escolar(n)
		ok(str(gs.desafio_atual()["nivel"]) == n, "nível escolar " + n)
	# 6) telas
	for tela in ["diretor", "prancheta", "desafio", "mapa"]:
		var cena: Node = load(gs.get_tree().root.get_node("SceneManager").CENAS[tela]).instantiate()
		add_child(cena)
		await get_tree().process_frame
		await get_tree().process_frame
		ok(cena.get_child_count() > 0, "tela %s abre sem erro" % tela)
		if tela == "diretor":
			ok(cena.find_child("Opcao_3", true, false) != null and cena.find_child("Enunciado", true, false) != null, "diretor: enunciado e 4 opções")
			(cena.find_child("BotaoCalculadora", true, false) as Button).pressed.emit()
			await get_tree().process_frame
			ok(cena.find_child("Calculadora", true, false) != null, "diretor: calculadora abre")
		if tela == "prancheta":
			ok(cena.find_child("StatMedia", true, false) != null and cena.find_child("GraficoOverall", true, false) != null and cena.find_child("StatDesvioBloqueado", true, false) != null, "prancheta: estatísticas, gráfico e desvio bloqueado")
		if tela == "desafio":
			ok(cena.find_child("BotaoDiretor", true, false) != null, "desafio: cartão do diretor")
		if tela == "mapa":
			ok(cena.find_child("BotaoPrancheta", true, false) != null, "mapa: botão da prancheta")
		cena.queue_free()
		await get_tree().process_frame
	# 7) save compatível
	var ss: Node = get_tree().root.get_node("SaveSystem")
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit()
