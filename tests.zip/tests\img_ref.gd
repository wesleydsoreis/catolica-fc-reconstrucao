extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 25: await process_frame
	await _cap("inicio")
	var sm: Node = root.get_node("SceneManager")
	var gs: Node = root.get_node("GameState")
	gs.novo_jogo(); gs.fut7_garantir()
	for t in ["hub","painel","elenco","mercado","torneios","desafio","escalacao","treino","tatica","config_partida"]:
		sm.ir_para(t, false)
		for i in 20: await process_frame
		await _cap(t)
	quit()
func _cap(n: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/ref_%s.png" % n)
