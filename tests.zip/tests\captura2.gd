extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState"); var sm = root.get_node("SceneManager")
	gs.novo_jogo()
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	sm.ir_para("tatica")
	for i in 5: await process_frame
	gs.escolher_tatica("ofensivo")
	var t = main.get_node("ScreenContainer").get_child(0)
	t._escolher("ofensivo")
	for i in 5: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/c_tatica.png")
	sm.ir_para("partida")
	for i in 240: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/c_jogo.png")
	var p = main.get_node("ScreenContainer").get_child(0)._partida
	p.piloto_auto = true
	for i in 1500: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/c_jogo2.png")
	print("size ", root.size, " estado ", p.estado, " gols ", p.gols)
	quit(0)
