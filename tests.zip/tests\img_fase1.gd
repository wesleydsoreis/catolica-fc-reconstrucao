extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	gs.escolher_eixos({"pressao": 2, "linha": 1, "construcao": 2})
	sm.ir_para("tatica", false)
	for i in 20: await process_frame
	await _cap("tatica")
	var tit: Array = gs.fut7_titulares()
	gs._processar_disciplina([{"id": tit[2]["id"], "nome": tit[2]["nome"], "time": 0, "tipo": "vermelho_direto"}, {"id": tit[3]["id"], "nome": tit[3]["nome"], "time": 0, "tipo": "amarelo"}])
	sm.ir_para("desafio", false)
	for i in 15: await process_frame
	await _cap("desafio_suspenso")
	sm.ir_para("escalacao", false)
	for i in 20: await process_frame
	await _cap("escalacao_suspenso")
	gs.simular_partida({"proprio": 1, "adversario": 1, "cartoes": [{"id": tit[4]["id"], "nome": tit[4]["nome"], "time": 0, "tipo": "amarelo"}]})
	sm.ir_para("resultado", false)
	for i in 20: await process_frame
	await _cap("resultado_disciplina")
	quit()
func _cap(nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/f1_%s.png" % nome)
