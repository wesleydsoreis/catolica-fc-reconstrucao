extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	sm.ir_para("partida", false)
	for i in 120: await process_frame
	var t0 := Time.get_ticks_msec()
	var dc := 0.0; var mx := 0.0; var obj := 0.0
	for i in 300:
		await process_frame
		dc = maxf(dc, Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))
		obj = maxf(obj, Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME))
	var ms := float(Time.get_ticks_msec() - t0) / 300.0
	print("PERF draw_calls_max=%d objetos_max=%d  frame_medio=%.1fms (llvmpipe, sem GPU)  nos=%d" % [dc, obj, ms, Performance.get_monitor(Performance.OBJECT_NODE_COUNT)])
	quit()
