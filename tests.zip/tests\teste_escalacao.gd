extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _ready() -> void:
	Cfg.usar_modo(false)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	for i in 5: await get_tree().process_frame
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	var ss: Node = get_tree().root.get_node("SaveSystem")
	var gd: Node = get_tree().root.get_node("GameData")
	gs.novo_jogo()
	ok(gd.formacoes_fut7.size() == 4, "4 formações FUT7 carregadas")
	for f in gd.formacoes_fut7:
		var gol := 0
		for s in f["slots"]:
			if s["cat"] == "GOL": gol += 1
		ok(f["slots"].size() == 7 and gol == 1, "%s: 7 jogadores, 1 goleiro" % f["id"])
	var elenco_antes: int = gs.elenco.size()
	var slots_antes: String = JSON.stringify(gs.slots)
	gs.fut7_garantir()
	var ids: Array = gs.escalacao_fut7["titulares"]
	ok(ids.size() == 7 and ids.duplicate().size() == 7, "escalação inicial com 7 titulares")
	var uniq := {}
	for id in ids: uniq[id] = true
	ok(uniq.size() == 7, "sem jogador repetido")
	ok(gs._categoria_de_posicao(str(gs.fut7_titulares()[0]["posicao"])) == "GOL", "goleiro no slot do goleiro")
	for f in gd.formacoes_fut7:
		gs.fut7_mudar_formacao(f["id"])
		var tit: Array = gs.fut7_titulares()
		var bate := tit.size() == 7
		for i in 7:
			if tit[i] == null:
				bate = false
			elif (gs._categoria_de_posicao(str(tit[i]["posicao"])) == "GOL") != (f["slots"][i]["cat"] == "GOL"):
				bate = false
			elif gs.fut7_afinidade(tit[i], f["slots"][i]["cat"]) > 1:
				bate = false
		ok(bate, "%s: goleiro só no gol e linha com afinidade (zagueiro/volante na defesa etc.)" % f["id"])
	ok(gs.elenco.size() == elenco_antes and JSON.stringify(gs.slots) == slots_antes, "elenco de %d e escalação de 11 da gestão intactos" % elenco_antes)
	ok(gs.fut7_titulares().size() + gs.fut7_banco().size() == elenco_antes, "titulares + banco = elenco inteiro")
	# troca com o banco e entre titulares
	gs.fut7_mudar_formacao("2-3-1")
	var t0: String = str(gs.fut7_titulares()[4]["id"]); var t1: String = str(gs.fut7_titulares()[5]["id"])
	gs.fut7_trocar(4, t1)
	ok(gs.escalacao_fut7["titulares"][4] == t1 and gs.escalacao_fut7["titulares"][5] == t0, "trocar dois titulares inverte os lugares")
	var b0: String = str(gs.fut7_banco()[0]["id"])
	gs.fut7_trocar(6, b0)
	ok(gs.escalacao_fut7["titulares"][6] == b0, "reserva entra no lugar do titular")
	var tot := {}
	for id in gs.escalacao_fut7["titulares"]: tot[id] = true
	ok(tot.size() == 7, "continua sem repetidos após trocas")
	# dados para a partida
	var d: Dictionary = gs.dados_partida_jogavel(null, false)
	ok(d["escalacao"].size() == 7 and d.has("formacao_linhas") and d["formacao_linhas"].size() == 7, "dados da partida: 7 titulares + formação")
	ok(str(d["escalacao"][6]["nome"]) == str(gs._jogador_por_id(b0)["nome"]), "partida usa o titular escolhido")
	# salvar/carregar e compatibilidade com save antigo
	gs.fut7_mudar_formacao("3-1-2")
	ok(ss.salvar(), "salvou")
	var antes: Array = gs.escalacao_fut7["titulares"].duplicate()
	gs.escalacao_fut7 = {}
	ok(ss.carregar() and gs.escalacao_fut7["formacao"] == "3-1-2" and gs.escalacao_fut7["titulares"] == antes, "save guarda a escalação FUT7")
	var f_ := FileAccess.open(ss.CAMINHO_SAVE, FileAccess.READ); var j = JSON.parse_string(f_.get_as_text()); f_.close()
	j.erase("escalacao_fut7")
	var f2 := FileAccess.open(ss.CAMINHO_SAVE, FileAccess.WRITE); f2.store_string(JSON.stringify(j)); f2.close()
	gs.escalacao_fut7 = {"formacao": "2-2-2", "titulares": ["x"]}
	ok(ss.carregar(), "save antigo (sem escalação FUT7) carrega")
	var d2: Dictionary = gs.dados_partida_jogavel(null, false)
	ok(d2["escalacao"].size() == 7, "save antigo: escalação gerada automaticamente")
	# jogador vendido some da escalação
	var vend: String = str(gs.fut7_titulares()[2]["id"])
	gs.elenco = gs.elenco.filter(func(x): return x["id"] != vend)
	gs.fut7_garantir()
	ok(not gs.escalacao_fut7["titulares"].has(vend) and gs.escalacao_fut7["titulares"].size() == 7, "jogador removido do elenco é substituído")
	ss.apagar_progresso()
	# tela: selecionar, trocar de lugar e substituir pelo banco
	gs.novo_jogo()
	gs.prep_confirmada = true
	sm.ir_para("escalacao", false)
	for i in 4: await get_tree().process_frame
	var tela: Node = main.get_node("ScreenContainer").get_child(0)
	var a: String = str(gs.escalacao_fut7["titulares"][1]); var b: String = str(gs.escalacao_fut7["titulares"][2])
	tela._clicou_token(1)
	for i in 3: await get_tree().process_frame
	tela._clicou_token(2)
	for i in 3: await get_tree().process_frame
	ok(gs.escalacao_fut7["titulares"][1] == b and gs.escalacao_fut7["titulares"][2] == a, "tela: tocar em dois titulares troca de lugar")
	var banco0: String = str(gs.fut7_banco()[0]["id"])
	tela._clicou_token(4)
	for i in 3: await get_tree().process_frame
	var botoes: Array = tela.find_children("*", "Button", true, false)
	var entrar: Button = null
	for bt in botoes:
		if bt.text == "ENTRAR":
			entrar = bt
			break
	ok(entrar != null and not entrar.disabled, "tela: botão ENTRAR habilitado com jogador selecionado")
	entrar.pressed.emit()
	for i in 3: await get_tree().process_frame
	ok(gs.escalacao_fut7["titulares"][4] == banco0, "tela: ENTRAR substitui o selecionado")
	var tem_ir: bool = false
	for bt in tela.find_children("*", "Button", true, false):
		if str(bt.text).begins_with("CONFIRMAR E IR"):
			tem_ir = true
	ok(tem_ir, "tela: botão para a tática aparece no fluxo da rodada")
	gs.prep_confirmada = false
	# partida real com cada formação
	for fo in gd.formacoes_fut7:
		gs.novo_jogo()
		gs.fut7_mudar_formacao(fo["id"])
		gs.amistoso = {"adversario_id": str(gs.adversarios_amistoso()[0]["id"]), "formacao_id": fo["id"], "dificuldade": "normal", "modo": "7", "em_jogo": true}
		sm.ir_para("partida", false)
		for i in 5: await get_tree().process_frame
		var pj: Node = main.get_node("ScreenContainer").get_child(0)
		var p = pj._partida
		var cont := {"GOL": 0, "DEF": 0, "MEI": 0, "ATA": 0}
		for jg in p.times[0]: cont[jg.papel] += 1
		var esperado := {"GOL": 0, "DEF": 0, "MEI": 0, "ATA": 0}
		for s in fo["slots"]: esperado[s["cat"]] += 1
		ok(p.times[0].size() == 7 and p.times[1].size() == 7 and cont == esperado, "partida %s: 7x7 com a formação certa" % fo["id"])
		for i in 1500: await get_tree().process_frame
		ok(p.estado != 5 or true, "partida %s rodou 25 s sem erro" % fo["id"])
		sm.bloqueio_voltar = false
		sm.ir_para("hub", false)
		for i in 3: await get_tree().process_frame
	print("FALHAS: %d" % falhas)
	get_tree().quit(1 if falhas > 0 else 0)
