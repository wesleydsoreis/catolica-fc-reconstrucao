extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	var gs = root.get_node("GameState")
	gs.novo_jogo()
	Cfg.usar_modo(true)
	gs.escolher_tatica("equilibrado")
	var d: Dictionary = gs.dados_partida_jogavel(null, true)
	for forca in [57, 68, 80]:
		var tot_c := 0; var tot_a := 0; var v := 0; var e := 0; var de := 0
		for k in 3:
			var p: Partida = Partida.new()
			p.modo_carreira = true
			p.escalacao_casa = d["escalacao"]
			p.forca_fora = (0.84 + (float(forca) - 76.0) * 0.004) / 0.84
			p.piloto_auto = true
			root.add_child(p)
			await process_frame
			var f := 0
			while p.estado != Partida.Estado.FIM and f < 30000:
				p._physics_process(1.0 / 60.0)
				p._process(1.0 / 60.0)
				f += 1
			var a: int = p.gols[0]; var b: int = p.gols[1]
			tot_c += a; tot_a += b
			if a > b: v += 1
			elif a == b: e += 1
			else: de += 1
			p.queue_free()
			await process_frame
		print("adv forca %d: gols %d x %d | V%d E%d D%d" % [forca, tot_c, tot_a, v, e, de])
	quit(0)
