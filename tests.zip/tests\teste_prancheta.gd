extends Node
## Fase 5: Prancheta com visão geral (mascote, adversário, resultados, tarefas, objetivos, alertas, atalhos, rever tutorial).
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _tela(main: Node) -> Node:
	return main.get_node("ScreenContainer").get_child(0)
func _ready() -> void:
	await _esperar(3)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	for p in Mascote.POSES:
		ok(Mascote.textura(p) != null and Mascote.textura(p).get_width() > 50, "pose do mascote carrega: " + p)
	gs.novo_jogo(); gs.tutorial_concluido = true
	sm.ir_para("prancheta", false); await _esperar(8)
	var pr: Node = _tela(main)
	for n in ["Visao_Mascote", "Visao_Proximo", "Visao_Resultados", "Visao_Tarefas", "Visao_Objetivos", "Visao_Alertas", "Visao_Atalhos"]:
		ok(pr.find_child(n, true, false) != null, "seção " + n)
	ok(pr.find_child("StatMedia", true, false) != null and pr.find_child("GraficoOverall", true, false) != null and pr.find_child("Calculadora", true, false) != null, "estatísticas, gráfico e calculadora antigos preservados")
	ok(pr.find_child("TarefaTreino", true, false) != null, "treino pendente aparece nas tarefas")
	ok(pr.find_child("ProxAdversario", true, false) != null, "próximo adversário real")
	ok(pr.find_child("GraficoPontos", true, false) == null, "sem jogos: sem gráfico de pontos")
	ok(Mascote.humor_do_clube() == "normal", "humor inicial neutro")
	# depois de jogar: resultados, gráfico e humor
	gs.simular_partida(); gs.avancar_rodada()
	gs.simular_partida(); gs.avancar_rodada()
	sm.ir_para("prancheta", false); await _esperar(8)
	pr = _tela(main)
	ok(pr.resultados().size() == 2 and pr.find_child("GraficoPontos", true, false) != null, "resultados reais e gráfico de pontos (2 jogos)")
	ok(["animado", "triste", "pensativo"].has(Mascote.humor_do_clube()), "humor segue o último resultado (%s)" % Mascote.humor_do_clube())
	# treino confirmado remove tarefa
	gs.confirmar_treino(gs.agenda_treino.duplicate(), "")
	sm.ir_para("prancheta", false); await _esperar(8)
	ok(_tela(main).find_child("TarefaTreino", true, false) == null, "tarefa de treino some depois de confirmado")
	# alertas financeiros
	var cx: float = float(gs.financas["caixa"])
	gs.financas["caixa"] = -5000.0
	ok(_tela(main).alertas_financeiros().size() >= 1 and Mascote.humor_do_clube() == "triste", "caixa negativo gera alerta e mascote triste")
	gs.financas["caixa"] = cx
	gs.financas["divida"] = 20000.0
	ok(_tela(main).alertas_financeiros().any(func(a): return str(a).begins_with("Dívida")), "dívida gera alerta")
	gs.financas["divida"] = 0.0
	# lesões
	gs.registrar_lesao(str(gs.elenco[0]["id"]), 2)
	sm.ir_para("prancheta", false); await _esperar(8)
	ok(_tela(main).find_child("TarefaEscalacao", true, false) != null, "lesionado gera tarefa de escalação")
	# atalhos
	var alvos := {"treino": "treino", "secretaria": "painel", "mercado": "mercado", "obras": "estadio_obras", "classificacao": "torneios", "financas": "financas", "elenco": "elenco"}
	for a in alvos.keys():
		sm.ir_para("prancheta", false); await _esperar(6)
		var b: Button = _tela(main).find_child("Atalho_" + a, true, false) as Button
		ok(b != null, "atalho " + a)
		b.pressed.emit(); await _esperar(6)
		ok(sm.tela_atual() == alvos[a], "atalho %s leva a %s" % [a, alvos[a]])
	# rever tutorial
	sm.ir_para("prancheta", false); await _esperar(6)
	(_tela(main).find_child("BotaoTutorial", true, false) as Button).pressed.emit()
	await _esperar(20)
	var mapa: Node = _tela(main)
	ok(mapa.name == "Mapa" and is_instance_valid(mapa._tutorial), "rever tutorial abre o tutorial no mapa")
	ok(gs.tutorial_concluido, "revisão não altera o progresso do tutorial")
	mapa._tutorial._fechar(false); await _esperar(5)
	ok(not is_instance_valid(mapa._tutorial) and gs.tutorial_concluido, "fecha e continua concluído")
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
