extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.novo_jogo(); gs.fut7_garantir()
	gs.tomar_emprestimo(100000)
	gs.simular_partida()
	sm.ir_para("financas", false)
	for i in 20: await process_frame
	await _cap("financas")
	sm.ir_para("imprensa", false)
	for i in 20: await process_frame
	await _cap("imprensa")
	quit()
func _cap(nome: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/f5_%s.png" % nome)
