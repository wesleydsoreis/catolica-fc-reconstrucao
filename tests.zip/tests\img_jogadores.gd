extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var c := Cenario.new(); root.add_child(c)
	var clubes: Array = JSON.parse_string(FileAccess.get_file_as_string("res://data/clubes_universitario.json"))
	var peles := [Color("F6C9A2"), Color("D98C4E"), Color("8A5230"), Color("5A3420")]
	var cabs := [Color("241812"), Color("6B4423"), Color("E0B040"), Color("14101C")]
	var anims := ["run_s", "run_f", "run_b", "chute_s", "carrinho", "festa", "idle_s", "gk_alto"]
	for i in 12:
		var cl: Dictionary = clubes[i]
		var p := Player.new()
		c.add_child(p)
		p.configurar(Player.kit_do_clube(Color(cl["cor1"]), Color(cl["cor2"])), peles[i % 4], cabs[(i * 3) % 4])
		p.position = Vector2(40 + (i % 6) * 70, 175 + (i / 6) * 55)
		p.tocar(anims[i % anims.size()], i % 3 == 0)
	var g := Player.new(); c.add_child(g)
	g.configurar(Player.kit_do_clube(Color.BLACK, Color.BLACK, true), peles[0], cabs[0]); g.position = Vector2(30, 240); g.tocar("gk_baixo", false)
	for i in 30: await process_frame
	root.get_viewport().get_texture().get_image().save_png("/tmp/s2/img/e4_godot.png")
	quit(0)
