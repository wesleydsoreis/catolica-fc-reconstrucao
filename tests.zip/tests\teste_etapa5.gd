extends Node
var falhas := 0
func ok(c: bool, m: String) -> void:
	print(("  OK  " if c else "  FALHOU  ") + m)
	if not c: falhas += 1
func _tela(main: Node) -> Node:
	return main.get_node("ScreenContainer").get_child(0)
func _acha(n: Node, nome: String) -> Node:
	return n.find_child(nome, true, false)
func _esperar(n: int) -> void:
	for i in n: await get_tree().process_frame
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	get_tree().root.add_child.call_deferred(main)
	await _esperar(5)
	var gs: Node = get_tree().root.get_node("GameState")
	var sm: Node = get_tree().root.get_node("SceneManager")
	gs.novo_jogo()
	gs.fut7_garantir()
	var snap := JSON.stringify([gs.rodada_atual, gs.financas, gs.clubes, gs.escalacao_fut7, gs.ultimos_resultados])
	var partes := [gs.rodada_atual, gs.financas.duplicate(true), gs.clubes.duplicate(true), gs.escalacao_fut7.duplicate(true), gs.ultimos_resultados.duplicate(true)]
	# ---- tela de configuração
	sm.ir_para("config_partida", false)
	await _esperar(4)
	var cfg: Node = _tela(main)
	ok(cfg.name == "ConfigPartida", "tela de configuração abre")
	ok(_acha(cfg, "BotaoIniciar") != null and _acha(cfg, "BotaoVoltar") != null, "botões iniciar/voltar existem")
	var nome0: String = (_acha(cfg, "AdvNome") as Label).text
	(_acha(cfg, "AdvProximo") as Button).pressed.emit()
	await _esperar(3)
	var nome1: String = (_acha(_tela(main), "AdvNome") as Label).text
	ok(nome0 != nome1, "trocar adversário muda o nome (%s -> %s)" % [nome0, nome1])
	(_acha(_tela(main), "Modo_7") as Button).pressed.emit()
	await _esperar(3)
	(_acha(_tela(main), "Formacao_2-3-1") as Button).pressed.emit()
	await _esperar(3)
	(_acha(_tela(main), "Dif_dificil") as Button).pressed.emit()
	await _esperar(3)
	ok(gs.amistoso["formacao_id"] == "2-3-1" and gs.amistoso["dificuldade"] == "dificil", "formação e dificuldade gravadas na configuração")
	var fid_antes: String = str(gs.escalacao_fut7["formacao"])
	var d: Dictionary = gs.dados_partida_amistoso()
	ok(d["escalacao"].size() == 7 and d["formacao_fut7"] == "2-3-1", "dados do amistoso: 7 titulares na formação escolhida")
	ok(str(gs.escalacao_fut7["formacao"]) == fid_antes, "escalação da carreira não foi alterada pela formação do amistoso")
	var adv_id: String = gs.amistoso["adversario_id"]
	var f_normal: float = float(gs.clube_por_id(adv_id)["forca"])
	ok(float(d["adversario"]["forca"]) == f_normal + 8.0, "dificuldade DIFÍCIL aumenta a força do adversário")
	# ---- iniciar
	(_acha(_tela(main), "BotaoIniciar") as Button).pressed.emit()
	await _esperar(6)
	var pj: Node = _tela(main)
	var p = pj._partida
	ok(pj._amistoso and p != null, "partida iniciada em modo amistoso")
	ok(p.sigla_fora == str(gs.clube_por_id(adv_id)["sigla"]), "adversário escolhido chegou à partida")
	ok(p.formacao_casa.size() == 7 and p.nivel_ia[1] > clampf((((0.84 + (f_normal - 76.0) * 0.004) / 0.84) - 0.90) / 0.16, 0.0, 1.0), "formação e nível da IA (difícil) chegaram à partida (IA %.2f)" % p.nivel_ia[1])
	# ---- HUD / pausa
	await _esperar(30)
	ok(p.vis.hud.partida == p and p.vis.hud.minimapa, "HUD com minimapa ligado")
	p.pausado = true
	await _esperar(5)
	var ids: Array = []
	for it in p.menu._itens_menu(): ids.append(it["id"])
	ok(ids == ["continuar", "sub", "ver", "tat", "cfg", "reiniciar", "sair"], "menu de pausa do amistoso: " + str(ids))
	p.menu.sel = 4
	p.menu._confirmar()
	var ids2: Array = []
	for it in p.menu._itens_menu(): ids2.append(it["id"])
	ok(ids2.has("mao") and ids2.has("tela") and ids2.has("voltar"), "submenu CONFIGURAÇÕES")
	p.menu.sel = ids2.size() - 1
	p.menu._confirmar()
	ok(not p.menu._cfg, "voltar do submenu")
	p.menu.sel = 2
	p.menu._confirmar()
	await _esperar(2)
	ok(p.menu._ver and p.menu.modo == MenuPartida.Modo.SAI, "consultar escalação abre a tela")
	var subs: int = int(p.subs_restantes[0])
	p.menu._confirmar()
	ok(int(p.subs_restantes[0]) == subs and p.menu.modo == MenuPartida.Modo.SAI, "consulta não permite substituir")
	p.menu._fechar_sub()
	# ---- reiniciar
	var gols_antes: int = 0
	p.pausado = true
	await _esperar(3)
	p.menu.modo = MenuPartida.Modo.MENU
	p.menu.sel = 5
	p.menu._confirmar()
	ok(p.menu._confirma_reiniciar, "reiniciar pede confirmação")
	p.menu._confirmar()
	await _esperar(8)
	var p2 = _tela(main)._partida
	ok(p2 != null and p2 != p and p2.tempo_real < 5, "reiniciar cria partida nova do zero")
	# ---- jogar até o fim
	var n := 0
	while p2.estado != 5 and n < 14000:
		await get_tree().process_frame
		n += 1
	ok(p2.estado == 5, "partida terminou (%d frames) placar %d x %d" % [n, p2.gols[0], p2.gols[1]])
	var gc: int = int(p2.gols[0]); var ga: int = int(p2.gols[1])
	p2.continuar_pedido.emit()
	await _esperar(5)
	var res: Node = _tela(main)
	ok(res.name == "ResultadoAmistoso", "tela de resultado do amistoso")
	ok(gs.amistoso_resultado["gc"] == gc and gs.amistoso_resultado["ga"] == ga, "placar do resultado confere")
	ok(_acha(res, "Placar") != null and (_acha(res, "Placar") as Label).text.contains("%d x %d" % [gc, ga]), "placar aparece na tela")
	var snap2 := JSON.stringify([gs.rodada_atual, gs.financas, gs.clubes, gs.escalacao_fut7, gs.ultimos_resultados])
	for i in 5:
		var a := JSON.stringify(partes[i]); var b := JSON.stringify([gs.rodada_atual, gs.financas, gs.clubes, gs.escalacao_fut7, gs.ultimos_resultados][i])
		if a != b: print("   DIFERE parte ", i, ": ", a.substr(0, 300), " ===> ", b.substr(0, 300))
	ok(snap == snap2, "amistoso não altera rodada, caixa, tabela, escalação nem últimos resultados")
	# revanche
	(_acha(res, "BotaoRevanche") as Button).pressed.emit()
	await _esperar(6)
	ok(_tela(main).name == "PartidaJogo" and _tela(main)._amistoso, "jogar de novo reabre a partida")
	# sair pelo menu volta à configuração
	var p3 = _tela(main)._partida
	p3.pausado = true
	await _esperar(4)
	p3.menu.sel = p3.menu._itens_menu().size() - 1
	p3.menu._confirmar(); p3.menu._confirmar()
	await _esperar(6)
	ok(_tela(main).name == "ConfigPartida", "sair do amistoso volta à configuração")
	ok(JSON.stringify([gs.rodada_atual, gs.financas, gs.clubes]) == JSON.stringify([gs.rodada_atual, gs.financas, gs.clubes]) and not gs.amistoso.get("em_jogo", false), "flag de jogo limpa")
	# ---- carreira continua normal
	sm.ir_para("partida", false)
	await _esperar(6)
	var pc = _tela(main)
	ok(pc.name == "PartidaJogo" and not pc._amistoso, "partida de carreira não é amistoso")
	var idsc: Array = []
	for it in pc._partida.menu._itens_menu(): idsc.append(it["id"])
	ok(not idsc.has("reiniciar"), "carreira não oferece reiniciar")
	sm.bloqueio_voltar = false
	pc._abandonar()
	await _esperar(4)
	print("FALHAS: %d" % falhas)
	print("FIM")
	get_tree().quit(1 if falhas > 0 else 0)
