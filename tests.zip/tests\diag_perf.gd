extends SceneTree
func _initialize() -> void:
	_rodar()
func _rodar() -> void:
	await process_frame
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var t0: int = Time.get_ticks_msec()
	var p := Partida.new()
	p.piloto_auto = true
	root.add_child(p)
	await process_frame
	print("MONTAGEM_MS ", Time.get_ticks_msec() - t0)
	var t1: int = Time.get_ticks_msec()
	var maior: int = 0
	var ult: int = Time.get_ticks_msec()
	for i in 600:
		await process_frame
		var agora: int = Time.get_ticks_msec()
		maior = maxi(maior, agora - ult); ult = agora
	print("MEDIA_MS_QUADRO ", float(Time.get_ticks_msec() - t1) / 600.0, " PIOR ", maior)
	var n: int = 0
	var stack: Array = [root]
	while not stack.is_empty():
		var x: Node = stack.pop_back(); n += 1
		for c in x.get_children(): stack.append(c)
	print("NOS ", n, " TEXTURAS_PLAYER ", Player._folhas.size())
	quit(0)
