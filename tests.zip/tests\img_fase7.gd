extends SceneTree
func _initialize() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	for i in 20: await process_frame
	var gs: Node = root.get_node("GameState")
	var sm: Node = root.get_node("SceneManager")
	gs.iniciar_sala("2A-2026", "Ana Souza")
	gs.promover_jovem(1)
	for k in 6:
		gs.simular_partida(); gs.avancar_rodada()
	for j in gs.elenco:
		if gs.pode_emprestar(j):
			gs.emprestar_jogador(str(j["id"])); break
	gs.h2h[gs.rival_id] = {"v": 1, "e": 0, "d": 1}
	for tela in ["base", "conquistas", "desafio", "painel"]:
		sm.ir_para(tela, false)
		for i in 20: await process_frame
		await process_frame
		await RenderingServer.frame_post_draw
		root.get_viewport().get_texture().get_image().save_png("/tmp/s2/shots/f7_%s.png" % tela)
	quit()
