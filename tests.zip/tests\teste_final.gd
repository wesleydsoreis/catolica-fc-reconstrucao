extends SceneTree
# Partidas completas com piloto automático + visual (PartidaVis). Conta eventos e erros.
func _initialize() -> void:
	Cfg.usar_modo(false)
	_rodar()
func _rodar() -> void:
	await process_frame
	var falhas: int = 0
	for m in 3:
		var p := Partida.new()
		p.nome_casa = "CATÓLICA FC"; p.sigla_casa = "CFC"; p.nome_fora = "UNIVILLE"; p.sigla_fora = "UNV"
		root.add_child(p)
		p.piloto_auto = true
		var fim := [false]
		p.continuar_pedido.connect(func(): fim[0] = true)
		var frames: int = 0
		var anims: Dictionary = {}
		var trocou: bool = false
		while p.estado != Partida.Estado.FIM and frames < 40000:
			await process_frame
			frames += 1
			if frames == 3000 and not trocou:
				trocou = true
				if p.has_method("_trocar_manual"):
					p._trocar_manual()
			if frames % 20 == 0:
				for c in p.get_children():
					if c is PartidaVis:
						for pl in (c as PartidaVis)._players.values():
							anims[pl.anim] = true
		print("PARTIDA ", m, " frames=", frames, " placar=", p.gols, " amarelos=", p.amarelos, " vermelhos=", p.vermelhos, " faltas=", p.faltas, " anims=", anims.size(), " fim=", p.estado == Partida.Estado.FIM)
		if p.estado != Partida.Estado.FIM: falhas += 1; print("FALHA: partida não terminou")
		if p.gols[0] < 0 or p.gols[1] > 30: falhas += 1
		p.queue_free()
		await process_frame
	print("FALHAS: ", falhas)
	quit(0)
