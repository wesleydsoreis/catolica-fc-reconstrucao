# Católica FC — A Reconstrução · Game Design Document (versão final)

Projeto acadêmico · Engenharia de Software, Católica SC (Joinville) · Autor: Erik Pinheiro
Engine: Godot 4 (GDScript) · Plataformas: PC (Windows/Linux/macOS), Web e celular (toque)

> Este documento descreve o jogo **como ele foi entregue**. O plano que originou as fases está em `docs/GDD_RECONSTRUCAO.md` (histórico) e o registro técnico fase a fase está em `docs/ATUALIZACAO_GERAL.md`.

## 1. Visão geral
Jogo de gestão e futebol em que o jogador comanda a Católica FC ao longo de várias temporadas. A semana é de decisões (treino, tática, finanças, mercado); o sábado é de partida jogável em tempo real. As decisões aparecem em campo e no caixa. Em paralelo, o jogo ensina matemática: os problemas usam os números da própria carreira do aluno.

- **Pilares:** (1) toda decisão tem consequência visível; (2) partida jogável de verdade, estilo arcade; (3) matemática como ferramenta de decisão, nunca como bloqueio.
- **Público:** estudantes (Fundamental II ao Superior) e professores que usam o jogo em sala de aula.
- **Identidade visual:** pixel art em vermelho, creme e branco, com amarelo para destaque; orientação paisagem.

## 2. Modos de jogo
| Modo | Descrição |
|---|---|
| **Carreira 11x11 (principal)** | Temporadas de 28 rodadas no Campeonato Universitário, mais InterLajes e Copa dos Gigantes. Campo de 3300×1950 com câmera que acompanha a bola; 5 substituições. |
| **Amistoso FUT7 (diversão)** | 7 contra 7, o jogador escolhe o time que quer jogar, adversário, formação e dificuldade. Não afeta a carreira. |
| **Professor · Sala de aula** | Código da turma vira a semente do jogo; relatório exportável. Ver seção 7. |

## 3. Loop da carreira
1. **Painel/Mapa:** o mundo é um mapa clicável (CT, Sede, Estádio, Empresário, Federação, Bar, Vila). O jogador escolhe o destino.
2. **Semana:** agenda de treino (4 turnos), escalação e tática, scouting do adversário, preço do ingresso, mercado, base.
3. **Desafio do Diretor** (opcional, 1 por rodada): problema de matemática com dados da carreira; recompensa em caixa e moral.
4. **Partida:** jogada ou simulada com as mesmas regras (atributos, tática, entrosamento, clima).
5. **Consequências:** evolução de jogadores, lesões, suspensões, moral, torcida, caixa, diretoria, manchete e coletiva de imprensa, conquistas.
6. **Fim de temporada:** veredito da diretoria, troféus, novas metas e novos jovens da base.

## 4. Mecânicas de partida
### 4.1 Controles
| Ação | Teclado | Controle | Toque |
|---|---|---|---|
| Mover | WASD / setas | Analógico esquerdo | Joystick virtual |
| Passe | J ou Z | A | Botão |
| Chute (segurar = força) | K ou X | B | Botão |
| Passe alto (lob) | I ou C | X | Botão |
| Correr | Shift ou Espaço | RB | Botão |
| Trocar jogador | L ou U | Y | Botão |
| Ajuda | H ou F1 | LB | — |
| Pausa / menu | P ou Esc | Start | Botão |
| Reiniciar lance | R ou Enter | Back | — |

### 4.2 Regras e sistemas
- **Atributos que chegam ao campo:** energia → fôlego e velocidade; moral → erro de passe/chute; forma recente e preparação → precisão.
- **Tática de 3 eixos:** Pressão (baixa/média/alta), Linha (recuada/média/adiantada), Construção (toque curto/bola longa/contra-ataque). Há também estilos prontos (Ofensivo, Equilibrado, Defensivo) com bônus e custos de desgaste. O **entrosamento** por estilo reduz erros de passe e sobe com treino tático e jogos.
- **Formações 11x11:** 4-3-3, 4-4-2, 4-2-3-1, 3-5-2, 5-3-2. FUT7: 3-2-1, 2-3-1, 2-2-2, 3-1-2.
- **Disciplina:** cartão vermelho = expulsão e 1 jogo de suspensão; 3 amarelos em partidas diferentes = 1 jogo de suspensão (contador zera); o 2º amarelo na mesma partida vira vermelho e não acumula. O amistoso ignora suspensões.
- **Goleiro:** não jogável; ao pegar a bola, os jogadores ocupam espaços livres (mínimo ~2 s, máximo ~5 s) antes do passe.
- **Bolas paradas jogáveis (a favor da casa):** pênalti, falta perigosa e escanteio. Setas movem a mira; segurar CHUTE carrega a força (acima de ~92% tende a ir por cima); no escanteio o chute cruza e ←/→ mudam a profundidade. Piloto automático e o adversário cobram automaticamente.
- **Lesão em jogo:** substituição automática; o lesionado fica indisponível a partir da rodada seguinte.
- **Clima:** sol (60%), chuva (22%: público −12% e erros de passe +12%) e calor (18%: cansaço +20%), determinístico por sala/temporada/rodada.
- **Mando de campo:** bônus de +1,5 em casa e −1,5 fora na força do time.

## 5. Gestão
- **Treino semanal:** 4 turnos entre Físico, Técnico, Tático, Recuperação e Folga + 1 jogador em foco. Risco de lesão = 1,2%×(turnos intensos−1) + 0,07%×(70−energia) − 1,2%×recuperações.
- **Elenco:** energia, moral individual, lesões, suspensões; reservas rotacionam. Salário base ≈ overall × 30.
- **Mercado:** catálogo de jogadores em faixas de preço.
- **Scouting:** 2 níveis (R$ 300 cada, zera a cada rodada) revelam perfil tático e ponto fraco do adversário; jogar contra o ponto fraco dá até +2,5 de overall.
- **Base e empréstimos:** 3 jovens por temporada (overall 52–60, potencial até ~82) podem ser promovidos (elenco máximo 24). Reservas podem ser emprestados por 6 rodadas (sem salário, indisponíveis, voltam com +1 ou +2 de overall); elenco mínimo 14.
- **Rivalidade:** um rival fixo por carreira. No clássico, público +25%, torcida e diretoria ±3, manchete especial e histórico de vitórias/empates/derrotas.
- **Metas pessoais:** até 3 meias/atacantes com meta de gols na temporada; meta batida = +15 de moral e R$ 5.000.
- **Conquistas:** 14 conquistas (por exemplo primeira vitória, sequência de 3, goleada, rei do clássico, craque dos números, nome limpo), R$ 3.000 cada, com aviso na tela de Resultado.
- **Finanças e diretoria:** preço do ingresso (demanda afim: −1,8% de público por R$ 1 acima de R$ 25), estádio, patrocínio, dívida com juros compostos (3% por rodada, limite R$ 300 mil). A diretoria dá 3 metas por temporada; confiança sobe e desce com resultados, dívida e caixa; meta cumprida paga R$ 15 mil. Veredito no fim da temporada (renovação, elogios ou ultimato; sem demissão).
- **Torcida e imprensa:** torcida reage a resultado e preço; manchete do dia e coletiva pós-jogo com 3 respostas (efeitos em moral, torcida e diretoria).

## 6. Camada educacional
**Princípio:** a matemática ajuda a decidir melhor; errar nunca trava a progressão.

| Área | Onde aparece | Conceitos |
|---|---|---|
| Estatística | Prancheta do Treinador | média, mediana, moda, amplitude, desvio padrão, quartis |
| Porcentagem | Aproveitamento, reajustes, juros | %, variação, reajustes sucessivos, juros compostos |
| Probabilidade | Chance de não perder, pênaltis | eventos independentes, valor esperado |
| Finanças | Bilheteria, caixa, dívida | ponto de equilíbrio, fôlego do caixa, quitação (PMT) |
| Funções | Preço × público | função afim, parábola, vértice (preço ótimo) |

- **Desafio do Diretor:** 5 áreas × 3 níveis escolares (Fundamental II, Médio, Superior), gerado proceduralmente com dados reais da carreira. 4 alternativas, dica, calculadora, passo a passo ao errar e nova tentativa. Acerto de primeira: R$ 5.000 + 2 de moral; na segunda tentativa: R$ 2.500.
- **Prancheta do Treinador:** gráficos e estatísticas do elenco e da campanha, árvore de competências e calculadora.
- **Árvore de competências:** Iniciante, Intermediário e Avançado por área (3 e 8 acertos de primeira); cada nível libera uma ferramenta (desvio padrão, quartis, projeção de pontos, valor esperado, simulador de quitação, equação da demanda, preço ótimo).

## 7. Para o professor
- **Modo sala de aula:** menu inicial → Professor. O código da turma é a semente: mesmo código, mesmo elenco, calendário, metas e problemas. Nome do aluno e turma entram no relatório.
- **Relatório de desempenho:** acertos na 1ª e 2ª tentativa, erros e tempo por área, log dos desafios e decisões por rodada. Exporta CSV (separador `;`, com BOM para Excel) e JSON. No navegador baixa o arquivo; no desktop grava em Documentos.

## 8. Interface e plataformas
Todas as telas são montadas em código com um tema único (vermelho, creme, amarelo). A tela inicial tem menu com botões e Sair; a pausa permite escalação, tática, configurações e reiniciar. Tela cheia no PC e no celular, com joystick e botões virtuais. Saves em JSON são compatíveis entre versões (campos novos têm valores padrão).

## 9. Qualidade e testes
- 20 suítes automatizadas em `tests/` (regras, temporada completa, 11x11, bolas paradas, fases 2 a 7) com 0 falhas, mais `teste_etapa7` que abre 23 telas em 5 resoluções.
- Simulação de 8 temporadas em 4 salas (`teste_fase7`) e balanceamento do 11x11 em partidas com piloto automático (~2,2 gols por jogo).
- Testado na Godot 4.4.1 em modo headless e por capturas; o autor usa a 4.7.2 no PC.

## 10. Limitações conhecidas
- Validação em celular real e do download do relatório na versão web ainda por fazer.
- Sprites dos jogadores de campo usam a arte atual; a folha de referência maior do autor ainda não foi integrada.
- Combinatória, geometria e otimização, previstas no plano original, ficaram fora desta versão.
