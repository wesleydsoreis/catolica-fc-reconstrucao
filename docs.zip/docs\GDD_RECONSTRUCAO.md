# Católica FC FUT7 — Reconstrução do loop de gestão (proposta v2)

## Diagnóstico
- A partida agora é jogada de verdade, mas `forca_casa = 1.0` é fixa. Tática só desloca a linha defensiva em 5%. Treino/preparação só alteram a fórmula do "Simular partida".
- Resultado: tática, treino, energia, moral e elenco quase não mudam o que acontece em campo. A gestão virou decoração.

## Princípio
**Toda decisão da semana tem que aparecer em campo ou no resultado do clube.** Se não aparece, não entra no jogo.

## Loop novo: Semana → Jogo → Consequência
1. **Segunda — Relatório:** lesões, moral, metas da diretoria, scouting do próximo adversário.
2. **Terça a sexta — Agenda de treino:** 4 turnos distribuídos entre Físico, Técnico, Tático, Recuperação e Folga, mais 1 jogador em foco individual.
3. **Sexta — Tática e escalação:** estilo + 7 titulares FUT7.
4. **Sábado — Jogo:** você joga (ou o assistente joga com os mesmos sistemas).
5. **Domingo — Consequências:** evolução, lesões, moral, caixa, confiança da diretoria, eventos.

## Mecânicas
### 1. Atributos que chegam ao campo
Overall, energia, moral e forma deixam de ser só números e viram física da partida:
- Energia → fôlego inicial e velocidade de corrida.
- Moral → erro de passe/chute e tempo de reação.
- Forma (média dos últimos jogos) → bônus pequeno de precisão.
- Cada jogador ganha 4 atributos: Velocidade, Passe, Chute, Marcação (goleiro: Reflexo). Vêm do overall + posição + evolução.

### 2. Tática de 3 eixos (comportamento visível dos 6 de linha)
| Eixo | Opções | Efeito em campo | Custo |
|---|---|---|---|
| Pressão | Baixa / Média / Alta | Raio e agressividade da marcação | Alta gasta mais fôlego |
| Linha | Recuada / Média / Adiantada | Posição da defesa e do time | Adiantada expõe contra-ataque |
| Construção | Toque curto / Bola longa / Contra-ataque | Escolha de passe da IA e velocidade da transição | Exige entrosamento |
- **Entrosamento (0–100)** por estilo: sobe com treino tático e jogos; baixo entrosamento causa erros de passe do time.
- **Plano B:** troca de tática no intervalo e gatilhos ("perdendo aos 2º tempo → pressão alta").

### 3. Adversários com identidade
Cada clube ganha estilo tático real (pressão, linha, construção) e pontos fracos. **Scouting** revela isso; escolher o contra certo dá vantagem real (pedra-papel-tesoura suave, nunca decisiva sozinha).

### 4. Treino semanal com consequência
- **Físico:** +fôlego máximo ao longo das semanas.
- **Técnico:** +Passe/Chute dos jogadores em foco.
- **Tático:** +entrosamento do estilo escolhido.
- **Recuperação:** energia e menos risco de lesão.
- **Folga:** moral.
- Sobrecarga (muito treino sem recuperação) aumenta lesões. Preparador físico (NPC) dá bônus.

### 5. Elenco vivo
Lesões (curtas e longas), suspensões, fadiga acumulada, rotação necessária. Jogadores evoluem por minutos jogados e treino; veteranos declinam. Peneira da base gera jovens; contratos têm prazo e salário.

### 6. Clube e diretoria
Metas de temporada (posição, título, lucro, revelar jogador). Confiança da diretoria sobe e desce; confiança baixa limita orçamento e pode encerrar a carreira. Patrocínios dependem de metas. Estádio e centro de treino viram melhorias de longo prazo com efeito real (recuperação, receita, moral da torcida).

### 7. Vila como interface (NPCs)
Treinador → tática e escalação · Preparador físico → agenda de treino · Empresário → mercado e contratos · Diretor → metas e finanças · Recepcionista → calendário e relatório · Funcionário → estádio e eventos. Eventos semanais com dilemas e consequências.

### 8. Assistente (simular partida)
"Simular" passa a usar os mesmos atributos, tática, entrosamento e scouting, para o resultado simulado ser coerente com o jogado.

## Fases de implementação (cada uma testada e entregue)
| Fase | Entrega | Prova de que funciona |
|---|---|---|
| 1 | Atributos de jogador + tática de 3 eixos ligados à partida jogável | Testes medindo diferença real (gols, posse, chutes, fôlego) entre táticas e entre times cansados/descansados |
| 2 | Agenda de treino, entrosamento, lesões e fadiga | Teste de 10 semanas mostrando evolução e risco |
| 3 | Estilo dos adversários + scouting | Contra certo vence mais em 100 simulações, sem ser decisivo |
| 4 | Diretoria, metas, economia e confiança | Temporada completa simulada com finais diferentes |
| 5 | Eventos semanais e papéis dos NPCs | Cada NPC abre uma decisão com efeito |
| 6 | Base, contratos e progressão de longo prazo | Várias temporadas sem quebrar o equilíbrio |
| 7 | Balanceamento, tutorial e testes completos | Bateria de regressão + métricas |

## Preservado e o que muda
- **Mantém:** partida jogável, pixel art, UI, Vila e NPCs, escalação FUT7, saves antigos continuam carregando (campos novos com valores padrão).
- **Muda (com sua liberação):** regras de competição, economia, treino/preparação, tática e progressão.


---
# Adições v2

## A. Mecânicas pedidas
- **Mapa clicável** no lugar da Vila andável: CT (treino), Sede (diretoria), Estádio, Empresário (mercado), Federação (campeonatos), Bar (eventos/imprensa). NPCs viram os rostos dos diálogos.
- **Expulsão:** sai da partida (time com um a menos) e cumpre 1 jogo de suspensão.
- **3 amarelos acumulados** em partidas diferentes = 1 jogo de suspensão; contador por jogador na temporada, zera ao cumprir.
- **Goleiro com a bola:** time se reposiciona nas posições livres, com limite de tempo, antes da reposição.
- **Bolas paradas** (escanteio, falta, pênalti) jogáveis; **lesão em jogo**; **torcida e moral**; **imprensa** (coletiva com escolhas). Depois: rivalidade, base/empréstimos, metas pessoais, clima, conquistas.

## B. Camada educacional (projeto acadêmico)
Princípio: **a matemática é a ferramenta para decidir melhor, não um quiz solto.** Cada conceito aparece onde o jogador já precisa decidir, e acertar dá vantagem pequena, nunca bloqueia o jogo.

| Área | Onde aparece no jogo | Conceitos |
|---|---|---|
| Estatística | Prancheta de dados: rendimento dos jogadores, gols por jogo | média, mediana, moda, desvio padrão, gráficos |
| Porcentagem e razão | Aproveitamento, posse, finalizações certas/total, bônus salariais | %, proporção, regra de três |
| Probabilidade | Chance de vitória no Desafio, pênaltis, risco de lesão | probabilidade, eventos independentes, valor esperado |
| Funções | Preço do ingresso × público (função afim), evolução do jogador no tempo | função afim, crescimento, gráfico |
| Finanças | Orçamento semanal, salários, patrocínio, financiamento do estádio | juros simples/compostos, fluxo de caixa, ponto de equilíbrio |
| Geometria e física | Bola parada: ângulo, distância e força; velocidade média do jogador | ângulos, trigonometria básica, parábola, velocidade |
| Combinatória/lógica | Tabela e mata-mata: "o que preciso para classificar?" | contagem, cenários, critérios de desempate |
| Otimização | Distribuir 4 turnos de treino e o orçamento com restrições | sistemas lineares, restrições, otimização simples |

### Desafios
- **Desafio do Diretor (semanal):** problema com os dados reais da carreira do próprio aluno (ex.: "o caixa é R$ X, o salário sobe 8%: quantas rodadas até o caixa zerar?"). Gerado proceduralmente, com números diferentes a cada vez.
- **Prancheta do Treinador:** ferramenta dentro do jogo (calculadora, gráficos, tabela) para o aluno resolver; mostra o raciocínio passo a passo na correção.
- **Bola parada como problema:** escolher ângulo/força vendo a trajetória; treino técnico libera mais precisão.
- **Recompensas:** bônus pequeno de caixa, moral ou entrosamento; errar mostra a explicação e dá nova tentativa. Nada trava a progressão.

### Progressão
- **Árvore de competências:** cada área acima tem níveis (Iniciante, Intermediário, Avançado); subir libera ferramentas (ex.: gráfico de desvio padrão) e desafios mais difíceis.
- **Níveis de dificuldade** escolhidos no início (ajustável): do ensino fundamental II ao médio, com opção superior.
- **Carreira em temporadas:** metas da diretoria viram currículo (ex.: "terminar entre os 4 primeiros usando análise de dados").

### Para o professor
- **Relatório de desempenho** exportável (CSV/JSON): acertos por área, tempo, tentativas.
- **Modo sala de aula:** seed fixa para todos os alunos receberem o mesmo cenário e compararem decisões.

## C. Fases revisadas
| Fase | Entrega |
|---|---|
| 1 | Atributos + tática de 3 eixos na partida; suspensão (vermelho e 3 amarelos); goleiro com reposicionamento |
| 2 | Mapa clicável; agenda de treino; entrosamento; lesões e fadiga |
| 3 | Adversários com estilo + scouting; bolas paradas |
| 4 | Prancheta de dados + Desafio do Diretor (estatística, %, probabilidade) |
| 5 | Diretoria, economia (funções, juros), torcida e imprensa |
| 6 | Árvore de competências, relatório do professor, modo sala de aula |
| 7 | Base, rivalidade, metas pessoais, clima, conquistas; balanceamento e testes finais |
