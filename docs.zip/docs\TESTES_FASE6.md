# Fase 6 — Matriz dos 23 testes obrigatórios

Rodar tudo: `GODOT=/caminho/godot bash tests/run_all.sh` (20 suítes, termina com FIM). Cada item abaixo indica onde é verificado.

| # | Teste | Suíte(s) que cobrem |
|---|-------|---------------------|
| 1 | Inicialização do jogo | teste_integracao, teste_etapa7 |
| 2 | Menu animado | teste_menu, teste_integracao |
| 3 | Nova carreira | teste_integracao (pelo botão do menu), teste_menu |
| 4 | Início do tutorial | teste_pausa, teste_integracao |
| 5 | Navegação entre etapas | teste_pausa, teste_integracao |
| 6 | Botão de voltar | teste_pausa, teste_integracao |
| 7 | Botão de pular | teste_pausa, teste_integracao |
| 8 | Conclusão do tutorial | teste_integracao (7 etapas até "Começar carreira") |
| 9 | Persistência no save | teste_pausa, teste_integracao |
| 10 | Carregamento de carreira antiga | teste_pausa, teste_integracao (save sem o campo) |
| 11 | Mapa animado | teste_mapa, teste_integracao |
| 12 | Hotspots | teste_mapa, teste_integracao |
| 13 | Entrada e saída de cada edifício | teste_integracao (8 edifícios), teste_telas |
| 14 | Vídeos internos | teste_telas, teste_integracao |
| 15 | Controles das telas | teste_telas, teste_prancheta, teste_fase2 |
| 16 | Dados dinâmicos | teste_integracao, teste_telas, teste_prancheta, teste_mapa |
| 17 | Salvar e carregar | teste_integracao, teste_mapa, teste_etapa7 |
| 18 | Partidas 11x11 | teste_integracao, teste_11x11, teste_etapa7, teste_formacoes_partida |
| 19 | Amistoso FUT7 | teste_integracao, teste_11x11, teste_etapa7 |
| 20 | Classificação | teste_integracao, teste_telas, teste_pausa (tabela do tutorial), teste_mapa |
| 21 | Calendário | teste_integracao, teste_etapa7 (temporada completa) |
| 22 | Resoluções | teste_integracao (8 telas × 5 resoluções), teste_telas, teste_mapa, teste_etapa7 |
| 23 | Desempenho e memória | teste_integracao (42 trocas de tela com vídeo: nós, órfãos, memória), teste_etapa7 (150 navegações, ms/frame), tests/img_desempenho.gd (render real) |

## Medições de render real (xvfb + OpenGL por software — CPU, sem GPU; pessimista)
Rodar: `xvfb-run -a -s "-screen 0 1280x720x24" godot --path . --rendering-driver opengl3 --resolution 1280x720 --script tests/img_desempenho.gd`
Memória estática 37–66 MB, memória de vídeo 20–37 MB. Tempo por frame só indica a ordem de grandeza: sem vídeo (Prancheta) já gasta 15 ms a 720p por causa do render por software.

## Correção encontrada na Fase 6
Ao abrir o jogo com um save existente, "Continuar" usava a carreira nova criada no boot e ignorava o save. Agora `GameState.carreira_ativa` distingue carreira iniciada/carregada na sessão do estado inicial do boot.
