# Atualização geral — Católica FC FUT7

Identidade: vermelho, creme e branco; amarelo para destaque/seleção.

| Etapa | Entrega |
|---|---|
| 1 | Diagnóstico |
| 2 | 8 NPCs animados na Vila + diálogos com dados reais (`Npc.gd`, `NpcDados.gd`, `Dialogo.gd`) |
| 3 | Tela inicial noturna com menu de 7 opções |
| 4 | Escalação FUT7 (7 titulares; 3-2-1, 2-3-1, 2-2-2, 3-1-2), compatível com saves antigos |
| 5 | Amistoso configurável (adversário/formação/dificuldade), HUD com minimapa, pausa (escalação, configurações, reiniciar), resultado |
| 6 | Federação padronizada (tabela, calendário "Jogos", artilharia, troféus), fim de temporada, desafio, preparação |
| 7 | Testes de navegação (5 tamanhos de janela), vazamento de nós, desempenho, fluxo de rodada, save/load, temporada completa |

## Testes (Godot 4.4.1, headless)
`teste_rapido`, `teste_regras`, `teste_temporada`, `teste_etapa2`, `teste_melhorias`, `teste_final`,
`teste_npcs`, `teste_menu`, `teste_escalacao`, `teste_formacoes_partida`, `teste_etapa5`, `teste_etapa6`, `teste_etapa7`.
Cenas de teste: `godot --headless --path . --fixed-fps 60 res://tests/<nome>.tscn`.

## Pendências conhecidas
- Validar no Godot 4.7.2 e em celular real (toque, orientação).
- Criar `export_presets.cfg` (Windows/Android) na sua máquina.
- Estádio e clima; 4 NPCs extras (empresário, preparador físico, recepcionista, funcionário).
- "Simular partida" ainda usa a escalação de 11 da gestão.

## Fase 1 da reconstrução (docs/GDD_RECONSTRUCAO.md)
- Tática de 3 eixos (pressão, linha, construção) que muda o comportamento dos jogadores em campo; esquemas prontos continuam.
- Energia, moral, forma recente e preparação passam a afetar a partida (velocidade, erro de passe/chute, precisão).
- Suspensões: vermelho = 1 jogo; 3 amarelos em partidas diferentes = 1 jogo (contador zera); 2º amarelo na mesma partida vira vermelho e não acumula. Valem na carreira e na simulação; amistoso ignora.
- Goleiro com a bola: time ocupa espaços livres (mín. 2 s, máx. ~5 s) e o adversário não invade a área.
- Tática pode ser mudada no intervalo/bola parada pelo menu de pausa.
- Medição (`tests/medir_taticas.gd`): 12 partidas por configuração; diferenças menores que ~0,6 gol são ruído.

## Fase 2 (Reconstrução) — Mapa, treino, entrosamento, lesões
- Mapa clicável (assets/gerado/mapa.png, scripts/Mapa.gd) substitui o mundo aberto; a Vila (NPCs) continua como local "VILA".
- Agenda de treino semanal (Treino.gd): 4 turnos (físico, técnico, tático, recuperação, folga) + jogador em foco; efeitos reais em físico, técnica, entrosamento, energia e moral; risco de lesão = 1,2%×(turnos intensos−1) + 0,07%×(70−energia) − 1,2%×recuperações.
- Entrosamento por estilo de construção afeta erro de passe; lesões em treino e em jogo (substituição automática); lesionado indisponível, conta a partir da rodada seguinte.
- Saves antigos carregam (novos campos com padrão). Testes: teste_fase2 (44 verificações), regressão completa e etapa7 sem falhas.

## 11x11 como modo principal + Fase 3 (parcial)
- Carreira em 11x11 (campo 3300x1950, câmera acompanha a bola, 5 substituições). FUT7 virou modo de diversão no Amistoso, com escolha do time.
- Fase 3: perfil tático e ponto fraco por clube, scouting em 2 níveis (R$ 300 cada, zera por rodada), bônus máx. +2,5 de overall ao jogar contra o ponto fraco. Save: campo `scouting` com padrão.
- Pendente da Fase 3: bolas paradas jogáveis (escanteio, falta, pênalti).

## Fase 3 — bolas paradas jogáveis
- Pênalti, escanteio e falta perigosa (3º final do campo) a favor da casa viram cobrança manual (estado BOLA_PARADA): setas movem a mira; pênalti/falta = segurar CHUTE para carregar força e soltar (força >92% tende a ir por cima); escanteio = CHUTE cruza, setas ←/→ mudam a profundidade na área. Jogadores se posicionam (área limpa no pênalti, barreira na falta, atacantes/zagueiros na área no escanteio).
- Piloto automático/IA e o time adversário continuam com a cobrança automática. Cursor de mira e barra de força no HUD. Teste: `teste_bolas_paradas`.

## Fase 4 — Prancheta de dados + Desafio do Diretor
- `scripts/educacao/Educacao.gd`: 15 geradores (5 áreas × 3 níveis escolares: Fundamental II, Médio, Superior) com dados reais da carreira: estatística (média, mediana, desvio padrão), porcentagem (aproveitamento, reajustes sucessivos, juros compostos), probabilidade (não perder, eventos independentes, valor esperado), finanças (bilheteria, fôlego do caixa, ponto de equilíbrio), funções (afim, preço × público, vértice da parábola). Semente por rodada/temporada/nível (+ `sala_seed` para o modo sala de aula).
- Desafio do Diretor (1 por rodada, opcional): 4 alternativas, dica, calculadora, passo a passo ao errar, nova tentativa. Acerto de primeira: R$ 5.000 + 2 de moral; na 2ª tentativa: R$ 2.500. Nada bloqueia a progressão.
- Prancheta do Treinador: gráfico de overall, média/mediana/moda/amplitude, desvio padrão liberado no nível Intermediário de Estatística, campanha (aproveitamento %, gols/jogo), árvore de competências e calculadora.
- Save: `nivel_escolar`, `competencias`, `desafio_estado`, `sala_seed`, `educacao_log` (todos com padrão). Testes: `teste_fase4`.

## Fase 5 — Diretoria, economia, torcida e imprensa
- `scripts/educacao/Gestao.gd`: demanda por preço (função afim: −1,8% de público por R$ 1 acima de R$ 25; receita = parábola com preço ótimo), dívida com juros compostos (3%/rodada, limite R$ 300 mil), 6 modelos de metas, coletivas e manchetes.
- Diretoria: 3 metas por temporada (sorteadas por temporada/sala), confiança sobe/desce com resultados, dívida e caixa negativo; meta cumprida paga R$ 15 mil e +4 de confiança; veredito no fim da temporada (renovação/elogios/ultimato, sem demissão).
- Torcida reage a resultado e preço (acima de R$ 45 irrita, até R$ 20 cresce). Bilheteria da simulação usa a mesma função de demanda.
- Imprensa: manchete do dia e coletiva pós-jogo (3 respostas com efeitos em moral, torcida e diretoria), uma por rodada.
- Telas: Finanças e Diretoria (Painel → botão), Coletiva (Resultado → botão). Save com campos novos e padrões. Teste: `teste_fase5`.

## Fase 6 — Árvore de competências, relatório do professor e sala de aula
- Árvore de competências (5 áreas × Iniciante/Intermediário/Avançado; 3 e 8 acertos de primeira): cada nível libera uma ferramenta (desvio padrão, quartis, variação % do caixa, projeção de pontos, valor esperado, simulador de quitação com PMT, tabela e equação da demanda, preço ótimo pelo vértice).
- Modo sala de aula (menu inicial → Professor · Sala de aula): o código da turma vira semente; mesmo código = mesmo elenco, calendário, metas e problemas. Nome do aluno e turma entram no relatório.
- Relatório do professor: resumo por área (acertos 1ª/2ª tentativa, erros, tempo médio), log de desafios (com tempo) e decisões por rodada (formação, tática, preço, scouting, dívida, caixa, resposta da coletiva). Exporta CSV (`;` + BOM para Excel) e JSON; no navegador baixa o arquivo, no desktop grava em Documentos.
- Problemas novos com dados reais: demanda do seu estádio e peso da dívida. Correção: a temporada agora entra na semente dos problemas. Teste: `teste_fase6`.

## Fase 7 — Base, rivalidade, metas pessoais, clima e conquistas
- **Clima** (`Extras.clima`, determinístico por sala/temporada/rodada): sol (60%), chuva (22%: público −12%, erros de passe +12% na partida) e calor (18%: cansaço +20%). Aparece na tela do Desafio e é enviado à partida.
- **Rivalidade**: um rival fixo por carreira (`rival_id`). Clássico: público +25%, torcida e diretoria ±3, manchete "CLÁSSICO!", histórico V/E/D (`h2h`).
- **Base e empréstimos** (tela `base`, botão no Painel): 3 jovens por temporada (overall 52–60, potencial até ~82), promoção ao elenco (limite 24); reservas podem ser emprestados por 6 rodadas (sem salário, indisponíveis, voltam com +1/+2 de overall); elenco mínimo 14.
- **Metas pessoais**: até 3 meias/atacantes com meta de gols na temporada; meta batida = +15 de moral e R$ 5.000.
- **Conquistas** (tela `conquistas`): 14 conquistas, R$ 3.000 cada, aviso na tela de Resultado.
- Salvamento compatível: todos os campos novos com valores padrão.
- Testes: `teste_fase7` (clima, rival, base, empréstimo, metas, conquistas, save/load, 8 temporadas simuladas em 4 salas, telas). Regressão: 20 suítes com 0 falhas + `teste_etapa7` (23 telas × 5 resoluções).

## Fase 8 — Verificações de polimento (sem mudança de código de jogo)
- **11x11 ao vivo** (`tests/balance_11.gd`, piloto automático, 9 jogos contra forças 57/68/80): 20 gols em 9 jogos (~2,2 por jogo; antes ~1). Meta atendida.
- **Economia**: um bot que não gasta nada termina 2 temporadas com R$ 1,3–3,4 mi (partindo de R$ 1 mi). Mantida: o jogador ativo gasta em preparação, estádio e dívida.
- **Toque nas bolas paradas**: a mira e a força usam as ações `esq/dir/cima/baixo/chute`, as mesmas que o joystick e o botão de chute do `TouchControles` já emitem; não precisou de código novo.
- Pendente: validar na Godot 4.7.2 e em celular real.

## Reformulação visual — Fase 1 (mapa)
Ver `docs/REFORMULACAO_VISUAL.md`. Mapa ilustrado com áreas clicáveis, hover, tabela e próximo jogo ao vivo, HUD, atalhos e fontes novas; `teste_mapa` e regressão (17 suítes) sem falhas.
