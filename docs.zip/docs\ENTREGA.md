# Checklist de entrega — item 4 (GitHub + GDD)

Preencha os links reais e confira cada um em uma aba anônima antes de enviar.

| Item | Link | Conferido |
|---|---|---|
| Repositório no GitHub (código-fonte + GDD + README) | [colar] | [ ] |
| Vídeo 1 | [colar] | [ ] |
| Vídeo 2 | [colar] | [ ] |
| Executável (Windows/Web) | [colar] | [ ] |

Conferir também: repositório **público** (ou professor com acesso), `docs/GDD.md` e `README.md` visíveis na página inicial, vídeos sem restrição de acesso (não listados ou públicos) e executável baixando e abrindo.
