# Reformulação visual — Católica FC

Objetivo: aparência de jogo comercial de gestão (cenários ilustrados, menus modernos), preservando todos os sistemas. Paleta: bordô, vermelho institucional, branco, creme e dourado. Tipografia: Barlow Condensed (títulos) e Roboto Condensed (textos).

| Fase | Entrega | Estado |
|---|---|---|
| 1 | Mapa ilustrado como centro de gestão e entrada da carreira | **Concluída** |
| 2 | Identidade visual global (tema, botões, painéis, cartões, fontes) | Pendente |
| 3 | Elenco, escalação e mercado | Pendente |
| 4 | Demais telas de gestão | Pendente |
| 5 | Animações e acabamento | Pendente |

## Fase 1 — Mapa e entrada da carreira
- `scripts/Mapa.gd` reescrito. A imagem `assets/ui/ref/mapa_ref.png` ocupa a tela inteira (proporção mantida em qualquer resolução; sobra preenchida em bordô).
- **Áreas clicáveis** reposicionadas sobre cada prédio (coordenadas da imagem 1280×720): Estádio (jogar rodada), Secretaria e Diretoria (painel), Campo de Treinamento, Mercado, Obras do Estádio, Campeonatos, Elenco (praça central); a Vila foi removida do jogo. Os ids `Local_*` e os destinos do SceneManager não mudaram.
- **Hover/seleção/foco:** brilho dourado sobre o prédio e cartão com informações ao vivo (também por teclado e controle).
- **Informações dinâmicas sem duplicar a imagem:** a tabela "pintada" na imagem era estática e ficaria desatualizada. Ela é coberta por um painel no mesmo estilo, com a classificação real (top 5, sempre incluindo a Católica) e o próximo jogo (adversário, mando, clima, clássico). Os nomes dos prédios que já estão na arte não são repetidos; só Elenco e Vila ganham rótulo, pois não existem na imagem.
- **Indicadores:** barra superior com temporada/rodada, caixa, torcida, diretoria e posição; botão JOGAR RODADA no estádio com o adversário; avisos (treino pendente, lesionados/suspensos, dívida ou caixa negativo).
- **Atalhos de gestão** sobre o estacionamento: Prancheta, Finanças, Base e Conquistas.
- **Entrada da carreira:** Novo jogo e Continuar levam ao mapa com um fade curto.
- **Fontes:** `scripts/ui/Fontes.gd` usa o Roboto variável (largura 75 = Roboto Condensed) e carrega a Barlow Condensed automaticamente se os arquivos `BarlowCondensed-SemiBold.ttf` e `BarlowCondensed-Bold.ttf` forem colocados em `assets/fonte/` (o download do Google Fonts não estava disponível no ambiente de desenvolvimento). Ver `assets/fonte/LEIA-ME.txt`.
- **Testes:** novo `tests/teste_mapa.gd` (dados ao vivo, cartões, avisos, 5 resoluções, navegação de todos os destinos e atalhos, salvar/carregar). Regressão: 17 suítes com 0 falhas. O teste de vazamento de nós passou a medir sempre na mesma tela, porque o mapa tem mais nós que as outras telas (128 → 128 após 150 trocas).
- Bug encontrado e corrigido durante os testes: rótulos liberados da tabela ao vivo permaneciam na lista de redimensionamento.

## Nova estrutura de experiência — Etapa 1 (pausa + tutorial)
- Esc / Start no mapa abre a pausa (Continuar, Salvar carreira, Configurações, Tutorial, Voltar ao menu principal; confirmação se houver progresso não salvo; a carreira não é apagada).
- Tutorial de 11 passos na primeira entrada de carreira nova (pulável, reabrível pela pausa ou pelo botão "?"); flag `tutorial_concluido` salva; saves antigos assumem concluído.
- Testes: tests/teste_pausa.tscn (23 verificações) + regressão completa (18 suítes, 0 falhas).

## Menu principal e mapa novos (artes dos vídeos enviados)
**Origem das artes.** As duas imagens estáticas não vieram como arquivo, mas os vídeos contêm as artes completas. Os quadros foram extraídos com ffmpeg (24 fps, 1280x720):
- `12883067-Animating_static_game_map_enviro…mp4` → mapa. Quadro 1 (sem nuvens) = `assets/ui/novo/mapa_catolica.png`.
- `83b5f470-Animating_flag_clouds_and_buttons…mp4` → menu. Quadro 120 = `assets/ui/novo/menu_catolica.png`.
- Quadros originais sem edição guardados em `assets/ui/novo/*_original_quadro.png`. O mapa antigo (`ref/mapa_ref.png`) foi mantido.

**Limpeza do que era variável.** No mapa, a barra de status ("Rodada 1/28 · Caixa …") e o botão PRANCHETA gravados foram removidos da estrada (texturas vizinhas clonadas) e redesenhados pelo Godot. No menu, os quatro botões gravados foram retirados e substituídos pelos botões do Godot. A tabela CAMPEONATO continua vazia na arte, e as linhas vêm de `Competicoes.ordenar_tabela`.

**Animações (todas discretas, sem tocar nos cliques).**
- Mapa (`assets/shaders/mapa_ambiente.gdshader`): árvores balançam, bandeirolas do estádio e dos postes oscilam, o guindaste ondula, e a torcida cintila. Nuvens (sprites extraídos do vídeo) atravessam o cenário. Os refletores pulsam.
- Menu (`assets/shaders/menu_ambiente.gdshader`): a bandeira ondula no mastro e o sol pulsa. Os refletores pulsam e brasas douradas sobem devagar.

**Fluxo.** Jogar = abre o mapa (retoma a carreira ou cria uma nova, com tutorial). Continuar carreira = mapa com a carreira da memória ou do save (desabilitado sem carreira). Nova carreira = pede confirmação se já existir uma. Configurações = toque, chute/passe, tela cheia, partida rápida, modo professor, créditos e apagar progresso. Sair = fecha o jogo.

## Fase 2 — Tutorial animado (7 etapas, vídeos e mascote)
- `TutorialMapa.gd` foi reescrito: 7 etapas com vídeos tocando (Mapa, Treinamento, Secretaria, Mercado, Obras, Classificação com o vídeo do mapa e Mapa final). Cada etapa tem painéis reais do Godot com dados da carreira, indicador "n DE 7", Anterior, Próximo, Pular e COMEÇAR CARREIRA.
- Os painéis cobrem só o que vinha gravado nos vídeos (cabeçalho, textos do balão, cartões com dados fictícios e botões). O cenário e o gatinho dos vídeos continuam animados.
- Vídeos convertidos para Ogg Theora 1280x720 sem áudio, com fade cruzado no fim para o loop: `assets/video/*.ogv`. Só um vídeo fica carregado por vez.
- Mascote recortado dos vídeos, com fundo transparente: `assets/ui/mascote/gatinho_neutro.png` e `gatinho_alegre.png` (solução temporária até o PNG original).
- Persistência: `tutorial_concluido` (salvo por carreira; saves antigos assumem concluído). Rever: menu de pausa (Esc) ou botão "?" do mapa.
- Classificação: usa o vídeo do mapa como fundo até chegar o vídeo próprio.

## Fase 3 — Mapa principal animado
- `Mapa.gd` usa `VideoFundo` com `assets/video/mapa_animado.ogv` (loop, sem áudio, 16:9, sem capturar cliques); quadro estático só como reserva.
- Hotspots reais do Godot por prédio, alinhados à área do vídeo; hover com destaque e cartão; classificação, rodada, adversário e HUD com dados reais da carreira.
- HUD/dock opacos cobrem a barra de status gravada no vídeo. Removidos shaders/nuvens/brilhos de código.
- Testes: teste_mapa (vídeo toca/avança/loop/alinhamento/5 resoluções), regressão completa 18 suítes sem falhas.

## Fase 4 — Telas internas com vídeo
- Novo componente `scripts/ui/TelaVideo.gd` (+ `scenes/telas/Tela*.tscn`): vídeo em loop (VideoFundo) + palco 1280x720 escalado + painéis reais do Godot.
- Telas: Treino (`treinamento.ogv`), Secretaria/Painel (`secretaria.ogv`), Mercado (`mercado.ogv`), Obras (`obras.ogv`), Classificação/Torneios (`mapa_animado.ogv`, provisório até chegar o vídeo próprio).
- As telas funcionais existentes (Treino.gd, Painel.gd, Mercado.gd, EstadioObras.gd, Torneios.gd) são hospedadas sem alterar regras; `SceneManager.CENAS` aponta para as cascas.
- Cobertura mínima: cabeçalho, balões/cartões com dados fictícios, botão "Voltar ao mapa" gravado. Gatinho do vídeo preservado; na Classificação o mascote PNG é colocado pelo Godot.
- Mascote com mensagem calculada de dados reais (energia/lesões, confiança da diretoria, caixa, capacidade, posição). Barra inferior: caixa, torcida, diretoria, posição.
- Teste: `tests/teste_telas.gd`.

## Fase 5 — Prancheta evoluída + mascote com poses
- `assets/ui/mascote/poses/` (13 PNGs transparentes recortados do modelo oficial) e `scripts/ui/Mascote.gd` (reutilizável; humor calculado de dados reais: caixa negativo, lesionados, diretoria, último resultado).
- `Prancheta.gd`: nova visão geral (assistente, próximo adversário, últimos resultados + gráfico de pontos, tarefas, objetivos da diretoria, alertas financeiros/notificações, atalhos, rever tutorial) acima das seções antigas (estatística, campanha, competências, calculadora), preservadas.
- "Rever tutorial": `SceneManager.tutorial_pendente` abre o tutorial no mapa sem alterar o progresso salvo.
- Mascote na Classificação usa a pose do humor atual. Teste: `tests/teste_prancheta.gd`.

## Jogabilidade — desarme, controles e árbitro (feedback das avaliações)
- Sem a bola: **K = desarme em pé** (rápido, baixo risco), **I = carrinho** (alcance maior, pune o erro), J = trocar jogador. Antes K era sempre carrinho.
- `Partida._resolver_desarme`: chance por desarme × drible, velocidade do driblador e ângulo; vir por trás aumenta o risco de falta (pé ~7%→12%; carrinho ~20%→53%). Carrinho em adversário sem a bola é falta quase certa. Errou: recuperação (0,22 s no pé, 0,5 s no carrinho).
- Controles: mira automática no portador quando você não aperta direção (ímã leve se já vai na direção dele); dica "K DESARMAR · I CARRINHO" aparece ao defender; tela COMANDOS e botões de toque (lob = carrinho) atualizados; feedback "DESARME!/ERROU!/BOLA!".
- Árbitro (`scripts/partida2/Arbitro.gd`): usa o sprite de jogador com uniforme amarelo, acompanha o lance a distância, vai até a falta, apita (som sintetizado), mostra cartão amarelo/vermelho e apita intervalo/fim. Só apresentação: não interfere na lógica.
- Número de jogadores: mantidos 11x11 e FUT7 (decisão do projeto). Teste: `tests/teste_jogabilidade.gd`.

## Refinamento da partida e tutorial (pós-avaliação)
- Partida: "coleira" tática por papel (DEF 230 / MEI 300 / ATA 360 px × escala) em torno da posição na formação, que acompanha a bola; só o marcador e a cobertura saem da zona. Distância média à bola: 397 → ~670 px (11x11) e 314 → ~410 px (FUT7).
- Cartões: gravidade por tipo de lance (desarme em pé leve ≈ sem vermelho; carrinho por trás é o lance grave). HUD mostra o nº de jogadores em campo quando os times diferem (expulsão).
- Tutorial: mascote de corpo inteiro (gato_grande_esq/dir) com sombra, fora dos cartões.

## Remoção da Vila e vídeos
- Vila do Clube removida (ponto no mapa, rota "vila", Hub.tscn/Hub.gd). O mapa em vídeo é o único cenário. Backup em /tmp/backup/vila.
- Vídeos: VideoFundo usa tamanho/posição inteiros e filtro linear; mapa, mercado e treinamento reencodados com suavização temporal e quadros-chave espaçados (originais guardados).

## Som de ambiente por área e créditos
- `scripts/autoload/Ambiente.gd`: um som por área em loop (assets/audio/area-*.ogg), fade de 0,35 s, sem sobreposição, só após o primeiro clique/toque/tecla, pausa em segundo plano; volume e mudo em Configurações, gravados em user://opcoes.cfg. Áudios extraídos dos vídeos com som enviados (mapa, secretaria, treino, mercado, obras); menu sem áudio (silêncio). Ver assets/audio/LEIA-ME.txt.
- Créditos: `Dialogo.abrir_creditos` (menu e fim de temporada) com "Equipe do projeto: Erik Pinheiro, Wesley Reis, Daniel Trindade".

## Torcida na partida e volumes
- `SomPartida.gd`: fundo de torcida sorteado (sem repetição), intensidade conforme perigo/minutos finais, reações a gol, chute, defesa, falta e fim; barramento "Partida" (inclui o apito do árbitro).
- Volumes: Geral (Master), Ambiente das áreas e Som da partida + Mudo, no menu Configurações e no menu de pausa da partida; gravados em user://opcoes.cfg.
- Menu: 3 sons sorteados/revezados (bola, pássaros, manhã). Árbitro: apito real em faltas, cartões, pênaltis, intervalo e fim.
- Partida: torcida-abertura no início; depois fundo contínuo sorteado com crossfade de 2,5 s até o fim.
